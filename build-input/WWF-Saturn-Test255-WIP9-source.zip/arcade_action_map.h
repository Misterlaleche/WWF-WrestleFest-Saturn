#ifndef WWF_ARCADE_ACTION_MAP_H
#define WWF_ARCADE_ACTION_MAP_H
#include <stdbool.h>
enum { ARCADE_ACTION_CHARACTERS=12, ARCADE_ACTION_CATEGORIES=21, ARCADE_ACTION_BUTTON_COMBOS=3 };
enum {
 ARCADE_ACTION_CATEGORY_STATIONARY=0x00,
 ARCADE_ACTION_CATEGORY_BEHIND=0x10,
 ARCADE_ACTION_CATEGORY_HELD_OBJECT=0x11,
 ARCADE_ACTION_CATEGORY_AGAINST_RUNNING=0x12
};
int arcade_action_for_buttons_internal(unsigned internal_character,unsigned category,unsigned fresh_buttons);
int arcade_action_for_buttons(unsigned selection_character,unsigned category,unsigned fresh_buttons);
int arcade_action_stationary(unsigned selection_character,unsigned fresh_buttons);
int arcade_action_behind(unsigned selection_character,unsigned fresh_buttons);
int arcade_action_against_running(unsigned selection_character,unsigned fresh_buttons);
bool arcade_behind_context_raw(int dx,int dy,int attacker_facing,int target_facing);
int arcade_behind_category_raw(unsigned attacker_34,unsigned attacker_21,unsigned attacker_af,
                               unsigned target_26_nonzero,unsigned target_21,unsigned target_65,
                               int dx,int dy,int attacker_facing,int target_facing);
bool arcade_ground_button2_selects_pin(unsigned selection_character,unsigned category);
/* Test75: exact raw classifier for ROM $E0B8/$E110 prone-action categories.
 * Fields are named by actor-structure offsets until their full semantics are proven. */
int arcade_prone_category_raw(unsigned attacker_34,unsigned attacker_21,
                              unsigned target_26_nonzero,unsigned target_21,
                              unsigned target_65,unsigned target_70);
int arcade_prone_action_raw(unsigned selection_character,unsigned fresh_buttons,
                            unsigned attacker_34,unsigned attacker_21,
                            unsigned target_26_nonzero,unsigned target_21,
                            unsigned target_65,unsigned target_70);

/* Test79: exact category $08 predicate at ROM $E180..$E1AC.
 * The attacker must already be linked through +$26 and be in raw state $0B.
 * On success the arcade sets bit6 of target +$44 before returning category $08. */
int arcade_pair_category8_raw(unsigned attacker_26_nonzero,unsigned attacker_21,
                              unsigned attacker_44,unsigned target_44,
                              unsigned *target_44_after);

/* Test80: exact category $09 predicate at ROM $E1B0..$E1D0. */
int arcade_pair_category9_raw(unsigned attacker_26_nonzero,unsigned attacker_21,
                              unsigned attacker_45,unsigned attacker_44,
                              unsigned *attacker_44_after);

#endif
