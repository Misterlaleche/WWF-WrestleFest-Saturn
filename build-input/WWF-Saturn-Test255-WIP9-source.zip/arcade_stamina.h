#ifndef WWF_ARCADE_STAMINA_H
#define WWF_ARCADE_STAMINA_H
#include <stdint.h>
#include <stdbool.h>

enum { ARCADE_STAMINA_RECOVERY_TICKS=128, ARCADE_STAMINA_LOW=24, ARCADE_RUMBLE_CPU_STAMINA=135 };
/* Test134: stationary Punch action $00 callback writes exact +$68=3 on hit. */
enum { ARCADE_STATIONARY_PUNCH_DAMAGE=3 };
enum { ARCADE_DIFFICULTY_NORMAL, ARCADE_DIFFICULTY_EASY, ARCADE_DIFFICULTY_HARD, ARCADE_DIFFICULTY_HARDEST };

/* WrestleFest program ROM $64cc: selection slot -> internal actor id. */
unsigned arcade_stamina_internal_id(unsigned character);
/* Program ROM $10830 combined with the $64cc selection map. */
unsigned arcade_stamina_human_max(unsigned character);
/* Program ROM $24ec2: 0=healthy, 1=weakened, 2=critical. */
unsigned arcade_stamina_tier(unsigned stamina,unsigned maximum);
/* Program ROM $107c8/$10848/$1085c.  The stage/difficulty inputs are kept
 * explicit until the native tournament progression is mapped completely. */
unsigned arcade_stamina_cpu_max(unsigned stage_index,bool secondary_slot,unsigned difficulty_index);
/* MAME/manual raw DIP encoding is Easy=2, Normal=3, Hard=1, Hardest=0.
 * The game stores an inverted copy in $1C0066, producing indices 1,0,2,3. */
unsigned arcade_difficulty_from_raw_dip(unsigned raw_bits);
/* Program ROM $1E1E-$1E6A packs the four operator input words into
 * $1C0066 and then inverts the complete 16-bit value. Difficulty occupies
 * packed bits 8-9 and comes specifically from raw $140022 bits 8-9. */
uint16_t arcade_operator_pack_config(uint16_t port20,uint16_t port22,uint16_t port24,uint16_t port26);
unsigned arcade_difficulty_from_config(uint16_t config_word);
/* Program ROM $90d6/$912a clear-stage stamina restore. Manual DIP 2:5-6
 * labels the four values 24/32/12/0 as CLEAR STAGE POWER UP. */
unsigned arcade_clear_stage_restore(unsigned setting);
bool arcade_stamina_low_warning(unsigned stamina);
/* Exact original natural-recovery state predicate from program ROM $8ECC.
 * state_code is fighter +$1D; linked_state_code is +$1D of +$26 owner when
 * state_code == $FF; pose_code is fighter +$61. */
bool arcade_stamina_recovery_state_allows(bool actor_active,unsigned state_code,unsigned linked_state_code,unsigned pose_code);

#endif
