#ifndef WWF_STRUGGLE_PAIR_ASSETS_H
#define WWF_STRUGGLE_PAIR_ASSETS_H
#include "finisher_assets.h"
#define STRUGGLE_PAIR_OVERLAY_MAX_BYTES 17259U
static const unsigned struggle_pair_bytes[10][10]={{0,15533,14908,15315,14719,14805,15403,14516,16290,15094},{15328,0,15769,16182,15601,15694,16282,15356,17104,15958},{15089,16056,0,14968,14822,14926,15040,14151,15912,14257},{15143,16052,14567,0,14901,14993,14834,14200,15800,14806},{14614,15825,14622,15071,0,13612,15135,14188,16043,14820},{14729,15946,14707,15155,13629,0,15226,14312,16115,14922},{15220,16127,14673,14849,14951,15043,0,14246,15897,14897},{14506,15370,13914,14342,14225,14319,14444,0,15268,14089},{16308,17259,15782,16068,16049,16126,16163,15364,0,15965},{15142,16039,14098,14983,14832,14952,15096,14134,15905,0}};
static const unsigned struggle_pair_hash[10][10]={{0U,2651029062U,2083345838U,413702221U,2603705936U,3525217942U,807297086U,3956440354U,1435240660U,3997613792U},{2223184826U,0U,775865972U,2840437488U,3656776U,3310842104U,401949658U,3594429098U,2797403726U,2104031299U},{1917655217U,3590851905U,0U,1028401889U,83169354U,2093431035U,3003722509U,980685507U,2723897743U,2538160382U},{3886211098U,2497154328U,730293625U,0U,2163408823U,1344064029U,139249643U,4161216577U,3338404381U,323392829U},{3391288490U,1189810264U,3631719503U,202612624U,0U,4054251360U,122168828U,2781510562U,2434088686U,337778652U},{4246390305U,359000436U,2534769129U,3838132304U,2395507577U,0U,3903224782U,1401921463U,4178341794U,420271590U},{654121991U,4228135422U,190436729U,286971022U,692020860U,2087566909U,0U,2470268594U,945882871U,1613372356U},{3380163595U,168864060U,1341860258U,1485367254U,1362700588U,3244361979U,3365744980U,0U,2707361755U,516998826U},{2719265496U,3310477232U,3704297720U,169203458U,2148899654U,4171403954U,2583688927U,986846025U,0U,737017498U},{1330888451U,3287291894U,167117327U,2944234793U,903776961U,3107535960U,361746667U,2758679624U,957703762U,0U}};
static const unsigned struggle_pair_frames[10][10]={{0,4,4,4,4,4,4,4,4,4},{4,0,4,4,4,4,4,4,4,4},{4,4,0,4,4,4,4,4,4,4},{4,4,4,0,4,4,4,4,4,4},{4,4,4,4,0,4,4,4,4,4},{4,4,4,4,4,0,4,4,4,4},{4,4,4,4,4,4,0,4,4,4},{4,4,4,4,4,4,4,0,4,4},{4,4,4,4,4,4,4,4,0,4},{4,4,4,4,4,4,4,4,4,0}};
static inline unsigned struggle_pair_asset_frame(unsigned a,unsigned p,unsigned pose){
 if(a==0U&&p==1U&&pose==245U)return 0U;
 if(a==0U&&p==1U&&pose==246U)return 1U;
 if(a==0U&&p==1U&&pose==247U)return 2U;
 if(a==0U&&p==1U&&pose==466U)return 3U;
 if(a==0U&&p==2U&&pose==245U)return 0U;
 if(a==0U&&p==2U&&pose==246U)return 1U;
 if(a==0U&&p==2U&&pose==247U)return 2U;
 if(a==0U&&p==2U&&pose==466U)return 3U;
 if(a==0U&&p==3U&&pose==245U)return 0U;
 if(a==0U&&p==3U&&pose==246U)return 1U;
 if(a==0U&&p==3U&&pose==247U)return 2U;
 if(a==0U&&p==3U&&pose==466U)return 3U;
 if(a==0U&&p==4U&&pose==245U)return 0U;
 if(a==0U&&p==4U&&pose==246U)return 1U;
 if(a==0U&&p==4U&&pose==247U)return 2U;
 if(a==0U&&p==4U&&pose==466U)return 3U;
 if(a==0U&&p==5U&&pose==245U)return 0U;
 if(a==0U&&p==5U&&pose==246U)return 1U;
 if(a==0U&&p==5U&&pose==247U)return 2U;
 if(a==0U&&p==5U&&pose==466U)return 3U;
 if(a==0U&&p==6U&&pose==245U)return 0U;
 if(a==0U&&p==6U&&pose==246U)return 1U;
 if(a==0U&&p==6U&&pose==247U)return 2U;
 if(a==0U&&p==6U&&pose==466U)return 3U;
 if(a==0U&&p==7U&&pose==245U)return 0U;
 if(a==0U&&p==7U&&pose==246U)return 1U;
 if(a==0U&&p==7U&&pose==247U)return 2U;
 if(a==0U&&p==7U&&pose==466U)return 3U;
 if(a==0U&&p==8U&&pose==245U)return 0U;
 if(a==0U&&p==8U&&pose==246U)return 1U;
 if(a==0U&&p==8U&&pose==247U)return 2U;
 if(a==0U&&p==8U&&pose==466U)return 3U;
 if(a==0U&&p==9U&&pose==245U)return 0U;
 if(a==0U&&p==9U&&pose==246U)return 1U;
 if(a==0U&&p==9U&&pose==247U)return 2U;
 if(a==0U&&p==9U&&pose==466U)return 3U;
 if(a==1U&&p==0U&&pose==245U)return 0U;
 if(a==1U&&p==0U&&pose==246U)return 1U;
 if(a==1U&&p==0U&&pose==247U)return 2U;
 if(a==1U&&p==0U&&pose==466U)return 3U;
 if(a==1U&&p==2U&&pose==245U)return 0U;
 if(a==1U&&p==2U&&pose==246U)return 1U;
 if(a==1U&&p==2U&&pose==247U)return 2U;
 if(a==1U&&p==2U&&pose==466U)return 3U;
 if(a==1U&&p==3U&&pose==245U)return 0U;
 if(a==1U&&p==3U&&pose==246U)return 1U;
 if(a==1U&&p==3U&&pose==247U)return 2U;
 if(a==1U&&p==3U&&pose==466U)return 3U;
 if(a==1U&&p==4U&&pose==245U)return 0U;
 if(a==1U&&p==4U&&pose==246U)return 1U;
 if(a==1U&&p==4U&&pose==247U)return 2U;
 if(a==1U&&p==4U&&pose==466U)return 3U;
 if(a==1U&&p==5U&&pose==245U)return 0U;
 if(a==1U&&p==5U&&pose==246U)return 1U;
 if(a==1U&&p==5U&&pose==247U)return 2U;
 if(a==1U&&p==5U&&pose==466U)return 3U;
 if(a==1U&&p==6U&&pose==245U)return 0U;
 if(a==1U&&p==6U&&pose==246U)return 1U;
 if(a==1U&&p==6U&&pose==247U)return 2U;
 if(a==1U&&p==6U&&pose==466U)return 3U;
 if(a==1U&&p==7U&&pose==245U)return 0U;
 if(a==1U&&p==7U&&pose==246U)return 1U;
 if(a==1U&&p==7U&&pose==247U)return 2U;
 if(a==1U&&p==7U&&pose==466U)return 3U;
 if(a==1U&&p==8U&&pose==245U)return 0U;
 if(a==1U&&p==8U&&pose==246U)return 1U;
 if(a==1U&&p==8U&&pose==247U)return 2U;
 if(a==1U&&p==8U&&pose==466U)return 3U;
 if(a==1U&&p==9U&&pose==245U)return 0U;
 if(a==1U&&p==9U&&pose==246U)return 1U;
 if(a==1U&&p==9U&&pose==247U)return 2U;
 if(a==1U&&p==9U&&pose==466U)return 3U;
 if(a==2U&&p==0U&&pose==245U)return 0U;
 if(a==2U&&p==0U&&pose==246U)return 1U;
 if(a==2U&&p==0U&&pose==247U)return 2U;
 if(a==2U&&p==0U&&pose==466U)return 3U;
 if(a==2U&&p==1U&&pose==245U)return 0U;
 if(a==2U&&p==1U&&pose==246U)return 1U;
 if(a==2U&&p==1U&&pose==247U)return 2U;
 if(a==2U&&p==1U&&pose==466U)return 3U;
 if(a==2U&&p==3U&&pose==245U)return 0U;
 if(a==2U&&p==3U&&pose==246U)return 1U;
 if(a==2U&&p==3U&&pose==247U)return 2U;
 if(a==2U&&p==3U&&pose==466U)return 3U;
 if(a==2U&&p==4U&&pose==245U)return 0U;
 if(a==2U&&p==4U&&pose==246U)return 1U;
 if(a==2U&&p==4U&&pose==247U)return 2U;
 if(a==2U&&p==4U&&pose==466U)return 3U;
 if(a==2U&&p==5U&&pose==245U)return 0U;
 if(a==2U&&p==5U&&pose==246U)return 1U;
 if(a==2U&&p==5U&&pose==247U)return 2U;
 if(a==2U&&p==5U&&pose==466U)return 3U;
 if(a==2U&&p==6U&&pose==245U)return 0U;
 if(a==2U&&p==6U&&pose==246U)return 1U;
 if(a==2U&&p==6U&&pose==247U)return 2U;
 if(a==2U&&p==6U&&pose==466U)return 3U;
 if(a==2U&&p==7U&&pose==245U)return 0U;
 if(a==2U&&p==7U&&pose==246U)return 1U;
 if(a==2U&&p==7U&&pose==247U)return 2U;
 if(a==2U&&p==7U&&pose==466U)return 3U;
 if(a==2U&&p==8U&&pose==245U)return 0U;
 if(a==2U&&p==8U&&pose==246U)return 1U;
 if(a==2U&&p==8U&&pose==247U)return 2U;
 if(a==2U&&p==8U&&pose==466U)return 3U;
 if(a==2U&&p==9U&&pose==245U)return 0U;
 if(a==2U&&p==9U&&pose==246U)return 1U;
 if(a==2U&&p==9U&&pose==247U)return 2U;
 if(a==2U&&p==9U&&pose==466U)return 3U;
 if(a==3U&&p==0U&&pose==245U)return 0U;
 if(a==3U&&p==0U&&pose==246U)return 1U;
 if(a==3U&&p==0U&&pose==247U)return 2U;
 if(a==3U&&p==0U&&pose==466U)return 3U;
 if(a==3U&&p==1U&&pose==245U)return 0U;
 if(a==3U&&p==1U&&pose==246U)return 1U;
 if(a==3U&&p==1U&&pose==247U)return 2U;
 if(a==3U&&p==1U&&pose==466U)return 3U;
 if(a==3U&&p==2U&&pose==245U)return 0U;
 if(a==3U&&p==2U&&pose==246U)return 1U;
 if(a==3U&&p==2U&&pose==247U)return 2U;
 if(a==3U&&p==2U&&pose==466U)return 3U;
 if(a==3U&&p==4U&&pose==245U)return 0U;
 if(a==3U&&p==4U&&pose==246U)return 1U;
 if(a==3U&&p==4U&&pose==247U)return 2U;
 if(a==3U&&p==4U&&pose==466U)return 3U;
 if(a==3U&&p==5U&&pose==245U)return 0U;
 if(a==3U&&p==5U&&pose==246U)return 1U;
 if(a==3U&&p==5U&&pose==247U)return 2U;
 if(a==3U&&p==5U&&pose==466U)return 3U;
 if(a==3U&&p==6U&&pose==245U)return 0U;
 if(a==3U&&p==6U&&pose==246U)return 1U;
 if(a==3U&&p==6U&&pose==247U)return 2U;
 if(a==3U&&p==6U&&pose==466U)return 3U;
 if(a==3U&&p==7U&&pose==245U)return 0U;
 if(a==3U&&p==7U&&pose==246U)return 1U;
 if(a==3U&&p==7U&&pose==247U)return 2U;
 if(a==3U&&p==7U&&pose==466U)return 3U;
 if(a==3U&&p==8U&&pose==245U)return 0U;
 if(a==3U&&p==8U&&pose==246U)return 1U;
 if(a==3U&&p==8U&&pose==247U)return 2U;
 if(a==3U&&p==8U&&pose==466U)return 3U;
 if(a==3U&&p==9U&&pose==245U)return 0U;
 if(a==3U&&p==9U&&pose==246U)return 1U;
 if(a==3U&&p==9U&&pose==247U)return 2U;
 if(a==3U&&p==9U&&pose==466U)return 3U;
 if(a==4U&&p==0U&&pose==245U)return 0U;
 if(a==4U&&p==0U&&pose==246U)return 1U;
 if(a==4U&&p==0U&&pose==247U)return 2U;
 if(a==4U&&p==0U&&pose==466U)return 3U;
 if(a==4U&&p==1U&&pose==245U)return 0U;
 if(a==4U&&p==1U&&pose==246U)return 1U;
 if(a==4U&&p==1U&&pose==247U)return 2U;
 if(a==4U&&p==1U&&pose==466U)return 3U;
 if(a==4U&&p==2U&&pose==245U)return 0U;
 if(a==4U&&p==2U&&pose==246U)return 1U;
 if(a==4U&&p==2U&&pose==247U)return 2U;
 if(a==4U&&p==2U&&pose==466U)return 3U;
 if(a==4U&&p==3U&&pose==245U)return 0U;
 if(a==4U&&p==3U&&pose==246U)return 1U;
 if(a==4U&&p==3U&&pose==247U)return 2U;
 if(a==4U&&p==3U&&pose==466U)return 3U;
 if(a==4U&&p==5U&&pose==245U)return 0U;
 if(a==4U&&p==5U&&pose==246U)return 1U;
 if(a==4U&&p==5U&&pose==247U)return 2U;
 if(a==4U&&p==5U&&pose==466U)return 3U;
 if(a==4U&&p==6U&&pose==245U)return 0U;
 if(a==4U&&p==6U&&pose==246U)return 1U;
 if(a==4U&&p==6U&&pose==247U)return 2U;
 if(a==4U&&p==6U&&pose==466U)return 3U;
 if(a==4U&&p==7U&&pose==245U)return 0U;
 if(a==4U&&p==7U&&pose==246U)return 1U;
 if(a==4U&&p==7U&&pose==247U)return 2U;
 if(a==4U&&p==7U&&pose==466U)return 3U;
 if(a==4U&&p==8U&&pose==245U)return 0U;
 if(a==4U&&p==8U&&pose==246U)return 1U;
 if(a==4U&&p==8U&&pose==247U)return 2U;
 if(a==4U&&p==8U&&pose==466U)return 3U;
 if(a==4U&&p==9U&&pose==245U)return 0U;
 if(a==4U&&p==9U&&pose==246U)return 1U;
 if(a==4U&&p==9U&&pose==247U)return 2U;
 if(a==4U&&p==9U&&pose==466U)return 3U;
 if(a==5U&&p==0U&&pose==245U)return 0U;
 if(a==5U&&p==0U&&pose==246U)return 1U;
 if(a==5U&&p==0U&&pose==247U)return 2U;
 if(a==5U&&p==0U&&pose==466U)return 3U;
 if(a==5U&&p==1U&&pose==245U)return 0U;
 if(a==5U&&p==1U&&pose==246U)return 1U;
 if(a==5U&&p==1U&&pose==247U)return 2U;
 if(a==5U&&p==1U&&pose==466U)return 3U;
 if(a==5U&&p==2U&&pose==245U)return 0U;
 if(a==5U&&p==2U&&pose==246U)return 1U;
 if(a==5U&&p==2U&&pose==247U)return 2U;
 if(a==5U&&p==2U&&pose==466U)return 3U;
 if(a==5U&&p==3U&&pose==245U)return 0U;
 if(a==5U&&p==3U&&pose==246U)return 1U;
 if(a==5U&&p==3U&&pose==247U)return 2U;
 if(a==5U&&p==3U&&pose==466U)return 3U;
 if(a==5U&&p==4U&&pose==245U)return 0U;
 if(a==5U&&p==4U&&pose==246U)return 1U;
 if(a==5U&&p==4U&&pose==247U)return 2U;
 if(a==5U&&p==4U&&pose==466U)return 3U;
 if(a==5U&&p==6U&&pose==245U)return 0U;
 if(a==5U&&p==6U&&pose==246U)return 1U;
 if(a==5U&&p==6U&&pose==247U)return 2U;
 if(a==5U&&p==6U&&pose==466U)return 3U;
 if(a==5U&&p==7U&&pose==245U)return 0U;
 if(a==5U&&p==7U&&pose==246U)return 1U;
 if(a==5U&&p==7U&&pose==247U)return 2U;
 if(a==5U&&p==7U&&pose==466U)return 3U;
 if(a==5U&&p==8U&&pose==245U)return 0U;
 if(a==5U&&p==8U&&pose==246U)return 1U;
 if(a==5U&&p==8U&&pose==247U)return 2U;
 if(a==5U&&p==8U&&pose==466U)return 3U;
 if(a==5U&&p==9U&&pose==245U)return 0U;
 if(a==5U&&p==9U&&pose==246U)return 1U;
 if(a==5U&&p==9U&&pose==247U)return 2U;
 if(a==5U&&p==9U&&pose==466U)return 3U;
 if(a==6U&&p==0U&&pose==245U)return 0U;
 if(a==6U&&p==0U&&pose==246U)return 1U;
 if(a==6U&&p==0U&&pose==247U)return 2U;
 if(a==6U&&p==0U&&pose==466U)return 3U;
 if(a==6U&&p==1U&&pose==245U)return 0U;
 if(a==6U&&p==1U&&pose==246U)return 1U;
 if(a==6U&&p==1U&&pose==247U)return 2U;
 if(a==6U&&p==1U&&pose==466U)return 3U;
 if(a==6U&&p==2U&&pose==245U)return 0U;
 if(a==6U&&p==2U&&pose==246U)return 1U;
 if(a==6U&&p==2U&&pose==247U)return 2U;
 if(a==6U&&p==2U&&pose==466U)return 3U;
 if(a==6U&&p==3U&&pose==245U)return 0U;
 if(a==6U&&p==3U&&pose==246U)return 1U;
 if(a==6U&&p==3U&&pose==247U)return 2U;
 if(a==6U&&p==3U&&pose==466U)return 3U;
 if(a==6U&&p==4U&&pose==245U)return 0U;
 if(a==6U&&p==4U&&pose==246U)return 1U;
 if(a==6U&&p==4U&&pose==247U)return 2U;
 if(a==6U&&p==4U&&pose==466U)return 3U;
 if(a==6U&&p==5U&&pose==245U)return 0U;
 if(a==6U&&p==5U&&pose==246U)return 1U;
 if(a==6U&&p==5U&&pose==247U)return 2U;
 if(a==6U&&p==5U&&pose==466U)return 3U;
 if(a==6U&&p==7U&&pose==245U)return 0U;
 if(a==6U&&p==7U&&pose==246U)return 1U;
 if(a==6U&&p==7U&&pose==247U)return 2U;
 if(a==6U&&p==7U&&pose==466U)return 3U;
 if(a==6U&&p==8U&&pose==245U)return 0U;
 if(a==6U&&p==8U&&pose==246U)return 1U;
 if(a==6U&&p==8U&&pose==247U)return 2U;
 if(a==6U&&p==8U&&pose==466U)return 3U;
 if(a==6U&&p==9U&&pose==245U)return 0U;
 if(a==6U&&p==9U&&pose==246U)return 1U;
 if(a==6U&&p==9U&&pose==247U)return 2U;
 if(a==6U&&p==9U&&pose==466U)return 3U;
 if(a==7U&&p==0U&&pose==245U)return 0U;
 if(a==7U&&p==0U&&pose==246U)return 1U;
 if(a==7U&&p==0U&&pose==247U)return 2U;
 if(a==7U&&p==0U&&pose==466U)return 3U;
 if(a==7U&&p==1U&&pose==245U)return 0U;
 if(a==7U&&p==1U&&pose==246U)return 1U;
 if(a==7U&&p==1U&&pose==247U)return 2U;
 if(a==7U&&p==1U&&pose==466U)return 3U;
 if(a==7U&&p==2U&&pose==245U)return 0U;
 if(a==7U&&p==2U&&pose==246U)return 1U;
 if(a==7U&&p==2U&&pose==247U)return 2U;
 if(a==7U&&p==2U&&pose==466U)return 3U;
 if(a==7U&&p==3U&&pose==245U)return 0U;
 if(a==7U&&p==3U&&pose==246U)return 1U;
 if(a==7U&&p==3U&&pose==247U)return 2U;
 if(a==7U&&p==3U&&pose==466U)return 3U;
 if(a==7U&&p==4U&&pose==245U)return 0U;
 if(a==7U&&p==4U&&pose==246U)return 1U;
 if(a==7U&&p==4U&&pose==247U)return 2U;
 if(a==7U&&p==4U&&pose==466U)return 3U;
 if(a==7U&&p==5U&&pose==245U)return 0U;
 if(a==7U&&p==5U&&pose==246U)return 1U;
 if(a==7U&&p==5U&&pose==247U)return 2U;
 if(a==7U&&p==5U&&pose==466U)return 3U;
 if(a==7U&&p==6U&&pose==245U)return 0U;
 if(a==7U&&p==6U&&pose==246U)return 1U;
 if(a==7U&&p==6U&&pose==247U)return 2U;
 if(a==7U&&p==6U&&pose==466U)return 3U;
 if(a==7U&&p==8U&&pose==245U)return 0U;
 if(a==7U&&p==8U&&pose==246U)return 1U;
 if(a==7U&&p==8U&&pose==247U)return 2U;
 if(a==7U&&p==8U&&pose==466U)return 3U;
 if(a==7U&&p==9U&&pose==245U)return 0U;
 if(a==7U&&p==9U&&pose==246U)return 1U;
 if(a==7U&&p==9U&&pose==247U)return 2U;
 if(a==7U&&p==9U&&pose==466U)return 3U;
 if(a==8U&&p==0U&&pose==245U)return 0U;
 if(a==8U&&p==0U&&pose==246U)return 1U;
 if(a==8U&&p==0U&&pose==247U)return 2U;
 if(a==8U&&p==0U&&pose==466U)return 3U;
 if(a==8U&&p==1U&&pose==245U)return 0U;
 if(a==8U&&p==1U&&pose==246U)return 1U;
 if(a==8U&&p==1U&&pose==247U)return 2U;
 if(a==8U&&p==1U&&pose==466U)return 3U;
 if(a==8U&&p==2U&&pose==245U)return 0U;
 if(a==8U&&p==2U&&pose==246U)return 1U;
 if(a==8U&&p==2U&&pose==247U)return 2U;
 if(a==8U&&p==2U&&pose==466U)return 3U;
 if(a==8U&&p==3U&&pose==245U)return 0U;
 if(a==8U&&p==3U&&pose==246U)return 1U;
 if(a==8U&&p==3U&&pose==247U)return 2U;
 if(a==8U&&p==3U&&pose==466U)return 3U;
 if(a==8U&&p==4U&&pose==245U)return 0U;
 if(a==8U&&p==4U&&pose==246U)return 1U;
 if(a==8U&&p==4U&&pose==247U)return 2U;
 if(a==8U&&p==4U&&pose==466U)return 3U;
 if(a==8U&&p==5U&&pose==245U)return 0U;
 if(a==8U&&p==5U&&pose==246U)return 1U;
 if(a==8U&&p==5U&&pose==247U)return 2U;
 if(a==8U&&p==5U&&pose==466U)return 3U;
 if(a==8U&&p==6U&&pose==245U)return 0U;
 if(a==8U&&p==6U&&pose==246U)return 1U;
 if(a==8U&&p==6U&&pose==247U)return 2U;
 if(a==8U&&p==6U&&pose==466U)return 3U;
 if(a==8U&&p==7U&&pose==245U)return 0U;
 if(a==8U&&p==7U&&pose==246U)return 1U;
 if(a==8U&&p==7U&&pose==247U)return 2U;
 if(a==8U&&p==7U&&pose==466U)return 3U;
 if(a==8U&&p==9U&&pose==245U)return 0U;
 if(a==8U&&p==9U&&pose==246U)return 1U;
 if(a==8U&&p==9U&&pose==247U)return 2U;
 if(a==8U&&p==9U&&pose==466U)return 3U;
 if(a==9U&&p==0U&&pose==245U)return 0U;
 if(a==9U&&p==0U&&pose==246U)return 1U;
 if(a==9U&&p==0U&&pose==247U)return 2U;
 if(a==9U&&p==0U&&pose==466U)return 3U;
 if(a==9U&&p==1U&&pose==245U)return 0U;
 if(a==9U&&p==1U&&pose==246U)return 1U;
 if(a==9U&&p==1U&&pose==247U)return 2U;
 if(a==9U&&p==1U&&pose==466U)return 3U;
 if(a==9U&&p==2U&&pose==245U)return 0U;
 if(a==9U&&p==2U&&pose==246U)return 1U;
 if(a==9U&&p==2U&&pose==247U)return 2U;
 if(a==9U&&p==2U&&pose==466U)return 3U;
 if(a==9U&&p==3U&&pose==245U)return 0U;
 if(a==9U&&p==3U&&pose==246U)return 1U;
 if(a==9U&&p==3U&&pose==247U)return 2U;
 if(a==9U&&p==3U&&pose==466U)return 3U;
 if(a==9U&&p==4U&&pose==245U)return 0U;
 if(a==9U&&p==4U&&pose==246U)return 1U;
 if(a==9U&&p==4U&&pose==247U)return 2U;
 if(a==9U&&p==4U&&pose==466U)return 3U;
 if(a==9U&&p==5U&&pose==245U)return 0U;
 if(a==9U&&p==5U&&pose==246U)return 1U;
 if(a==9U&&p==5U&&pose==247U)return 2U;
 if(a==9U&&p==5U&&pose==466U)return 3U;
 if(a==9U&&p==6U&&pose==245U)return 0U;
 if(a==9U&&p==6U&&pose==246U)return 1U;
 if(a==9U&&p==6U&&pose==247U)return 2U;
 if(a==9U&&p==6U&&pose==466U)return 3U;
 if(a==9U&&p==7U&&pose==245U)return 0U;
 if(a==9U&&p==7U&&pose==246U)return 1U;
 if(a==9U&&p==7U&&pose==247U)return 2U;
 if(a==9U&&p==7U&&pose==466U)return 3U;
 if(a==9U&&p==8U&&pose==245U)return 0U;
 if(a==9U&&p==8U&&pose==246U)return 1U;
 if(a==9U&&p==8U&&pose==247U)return 2U;
 if(a==9U&&p==8U&&pose==466U)return 3U;
 return 0xffffU;
}
static const finisher_run_t spr_0_1_0[]={{0,26},{1,27}};
static const finisher_run_t spr_0_1_1[]={{0,24},{1,27},{0,2}};
static const finisher_run_t spr_0_1_2[]={{0,23},{1,31}};
static const finisher_run_t spr_0_1_3[]={{0,22},{1,28}};
static const finisher_run_t spr_0_2_0[]={{0,26},{1,21}};
static const finisher_run_t spr_0_2_1[]={{0,24},{1,20},{0,2}};
static const finisher_run_t spr_0_2_2[]={{0,23},{1,24}};
static const finisher_run_t spr_0_2_3[]={{0,22},{1,22}};
static const finisher_run_t spr_0_3_0[]={{0,26},{1,23}};
static const finisher_run_t spr_0_3_1[]={{0,24},{1,22},{0,2}};
static const finisher_run_t spr_0_3_2[]={{0,23},{1,25}};
static const finisher_run_t spr_0_3_3[]={{0,22},{1,23}};
static const finisher_run_t spr_0_4_0[]={{0,26},{1,22}};
static const finisher_run_t spr_0_4_1[]={{0,24},{1,23},{0,2}};
static const finisher_run_t spr_0_4_2[]={{0,23},{1,25}};
static const finisher_run_t spr_0_4_3[]={{0,22},{1,22}};
static const finisher_run_t spr_0_5_0[]={{0,26},{1,22}};
static const finisher_run_t spr_0_5_1[]={{0,24},{1,23},{0,2}};
static const finisher_run_t spr_0_5_2[]={{0,23},{1,25}};
static const finisher_run_t spr_0_5_3[]={{0,22},{1,22}};
static const finisher_run_t spr_0_6_0[]={{0,26},{1,22}};
static const finisher_run_t spr_0_6_1[]={{0,24},{1,21},{0,2}};
static const finisher_run_t spr_0_6_2[]={{0,23},{1,25}};
static const finisher_run_t spr_0_6_3[]={{0,22},{1,24}};
static const finisher_run_t spr_0_7_0[]={{0,26},{1,17}};
static const finisher_run_t spr_0_7_1[]={{0,24},{1,19},{0,2}};
static const finisher_run_t spr_0_7_2[]={{0,23},{1,19}};
static const finisher_run_t spr_0_7_3[]={{0,22},{1,20}};
static const finisher_run_t spr_0_8_0[]={{0,26},{1,23}};
static const finisher_run_t spr_0_8_1[]={{0,24},{1,23},{0,2}};
static const finisher_run_t spr_0_8_2[]={{0,23},{1,25}};
static const finisher_run_t spr_0_8_3[]={{0,22},{1,24}};
static const finisher_run_t spr_0_9_0[]={{0,26},{1,21}};
static const finisher_run_t spr_0_9_1[]={{0,24},{1,20},{0,2}};
static const finisher_run_t spr_0_9_2[]={{0,23},{1,24}};
static const finisher_run_t spr_0_9_3[]={{0,22},{1,22}};
static const finisher_run_t spr_1_0_0[]={{0,34},{1,22}};
static const finisher_run_t spr_1_0_1[]={{0,34},{1,23}};
static const finisher_run_t spr_1_0_2[]={{0,29},{1,25}};
static const finisher_run_t spr_1_0_3[]={{0,28},{1,22}};
static const finisher_run_t spr_1_2_0[]={{0,34},{1,21}};
static const finisher_run_t spr_1_2_1[]={{0,34},{1,20}};
static const finisher_run_t spr_1_2_2[]={{0,29},{1,24}};
static const finisher_run_t spr_1_2_3[]={{0,28},{1,22}};
static const finisher_run_t spr_1_3_0[]={{0,34},{1,23}};
static const finisher_run_t spr_1_3_1[]={{0,34},{1,22}};
static const finisher_run_t spr_1_3_2[]={{0,29},{1,25}};
static const finisher_run_t spr_1_3_3[]={{0,28},{1,23}};
static const finisher_run_t spr_1_4_0[]={{0,34},{1,22}};
static const finisher_run_t spr_1_4_1[]={{0,34},{1,23}};
static const finisher_run_t spr_1_4_2[]={{0,29},{1,25}};
static const finisher_run_t spr_1_4_3[]={{0,28},{1,22}};
static const finisher_run_t spr_1_5_0[]={{0,34},{1,22}};
static const finisher_run_t spr_1_5_1[]={{0,34},{1,23}};
static const finisher_run_t spr_1_5_2[]={{0,29},{1,25}};
static const finisher_run_t spr_1_5_3[]={{0,28},{1,22}};
static const finisher_run_t spr_1_6_0[]={{0,34},{1,22}};
static const finisher_run_t spr_1_6_1[]={{0,34},{1,21}};
static const finisher_run_t spr_1_6_2[]={{0,29},{1,25}};
static const finisher_run_t spr_1_6_3[]={{0,28},{1,24}};
static const finisher_run_t spr_1_7_0[]={{0,34},{1,17}};
static const finisher_run_t spr_1_7_1[]={{0,34},{1,19}};
static const finisher_run_t spr_1_7_2[]={{0,29},{1,19}};
static const finisher_run_t spr_1_7_3[]={{0,28},{1,20}};
static const finisher_run_t spr_1_8_0[]={{0,34},{1,23}};
static const finisher_run_t spr_1_8_1[]={{0,34},{1,23}};
static const finisher_run_t spr_1_8_2[]={{0,29},{1,25}};
static const finisher_run_t spr_1_8_3[]={{0,28},{1,24}};
static const finisher_run_t spr_1_9_0[]={{0,34},{1,21}};
static const finisher_run_t spr_1_9_1[]={{0,34},{1,20}};
static const finisher_run_t spr_1_9_2[]={{0,29},{1,24}};
static const finisher_run_t spr_1_9_3[]={{0,28},{1,22}};
static const finisher_run_t spr_2_0_0[]={{0,23},{1,22}};
static const finisher_run_t spr_2_0_1[]={{0,22},{1,23},{0,2}};
static const finisher_run_t spr_2_0_2[]={{0,21},{1,25}};
static const finisher_run_t spr_2_0_3[]={{0,22},{1,22}};
static const finisher_run_t spr_2_1_0[]={{0,23},{1,27}};
static const finisher_run_t spr_2_1_1[]={{0,22},{1,27},{0,2}};
static const finisher_run_t spr_2_1_2[]={{0,21},{1,31}};
static const finisher_run_t spr_2_1_3[]={{0,22},{1,28}};
static const finisher_run_t spr_2_3_0[]={{0,23},{1,23}};
static const finisher_run_t spr_2_3_1[]={{0,22},{1,22},{0,2}};
static const finisher_run_t spr_2_3_2[]={{0,21},{1,25}};
static const finisher_run_t spr_2_3_3[]={{0,22},{1,23}};
static const finisher_run_t spr_2_4_0[]={{0,23},{1,22}};
static const finisher_run_t spr_2_4_1[]={{0,22},{1,23},{0,2}};
static const finisher_run_t spr_2_4_2[]={{0,21},{1,25}};
static const finisher_run_t spr_2_4_3[]={{0,22},{1,22}};
static const finisher_run_t spr_2_5_0[]={{0,23},{1,22}};
static const finisher_run_t spr_2_5_1[]={{0,22},{1,23},{0,2}};
static const finisher_run_t spr_2_5_2[]={{0,21},{1,25}};
static const finisher_run_t spr_2_5_3[]={{0,22},{1,22}};
static const finisher_run_t spr_2_6_0[]={{0,23},{1,22}};
static const finisher_run_t spr_2_6_1[]={{0,22},{1,21},{0,2}};
static const finisher_run_t spr_2_6_2[]={{0,21},{1,25}};
static const finisher_run_t spr_2_6_3[]={{0,22},{1,24}};
static const finisher_run_t spr_2_7_0[]={{0,23},{1,17}};
static const finisher_run_t spr_2_7_1[]={{0,22},{1,19},{0,2}};
static const finisher_run_t spr_2_7_2[]={{0,21},{1,19}};
static const finisher_run_t spr_2_7_3[]={{0,22},{1,20}};
static const finisher_run_t spr_2_8_0[]={{0,23},{1,23}};
static const finisher_run_t spr_2_8_1[]={{0,22},{1,23},{0,2}};
static const finisher_run_t spr_2_8_2[]={{0,21},{1,25}};
static const finisher_run_t spr_2_8_3[]={{0,22},{1,24}};
static const finisher_run_t spr_2_9_0[]={{0,23},{1,21}};
static const finisher_run_t spr_2_9_1[]={{0,22},{1,20},{0,2}};
static const finisher_run_t spr_2_9_2[]={{0,21},{1,24}};
static const finisher_run_t spr_2_9_3[]={{0,22},{1,22}};
static const finisher_run_t spr_3_0_0[]={{0,26},{1,22}};
static const finisher_run_t spr_3_0_1[]={{0,23},{1,23},{0,2}};
static const finisher_run_t spr_3_0_2[]={{0,22},{1,25}};
static const finisher_run_t spr_3_0_3[]={{0,24},{1,22}};
static const finisher_run_t spr_3_1_0[]={{0,26},{1,27}};
static const finisher_run_t spr_3_1_1[]={{0,23},{1,27},{0,2}};
static const finisher_run_t spr_3_1_2[]={{0,22},{1,31}};
static const finisher_run_t spr_3_1_3[]={{0,24},{1,28}};
static const finisher_run_t spr_3_2_0[]={{0,26},{1,21}};
static const finisher_run_t spr_3_2_1[]={{0,23},{1,20},{0,2}};
static const finisher_run_t spr_3_2_2[]={{0,22},{1,24}};
static const finisher_run_t spr_3_2_3[]={{0,24},{1,22}};
static const finisher_run_t spr_3_4_0[]={{0,26},{1,22}};
static const finisher_run_t spr_3_4_1[]={{0,23},{1,23},{0,2}};
static const finisher_run_t spr_3_4_2[]={{0,22},{1,25}};
static const finisher_run_t spr_3_4_3[]={{0,24},{1,22}};
static const finisher_run_t spr_3_5_0[]={{0,26},{1,22}};
static const finisher_run_t spr_3_5_1[]={{0,23},{1,23},{0,2}};
static const finisher_run_t spr_3_5_2[]={{0,22},{1,25}};
static const finisher_run_t spr_3_5_3[]={{0,24},{1,22}};
static const finisher_run_t spr_3_6_0[]={{0,26},{1,22}};
static const finisher_run_t spr_3_6_1[]={{0,23},{1,21},{0,2}};
static const finisher_run_t spr_3_6_2[]={{0,22},{1,25}};
static const finisher_run_t spr_3_6_3[]={{0,24},{1,24}};
static const finisher_run_t spr_3_7_0[]={{0,26},{1,17}};
static const finisher_run_t spr_3_7_1[]={{0,23},{1,19},{0,2}};
static const finisher_run_t spr_3_7_2[]={{0,22},{1,19}};
static const finisher_run_t spr_3_7_3[]={{0,24},{1,20}};
static const finisher_run_t spr_3_8_0[]={{0,26},{1,23}};
static const finisher_run_t spr_3_8_1[]={{0,23},{1,23},{0,2}};
static const finisher_run_t spr_3_8_2[]={{0,22},{1,25}};
static const finisher_run_t spr_3_8_3[]={{0,24},{1,24}};
static const finisher_run_t spr_3_9_0[]={{0,26},{1,21}};
static const finisher_run_t spr_3_9_1[]={{0,23},{1,20},{0,2}};
static const finisher_run_t spr_3_9_2[]={{0,22},{1,24}};
static const finisher_run_t spr_3_9_3[]={{0,24},{1,22}};
static const finisher_run_t spr_4_0_0[]={{0,26},{1,22}};
static const finisher_run_t spr_4_0_1[]={{0,23},{1,23},{0,2}};
static const finisher_run_t spr_4_0_2[]={{0,23},{1,25}};
static const finisher_run_t spr_4_0_3[]={{0,22},{1,22}};
static const finisher_run_t spr_4_1_0[]={{0,26},{1,27}};
static const finisher_run_t spr_4_1_1[]={{0,23},{1,27},{0,2}};
static const finisher_run_t spr_4_1_2[]={{0,23},{1,31}};
static const finisher_run_t spr_4_1_3[]={{0,22},{1,28}};
static const finisher_run_t spr_4_2_0[]={{0,26},{1,21}};
static const finisher_run_t spr_4_2_1[]={{0,23},{1,20},{0,2}};
static const finisher_run_t spr_4_2_2[]={{0,23},{1,24}};
static const finisher_run_t spr_4_2_3[]={{0,22},{1,22}};
static const finisher_run_t spr_4_3_0[]={{0,26},{1,23}};
static const finisher_run_t spr_4_3_1[]={{0,23},{1,22},{0,2}};
static const finisher_run_t spr_4_3_2[]={{0,23},{1,25}};
static const finisher_run_t spr_4_3_3[]={{0,22},{1,23}};
static const finisher_run_t spr_4_5_0[]={{0,26},{1,22}};
static const finisher_run_t spr_4_5_1[]={{0,23},{1,23},{0,2}};
static const finisher_run_t spr_4_5_2[]={{0,23},{1,25}};
static const finisher_run_t spr_4_5_3[]={{0,22},{1,22}};
static const finisher_run_t spr_4_6_0[]={{0,26},{1,22}};
static const finisher_run_t spr_4_6_1[]={{0,23},{1,21},{0,2}};
static const finisher_run_t spr_4_6_2[]={{0,23},{1,25}};
static const finisher_run_t spr_4_6_3[]={{0,22},{1,24}};
static const finisher_run_t spr_4_7_0[]={{0,26},{1,17}};
static const finisher_run_t spr_4_7_1[]={{0,23},{1,19},{0,2}};
static const finisher_run_t spr_4_7_2[]={{0,23},{1,19}};
static const finisher_run_t spr_4_7_3[]={{0,22},{1,20}};
static const finisher_run_t spr_4_8_0[]={{0,26},{1,23}};
static const finisher_run_t spr_4_8_1[]={{0,23},{1,23},{0,2}};
static const finisher_run_t spr_4_8_2[]={{0,23},{1,25}};
static const finisher_run_t spr_4_8_3[]={{0,22},{1,24}};
static const finisher_run_t spr_4_9_0[]={{0,26},{1,21}};
static const finisher_run_t spr_4_9_1[]={{0,23},{1,20},{0,2}};
static const finisher_run_t spr_4_9_2[]={{0,23},{1,24}};
static const finisher_run_t spr_4_9_3[]={{0,22},{1,22}};
static const finisher_run_t spr_5_0_0[]={{0,26},{1,22}};
static const finisher_run_t spr_5_0_1[]={{0,23},{1,23},{0,2}};
static const finisher_run_t spr_5_0_2[]={{0,23},{1,25}};
static const finisher_run_t spr_5_0_3[]={{0,22},{1,22}};
static const finisher_run_t spr_5_1_0[]={{0,26},{1,27}};
static const finisher_run_t spr_5_1_1[]={{0,23},{1,27},{0,2}};
static const finisher_run_t spr_5_1_2[]={{0,23},{1,31}};
static const finisher_run_t spr_5_1_3[]={{0,22},{1,28}};
static const finisher_run_t spr_5_2_0[]={{0,26},{1,21}};
static const finisher_run_t spr_5_2_1[]={{0,23},{1,20},{0,2}};
static const finisher_run_t spr_5_2_2[]={{0,23},{1,24}};
static const finisher_run_t spr_5_2_3[]={{0,22},{1,22}};
static const finisher_run_t spr_5_3_0[]={{0,26},{1,23}};
static const finisher_run_t spr_5_3_1[]={{0,23},{1,22},{0,2}};
static const finisher_run_t spr_5_3_2[]={{0,23},{1,25}};
static const finisher_run_t spr_5_3_3[]={{0,22},{1,23}};
static const finisher_run_t spr_5_4_0[]={{0,26},{1,22}};
static const finisher_run_t spr_5_4_1[]={{0,23},{1,23},{0,2}};
static const finisher_run_t spr_5_4_2[]={{0,23},{1,25}};
static const finisher_run_t spr_5_4_3[]={{0,22},{1,22}};
static const finisher_run_t spr_5_6_0[]={{0,26},{1,22}};
static const finisher_run_t spr_5_6_1[]={{0,23},{1,21},{0,2}};
static const finisher_run_t spr_5_6_2[]={{0,23},{1,25}};
static const finisher_run_t spr_5_6_3[]={{0,22},{1,24}};
static const finisher_run_t spr_5_7_0[]={{0,26},{1,17}};
static const finisher_run_t spr_5_7_1[]={{0,23},{1,19},{0,2}};
static const finisher_run_t spr_5_7_2[]={{0,23},{1,19}};
static const finisher_run_t spr_5_7_3[]={{0,22},{1,20}};
static const finisher_run_t spr_5_8_0[]={{0,26},{1,23}};
static const finisher_run_t spr_5_8_1[]={{0,23},{1,23},{0,2}};
static const finisher_run_t spr_5_8_2[]={{0,23},{1,25}};
static const finisher_run_t spr_5_8_3[]={{0,22},{1,24}};
static const finisher_run_t spr_5_9_0[]={{0,26},{1,21}};
static const finisher_run_t spr_5_9_1[]={{0,23},{1,20},{0,2}};
static const finisher_run_t spr_5_9_2[]={{0,23},{1,24}};
static const finisher_run_t spr_5_9_3[]={{0,22},{1,22}};
static const finisher_run_t spr_6_0_0[]={{0,26},{1,22}};
static const finisher_run_t spr_6_0_1[]={{0,23},{1,23},{0,2}};
static const finisher_run_t spr_6_0_2[]={{1,25},{0,23}};
static const finisher_run_t spr_6_0_3[]={{0,24},{1,22}};
static const finisher_run_t spr_6_1_0[]={{0,26},{1,27}};
static const finisher_run_t spr_6_1_1[]={{0,23},{1,27},{0,2}};
static const finisher_run_t spr_6_1_2[]={{1,25},{0,23},{1,6}};
static const finisher_run_t spr_6_1_3[]={{0,24},{1,28}};
static const finisher_run_t spr_6_2_0[]={{0,26},{1,21}};
static const finisher_run_t spr_6_2_1[]={{0,23},{1,20},{0,2}};
static const finisher_run_t spr_6_2_2[]={{1,24},{0,23}};
static const finisher_run_t spr_6_2_3[]={{0,24},{1,22}};
static const finisher_run_t spr_6_3_0[]={{0,26},{1,23}};
static const finisher_run_t spr_6_3_1[]={{0,23},{1,22},{0,2}};
static const finisher_run_t spr_6_3_2[]={{1,25},{0,23}};
static const finisher_run_t spr_6_3_3[]={{0,24},{1,23}};
static const finisher_run_t spr_6_4_0[]={{0,26},{1,22}};
static const finisher_run_t spr_6_4_1[]={{0,23},{1,23},{0,2}};
static const finisher_run_t spr_6_4_2[]={{1,25},{0,23}};
static const finisher_run_t spr_6_4_3[]={{0,24},{1,22}};
static const finisher_run_t spr_6_5_0[]={{0,26},{1,22}};
static const finisher_run_t spr_6_5_1[]={{0,23},{1,23},{0,2}};
static const finisher_run_t spr_6_5_2[]={{1,25},{0,23}};
static const finisher_run_t spr_6_5_3[]={{0,24},{1,22}};
static const finisher_run_t spr_6_7_0[]={{0,26},{1,17}};
static const finisher_run_t spr_6_7_1[]={{0,23},{1,19},{0,2}};
static const finisher_run_t spr_6_7_2[]={{1,19},{0,23}};
static const finisher_run_t spr_6_7_3[]={{0,24},{1,20}};
static const finisher_run_t spr_6_8_0[]={{0,26},{1,23}};
static const finisher_run_t spr_6_8_1[]={{0,23},{1,23},{0,2}};
static const finisher_run_t spr_6_8_2[]={{1,25},{0,23}};
static const finisher_run_t spr_6_8_3[]={{0,24},{1,24}};
static const finisher_run_t spr_6_9_0[]={{0,26},{1,21}};
static const finisher_run_t spr_6_9_1[]={{0,23},{1,20},{0,2}};
static const finisher_run_t spr_6_9_2[]={{1,24},{0,23}};
static const finisher_run_t spr_6_9_3[]={{0,24},{1,22}};
static const finisher_run_t spr_7_0_0[]={{0,21},{1,22}};
static const finisher_run_t spr_7_0_1[]={{0,18},{1,23},{0,2}};
static const finisher_run_t spr_7_0_2[]={{0,18},{1,25}};
static const finisher_run_t spr_7_0_3[]={{0,20},{1,22}};
static const finisher_run_t spr_7_1_0[]={{0,21},{1,27}};
static const finisher_run_t spr_7_1_1[]={{0,18},{1,27},{0,2}};
static const finisher_run_t spr_7_1_2[]={{0,18},{1,31}};
static const finisher_run_t spr_7_1_3[]={{0,20},{1,28}};
static const finisher_run_t spr_7_2_0[]={{0,21},{1,21}};
static const finisher_run_t spr_7_2_1[]={{0,18},{1,20},{0,2}};
static const finisher_run_t spr_7_2_2[]={{0,18},{1,24}};
static const finisher_run_t spr_7_2_3[]={{0,20},{1,22}};
static const finisher_run_t spr_7_3_0[]={{0,21},{1,23}};
static const finisher_run_t spr_7_3_1[]={{0,18},{1,22},{0,2}};
static const finisher_run_t spr_7_3_2[]={{0,18},{1,25}};
static const finisher_run_t spr_7_3_3[]={{0,20},{1,23}};
static const finisher_run_t spr_7_4_0[]={{0,21},{1,22}};
static const finisher_run_t spr_7_4_1[]={{0,18},{1,23},{0,2}};
static const finisher_run_t spr_7_4_2[]={{0,18},{1,25}};
static const finisher_run_t spr_7_4_3[]={{0,20},{1,22}};
static const finisher_run_t spr_7_5_0[]={{0,21},{1,22}};
static const finisher_run_t spr_7_5_1[]={{0,18},{1,23},{0,2}};
static const finisher_run_t spr_7_5_2[]={{0,18},{1,25}};
static const finisher_run_t spr_7_5_3[]={{0,20},{1,22}};
static const finisher_run_t spr_7_6_0[]={{0,21},{1,22}};
static const finisher_run_t spr_7_6_1[]={{0,18},{1,21},{0,2}};
static const finisher_run_t spr_7_6_2[]={{0,18},{1,25}};
static const finisher_run_t spr_7_6_3[]={{0,20},{1,24}};
static const finisher_run_t spr_7_8_0[]={{0,21},{1,23}};
static const finisher_run_t spr_7_8_1[]={{0,18},{1,23},{0,2}};
static const finisher_run_t spr_7_8_2[]={{0,18},{1,25}};
static const finisher_run_t spr_7_8_3[]={{0,20},{1,24}};
static const finisher_run_t spr_7_9_0[]={{0,21},{1,21}};
static const finisher_run_t spr_7_9_1[]={{0,18},{1,20},{0,2}};
static const finisher_run_t spr_7_9_2[]={{0,18},{1,24}};
static const finisher_run_t spr_7_9_3[]={{0,20},{1,22}};
static const finisher_run_t spr_8_0_0[]={{0,28},{1,22}};
static const finisher_run_t spr_8_0_1[]={{0,24},{1,23},{0,2}};
static const finisher_run_t spr_8_0_2[]={{0,23},{1,25}};
static const finisher_run_t spr_8_0_3[]={{0,24},{1,22}};
static const finisher_run_t spr_8_1_0[]={{0,28},{1,27}};
static const finisher_run_t spr_8_1_1[]={{0,24},{1,27},{0,2}};
static const finisher_run_t spr_8_1_2[]={{0,23},{1,31}};
static const finisher_run_t spr_8_1_3[]={{0,24},{1,28}};
static const finisher_run_t spr_8_2_0[]={{0,28},{1,21}};
static const finisher_run_t spr_8_2_1[]={{0,24},{1,20},{0,2}};
static const finisher_run_t spr_8_2_2[]={{0,23},{1,24}};
static const finisher_run_t spr_8_2_3[]={{0,24},{1,22}};
static const finisher_run_t spr_8_3_0[]={{0,28},{1,23}};
static const finisher_run_t spr_8_3_1[]={{0,24},{1,22},{0,2}};
static const finisher_run_t spr_8_3_2[]={{0,23},{1,25}};
static const finisher_run_t spr_8_3_3[]={{0,24},{1,23}};
static const finisher_run_t spr_8_4_0[]={{0,28},{1,22}};
static const finisher_run_t spr_8_4_1[]={{0,24},{1,23},{0,2}};
static const finisher_run_t spr_8_4_2[]={{0,23},{1,25}};
static const finisher_run_t spr_8_4_3[]={{0,24},{1,22}};
static const finisher_run_t spr_8_5_0[]={{0,28},{1,22}};
static const finisher_run_t spr_8_5_1[]={{0,24},{1,23},{0,2}};
static const finisher_run_t spr_8_5_2[]={{0,23},{1,25}};
static const finisher_run_t spr_8_5_3[]={{0,24},{1,22}};
static const finisher_run_t spr_8_6_0[]={{0,28},{1,22}};
static const finisher_run_t spr_8_6_1[]={{0,24},{1,21},{0,2}};
static const finisher_run_t spr_8_6_2[]={{0,23},{1,25}};
static const finisher_run_t spr_8_6_3[]={{0,24},{1,24}};
static const finisher_run_t spr_8_7_0[]={{0,28},{1,17}};
static const finisher_run_t spr_8_7_1[]={{0,24},{1,19},{0,2}};
static const finisher_run_t spr_8_7_2[]={{0,23},{1,19}};
static const finisher_run_t spr_8_7_3[]={{0,24},{1,20}};
static const finisher_run_t spr_8_9_0[]={{0,28},{1,21}};
static const finisher_run_t spr_8_9_1[]={{0,24},{1,20},{0,2}};
static const finisher_run_t spr_8_9_2[]={{0,23},{1,24}};
static const finisher_run_t spr_8_9_3[]={{0,24},{1,22}};
static const finisher_run_t spr_9_0_0[]={{0,23},{1,22}};
static const finisher_run_t spr_9_0_1[]={{0,23},{1,23},{0,2}};
static const finisher_run_t spr_9_0_2[]={{0,21},{1,25}};
static const finisher_run_t spr_9_0_3[]={{0,22},{1,22}};
static const finisher_run_t spr_9_1_0[]={{0,23},{1,27}};
static const finisher_run_t spr_9_1_1[]={{0,23},{1,27},{0,2}};
static const finisher_run_t spr_9_1_2[]={{0,21},{1,31}};
static const finisher_run_t spr_9_1_3[]={{0,22},{1,28}};
static const finisher_run_t spr_9_2_0[]={{0,23},{1,21}};
static const finisher_run_t spr_9_2_1[]={{0,23},{1,20},{0,2}};
static const finisher_run_t spr_9_2_2[]={{0,21},{1,24}};
static const finisher_run_t spr_9_2_3[]={{0,22},{1,22}};
static const finisher_run_t spr_9_3_0[]={{0,23},{1,23}};
static const finisher_run_t spr_9_3_1[]={{0,23},{1,22},{0,2}};
static const finisher_run_t spr_9_3_2[]={{0,21},{1,25}};
static const finisher_run_t spr_9_3_3[]={{0,22},{1,23}};
static const finisher_run_t spr_9_4_0[]={{0,23},{1,22}};
static const finisher_run_t spr_9_4_1[]={{0,23},{1,23},{0,2}};
static const finisher_run_t spr_9_4_2[]={{0,21},{1,25}};
static const finisher_run_t spr_9_4_3[]={{0,22},{1,22}};
static const finisher_run_t spr_9_5_0[]={{0,23},{1,22}};
static const finisher_run_t spr_9_5_1[]={{0,23},{1,23},{0,2}};
static const finisher_run_t spr_9_5_2[]={{0,21},{1,25}};
static const finisher_run_t spr_9_5_3[]={{0,22},{1,22}};
static const finisher_run_t spr_9_6_0[]={{0,23},{1,22}};
static const finisher_run_t spr_9_6_1[]={{0,23},{1,21},{0,2}};
static const finisher_run_t spr_9_6_2[]={{0,21},{1,25}};
static const finisher_run_t spr_9_6_3[]={{0,22},{1,24}};
static const finisher_run_t spr_9_7_0[]={{0,23},{1,17}};
static const finisher_run_t spr_9_7_1[]={{0,23},{1,19},{0,2}};
static const finisher_run_t spr_9_7_2[]={{0,21},{1,19}};
static const finisher_run_t spr_9_7_3[]={{0,22},{1,20}};
static const finisher_run_t spr_9_8_0[]={{0,23},{1,23}};
static const finisher_run_t spr_9_8_1[]={{0,23},{1,23},{0,2}};
static const finisher_run_t spr_9_8_2[]={{0,21},{1,25}};
static const finisher_run_t spr_9_8_3[]={{0,22},{1,24}};
static inline const finisher_run_t *struggle_pair_asset_runs(unsigned a,unsigned p,unsigned frame,unsigned *count){
 if(a==0U&&p==1U&&frame==0U){*count=2U;return spr_0_1_0;}
 if(a==0U&&p==1U&&frame==1U){*count=3U;return spr_0_1_1;}
 if(a==0U&&p==1U&&frame==2U){*count=2U;return spr_0_1_2;}
 if(a==0U&&p==1U&&frame==3U){*count=2U;return spr_0_1_3;}
 if(a==0U&&p==2U&&frame==0U){*count=2U;return spr_0_2_0;}
 if(a==0U&&p==2U&&frame==1U){*count=3U;return spr_0_2_1;}
 if(a==0U&&p==2U&&frame==2U){*count=2U;return spr_0_2_2;}
 if(a==0U&&p==2U&&frame==3U){*count=2U;return spr_0_2_3;}
 if(a==0U&&p==3U&&frame==0U){*count=2U;return spr_0_3_0;}
 if(a==0U&&p==3U&&frame==1U){*count=3U;return spr_0_3_1;}
 if(a==0U&&p==3U&&frame==2U){*count=2U;return spr_0_3_2;}
 if(a==0U&&p==3U&&frame==3U){*count=2U;return spr_0_3_3;}
 if(a==0U&&p==4U&&frame==0U){*count=2U;return spr_0_4_0;}
 if(a==0U&&p==4U&&frame==1U){*count=3U;return spr_0_4_1;}
 if(a==0U&&p==4U&&frame==2U){*count=2U;return spr_0_4_2;}
 if(a==0U&&p==4U&&frame==3U){*count=2U;return spr_0_4_3;}
 if(a==0U&&p==5U&&frame==0U){*count=2U;return spr_0_5_0;}
 if(a==0U&&p==5U&&frame==1U){*count=3U;return spr_0_5_1;}
 if(a==0U&&p==5U&&frame==2U){*count=2U;return spr_0_5_2;}
 if(a==0U&&p==5U&&frame==3U){*count=2U;return spr_0_5_3;}
 if(a==0U&&p==6U&&frame==0U){*count=2U;return spr_0_6_0;}
 if(a==0U&&p==6U&&frame==1U){*count=3U;return spr_0_6_1;}
 if(a==0U&&p==6U&&frame==2U){*count=2U;return spr_0_6_2;}
 if(a==0U&&p==6U&&frame==3U){*count=2U;return spr_0_6_3;}
 if(a==0U&&p==7U&&frame==0U){*count=2U;return spr_0_7_0;}
 if(a==0U&&p==7U&&frame==1U){*count=3U;return spr_0_7_1;}
 if(a==0U&&p==7U&&frame==2U){*count=2U;return spr_0_7_2;}
 if(a==0U&&p==7U&&frame==3U){*count=2U;return spr_0_7_3;}
 if(a==0U&&p==8U&&frame==0U){*count=2U;return spr_0_8_0;}
 if(a==0U&&p==8U&&frame==1U){*count=3U;return spr_0_8_1;}
 if(a==0U&&p==8U&&frame==2U){*count=2U;return spr_0_8_2;}
 if(a==0U&&p==8U&&frame==3U){*count=2U;return spr_0_8_3;}
 if(a==0U&&p==9U&&frame==0U){*count=2U;return spr_0_9_0;}
 if(a==0U&&p==9U&&frame==1U){*count=3U;return spr_0_9_1;}
 if(a==0U&&p==9U&&frame==2U){*count=2U;return spr_0_9_2;}
 if(a==0U&&p==9U&&frame==3U){*count=2U;return spr_0_9_3;}
 if(a==1U&&p==0U&&frame==0U){*count=2U;return spr_1_0_0;}
 if(a==1U&&p==0U&&frame==1U){*count=2U;return spr_1_0_1;}
 if(a==1U&&p==0U&&frame==2U){*count=2U;return spr_1_0_2;}
 if(a==1U&&p==0U&&frame==3U){*count=2U;return spr_1_0_3;}
 if(a==1U&&p==2U&&frame==0U){*count=2U;return spr_1_2_0;}
 if(a==1U&&p==2U&&frame==1U){*count=2U;return spr_1_2_1;}
 if(a==1U&&p==2U&&frame==2U){*count=2U;return spr_1_2_2;}
 if(a==1U&&p==2U&&frame==3U){*count=2U;return spr_1_2_3;}
 if(a==1U&&p==3U&&frame==0U){*count=2U;return spr_1_3_0;}
 if(a==1U&&p==3U&&frame==1U){*count=2U;return spr_1_3_1;}
 if(a==1U&&p==3U&&frame==2U){*count=2U;return spr_1_3_2;}
 if(a==1U&&p==3U&&frame==3U){*count=2U;return spr_1_3_3;}
 if(a==1U&&p==4U&&frame==0U){*count=2U;return spr_1_4_0;}
 if(a==1U&&p==4U&&frame==1U){*count=2U;return spr_1_4_1;}
 if(a==1U&&p==4U&&frame==2U){*count=2U;return spr_1_4_2;}
 if(a==1U&&p==4U&&frame==3U){*count=2U;return spr_1_4_3;}
 if(a==1U&&p==5U&&frame==0U){*count=2U;return spr_1_5_0;}
 if(a==1U&&p==5U&&frame==1U){*count=2U;return spr_1_5_1;}
 if(a==1U&&p==5U&&frame==2U){*count=2U;return spr_1_5_2;}
 if(a==1U&&p==5U&&frame==3U){*count=2U;return spr_1_5_3;}
 if(a==1U&&p==6U&&frame==0U){*count=2U;return spr_1_6_0;}
 if(a==1U&&p==6U&&frame==1U){*count=2U;return spr_1_6_1;}
 if(a==1U&&p==6U&&frame==2U){*count=2U;return spr_1_6_2;}
 if(a==1U&&p==6U&&frame==3U){*count=2U;return spr_1_6_3;}
 if(a==1U&&p==7U&&frame==0U){*count=2U;return spr_1_7_0;}
 if(a==1U&&p==7U&&frame==1U){*count=2U;return spr_1_7_1;}
 if(a==1U&&p==7U&&frame==2U){*count=2U;return spr_1_7_2;}
 if(a==1U&&p==7U&&frame==3U){*count=2U;return spr_1_7_3;}
 if(a==1U&&p==8U&&frame==0U){*count=2U;return spr_1_8_0;}
 if(a==1U&&p==8U&&frame==1U){*count=2U;return spr_1_8_1;}
 if(a==1U&&p==8U&&frame==2U){*count=2U;return spr_1_8_2;}
 if(a==1U&&p==8U&&frame==3U){*count=2U;return spr_1_8_3;}
 if(a==1U&&p==9U&&frame==0U){*count=2U;return spr_1_9_0;}
 if(a==1U&&p==9U&&frame==1U){*count=2U;return spr_1_9_1;}
 if(a==1U&&p==9U&&frame==2U){*count=2U;return spr_1_9_2;}
 if(a==1U&&p==9U&&frame==3U){*count=2U;return spr_1_9_3;}
 if(a==2U&&p==0U&&frame==0U){*count=2U;return spr_2_0_0;}
 if(a==2U&&p==0U&&frame==1U){*count=3U;return spr_2_0_1;}
 if(a==2U&&p==0U&&frame==2U){*count=2U;return spr_2_0_2;}
 if(a==2U&&p==0U&&frame==3U){*count=2U;return spr_2_0_3;}
 if(a==2U&&p==1U&&frame==0U){*count=2U;return spr_2_1_0;}
 if(a==2U&&p==1U&&frame==1U){*count=3U;return spr_2_1_1;}
 if(a==2U&&p==1U&&frame==2U){*count=2U;return spr_2_1_2;}
 if(a==2U&&p==1U&&frame==3U){*count=2U;return spr_2_1_3;}
 if(a==2U&&p==3U&&frame==0U){*count=2U;return spr_2_3_0;}
 if(a==2U&&p==3U&&frame==1U){*count=3U;return spr_2_3_1;}
 if(a==2U&&p==3U&&frame==2U){*count=2U;return spr_2_3_2;}
 if(a==2U&&p==3U&&frame==3U){*count=2U;return spr_2_3_3;}
 if(a==2U&&p==4U&&frame==0U){*count=2U;return spr_2_4_0;}
 if(a==2U&&p==4U&&frame==1U){*count=3U;return spr_2_4_1;}
 if(a==2U&&p==4U&&frame==2U){*count=2U;return spr_2_4_2;}
 if(a==2U&&p==4U&&frame==3U){*count=2U;return spr_2_4_3;}
 if(a==2U&&p==5U&&frame==0U){*count=2U;return spr_2_5_0;}
 if(a==2U&&p==5U&&frame==1U){*count=3U;return spr_2_5_1;}
 if(a==2U&&p==5U&&frame==2U){*count=2U;return spr_2_5_2;}
 if(a==2U&&p==5U&&frame==3U){*count=2U;return spr_2_5_3;}
 if(a==2U&&p==6U&&frame==0U){*count=2U;return spr_2_6_0;}
 if(a==2U&&p==6U&&frame==1U){*count=3U;return spr_2_6_1;}
 if(a==2U&&p==6U&&frame==2U){*count=2U;return spr_2_6_2;}
 if(a==2U&&p==6U&&frame==3U){*count=2U;return spr_2_6_3;}
 if(a==2U&&p==7U&&frame==0U){*count=2U;return spr_2_7_0;}
 if(a==2U&&p==7U&&frame==1U){*count=3U;return spr_2_7_1;}
 if(a==2U&&p==7U&&frame==2U){*count=2U;return spr_2_7_2;}
 if(a==2U&&p==7U&&frame==3U){*count=2U;return spr_2_7_3;}
 if(a==2U&&p==8U&&frame==0U){*count=2U;return spr_2_8_0;}
 if(a==2U&&p==8U&&frame==1U){*count=3U;return spr_2_8_1;}
 if(a==2U&&p==8U&&frame==2U){*count=2U;return spr_2_8_2;}
 if(a==2U&&p==8U&&frame==3U){*count=2U;return spr_2_8_3;}
 if(a==2U&&p==9U&&frame==0U){*count=2U;return spr_2_9_0;}
 if(a==2U&&p==9U&&frame==1U){*count=3U;return spr_2_9_1;}
 if(a==2U&&p==9U&&frame==2U){*count=2U;return spr_2_9_2;}
 if(a==2U&&p==9U&&frame==3U){*count=2U;return spr_2_9_3;}
 if(a==3U&&p==0U&&frame==0U){*count=2U;return spr_3_0_0;}
 if(a==3U&&p==0U&&frame==1U){*count=3U;return spr_3_0_1;}
 if(a==3U&&p==0U&&frame==2U){*count=2U;return spr_3_0_2;}
 if(a==3U&&p==0U&&frame==3U){*count=2U;return spr_3_0_3;}
 if(a==3U&&p==1U&&frame==0U){*count=2U;return spr_3_1_0;}
 if(a==3U&&p==1U&&frame==1U){*count=3U;return spr_3_1_1;}
 if(a==3U&&p==1U&&frame==2U){*count=2U;return spr_3_1_2;}
 if(a==3U&&p==1U&&frame==3U){*count=2U;return spr_3_1_3;}
 if(a==3U&&p==2U&&frame==0U){*count=2U;return spr_3_2_0;}
 if(a==3U&&p==2U&&frame==1U){*count=3U;return spr_3_2_1;}
 if(a==3U&&p==2U&&frame==2U){*count=2U;return spr_3_2_2;}
 if(a==3U&&p==2U&&frame==3U){*count=2U;return spr_3_2_3;}
 if(a==3U&&p==4U&&frame==0U){*count=2U;return spr_3_4_0;}
 if(a==3U&&p==4U&&frame==1U){*count=3U;return spr_3_4_1;}
 if(a==3U&&p==4U&&frame==2U){*count=2U;return spr_3_4_2;}
 if(a==3U&&p==4U&&frame==3U){*count=2U;return spr_3_4_3;}
 if(a==3U&&p==5U&&frame==0U){*count=2U;return spr_3_5_0;}
 if(a==3U&&p==5U&&frame==1U){*count=3U;return spr_3_5_1;}
 if(a==3U&&p==5U&&frame==2U){*count=2U;return spr_3_5_2;}
 if(a==3U&&p==5U&&frame==3U){*count=2U;return spr_3_5_3;}
 if(a==3U&&p==6U&&frame==0U){*count=2U;return spr_3_6_0;}
 if(a==3U&&p==6U&&frame==1U){*count=3U;return spr_3_6_1;}
 if(a==3U&&p==6U&&frame==2U){*count=2U;return spr_3_6_2;}
 if(a==3U&&p==6U&&frame==3U){*count=2U;return spr_3_6_3;}
 if(a==3U&&p==7U&&frame==0U){*count=2U;return spr_3_7_0;}
 if(a==3U&&p==7U&&frame==1U){*count=3U;return spr_3_7_1;}
 if(a==3U&&p==7U&&frame==2U){*count=2U;return spr_3_7_2;}
 if(a==3U&&p==7U&&frame==3U){*count=2U;return spr_3_7_3;}
 if(a==3U&&p==8U&&frame==0U){*count=2U;return spr_3_8_0;}
 if(a==3U&&p==8U&&frame==1U){*count=3U;return spr_3_8_1;}
 if(a==3U&&p==8U&&frame==2U){*count=2U;return spr_3_8_2;}
 if(a==3U&&p==8U&&frame==3U){*count=2U;return spr_3_8_3;}
 if(a==3U&&p==9U&&frame==0U){*count=2U;return spr_3_9_0;}
 if(a==3U&&p==9U&&frame==1U){*count=3U;return spr_3_9_1;}
 if(a==3U&&p==9U&&frame==2U){*count=2U;return spr_3_9_2;}
 if(a==3U&&p==9U&&frame==3U){*count=2U;return spr_3_9_3;}
 if(a==4U&&p==0U&&frame==0U){*count=2U;return spr_4_0_0;}
 if(a==4U&&p==0U&&frame==1U){*count=3U;return spr_4_0_1;}
 if(a==4U&&p==0U&&frame==2U){*count=2U;return spr_4_0_2;}
 if(a==4U&&p==0U&&frame==3U){*count=2U;return spr_4_0_3;}
 if(a==4U&&p==1U&&frame==0U){*count=2U;return spr_4_1_0;}
 if(a==4U&&p==1U&&frame==1U){*count=3U;return spr_4_1_1;}
 if(a==4U&&p==1U&&frame==2U){*count=2U;return spr_4_1_2;}
 if(a==4U&&p==1U&&frame==3U){*count=2U;return spr_4_1_3;}
 if(a==4U&&p==2U&&frame==0U){*count=2U;return spr_4_2_0;}
 if(a==4U&&p==2U&&frame==1U){*count=3U;return spr_4_2_1;}
 if(a==4U&&p==2U&&frame==2U){*count=2U;return spr_4_2_2;}
 if(a==4U&&p==2U&&frame==3U){*count=2U;return spr_4_2_3;}
 if(a==4U&&p==3U&&frame==0U){*count=2U;return spr_4_3_0;}
 if(a==4U&&p==3U&&frame==1U){*count=3U;return spr_4_3_1;}
 if(a==4U&&p==3U&&frame==2U){*count=2U;return spr_4_3_2;}
 if(a==4U&&p==3U&&frame==3U){*count=2U;return spr_4_3_3;}
 if(a==4U&&p==5U&&frame==0U){*count=2U;return spr_4_5_0;}
 if(a==4U&&p==5U&&frame==1U){*count=3U;return spr_4_5_1;}
 if(a==4U&&p==5U&&frame==2U){*count=2U;return spr_4_5_2;}
 if(a==4U&&p==5U&&frame==3U){*count=2U;return spr_4_5_3;}
 if(a==4U&&p==6U&&frame==0U){*count=2U;return spr_4_6_0;}
 if(a==4U&&p==6U&&frame==1U){*count=3U;return spr_4_6_1;}
 if(a==4U&&p==6U&&frame==2U){*count=2U;return spr_4_6_2;}
 if(a==4U&&p==6U&&frame==3U){*count=2U;return spr_4_6_3;}
 if(a==4U&&p==7U&&frame==0U){*count=2U;return spr_4_7_0;}
 if(a==4U&&p==7U&&frame==1U){*count=3U;return spr_4_7_1;}
 if(a==4U&&p==7U&&frame==2U){*count=2U;return spr_4_7_2;}
 if(a==4U&&p==7U&&frame==3U){*count=2U;return spr_4_7_3;}
 if(a==4U&&p==8U&&frame==0U){*count=2U;return spr_4_8_0;}
 if(a==4U&&p==8U&&frame==1U){*count=3U;return spr_4_8_1;}
 if(a==4U&&p==8U&&frame==2U){*count=2U;return spr_4_8_2;}
 if(a==4U&&p==8U&&frame==3U){*count=2U;return spr_4_8_3;}
 if(a==4U&&p==9U&&frame==0U){*count=2U;return spr_4_9_0;}
 if(a==4U&&p==9U&&frame==1U){*count=3U;return spr_4_9_1;}
 if(a==4U&&p==9U&&frame==2U){*count=2U;return spr_4_9_2;}
 if(a==4U&&p==9U&&frame==3U){*count=2U;return spr_4_9_3;}
 if(a==5U&&p==0U&&frame==0U){*count=2U;return spr_5_0_0;}
 if(a==5U&&p==0U&&frame==1U){*count=3U;return spr_5_0_1;}
 if(a==5U&&p==0U&&frame==2U){*count=2U;return spr_5_0_2;}
 if(a==5U&&p==0U&&frame==3U){*count=2U;return spr_5_0_3;}
 if(a==5U&&p==1U&&frame==0U){*count=2U;return spr_5_1_0;}
 if(a==5U&&p==1U&&frame==1U){*count=3U;return spr_5_1_1;}
 if(a==5U&&p==1U&&frame==2U){*count=2U;return spr_5_1_2;}
 if(a==5U&&p==1U&&frame==3U){*count=2U;return spr_5_1_3;}
 if(a==5U&&p==2U&&frame==0U){*count=2U;return spr_5_2_0;}
 if(a==5U&&p==2U&&frame==1U){*count=3U;return spr_5_2_1;}
 if(a==5U&&p==2U&&frame==2U){*count=2U;return spr_5_2_2;}
 if(a==5U&&p==2U&&frame==3U){*count=2U;return spr_5_2_3;}
 if(a==5U&&p==3U&&frame==0U){*count=2U;return spr_5_3_0;}
 if(a==5U&&p==3U&&frame==1U){*count=3U;return spr_5_3_1;}
 if(a==5U&&p==3U&&frame==2U){*count=2U;return spr_5_3_2;}
 if(a==5U&&p==3U&&frame==3U){*count=2U;return spr_5_3_3;}
 if(a==5U&&p==4U&&frame==0U){*count=2U;return spr_5_4_0;}
 if(a==5U&&p==4U&&frame==1U){*count=3U;return spr_5_4_1;}
 if(a==5U&&p==4U&&frame==2U){*count=2U;return spr_5_4_2;}
 if(a==5U&&p==4U&&frame==3U){*count=2U;return spr_5_4_3;}
 if(a==5U&&p==6U&&frame==0U){*count=2U;return spr_5_6_0;}
 if(a==5U&&p==6U&&frame==1U){*count=3U;return spr_5_6_1;}
 if(a==5U&&p==6U&&frame==2U){*count=2U;return spr_5_6_2;}
 if(a==5U&&p==6U&&frame==3U){*count=2U;return spr_5_6_3;}
 if(a==5U&&p==7U&&frame==0U){*count=2U;return spr_5_7_0;}
 if(a==5U&&p==7U&&frame==1U){*count=3U;return spr_5_7_1;}
 if(a==5U&&p==7U&&frame==2U){*count=2U;return spr_5_7_2;}
 if(a==5U&&p==7U&&frame==3U){*count=2U;return spr_5_7_3;}
 if(a==5U&&p==8U&&frame==0U){*count=2U;return spr_5_8_0;}
 if(a==5U&&p==8U&&frame==1U){*count=3U;return spr_5_8_1;}
 if(a==5U&&p==8U&&frame==2U){*count=2U;return spr_5_8_2;}
 if(a==5U&&p==8U&&frame==3U){*count=2U;return spr_5_8_3;}
 if(a==5U&&p==9U&&frame==0U){*count=2U;return spr_5_9_0;}
 if(a==5U&&p==9U&&frame==1U){*count=3U;return spr_5_9_1;}
 if(a==5U&&p==9U&&frame==2U){*count=2U;return spr_5_9_2;}
 if(a==5U&&p==9U&&frame==3U){*count=2U;return spr_5_9_3;}
 if(a==6U&&p==0U&&frame==0U){*count=2U;return spr_6_0_0;}
 if(a==6U&&p==0U&&frame==1U){*count=3U;return spr_6_0_1;}
 if(a==6U&&p==0U&&frame==2U){*count=2U;return spr_6_0_2;}
 if(a==6U&&p==0U&&frame==3U){*count=2U;return spr_6_0_3;}
 if(a==6U&&p==1U&&frame==0U){*count=2U;return spr_6_1_0;}
 if(a==6U&&p==1U&&frame==1U){*count=3U;return spr_6_1_1;}
 if(a==6U&&p==1U&&frame==2U){*count=3U;return spr_6_1_2;}
 if(a==6U&&p==1U&&frame==3U){*count=2U;return spr_6_1_3;}
 if(a==6U&&p==2U&&frame==0U){*count=2U;return spr_6_2_0;}
 if(a==6U&&p==2U&&frame==1U){*count=3U;return spr_6_2_1;}
 if(a==6U&&p==2U&&frame==2U){*count=2U;return spr_6_2_2;}
 if(a==6U&&p==2U&&frame==3U){*count=2U;return spr_6_2_3;}
 if(a==6U&&p==3U&&frame==0U){*count=2U;return spr_6_3_0;}
 if(a==6U&&p==3U&&frame==1U){*count=3U;return spr_6_3_1;}
 if(a==6U&&p==3U&&frame==2U){*count=2U;return spr_6_3_2;}
 if(a==6U&&p==3U&&frame==3U){*count=2U;return spr_6_3_3;}
 if(a==6U&&p==4U&&frame==0U){*count=2U;return spr_6_4_0;}
 if(a==6U&&p==4U&&frame==1U){*count=3U;return spr_6_4_1;}
 if(a==6U&&p==4U&&frame==2U){*count=2U;return spr_6_4_2;}
 if(a==6U&&p==4U&&frame==3U){*count=2U;return spr_6_4_3;}
 if(a==6U&&p==5U&&frame==0U){*count=2U;return spr_6_5_0;}
 if(a==6U&&p==5U&&frame==1U){*count=3U;return spr_6_5_1;}
 if(a==6U&&p==5U&&frame==2U){*count=2U;return spr_6_5_2;}
 if(a==6U&&p==5U&&frame==3U){*count=2U;return spr_6_5_3;}
 if(a==6U&&p==7U&&frame==0U){*count=2U;return spr_6_7_0;}
 if(a==6U&&p==7U&&frame==1U){*count=3U;return spr_6_7_1;}
 if(a==6U&&p==7U&&frame==2U){*count=2U;return spr_6_7_2;}
 if(a==6U&&p==7U&&frame==3U){*count=2U;return spr_6_7_3;}
 if(a==6U&&p==8U&&frame==0U){*count=2U;return spr_6_8_0;}
 if(a==6U&&p==8U&&frame==1U){*count=3U;return spr_6_8_1;}
 if(a==6U&&p==8U&&frame==2U){*count=2U;return spr_6_8_2;}
 if(a==6U&&p==8U&&frame==3U){*count=2U;return spr_6_8_3;}
 if(a==6U&&p==9U&&frame==0U){*count=2U;return spr_6_9_0;}
 if(a==6U&&p==9U&&frame==1U){*count=3U;return spr_6_9_1;}
 if(a==6U&&p==9U&&frame==2U){*count=2U;return spr_6_9_2;}
 if(a==6U&&p==9U&&frame==3U){*count=2U;return spr_6_9_3;}
 if(a==7U&&p==0U&&frame==0U){*count=2U;return spr_7_0_0;}
 if(a==7U&&p==0U&&frame==1U){*count=3U;return spr_7_0_1;}
 if(a==7U&&p==0U&&frame==2U){*count=2U;return spr_7_0_2;}
 if(a==7U&&p==0U&&frame==3U){*count=2U;return spr_7_0_3;}
 if(a==7U&&p==1U&&frame==0U){*count=2U;return spr_7_1_0;}
 if(a==7U&&p==1U&&frame==1U){*count=3U;return spr_7_1_1;}
 if(a==7U&&p==1U&&frame==2U){*count=2U;return spr_7_1_2;}
 if(a==7U&&p==1U&&frame==3U){*count=2U;return spr_7_1_3;}
 if(a==7U&&p==2U&&frame==0U){*count=2U;return spr_7_2_0;}
 if(a==7U&&p==2U&&frame==1U){*count=3U;return spr_7_2_1;}
 if(a==7U&&p==2U&&frame==2U){*count=2U;return spr_7_2_2;}
 if(a==7U&&p==2U&&frame==3U){*count=2U;return spr_7_2_3;}
 if(a==7U&&p==3U&&frame==0U){*count=2U;return spr_7_3_0;}
 if(a==7U&&p==3U&&frame==1U){*count=3U;return spr_7_3_1;}
 if(a==7U&&p==3U&&frame==2U){*count=2U;return spr_7_3_2;}
 if(a==7U&&p==3U&&frame==3U){*count=2U;return spr_7_3_3;}
 if(a==7U&&p==4U&&frame==0U){*count=2U;return spr_7_4_0;}
 if(a==7U&&p==4U&&frame==1U){*count=3U;return spr_7_4_1;}
 if(a==7U&&p==4U&&frame==2U){*count=2U;return spr_7_4_2;}
 if(a==7U&&p==4U&&frame==3U){*count=2U;return spr_7_4_3;}
 if(a==7U&&p==5U&&frame==0U){*count=2U;return spr_7_5_0;}
 if(a==7U&&p==5U&&frame==1U){*count=3U;return spr_7_5_1;}
 if(a==7U&&p==5U&&frame==2U){*count=2U;return spr_7_5_2;}
 if(a==7U&&p==5U&&frame==3U){*count=2U;return spr_7_5_3;}
 if(a==7U&&p==6U&&frame==0U){*count=2U;return spr_7_6_0;}
 if(a==7U&&p==6U&&frame==1U){*count=3U;return spr_7_6_1;}
 if(a==7U&&p==6U&&frame==2U){*count=2U;return spr_7_6_2;}
 if(a==7U&&p==6U&&frame==3U){*count=2U;return spr_7_6_3;}
 if(a==7U&&p==8U&&frame==0U){*count=2U;return spr_7_8_0;}
 if(a==7U&&p==8U&&frame==1U){*count=3U;return spr_7_8_1;}
 if(a==7U&&p==8U&&frame==2U){*count=2U;return spr_7_8_2;}
 if(a==7U&&p==8U&&frame==3U){*count=2U;return spr_7_8_3;}
 if(a==7U&&p==9U&&frame==0U){*count=2U;return spr_7_9_0;}
 if(a==7U&&p==9U&&frame==1U){*count=3U;return spr_7_9_1;}
 if(a==7U&&p==9U&&frame==2U){*count=2U;return spr_7_9_2;}
 if(a==7U&&p==9U&&frame==3U){*count=2U;return spr_7_9_3;}
 if(a==8U&&p==0U&&frame==0U){*count=2U;return spr_8_0_0;}
 if(a==8U&&p==0U&&frame==1U){*count=3U;return spr_8_0_1;}
 if(a==8U&&p==0U&&frame==2U){*count=2U;return spr_8_0_2;}
 if(a==8U&&p==0U&&frame==3U){*count=2U;return spr_8_0_3;}
 if(a==8U&&p==1U&&frame==0U){*count=2U;return spr_8_1_0;}
 if(a==8U&&p==1U&&frame==1U){*count=3U;return spr_8_1_1;}
 if(a==8U&&p==1U&&frame==2U){*count=2U;return spr_8_1_2;}
 if(a==8U&&p==1U&&frame==3U){*count=2U;return spr_8_1_3;}
 if(a==8U&&p==2U&&frame==0U){*count=2U;return spr_8_2_0;}
 if(a==8U&&p==2U&&frame==1U){*count=3U;return spr_8_2_1;}
 if(a==8U&&p==2U&&frame==2U){*count=2U;return spr_8_2_2;}
 if(a==8U&&p==2U&&frame==3U){*count=2U;return spr_8_2_3;}
 if(a==8U&&p==3U&&frame==0U){*count=2U;return spr_8_3_0;}
 if(a==8U&&p==3U&&frame==1U){*count=3U;return spr_8_3_1;}
 if(a==8U&&p==3U&&frame==2U){*count=2U;return spr_8_3_2;}
 if(a==8U&&p==3U&&frame==3U){*count=2U;return spr_8_3_3;}
 if(a==8U&&p==4U&&frame==0U){*count=2U;return spr_8_4_0;}
 if(a==8U&&p==4U&&frame==1U){*count=3U;return spr_8_4_1;}
 if(a==8U&&p==4U&&frame==2U){*count=2U;return spr_8_4_2;}
 if(a==8U&&p==4U&&frame==3U){*count=2U;return spr_8_4_3;}
 if(a==8U&&p==5U&&frame==0U){*count=2U;return spr_8_5_0;}
 if(a==8U&&p==5U&&frame==1U){*count=3U;return spr_8_5_1;}
 if(a==8U&&p==5U&&frame==2U){*count=2U;return spr_8_5_2;}
 if(a==8U&&p==5U&&frame==3U){*count=2U;return spr_8_5_3;}
 if(a==8U&&p==6U&&frame==0U){*count=2U;return spr_8_6_0;}
 if(a==8U&&p==6U&&frame==1U){*count=3U;return spr_8_6_1;}
 if(a==8U&&p==6U&&frame==2U){*count=2U;return spr_8_6_2;}
 if(a==8U&&p==6U&&frame==3U){*count=2U;return spr_8_6_3;}
 if(a==8U&&p==7U&&frame==0U){*count=2U;return spr_8_7_0;}
 if(a==8U&&p==7U&&frame==1U){*count=3U;return spr_8_7_1;}
 if(a==8U&&p==7U&&frame==2U){*count=2U;return spr_8_7_2;}
 if(a==8U&&p==7U&&frame==3U){*count=2U;return spr_8_7_3;}
 if(a==8U&&p==9U&&frame==0U){*count=2U;return spr_8_9_0;}
 if(a==8U&&p==9U&&frame==1U){*count=3U;return spr_8_9_1;}
 if(a==8U&&p==9U&&frame==2U){*count=2U;return spr_8_9_2;}
 if(a==8U&&p==9U&&frame==3U){*count=2U;return spr_8_9_3;}
 if(a==9U&&p==0U&&frame==0U){*count=2U;return spr_9_0_0;}
 if(a==9U&&p==0U&&frame==1U){*count=3U;return spr_9_0_1;}
 if(a==9U&&p==0U&&frame==2U){*count=2U;return spr_9_0_2;}
 if(a==9U&&p==0U&&frame==3U){*count=2U;return spr_9_0_3;}
 if(a==9U&&p==1U&&frame==0U){*count=2U;return spr_9_1_0;}
 if(a==9U&&p==1U&&frame==1U){*count=3U;return spr_9_1_1;}
 if(a==9U&&p==1U&&frame==2U){*count=2U;return spr_9_1_2;}
 if(a==9U&&p==1U&&frame==3U){*count=2U;return spr_9_1_3;}
 if(a==9U&&p==2U&&frame==0U){*count=2U;return spr_9_2_0;}
 if(a==9U&&p==2U&&frame==1U){*count=3U;return spr_9_2_1;}
 if(a==9U&&p==2U&&frame==2U){*count=2U;return spr_9_2_2;}
 if(a==9U&&p==2U&&frame==3U){*count=2U;return spr_9_2_3;}
 if(a==9U&&p==3U&&frame==0U){*count=2U;return spr_9_3_0;}
 if(a==9U&&p==3U&&frame==1U){*count=3U;return spr_9_3_1;}
 if(a==9U&&p==3U&&frame==2U){*count=2U;return spr_9_3_2;}
 if(a==9U&&p==3U&&frame==3U){*count=2U;return spr_9_3_3;}
 if(a==9U&&p==4U&&frame==0U){*count=2U;return spr_9_4_0;}
 if(a==9U&&p==4U&&frame==1U){*count=3U;return spr_9_4_1;}
 if(a==9U&&p==4U&&frame==2U){*count=2U;return spr_9_4_2;}
 if(a==9U&&p==4U&&frame==3U){*count=2U;return spr_9_4_3;}
 if(a==9U&&p==5U&&frame==0U){*count=2U;return spr_9_5_0;}
 if(a==9U&&p==5U&&frame==1U){*count=3U;return spr_9_5_1;}
 if(a==9U&&p==5U&&frame==2U){*count=2U;return spr_9_5_2;}
 if(a==9U&&p==5U&&frame==3U){*count=2U;return spr_9_5_3;}
 if(a==9U&&p==6U&&frame==0U){*count=2U;return spr_9_6_0;}
 if(a==9U&&p==6U&&frame==1U){*count=3U;return spr_9_6_1;}
 if(a==9U&&p==6U&&frame==2U){*count=2U;return spr_9_6_2;}
 if(a==9U&&p==6U&&frame==3U){*count=2U;return spr_9_6_3;}
 if(a==9U&&p==7U&&frame==0U){*count=2U;return spr_9_7_0;}
 if(a==9U&&p==7U&&frame==1U){*count=3U;return spr_9_7_1;}
 if(a==9U&&p==7U&&frame==2U){*count=2U;return spr_9_7_2;}
 if(a==9U&&p==7U&&frame==3U){*count=2U;return spr_9_7_3;}
 if(a==9U&&p==8U&&frame==0U){*count=2U;return spr_9_8_0;}
 if(a==9U&&p==8U&&frame==1U){*count=3U;return spr_9_8_1;}
 if(a==9U&&p==8U&&frame==2U){*count=2U;return spr_9_8_2;}
 if(a==9U&&p==8U&&frame==3U){*count=2U;return spr_9_8_3;}
 *count=0;return 0;
}
#endif
