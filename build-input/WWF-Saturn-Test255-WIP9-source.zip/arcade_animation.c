#include "arcade_animation.h"
#include "arcade_animation_data.h"
void arcade_animation_reset(arcade_animation_clock_t *c,const arcade_animation_t *a){
 c->frame=0;c->finished=a->count==0;c->remaining=a->count?arcade_animation_frames[a->first].duration:0;
}
void arcade_animation_tick(arcade_animation_clock_t *c,const arcade_animation_t *a){
 if(c->finished||!a->count||c->remaining==0xff00)return;
 if(c->remaining){--c->remaining;return;}
 if(++c->frame==a->count){
  if(a->kind==2)c->frame=0;
  else{c->frame=a->count-1;c->finished=true;return;}
 }
 c->remaining=arcade_animation_frames[a->first+c->frame].duration;
}
uint16_t arcade_animation_pose(const arcade_animation_clock_t *c,const arcade_animation_t *a){
 return a->count&&c->frame<a->count?arcade_animation_frames[a->first+c->frame].pose:0xffff;
}
uint16_t arcade_animation_sample(uint32_t address,uint32_t elapsed){
 const arcade_animation_t *a=0;
 for(unsigned i=0;i<ARCADE_ANIMATION_COUNT;i++)if(arcade_animations[i].rom_address==address){a=&arcade_animations[i];break;}
 if(!a||!a->count)return 0xffff;
 uint32_t period=0;bool indefinite=false;
 for(unsigned i=0;i<a->count;i++){
  unsigned d=arcade_animation_frames[a->first+i].duration;
  if(d==0xff00){indefinite=true;break;}
  period+=d+1U;
 }
 if(a->kind==2&&!indefinite&&period)elapsed%=period;
 for(unsigned i=0;i<a->count;i++){
  const arcade_animation_frame_t *f=&arcade_animation_frames[a->first+i];
  if(f->duration==0xff00||elapsed<=f->duration)return f->pose;
  elapsed-=f->duration+1U;
 }
 return arcade_animation_frames[a->first+a->count-1].pose;
}

uint32_t arcade_animation_finite_ticks(uint32_t address){
 const arcade_animation_t *a=0;
 for(unsigned i=0;i<ARCADE_ANIMATION_COUNT;i++)if(arcade_animations[i].rom_address==address){a=&arcade_animations[i];break;}
 if(!a||!a->count)return 0;
 uint32_t total=0;
 for(unsigned i=0;i<a->count;i++){
  unsigned d=arcade_animation_frames[a->first+i].duration;
  if(d==0xff00)return 0;
  total+=d+1U;
 }
 return total;
}

uint32_t arcade_action_descriptor_address(unsigned raw_action){
 if(raw_action>=sizeof(arcade_action_animations)/sizeof(arcade_action_animations[0]))return 0;
 unsigned i=arcade_action_animations[raw_action];return i<ARCADE_ANIMATION_COUNT?arcade_animations[i].rom_address:0;
}
uint32_t arcade_action_callback_address(unsigned raw_action){
 if(raw_action>=sizeof(arcade_action_animations)/sizeof(arcade_action_animations[0]))return 0;
 unsigned i=arcade_action_animations[raw_action];return i<ARCADE_ANIMATION_COUNT?arcade_animations[i].callback_address:0;
}
