#ifndef WWF_RENDER_POSE_H
#define WWF_RENDER_POSE_H
#include "game.h"
#include "roster_data.h"
#include "finisher_assets.h"
typedef struct {unsigned frame;int lift;bool mirror;} render_pose_t;
static inline bool render_pose_registered_fallback(const fighter_t *f,unsigned raw){
    (void)f;(void)raw;
    /* Test252 audit: the complete former Test212 registry is now covered by
     * ROM-exact resident art, Gxy partner overlays, or OBJ15.PAK.  Keep this
     * hook fail-closed so a newly discovered unmapped raw pose trips CHECK324
     * instead of silently substituting legacy native art. */
    return false;
}

/* Same frame choice for the Saturn command emitter and software layer audit. */
static inline render_pose_t render_fighter_pose(const fighter_t *f){
    render_pose_t p={.lift=game_fighter_lift(f),.mirror=f->facing<0};
    int original=game_arcade_pose(f);
    if(original>=0){
        unsigned frame=roster_arcade_frame_character(f->character,(unsigned)original&0x7fff);
        if(frame<ROSTER_FRAMES){p.frame=frame;p.mirror^=(original&0x8000)!=0;p.lift=0;return p;}
        /* Test252: any ROM pose not in the resident Cxx atlas must have been
         * intercepted by an exact composition renderer (Fxx/Gxy/OBJ15) before
         * reaching this helper.  Anything else fails closed with CHECK324. */
        if(!render_pose_registered_fallback(f,(unsigned)original&0x7fffU)){p.frame=ROSTER_FRAMES;return p;}
    }
    if(f->state==ST_TOSSED)p.frame=EXTRA_FIRST+12+(f->tick/12)%4;
    else if(f->state==ST_RING_EXIT||f->state==ST_RING_ENTER){unsigned t=f->state==ST_RING_ENTER?47-f->tick:f->tick;p.frame=EXTRA_FIRST+4+(t/7)%7;}
    else if(f->state>=ST_CLIMB&&f->state<=ST_LAND)p.frame=roster_parts[0][game_pose(f)][0];
    else {unsigned role=game_animation_role(f);p.frame=roster_parts[role][game_pose(f)][role];}
    return p;
}
#endif
