#pragma once
#include "game.h"
enum { MATCH_HISTORY_CAPACITY=8 };
typedef struct {unsigned character,health,hits,attacks;} match_fighter_result_t;
typedef struct {
 unsigned mode,reason,roster_count,starting_roster[6];
 int winner;
 unsigned elapsed_ticks,time_left,tags,rescues,blocks,throws,eliminated;
 match_fighter_result_t fighters[6];
} match_result_t;
typedef struct {match_result_t records[MATCH_HISTORY_CAPACITY];unsigned next,count;} match_history_t;
bool match_result_capture(match_result_t *result,const game_t *game);
bool match_history_record(match_history_t *history,const game_t *game);
const match_result_t *match_history_recent(const match_history_t *history,unsigned age);
void match_result_retry_roster(const match_result_t *result,unsigned characters[6]);
const char *match_result_reason(const match_result_t *result);
