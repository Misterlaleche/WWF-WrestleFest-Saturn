#ifndef WWF_CAMPAIGN_RUNTIME_H
#define WWF_CAMPAIGN_RUNTIME_H
#include "campaign.h"
#include "game.h"
/* Host-testable bridge between tournament progression and one native match. */
void campaign_prepare_roster(const campaign_t *c,unsigned characters[6],unsigned roll_first,unsigned roll_second);
void campaign_start_game(const campaign_t *c,game_t *g,unsigned characters[6],unsigned roll_first,unsigned roll_second);
void campaign_restart_game(const campaign_t *c,game_t *g,const unsigned characters[6]);
/* Capture the human team by character identity, apply Clear Stage Power Up,
 * then advance campaign state. Returns true when another match remains. */
bool campaign_commit_win(campaign_t *c,const game_t *g);
#endif
