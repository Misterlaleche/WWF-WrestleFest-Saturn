#include "arcade_ai.h"

static const uint8_t distance_mid[12]={8,14,5,7,16,10,3,12,7,8,10,12};
static const uint8_t distance_far[12]={20,30,15,20,35,25,10,25,12,18,25,22};

unsigned arcade_ai_weighted_choice(const uint8_t *weights,unsigned roll_0_99){
 unsigned roll=roll_0_99%100U;
 if(roll==0)roll=1;
 unsigned total=0,index=0;
 do{total+=weights[index];if(total>=roll)return index;++index;}while(index<256U);
 return 255U;
}
unsigned arcade_ai_distance_gate_weight(unsigned character,int far_gate){
 if(character>11)character=0;
 return far_gate?distance_far[character]:distance_mid[character];
}


bool arcade_ai_state0_enter_approach(unsigned character,unsigned raw_distance,unsigned roll_0_99){
 if(raw_distance<0xc8U)return false;
 unsigned w=arcade_ai_distance_gate_weight(character,raw_distance>=0xe0U);
 unsigned roll=roll_0_99%100U;if(roll==0)roll=1;
 return roll<=w;
}
unsigned arcade_ai_state2_range_transition(unsigned current_distance,unsigned desired_distance,bool alternate_branch){
 if(!desired_distance||current_distance>desired_distance)return 2U;
 return alternate_branch?5U:3U;
}

unsigned arcade_ai_stamina_bucket(unsigned raw_stamina){
 if(raw_stamina==0)return 8U;
 if(raw_stamina>=0x80U)return 0U;
 if(raw_stamina>=0x65U)return 1U;
 if(raw_stamina>=0x50U)return 2U;
 if(raw_stamina>=0x40U)return 3U;
 if(raw_stamina>=0x25U)return 4U;
 return 5U;
}
bool arcade_ai_stamina_gate_match(unsigned raw_stamina,unsigned raw_109){
 return (raw_109&0xffU)==arcade_ai_stamina_bucket(raw_stamina);
}

bool arcade_ai_stamina_gate_transition(unsigned raw_stamina,unsigned raw_109,unsigned raw_61,
                                       uint8_t *raw_state20_low,uint16_t *raw_60){
 if(!arcade_ai_stamina_gate_match(raw_stamina,raw_109))return false;
 if(raw_state20_low)*raw_state20_low=0;
 if(raw_60)*raw_60=(raw_61==0x4aU||raw_61==0x64U)?0x004bU:0x0056U;
 return true;
}
