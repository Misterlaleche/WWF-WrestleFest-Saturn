#include "intro.h"
#include <string.h>
void intro_reset(intro_t *intro)
{
    memset(intro,0,sizeof(*intro));intro->screen=INTRO_WARNING;
    /* A button held during boot must first be released. */
    intro->start_down=true;
}
bool intro_tick(intro_t *intro,bool down)
{
    bool edge=down&&!intro->start_down;intro->start_down=down;
    if(intro->screen>=INTRO_GAME)return false;
    unsigned limit=intro->screen==INTRO_TITLE?INTRO_TITLE_TICKS:INTRO_PLATE_TICKS;
    if(edge||++intro->elapsed>=limit){
        intro->demo=intro->screen==INTRO_TITLE&&!edge;
        intro->screen++;intro->blink=0;intro->elapsed=0;return true;
    }
    intro->blink=(intro->blink+1)%60;
    return false;
}
bool intro_prompt_visible(const intro_t *intro)
{
    return intro->screen==INTRO_TITLE&&intro->blink<42;
}
bool intro_unpack(const uint8_t *src,size_t size,uint8_t *dst,size_t capacity)
{
    if(!src||!dst)return false;
    size_t in=0,out=0;
    while(in<size) {
        unsigned tag=src[in++];size_t count=(tag&127U)+1;
        if(count>capacity-out)return false;
        if(tag&128U) {
            if(in==size)return false;
            memset(dst+out,src[in++],count);
        } else {
            if(count>size-in)return false;
            memcpy(dst+out,src+in,count);in+=count;
        }
        out+=count;
    }
    return out==capacity;
}
