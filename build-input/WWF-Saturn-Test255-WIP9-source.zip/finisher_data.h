#ifndef WWF_FINISHER_DATA_H
#define WWF_FINISHER_DATA_H
#include <stdbool.h>
#include <stdint.h>
#include "arcade_animation.h"
#include "finisher_assets.h"

/* Trademark identities are ordered exactly like the ten selectable Saturn
 * roster slots.  The descriptor mapping below is deliberately evidence
 * graded: conditions/names come from the documented arcade move set, while
 * descriptor candidates are tied to ROM addresses and character-exclusive
 * pose families recovered from the user's program data. */
typedef enum {
 FINISHER_HOGAN_LEGDROP,
 FINISHER_WARRIOR_GORILLA_PRESS,
 FINISHER_JAKE_DDT,
 FINISHER_BOSSMAN_SLAM,
 FINISHER_SMASH_SUPLEX,
 FINISHER_CRUSH_BACKBREAKER,
 FINISHER_SLAUGHTER_COBRA_CLUTCH,
 FINISHER_PERFECT_PLEX,
 FINISHER_EARTHQUAKE_SPLASH,
 FINISHER_DIBIASE_MILLION_DOLLAR_DREAM,
 FINISHER_COUNT
} finisher_id_t;

typedef enum {
 FINISHER_COND_UNMAPPED,
 FINISHER_COND_GRAPPLE,
 FINISHER_COND_PRONE_DIAGONAL,
 FINISHER_COND_OPPONENT_RUNNING,
 FINISHER_COND_BEHIND
} finisher_condition_t;

typedef enum {
 FINISHER_EVIDENCE_IDENTITY_ONLY,
 FINISHER_EVIDENCE_CANDIDATE,
 FINISHER_EVIDENCE_HIGH_CONFIDENCE
} finisher_evidence_t;

typedef struct {
 finisher_id_t id;
 uint8_t character;
 finisher_condition_t condition;
 finisher_evidence_t evidence;
 uint16_t descriptor_index;
 uint16_t action_index;
 uint32_t rom_address;
 uint32_t callback_address;
 const uint16_t *poses;
 const uint16_t *durations;
 uint8_t pose_count;
 uint8_t partner_dependent_poses;
 uint8_t damage;
 uint8_t damage_exact;
 const char *name;
} finisher_record_t;

#define FINISHER_DESCRIPTOR_UNMAPPED 0xffffU
#define FINISHER_ACTION_UNMAPPED 0xffffU

/* V0.029 descriptor/overlay mapping.  These are visual-clock descriptors from
 * the user's original WrestleFest program ROM.  The first four were audited in
 * V0.028; the remaining six are now mapped to character-specific composition
 * families and stored in on-demand Fxx.PAK overlays.  Callback semantics and
 * six impact values are now callback-verified; hold/candidate damage remains
 * explicitly provisional until its repeated/indirect callback semantics close. */
static const uint16_t finisher_hogan_poses[]={132,133,230,231,232};
static const uint16_t finisher_hogan_durations[]={8,20,16,0xff00,16};
static const uint16_t finisher_warrior_poses[]={263,264,272,526,527,0};
static const uint16_t finisher_warrior_durations[]={6,10,8,24,16,56};
static const uint16_t finisher_jake_poses[]={144,145,312,313,314,315,316,317,104};
static const uint16_t finisher_jake_durations[]={8,9,10,8,8,0xff00,16,16,40};
static const uint16_t finisher_bossman_poses[]={194,195,196,197,198,199,200,201};
static const uint16_t finisher_bossman_durations[]={32,4,4,4,4,0xff00,8,28};
static const uint16_t finisher_smash_poses[]={334,335,336,337};
static const uint16_t finisher_smash_durations[]={16,16,0xff00,32};
static const uint16_t finisher_crush_poses[]={269,452,453,454,455};
static const uint16_t finisher_crush_durations[]={24,16,16,12,12};
static const uint16_t finisher_slaughter_poses[]={411,412,413,414,415};
static const uint16_t finisher_slaughter_durations[]={8,12,32,24,24};
static const uint16_t finisher_perfect_poses[]={324,325,326,327,328};
static const uint16_t finisher_perfect_durations[]={12,8,10,10,12};
static const uint16_t finisher_quake_poses[]={470,471};
static const uint16_t finisher_quake_durations[]={0xff00,16};
static const uint16_t finisher_dibiase_poses[]={248,299,300,301};
static const uint16_t finisher_dibiase_durations[]={8,16,20,20};

static const finisher_record_t finisher_records[FINISHER_COUNT]={
 {FINISHER_HOGAN_LEGDROP,0,FINISHER_COND_PRONE_DIAGONAL,FINISHER_EVIDENCE_HIGH_CONFIDENCE,
  64,53,0x175a8,0x175c4,finisher_hogan_poses,finisher_hogan_durations,5,0,18,1,"LEGDROP"},
 {FINISHER_WARRIOR_GORILLA_PRESS,1,FINISHER_COND_GRAPPLE,FINISHER_EVIDENCE_HIGH_CONFIDENCE,
  58,47,0x16c5e,0x16c9e,finisher_warrior_poses,finisher_warrior_durations,6,4,22,1,"GORILLA PRESS"},
 {FINISHER_JAKE_DDT,2,FINISHER_COND_GRAPPLE,FINISHER_EVIDENCE_HIGH_CONFIDENCE,
  63,52,0x1747e,0x174aa,finisher_jake_poses,finisher_jake_durations,9,7,28,1,"DDT"},
 {FINISHER_BOSSMAN_SLAM,3,FINISHER_COND_OPPONENT_RUNNING,FINISHER_EVIDENCE_HIGH_CONFIDENCE,
  60,49,0x16fd8,0x17000,finisher_bossman_poses,finisher_bossman_durations,8,5,22,1,"BOSS MAN SLAM"},
 {FINISHER_SMASH_SUPLEX,4,FINISHER_COND_GRAPPLE,FINISHER_EVIDENCE_HIGH_CONFIDENCE,
  51,40,0x1641e,0x16436,finisher_smash_poses,finisher_smash_durations,4,4,18,1,"SUPLEX"},
 {FINISHER_CRUSH_BACKBREAKER,5,FINISHER_COND_GRAPPLE,FINISHER_EVIDENCE_HIGH_CONFIDENCE,
  141,137,0x1aba4,0x1abc0,finisher_crush_poses,finisher_crush_durations,5,5,42,0,"BACK-BREAKER"},
 {FINISHER_SLAUGHTER_COBRA_CLUTCH,6,FINISHER_COND_BEHIND,FINISHER_EVIDENCE_HIGH_CONFIDENCE,
  70,59,0x17cf6,0x17d12,finisher_slaughter_poses,finisher_slaughter_durations,5,5,38,0,"COBRA CLUTCH"},
 {FINISHER_PERFECT_PLEX,7,FINISHER_COND_GRAPPLE,FINISHER_EVIDENCE_HIGH_CONFIDENCE,
  38,26,0x1520c,0x15228,finisher_perfect_poses,finisher_perfect_durations,5,5,22,1,"PERFECT PLEX"},
 {FINISHER_EARTHQUAKE_SPLASH,8,FINISHER_COND_PRONE_DIAGONAL,FINISHER_EVIDENCE_CANDIDATE,
  46,35,0x15ce0,0x15d08,finisher_quake_poses,finisher_quake_durations,2,0,44,0,"VERTICAL SPLASH"},
 {FINISHER_DIBIASE_MILLION_DOLLAR_DREAM,9,FINISHER_COND_BEHIND,FINISHER_EVIDENCE_HIGH_CONFIDENCE,
  65,54,0x17912,0x1792a,finisher_dibiase_poses,finisher_dibiase_durations,4,4,38,0,"MILLION DOLLAR DREAM"}
};

static inline finisher_id_t finisher_for_character(unsigned ch){return (finisher_id_t)(ch<FINISHER_COUNT?ch:0);}
static inline const finisher_record_t *finisher_record(unsigned ch){return &finisher_records[ch<FINISHER_COUNT?ch:0];}
static inline bool finisher_descriptor_mapped(unsigned ch){const finisher_record_t *r=finisher_record(ch);return r->descriptor_index!=FINISHER_DESCRIPTOR_UNMAPPED&&r->evidence==FINISHER_EVIDENCE_HIGH_CONFIDENCE;}
/* Generated V0.028 banks contain exact original compositions for this first
 * batch. Unmapped trademark identities remain gated. */
static inline bool finisher_graphics_ready(unsigned ch){return ch<FINISHER_COUNT&&finisher_overlay_bytes[ch]>0&&finisher_asset_phase_count(ch)>0;}
static inline unsigned finisher_damage_value(unsigned ch){return finisher_record(ch)->damage;}
static inline bool finisher_damage_exact(unsigned ch){return finisher_record(ch)->damage_exact!=0;}

/* Test145: the Cobra Clutch and Million Dollar Dream callbacks each write
 * exactly 5 to the victim +$68 damage operand immediately before invoking
 * the shared callback at $111C8.  This is an exact per-pulse operand, not a
 * claim about total hold damage or repeat cadence. */
static inline bool finisher_hold_pulse_damage_exact(unsigned ch){return ch==6U||ch==9U;}
static inline unsigned finisher_hold_pulse_damage(unsigned ch){return finisher_hold_pulse_damage_exact(ch)?5U:0U;}

/* This samples the recovered visual clock only.  Callback semantics are still
 * implemented natively by the Saturn port; no M68000 code is executed. */
static inline uint16_t finisher_sequence_pose(unsigned ch,uint32_t elapsed){
 const finisher_record_t *r=finisher_record(ch);
 return r->rom_address?arcade_animation_sample(r->rom_address,elapsed):0xffffU;
}
#endif
