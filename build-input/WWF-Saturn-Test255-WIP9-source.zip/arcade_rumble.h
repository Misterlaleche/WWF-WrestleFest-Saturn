#ifndef WWF_ARCADE_RUMBLE_H
#define WWF_ARCADE_RUMBLE_H
#include <stdbool.h>
#include <stdint.h>

enum {
    ARCADE_RUMBLE_ACTIVE_MAX = 6,
    ARCADE_RUMBLE_ROSTER_TOTAL = 12,
    ARCADE_RUMBLE_ENTRY_DELAY = 0x126
};

typedef struct { uint16_t x,y; } arcade_rumble_raw_pos_t;

/* ROM $10ACC: six simultaneous Royal Rumble actor anchors. */
extern const arcade_rumble_raw_pos_t arcade_rumble_raw_positions[ARCADE_RUMBLE_ACTIVE_MAX];

/* ROM $10AF0/$10B26: scan a six-word occupancy table from index 5 down to 0.
 * Returns -1 when all six entries are nonzero. */
int arcade_rumble_reverse_free_slot(const uint16_t words[ARCADE_RUMBLE_ACTIVE_MAX]);

/* ROM $BB30..$BB7A: pending eliminations are serviced only after 0x126 ticks,
 * and only when fewer than six actors are active.  On a successful service,
 * one pending elimination is consumed. */
bool arcade_rumble_entry_delay_step(unsigned *pending,unsigned *timer,unsigned active_count);

/* ROM $BB80..$BBCx counts live actors by +$56 bit5.  If upper-half actors
 * (IDs 6..11) are fewer than lower-half actors (IDs 0..5), upper is preferred;
 * ties prefer lower. */
unsigned arcade_rumble_preferred_pool(unsigned lower_active,unsigned upper_active);

/* ROM $BC00..$BC66: choose within the preferred six-ID pool, make four random
 * attempts, then fall back to the reverse free scan used by $10AF0/$10B26.
 * If the preferred pool is full, try the other pool.  rolls[] are already
 * normalized to arbitrary integers; the original RNG producer is outside this
 * helper and may remain provisional at the native call site. */
int arcade_rumble_select_entrant(uint16_t used_mask,unsigned lower_active,unsigned upper_active,const unsigned rolls[4]);

#endif
