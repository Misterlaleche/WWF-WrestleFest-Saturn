#pragma once
#include <stdbool.h>
enum {MENU_LEFT=1,MENU_RIGHT=2,MENU_UP=4,MENU_DOWN=8,MENU_OK=16,MENU_BACK=32};
enum {SESSION_MODE,SESSION_SELECT,SESSION_CPU,SESSION_HALL,SESSION_RING,SESSION_ANNOUNCE,SESSION_PLAY};
enum {HALL_TICKS=240,RING_ENTRY_TICKS=240,ANNOUNCE_TICKS=360,TAG_ANNOUNCE_WRESTLER_TICKS=180,TAG_ANNOUNCE_EXIT_TICKS=180,TAG_ANNOUNCE_TICKS=900};
typedef struct {unsigned phase,mode,cursor,count,selected[2],characters[10],tick,previous,confirmed,flash[10],entropy;} session_t;
void session_reset(session_t *s,unsigned held);
bool session_tick(session_t *s,unsigned buttons);
unsigned session_tag_announce_wrestler(const session_t *s);
unsigned session_tag_announce_local_tick(const session_t *s);
int session_tag_presenter_y(const session_t *s);
unsigned session_tag_presenter_pose(const session_t *s);
bool session_tag_presenter_exiting(const session_t *s);
unsigned session_character(const session_t *s);
unsigned session_page(const session_t *s);
unsigned session_cpu_cursor(const session_t *s);
unsigned session_highlight(const session_t *s,unsigned cursor);
void session_entropy_mix(session_t *s,unsigned value);
