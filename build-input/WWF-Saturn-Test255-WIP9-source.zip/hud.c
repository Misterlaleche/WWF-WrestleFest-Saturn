#include "hud.h"
#include "hud_assets.h"
#include "arcade_stamina.h"
#include <string.h>
unsigned hud_health_step(unsigned shown,unsigned target,unsigned ticks){
 if(ticks>128)ticks=128;
 unsigned delta=ticks*2;
 if(shown<target)return target-shown>delta?shown+delta:target;
 return shown-target>delta?shown-delta:target;
}
unsigned hud_bar_tile(unsigned health,unsigned col,unsigned slot,bool lower){
 unsigned full=(health&255)/16,partial=((health&15)/2),fill=col<full?8:col==full?partial:0;
 unsigned tile=fill?((slot&2)?0xaf2:0xad9)+fill:0xb33;
 return tile+(lower?(fill?((slot&2)?14:11):7):0);
}
static void set(hud_cell_t *cells,unsigned x,unsigned y,unsigned tile,unsigned pal){cells[y*40+x]=(hud_cell_t){tile,pal};}
void hud_map(const hud_slot_t s[4],hud_cell_t cells[160]){
 memset(cells,0,160*sizeof(*cells));
 static const unsigned x0[4]={1,10,21,30};
 for(unsigned slot=0;slot<4;slot++){
  unsigned x=x0[slot],ch=s[slot].character%12,id=s[slot].player%4;
  /* Test216 ROM-EXACT identity conversion: HUD portrait tiles/palettes are
   * stored in the arcade internal actor order, not character-select order.
   * Reuse the exact $64CC selection->internal map already pinned by stamina. */
  unsigned portrait=arcade_stamina_internal_id(ch);
  if(s[slot].status==HUD_EMPTY)continue;
  if(s[slot].status==HUD_JOIN){
   for(unsigned y=0;y<2;y++)for(unsigned c=0;c<9;c++)set(cells,x+c,y,0xca3+y*9+c,1);
   for(unsigned y=0;y<2;y++)for(unsigned c=0;c<7;c++)set(cells,x+1+c,y+2,0xcb5+y*7+c,1);
   continue;
  }
  for(unsigned c=0;c<3;c++)set(cells,x+c,0,s[slot].cpu?(unsigned)"CPU"[c]-16:0xb0f+id*9+c,s[slot].cpu?15:1);
  for(unsigned y=0;y<3;y++)for(unsigned c=0;c<3;c++)set(cells,x+c,y+1,0x1d0+portrait*9+y*3+c,s[slot].grayscale?14:2+portrait);
  for(unsigned c=0;c<6;c++){
   unsigned top=0xaaf+c,bottom=(s[slot].status==HUD_WAITING?0xab5:0xac1)+c;
   if(s[slot].message==HUD_BUTTON)top=(id==0?0xaed:id==1?0xb09:id==2?0xb1b:0xb2d)+c;
   /* HUD_NEUTRAL remains accepted for old host fixtures, but all runtime
    * combat panels use the original tile artwork. */
   if(s[slot].message==HUD_NEUTRAL){top=0xaaf+c;}
   set(cells,x+3+c,0,top,1);
   set(cells,x+3+c,1,bottom,1);
   set(cells,x+3+c,2,hud_bar_tile(s[slot].health,c,slot,false),1);
   set(cells,x+3+c,3,hud_bar_tile(s[slot].health,c,slot,true),1);
  }
 }
}
static const uint8_t *tile_data(unsigned code){
 unsigned lo=0,hi=HUD_ASSET_COUNT;
 while(lo<hi){unsigned mid=(lo+hi)/2;if(hud_codes[mid]<code)lo=mid+1;else hi=mid;}
 return lo<HUD_ASSET_COUNT&&hud_codes[lo]==code?hud_tiles[lo]:hud_tiles[0];
}
void hud_pixels(const hud_cell_t cells[160],uint8_t pixels[HUD_BYTES]){
 for(unsigned cy=0;cy<4;cy++)for(unsigned cx=0;cx<40;cx++){
  hud_cell_t c=cells[cy*40+cx];const uint8_t *src=tile_data(c.tile);
  for(unsigned y=0;y<8;y++)for(unsigned x=0;x<8;x++){
   unsigned p=src[y*8+x];pixels[(cy*8+y)*320+cx*8+x]=p?(c.palette*16+p):0;
  }
 }
}
void hud_palettes(uint16_t colors[256]){memcpy(colors,hud_colors,sizeof(hud_colors));}

void hud_tag_slots(const unsigned characters[4],const unsigned health[4],hud_slot_t slots[4]){
 static const unsigned who[4]={0,2,1,3};
 for(unsigned slot=0;slot<4;slot++){
  unsigned fighter=who[slot];
  bool reserve=fighter>=2,cpu=(fighter&1U)!=0;
  slots[slot]=(hud_slot_t){.character=characters[fighter],.health=health[fighter],
   .player=cpu?1U:0U,.status=reserve?HUD_WAITING:HUD_ACTIVE,
   .message=(!cpu&&!reserve)?HUD_BUTTON:HUD_NEUTRAL,.grayscale=false,.cpu=cpu};
 }
}

