#include "wf_music_cdda.h"
#include <yaul.h>

/* libyaul's execute routine is internal but exported; this structure is ABI-identical
   to cd_block_regs_t in the pinned Yaul used by the project. */
typedef struct {
 uint16_t dtr,hirq,hirq_mask,cr1,cr2,cr3,cr4;
} wf_cd_regs_t;
extern int cd_block_cmd_execute(wf_cd_regs_t *regs,wf_cd_regs_t *status);

static const wf_music_cdda_entry_t music[0x13]={
 {0u,0u,0u},
 {2u,14u,4875u},
 {3u,14u,4125u},
 {4u,14u,3750u},
 {5u,14u,39000u},
 {6u,0u,300u},
 {7u,14u,45000u},
 {8u,14u,3000u},
 {9u,0u,225u},
 {10u,0u,600u},
 {11u,14u,45000u},
 {12u,14u,22500u},
 {13u,14u,42750u},
 {14u,14u,1875u},
 {15u,14u,2400u},
 {16u,14u,45750u},
 {17u,14u,750u},
 {18u,0u,11250u},
 {19u,14u,3375u}
};
static uint8_t current_cmd;

const wf_music_cdda_entry_t *wf_music_cdda_entry(uint8_t c){
 if(c>=0x13u||music[c].track==0u)return 0;
 return &music[c];
}
bool wf_music_cdda_play(uint8_t c){
 const wf_music_cdda_entry_t *m=wf_music_cdda_entry(c);
 if(!m)return false;
 if(current_cmd==c)return true;

 volatile uint16_t *hirq=(volatile uint16_t *)0x25890008UL;
 *hirq=(uint16_t)(*hirq & (uint16_t)~(0x0010u|0x0004u));
 *hirq=(uint16_t)(*hirq | 0x0001u);

 wf_cd_regs_t r={0},s={0};
 /* Start Position in TRACK mode:
    CR2 high byte = track number, low byte = index 1.
    End Position in relative-FAD mode: bit23 set plus sector count.
    Play mode high byte = hardware repeat count. */
 r.hirq_mask=0;
 r.cr1=0x1000u;
 r.cr2=(uint16_t)(((uint16_t)m->track<<8)|1u);
 r.cr3=(uint16_t)(((uint16_t)m->repeat_count<<8)|0x0080u|
                  ((m->audio_sectors>>16)&0x007Fu));
 r.cr4=(uint16_t)(m->audio_sectors&0xFFFFu);
 if(cd_block_cmd_execute(&r,&s)!=0)return false;
 current_cmd=c;return true;
}
void wf_music_cdda_stop(void){
 (void)cd_block_cmd_disk_seek(150u);
 current_cmd=0;
}
uint8_t wf_music_cdda_current(void){return current_cmd;}
