#ifndef WWF_ARCADE_AI_H
#define WWF_ARCADE_AI_H
#include <stdint.h>
#include <stdbool.h>

/* Program ROM $24CC: weighted byte-table selector. The random source is
 * normalized to 1..99 by the original routine before weights are accumulated. */
unsigned arcade_ai_weighted_choice(const uint8_t *weights,unsigned roll_0_99);

/* Program ROM $1F318-$1F3D6: two 12-wrestler weighted gates selected by raw
 * horizontal distance.  These expose the exact first-choice percentages only;
 * their native Saturn distance transform is intentionally not guessed. */
unsigned arcade_ai_distance_gate_weight(unsigned character,int far_gate);

/* Test131: state-0 distance policy. For raw horizontal distance below $C8 the
 * weighted state-2 transition is not consulted. $C8..$DF uses the mid table
 * and >=$E0 uses the far table. Returns true when bucket zero is selected. */
bool arcade_ai_state0_enter_approach(unsigned character,unsigned raw_distance,unsigned roll_0_99);

/* Test132: raw state 2 is a distance-closing/engagement state. At $1D8F8
 * desired distance +$BC is compared with current +$B0; while current is
 * larger the actor stays in state 2. Once current <= desired, prior +$B7 bit0
 * selects state 5, otherwise state 3. */
unsigned arcade_ai_state2_range_transition(unsigned current_distance,unsigned desired_distance,bool alternate_branch);


/* Test138: ROM $1E48C-$1E4D8 classifies actor stamina +$66 into the exact
 * byte written at +$BD.  Zero is a dedicated bucket 8. */
unsigned arcade_ai_stamina_bucket(unsigned raw_stamina);
/* Test139: $1E45C-$1E464 compares actor +$109 against the +$BD result from
 * the classifier.  This exposes the exact predicate only; +$109 semantics
 * remain deliberately unnamed until its producer is proven. */
bool arcade_ai_stamina_gate_match(unsigned raw_stamina,unsigned raw_109);

/* Test144: ROM $1E45C-$1E48A.  On an exact +$109 == +$BD match the
 * low byte of raw state +$20 is cleared and +$60 becomes $004B only for
 * raw +$61 values $4A/$64, otherwise $0056.  Names remain deliberately raw. */
bool arcade_ai_stamina_gate_transition(unsigned raw_stamina,unsigned raw_109,unsigned raw_61,
                                       uint8_t *raw_state20_low,uint16_t *raw_60);

#endif
