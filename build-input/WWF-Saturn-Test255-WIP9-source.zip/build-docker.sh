#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
image='ijacquez/yaul@sha256:b6d272204767cd0a734139dd3a2ab298ef5912fb7b7224b78e6d9fac1a7825a6'
docker run --rm --platform linux/amd64 -v "$PWD:/work" -w /work "$image" /bin/bash -lc 'make clean && make'
python3 tools/verify_iso.py .
