#ifndef WF_MUSIC_CDDA_H
#define WF_MUSIC_CDDA_H
#include <stdbool.h>
#include <stdint.h>
typedef struct {
    uint8_t track;
    uint8_t repeat_count;
    uint32_t audio_sectors;
} wf_music_cdda_entry_t;
bool wf_music_cdda_play(uint8_t fm_command);
void wf_music_cdda_stop(void);
uint8_t wf_music_cdda_current(void);
const wf_music_cdda_entry_t *wf_music_cdda_entry(uint8_t fm_command);
#endif
