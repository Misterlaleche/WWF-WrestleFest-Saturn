#include "arcade_pair_state.h"
bool arcade_pair29_apply_terminal(arcade_pair29_state_t *s,unsigned a1c,unsigned a25){
 if(!s)return false;
 if(!(a1c&0x80U)){
  s->attacker_44&=~0x80U;s->target_44|=0x80U;s->target_state=0xffU;return true;
 }
 if(a25!=0xfeU)return false;
 s->target_68=1U;s->target_c7=(s->target_c7+1U)&0xffU;s->target_54=0x100U;s->target_52=(s->target_52+1U)&0xffffU;
 if(s->target_52<2U){s->attacker_state=0x0bU;s->target_state=0x0bU;s->attacker_44=0;s->target_44=0x8000U;}
 else {s->attacker_state=0x0cU;s->attacker_44=0x2000U;s->target_state=0xffU;s->target_44=0;}
 return true;
}
