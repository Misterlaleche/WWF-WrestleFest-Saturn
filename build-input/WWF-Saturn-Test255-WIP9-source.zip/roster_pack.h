#pragma once
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

enum { ROSTER_TILE_BYTES=128, ROSTER_MAX_BLOCK_TILES=32,
       ROSTER_BLOCK_BYTES=ROSTER_TILE_BYTES*ROSTER_MAX_BLOCK_TILES,
       ROSTER_CACHE_BLOCKS=4 };
#define ROSTER_MAGIC_RAW 0x57464331U
#define ROSTER_MAGIC_BLOCKS 0x57464332U

typedef struct {
    const uint8_t *data;
    size_t size;
    uint32_t magic,frames,records,tiles,texture_offset,blocks,block_tiles;
} roster_pack_t;
typedef struct {
    const uint8_t *owner;
    unsigned block;
    uint8_t bytes[ROSTER_BLOCK_BYTES];
} roster_cache_entry_t;
typedef struct {
    roster_cache_entry_t entries[ROSTER_CACHE_BLOCKS];
    unsigned next,decodes,hits;
} roster_block_cache_t;

/* Validate bounds, all frame/record references, and compressed block directory.
   Does not allocate, DMA from low RAM, or decode the entire texture bank. */
bool roster_pack_open(roster_pack_t *pack,const uint8_t *data,size_t size,
                      unsigned expected_frames);
void roster_pack_cache_reset(roster_block_cache_t *cache);
/* Copies one packed 4bpp tile to the existing high-RAM VDP1 staging buffer. */
bool roster_pack_tile(const roster_pack_t *pack,unsigned tile,uint8_t *output,
                      roster_block_cache_t *cache);
