#ifndef WWF_PRESENTATION_H
#define WWF_PRESENTATION_H
#include <stdint.h>
typedef struct {int x,y,w,h;} ui_rect_t;
/* Measured from the arcade cursor: inclusive bounds 27..114, 35..122. */
static inline ui_rect_t roster_cursor_rect(unsigned cursor)
{
 if(cursor==9)cursor=8; /* Both Demolition identities share the arcade photo. */
 unsigned col=cursor%5,page=col>=3;
 return (ui_rect_t){27-16*(int)page+96*(int)(col-(page?2:0)),35+96*(int)(cursor/5),88,88};
}
static inline unsigned cursor_luminance(unsigned tick)
{
 unsigned t=tick%60;
 return 12+(t<30?t:59-t)*19/29;
}
static inline unsigned hud_fighter(unsigned slot){return (slot%2)*2+slot/2;}
/* Test100 hardware/reference captures: rear reserves are drawn first, then the
 * two legal wrestlers in front. Anchors are Saturn presentation-space values,
 * deliberately separate from gameplay coordinates. */
static inline unsigned tag_announce_fighter(unsigned draw_slot){static const unsigned v[4]={2,3,0,1};return v[draw_slot&3U];}
static inline int tag_announce_x(unsigned fighter){static const int v[4]={98,222,58,262};return v[fighter&3U];}
static inline int tag_announce_y(unsigned fighter){return fighter>=2?166:188;}
/* Royal opening formation reconstructed from Test100 hardware comparison
 * reference: two front wrestlers, two middle/rear, two upper/rear. */
static inline int rumble_intro_x(unsigned fighter){static const int v[6]={96,238,122,266,52,190};return v[fighter%6U];}
static inline int rumble_intro_y(unsigned fighter){static const int v[6]={244,244,210,210,176,176};return v[fighter%6U];}

/* Test222 PROVISIONAL layout cleanup: unlike the old single horizontal row,
 * six Royal entrants are staged as a 3x2 in-ring presentation grid.  Exact
 * arcade coordinates remain pending; these helpers only prevent overlap/off-
 * composition and are not labelled ROM-EXACT. */
static inline int rumble_announce_x(unsigned fighter){static const int v[6]={70,160,250,70,160,250};return v[fighter%6U];}
static inline int rumble_announce_y(unsigned fighter){return fighter<3?164:210;}

/* Replacement announcement overlay. Native layout only; duration/art remain
 * PROVISIONAL pending direct arcade measurement. The state/identity comes
 * from the validated Rumble lifecycle, never from a second presentation queue. */
static inline int rumble_announce_name_x(unsigned name_len){int w=(int)name_len*8;return (320-w)/2;}
static inline int rumble_announce_name_y(void){return 48;}
static inline int rumble_announce_label_x(void){return 108;}
static inline int rumble_announce_label_y(void){return 28;}
static inline void selection_paint(uint8_t *bitmap,unsigned page,const unsigned colors[6],const uint8_t *masks){
 for(unsigned row=0;row<2;row++)for(unsigned col=0;col<3;col++){
  const uint8_t *mask=masks+(page*6+row*3+col)*800;
  for(unsigned i=0;i<6400;i++)if(mask[i/8]&(128>>(i%8)))
   bitmap[(40+row*96+i/80)*512+32-page*16+col*96+i%80]=253+colors[row*3+col];
 }
}
#endif
