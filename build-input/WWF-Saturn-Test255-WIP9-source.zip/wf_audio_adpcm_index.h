#ifndef WF_AUDIO_ADPCM_INDEX_H
#define WF_AUDIO_ADPCM_INDEX_H
#include <stdint.h>
typedef struct {
    uint32_t offset;
    uint16_t adpcm_bytes;
    uint16_t pcm8_bytes;
} wf_adpcm_asset_t;
extern const wf_adpcm_asset_t wf_adpcm_bank0[74];
extern const wf_adpcm_asset_t wf_adpcm_bank1[42];
const wf_adpcm_asset_t *wf_adpcm_asset(unsigned bank,unsigned sample_id);
#endif
