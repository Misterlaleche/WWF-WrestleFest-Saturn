#include "arcade_input.h"
arcade_input_sample_t arcade_input_decode(uint16_t active_low_port,uint8_t prev_buttons){
 arcade_input_sample_t s={0};
 s.activated_low=(uint8_t)(~active_low_port)&0xffu;
 s.direction=s.activated_low&ARCADE_DIRECTION_MASK;
 s.buttons=(s.activated_low>>4)&ARCADE_BUTTON_MASK;
 s.pressed=s.buttons&((uint8_t)~prev_buttons)&ARCADE_BUTTON_MASK;
 return s;
}
