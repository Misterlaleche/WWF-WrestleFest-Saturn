#ifndef WF_AUDIO_SATURN_H
#define WF_AUDIO_SATURN_H
#include <stdbool.h>
#include <stdint.h>
#include "wf_audio_event.h"
typedef enum { WF_AUDIO_BACKEND_DISABLED=0,WF_AUDIO_BACKEND_READY=1,WF_AUDIO_BACKEND_ERROR=2 } wf_audio_backend_state_t;
bool wf_audio_saturn_init(uint32_t pcm_pack_fad);
void wf_audio_saturn_vblank(void *work);
void wf_audio_saturn_emit(wf_audio_event_t event,void *user);
wf_audio_backend_state_t wf_audio_saturn_state(void);
unsigned wf_audio_saturn_last_command(void);
unsigned wf_audio_saturn_cache_misses(void);
#endif
