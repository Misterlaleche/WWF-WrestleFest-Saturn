#ifndef WF_AUDIO_EVENT_H
#define WF_AUDIO_EVENT_H
#include <stdbool.h>
#include <stdint.h>
#include "game.h"

typedef enum {
    WF_AUDIO_CLASS_MUSIC = 0,
    WF_AUDIO_CLASS_SFX = 1
} wf_audio_class_t;

typedef struct {
    uint8_t command;
    uint8_t priority;
    wf_audio_class_t klass;
} wf_audio_event_t;

typedef void (*wf_audio_emit_fn)(wf_audio_event_t event, void *user);

typedef struct {
    unsigned last_ringout_count;
    bool low_stamina_latched;
    bool last_finisher_impact;
    bool stage_music_started;
    unsigned stage_index;
} wf_audio_observer_t;

void wf_audio_observer_reset(wf_audio_observer_t *o, unsigned stage_index);
uint8_t wf_audio_stage_music_command(unsigned stage_index);
void wf_audio_observe_game(wf_audio_observer_t *o, const game_t *g,
                           wf_audio_emit_fn emit, void *user);

#endif
