#include "codec.h"
#include <string.h>
/* Bounded LZ4 block decoder, independently implemented from the block format.
 * No frame wrapper and no unbounded pointer arithmetic on malformed input. */
bool lz4_unpack(const uint8_t *src,size_t size,uint8_t *dst,size_t capacity){
 size_t in=0,out=0;
 while(in<size){
  unsigned token=src[in++];size_t literal=token>>4,match=(token&15)+4;
  if(literal==15){unsigned b;do{if(in>=size)return false;b=src[in++];if(literal>capacity||b>capacity-literal)return false;literal+=b;}while(b==255);}
  if(literal>size-in||literal>capacity-out)return false;
  memcpy(dst+out,src+in,literal);in+=literal;out+=literal;
  if(in==size)return out==capacity;
  if(size-in<2)return false;
  size_t offset=src[in]|((size_t)src[in+1]<<8);in+=2;
  if(!offset||offset>out)return false;
  if((token&15)==15){unsigned b;do{if(in>=size)return false;b=src[in++];if(match>capacity||b>capacity-match)return false;match+=b;}while(b==255);}
  if(match>capacity-out)return false;
  if(offset==1){memset(dst+out,dst[out-1],match);out+=match;}
  else if(offset>=match){memcpy(dst+out,dst+out-offset,match);out+=match;}
  else while(match--){dst[out]=dst[out-offset];++out;}
 }
 return out==capacity;
}
