#include "match_result.h"
#include <string.h>
bool match_result_capture(match_result_t *r,const game_t *g){
 if(!g->finished)return false;
 memset(r,0,sizeof(*r));r->mode=g->mode;r->reason=g->finish_reason;
 r->winner=g->winner;r->roster_count=g->roster_count;r->elapsed_ticks=g->ticks;r->time_left=g->time_left;
 r->tags=g->tags;r->rescues=g->rescues;r->blocks=g->blocks;r->throws=g->throws;r->eliminated=g->eliminated;
 memcpy(r->starting_roster,g->starting_roster,sizeof(r->starting_roster));
 for(unsigned i=0;i<g->roster_count&&i<6;i++){
  const fighter_t *f=&g->fighters[i];
  r->fighters[i]=(match_fighter_result_t){f->character,f->health,g->hits[i],f->attack_serial};
 }
 return true;
}
bool match_history_record(match_history_t *h,const game_t *g){
 if(!g->finished)return false;
 match_result_capture(&h->records[h->next],g);
 h->next=(h->next+1)%MATCH_HISTORY_CAPACITY;if(h->count<MATCH_HISTORY_CAPACITY)++h->count;return true;
}
const match_result_t *match_history_recent(const match_history_t *h,unsigned age){
 if(age>=h->count)return 0;
 return &h->records[(h->next+MATCH_HISTORY_CAPACITY-1-age)%MATCH_HISTORY_CAPACITY];
}
void match_result_retry_roster(const match_result_t *r,unsigned characters[6]){memcpy(characters,r->starting_roster,sizeof(r->starting_roster));}
const char *match_result_reason(const match_result_t *r){
 switch(r->reason){case FINISH_PIN:return "PIN FALL";case FINISH_DOUBLE_KO:return "DOUBLE KO";
 case FINISH_TIME:return "TIME UP";case FINISH_ELIMINATION:return "ELIMINATION";case FINISH_SUBMISSION:return "SUBMISSION";case FINISH_COUNTOUT:return "COUNT OUT";default:return "RESULT";}
}
