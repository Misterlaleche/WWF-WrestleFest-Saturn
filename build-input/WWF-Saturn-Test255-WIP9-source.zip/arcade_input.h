#ifndef WWF_ARCADE_INPUT_H
#define WWF_ARCADE_INPUT_H
#include <stdint.h>
enum {
 ARCADE_PORT_RIGHT=0x01, ARCADE_PORT_LEFT=0x02, ARCADE_PORT_UP=0x04, ARCADE_PORT_DOWN=0x08,
 ARCADE_PORT_BUTTON1=0x10, ARCADE_PORT_BUTTON2=0x20
};
enum { ARCADE_DIRECTION_MASK=0x0f, ARCADE_BUTTON_MASK=0x03 };
typedef struct { uint8_t activated_low,direction,buttons,pressed; } arcade_input_sample_t;
arcade_input_sample_t arcade_input_decode(uint16_t active_low_port,uint8_t prev_buttons);
#endif
