#include "wf_oki_decode.h"
static const int step_table[49]={
16,17,19,21,23,25,28,31,34,37,41,45,50,55,60,66,73,80,88,97,107,118,130,
143,157,173,190,209,230,253,279,307,337,371,408,449,494,544,598,658,724,
796,876,963,1060,1166,1282,1411,1552};
static const int index_shift[8]={-1,-1,-1,-1,2,4,6,8};
size_t wf_oki_decode_pcm8(const uint8_t *src,size_t n,int8_t *dst,size_t cap){
 if(!src||!dst||cap<n*2u)return 0;
 int signal=-2,index=0;size_t out=0;
 for(size_t i=0;i<n;i++){
  for(unsigned half=0;half<2;half++){
   unsigned x=half?(src[i]&15u):(src[i]>>4);
   int step=step_table[index],diff=step>>3;
   if(x&1u)diff+=step>>2;
   if(x&2u)diff+=step>>1;
   if(x&4u)diff+=step;
   signal+=(x&8u)?-diff:diff;
   if(signal<-2048)signal=-2048;
   if(signal>2047)signal=2047;
   index+=index_shift[x&7u];
   if(index<0)index=0;
   if(index>48)index=48;
   int q=signal/16;
   int rem=signal<0?(-signal)%16:signal%16;
   if(rem>8||(rem==8&&((q<0?-q:q)&1)))q+=(signal<0)?-1:1;
   if(q<-128)q=-128;
   if(q>127)q=127;
   dst[out++]=(int8_t)q;
  }
 }
 return out;
}
