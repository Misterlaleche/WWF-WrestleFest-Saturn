#ifndef WWF_AUTOPLAY_H
#define WWF_AUTOPLAY_H
#include "game.h"
/* Native demonstration of the CURRENT engine. Not the original attract AI. */
static inline unsigned autoplay_buttons(const game_t *g){
 const fighter_t *p=&g->fighters[0],*q=&g->fighters[1];
 if(g->pair==PAIR_PIN)return g->pin_attacker?(g->ticks%4==0?INPUT_PUNCH|INPUT_KICK:0):0;
 if(g->pair==PAIR_HOLD){
  /* Exercise the same public combat transitions as a player: sometimes turn
     a captured hold into the new counter, otherwise escape; from an owned
     hold alternate the body slam and the original K -> Irish Whip route. */
  if(g->pair_attacker)return g->pair_tick>=10&&g->pair_tick<=12?INPUT_GRAB:INPUT_PUNCH;
  return ((g->ticks/180)&1)?INPUT_KICK:INPUT_PUNCH;
 }
 if(p->state==ST_CORNER)return INPUT_PUNCH;
 if(p->outside)return INPUT_RING;
 int dx=(q->x-p->x)/256,dy=(q->rise_y-p->y)/256;
 unsigned b=0;
 if(dx>48)b|=INPUT_RIGHT;else if(dx<-48)b|=INPUT_LEFT;
 if(dy>4)b|=INPUT_DOWN;else if(dy<-4)b|=INPUT_UP;
 if(dx>=-70&&dx<=70&&dy>=-8&&dy<=8){
  b|=dx<0?INPUT_LEFT:INPUT_RIGHT;
  if(q->state==ST_DOWN||q->state==ST_RECOVER)b|=INPUT_PIN;
  else if(g->ticks%45==0)b|=(g->ticks/45)%3==0?INPUT_GRAB:INPUT_KICK;
 }
 return b;
}
#endif
