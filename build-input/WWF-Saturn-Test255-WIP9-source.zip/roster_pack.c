#include "roster_pack.h"
#include "codec.h"
#include <string.h>

static uint32_t be32(const uint8_t *p){
    return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3];
}
static unsigned be16(const uint8_t *p){return ((unsigned)p[0]<<8)|p[1];}

bool roster_pack_open(roster_pack_t *out,const uint8_t *data,size_t size,
                      unsigned expected_frames){
    if(!out||!data||size<32)return false;
    roster_pack_t p={.data=data,.size=size,.magic=be32(data),
        .frames=be32(data+4),.records=be32(data+8),.tiles=be32(data+12),
        .texture_offset=be32(data+16),.blocks=be32(data+28),.block_tiles=be32(data+24)};
    if((p.magic!=ROSTER_MAGIC_RAW&&p.magic!=ROSTER_MAGIC_BLOCKS)||
       !p.frames||p.frames!=expected_frames||p.frames>65535||
       p.records>65535||!p.tiles||p.tiles>65535)return false;
    if(p.frames>(size-32)/4)return false;
    size_t records_offset=32+p.frames*4;
    if(p.records>(size-records_offset)/8)return false;
    size_t metadata_end=records_offset+p.records*8;
    if(p.texture_offset<metadata_end||p.texture_offset>size||(p.texture_offset&31))return false;
    for(unsigned i=0;i<p.frames;i++){
        unsigned first=be16(data+32+i*4),count=be16(data+34+i*4);
        if(first>p.records||count>p.records-first)return false;
    }
    for(unsigned i=0;i<p.records;i++){
        const uint8_t *r=data+records_offset+i*8;
        if(be16(r)>=p.tiles||be16(r+6)>3)return false;
    }
    if(p.magic==ROSTER_MAGIC_RAW){
        if(p.block_tiles||p.blocks||p.tiles*128U>size-p.texture_offset)return false;
    }else{
        if((p.block_tiles!=16&&p.block_tiles!=32)||
           p.block_tiles>ROSTER_MAX_BLOCK_TILES||
           p.blocks!=(p.tiles+p.block_tiles-1)/p.block_tiles||
           p.blocks>(size-p.texture_offset)/12)return false;
        size_t previous_end=p.texture_offset+p.blocks*12;
        for(unsigned i=0;i<p.blocks;i++){
            const uint8_t *entry=data+p.texture_offset+i*12;
            uint32_t offset=be32(entry),stored=be32(entry+4),raw=be32(entry+8);
            unsigned remaining=p.tiles-i*p.block_tiles;
            unsigned expected=(remaining<p.block_tiles?remaining:p.block_tiles)*128;
            if(offset<previous_end||offset>size||!stored||stored>size-offset||raw!=expected)return false;
            previous_end=offset+stored;
        }
        if(previous_end!=size)return false;
    }
    *out=p;return true;
}

void roster_pack_cache_reset(roster_block_cache_t *cache){memset(cache,0,sizeof(*cache));}

bool roster_pack_tile(const roster_pack_t *p,unsigned tile,uint8_t *out,
                      roster_block_cache_t *cache){
    if(!p||!out||!cache||!p->data||tile>=p->tiles)return false;
    if(p->magic==ROSTER_MAGIC_RAW){
        memcpy(out,p->data+p->texture_offset+tile*128,128);return true;
    }
    if(p->magic!=ROSTER_MAGIC_BLOCKS)return false;
    unsigned block=tile/p->block_tiles;
    for(unsigned i=0;i<ROSTER_CACHE_BLOCKS;i++){
        roster_cache_entry_t *e=&cache->entries[i];
        if(e->owner==p->data&&e->block==block){
            ++cache->hits;memcpy(out,e->bytes+(tile%p->block_tiles)*128,128);return true;
        }
    }
    roster_cache_entry_t *e=&cache->entries[cache->next];
    const uint8_t *entry=p->data+p->texture_offset+block*12;
    unsigned offset=be32(entry),stored=be32(entry+4),raw=be32(entry+8);
    e->owner=NULL; /* A malformed stream must never become a valid cache hit. */
    if(!lz4_unpack(p->data+offset,stored,e->bytes,raw))return false;
    e->owner=p->data;e->block=block;++cache->decodes;
    cache->next=(cache->next+1)%ROSTER_CACHE_BLOCKS;
    memcpy(out,e->bytes+(tile%p->block_tiles)*128,128);return true;
}
