#pragma once
#include <stdbool.h>
enum {FLOW_PLAY,FLOW_RESULT,FLOW_CONTINUE,FLOW_GAMEOVER};
enum {FLOW_NONE,FLOW_RETRY,FLOW_TITLE,FLOW_ADVANCE};
typedef struct {unsigned phase,tick,previous;int winner;bool draw;} match_flow_t;
void match_flow_reset(match_flow_t *f,unsigned buttons);
unsigned match_flow_tick(match_flow_t *f,bool finished,int winner,bool draw,unsigned buttons,unsigned video_ticks);
unsigned match_flow_seconds(const match_flow_t *f);
