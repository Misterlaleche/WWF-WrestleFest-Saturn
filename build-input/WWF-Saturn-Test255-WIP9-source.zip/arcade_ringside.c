#include "arcade_ringside.h"
#include "arcade_stamina.h"

static const arcade_ringside_object_init_t init[ARCADE_RINGSIDE_OBJECTS]={
    {0,0x040d,0x0140}, /* ROM $FFD2 object at $1C0F1C */
    {1,0x0330,0x0119}, /* ROM $FFD2 object at $1C1028 */
};
const arcade_ringside_object_init_t *arcade_ringside_object_init(unsigned index){
 return index<ARCADE_RINGSIDE_OBJECTS?&init[index]:0;
}
static unsigned mag(int v){return (unsigned)(v<0?-v:v);}
bool arcade_ringside_pickup_contact(int fx,int fy,int ox,int oy,unsigned state,bool held){
 if(held||state!=ARCADE_OBJECT_AVAILABLE_STATE)return false;
 return mag(ox-fx)<ARCADE_OBJECT_CONTACT&&mag(oy-fy)<ARCADE_OBJECT_CONTACT;
}

/* Each pair is {seek, no-seek}; $24CC chooses a weighted result and $1C7C0
 * proceeds only when result index zero. Internal IDs 7/8/9 share a pointer.
 * Internal 11's table is followed by the next pointer table after stage 5,
 * so stages 6-9 are deliberately reported unknown until that aliasing is
 * proven rather than reading pointer bytes as probabilities. */
static const uint8_t seek[12][10]={
 {0,15,0,20,0,25,0,20,0,25},
 {0,20,0,25,0,30,5,20,0,25},
 {5,20,0,25,0,30,10,30,0,35},
 {10,30,0,35,0,40,0,0,0,0},
 {0,0,0,0,25,0,0,0,0,0},
 {0,0,0,0,50,0,15,25,0,40},
 {15,25,0,40,0,55,10,20,0,30},
 {10,20,0,30,0,45,15,30,0,45},
 {10,20,0,30,0,45,15,30,0,45},
 {10,20,0,30,0,45,15,30,0,45},
 {15,30,0,45,0,55,10,25,0,35},
 {10,25,0,35,0,50,0,0,0,0},
};
bool arcade_ringside_weapon_seek_percent(unsigned logical,unsigned stage,unsigned *percent){
 if(!percent||logical>=12||stage>=10)return false;
 unsigned internal=arcade_stamina_internal_id(logical);
 if(internal==11&&stage>=6)return false;
 *percent=seek[internal][stage];return true;
}
bool arcade_ringside_weapon_seek_roll(unsigned logical,unsigned stage,unsigned roll,bool *known){
 unsigned p=0;bool k=arcade_ringside_weapon_seek_percent(logical,stage,&p);
 if(known)*known=k;if(!k)return false;return roll%100U<p;
}

unsigned arcade_ringside_pickup_descriptor(unsigned type){return type?0x19e90U:0x19e80U;}
unsigned arcade_ringside_use_descriptor(unsigned type){return type?0x15a0cU:0x159f8U;}


bool arcade_ringside_cpu_weapon_direct_contact(int dx,int dy){
 return mag(dx)<ARCADE_CPU_WEAPON_DIRECT_X && mag(dy)<ARCADE_CPU_WEAPON_Y;
}

/* Test51: ROM $1D032->$24CC, table $1D066 = 0x32,0x32. */
bool arcade_ringside_cpu_weapon_mid_use(int dx,int dy,unsigned roll){
 unsigned ax=mag(dx),ay=mag(dy);
 if(ay>=ARCADE_CPU_WEAPON_Y||ax<ARCADE_CPU_WEAPON_DIRECT_X||ax>=ARCADE_CPU_WEAPON_MID_X)return false;
 return roll%100U<50U;
}


/* Test57: exact state-2 integration tail at ROM $FEE6..$FF0C. */
unsigned arcade_ringside_state2_integrate(int *x,int *y,int *z,
                                           int vx,int vy,int vz,
                                           unsigned collision_flags){
 if(x)*x+=vx;if(y)*y+=vy;if(z)*z+=vz;
 return (collision_flags&ARCADE_OBJECT_STATE2_COLLISION_BIT)?ARCADE_OBJECT_POST_THROW_STATE:ARCADE_OBJECT_THROWN_STATE;
}

/* Test59: exact $FE82 two-probe orchestration around shared resolver $280DC. */
bool arcade_ringside_state2_apply_probes(int *x,int *y,int *z,
                                          const arcade_ringside_state2_probe_t *forward,
                                          const arcade_ringside_state2_probe_t *reverse,
                                          unsigned *state_out){
 const arcade_ringside_state2_probe_t *p=0;
 if(forward&&forward->contact_code)p=forward;
 else if(reverse&&reverse->contact_code)p=reverse;
 if(!p){if(state_out)*state_out=ARCADE_OBJECT_THROWN_STATE;return false;}
 unsigned state=arcade_ringside_state2_integrate(x,y,z,p->raw_dx,p->raw_dy,p->raw_dz,p->collision_flags);
 if(state_out)*state_out=state;
 return true;
}



/* Test61: $280DC -> $28128 -> table $28154 for objects with +$32 bit 2 set.
 * Valid demonstrated second-column pointers for global low-3-bit modes 0..6:
 * 0:$28288, 1:$2818C (RTS), 2:$2851E, 3:$2818C, 4:$2818C,
 * 5:$28288, 6:$2851E.  Index 7 would step beyond the bounded pointer table,
 * so it is explicitly unknown until the producer of $1C007E proves it valid. */
bool arcade_ringside_object_resolver_route(unsigned global_mode,
                                            arcade_ringside_resolver_route_t *route,
                                            unsigned *raw_handler){
 static const unsigned handler[7]={0x28288U,0x2818cU,0x2851eU,0x2818cU,0x2818cU,0x28288U,0x2851eU};
 if(route)*route=ARCADE_RESOLVER_ROUTE_UNKNOWN;
 if(raw_handler)*raw_handler=0;
 if(global_mode>=7)return false;
 unsigned h=handler[global_mode];
 if(raw_handler)*raw_handler=h;
 if(route)*route=h==0x2818cU?ARCADE_RESOLVER_ROUTE_RTS:(h==0x28288U?ARCADE_RESOLVER_ROUTE_28288:ARCADE_RESOLVER_ROUTE_2851E);
 return true;
}


/* Test62: exact $2851E boundary/contact generator.  This is the second-column
 * handler selected for the $FFD2 objects in global modes 2 and 6. */
bool arcade_ringside_resolver_2851e(int probe_x,int raw_y,int raw_z,int raw_z_bias,
                                     arcade_ringside_state2_probe_t *out){
 if(!out)return false;
 out->contact_code=0;out->raw_dx=0;out->raw_dy=0;out->raw_dz=0;out->collision_flags=0;
 if(raw_y<0x110){
  out->collision_flags|=0x08U;out->raw_dy=0x110-raw_y;out->contact_code=1;
 }
 if(raw_y>0x140){
  out->collision_flags|=0x04U;out->raw_dy=0x140-raw_y;out->contact_code=1;
  if(probe_x>=0x294&&probe_x<0x38c)out->contact_code=4;
 }
 if(raw_z<0x100){
  out->collision_flags|=0x10U;out->raw_dz=(0x100-raw_z)+raw_z_bias;
 }
 if(probe_x<0x1c8){
  out->collision_flags|=0x02U;out->raw_dx=0x1c8-probe_x;out->contact_code=3;
 }else if(probe_x>0x470){
  out->collision_flags|=0x01U;out->raw_dx=0x470-probe_x;out->contact_code=3;
 }
 return out->contact_code!=0;
}

/* Test64: exact $28288 first-column resolver.  68000 word arithmetic and
 * unsigned BCC/BLS comparisons are preserved explicitly. */
bool arcade_ringside_resolver_28288(int probe_x,int raw_y,int raw_z,int raw_z_bias,
                                     arcade_ringside_state2_probe_t *out){
 if(!out)return false;
 out->contact_code=0;out->raw_dx=0;out->raw_dy=0;out->raw_dz=0;out->collision_flags=0;
 uint16_t x=(uint16_t)probe_x,y=(uint16_t)raw_y,z=(uint16_t)raw_z;
 if(z<0x0100U){
  out->collision_flags|=0x10U;
  out->raw_dz=(int16_t)((uint16_t)(0x0100U-z)+(uint16_t)raw_z_bias);
 }
 if(x<0x01c7U){
  int32_t n=(int32_t)((uint32_t)y<<8)+0x00028000L;
  int16_t q=(int16_t)(n/(int32_t)0x02e0);
  if(x<(uint16_t)q){
   out->raw_dx=(int16_t)((uint16_t)q-x);
   out->collision_flags|=0x02U;out->contact_code=3;
  }
 }else if(x>0x0360U){
  int32_t n=(int32_t)((uint32_t)y<<8)-0x000ba000L;
  int16_t q=(int16_t)(n/(int32_t)0x02e0);
  uint16_t bound=(uint16_t)(int16_t)(-q);
  if(x>bound){
   out->raw_dx=(int16_t)(bound-x);
   out->collision_flags|=0x01U;out->contact_code=3;
  }
 }
 return out->contact_code!=0;
}

/* Test58: exact state-4 reavailability clock at ROM $FF54..$FFC2. */
unsigned arcade_ringside_state4_step(bool *initialized,unsigned *timer,unsigned *phase){
 if(!initialized||!timer||!phase)return ARCADE_OBJECT_POST_THROW_STATE;
 if(!*initialized){
  *initialized=true;*timer=ARCADE_OBJECT_STATE4_TIMER;*phase=1;
  return ARCADE_OBJECT_POST_THROW_STATE;
 }
 if(*timer>0)--*timer;
 if(*timer!=0)return ARCADE_OBJECT_POST_THROW_STATE;
 *timer=ARCADE_OBJECT_STATE4_TIMER;
 ++*phase;
 return *phase==ARCADE_OBJECT_STATE4_PHASES?ARCADE_OBJECT_AVAILABLE_STATE:ARCADE_OBJECT_POST_THROW_STATE;
}

/* Test65: ROM $FEBC..$FEE0 + $280DC exact bounded two-probe orchestration.
 * $280DC clears +$38/+3A/+3C on every call but does not clear the collision
 * flag byte +$37, so flags from the first no-contact probe can survive into
 * the second.  A no-op dispatcher route is a known result, not an unknown one. */
bool arcade_ringside_state2_resolve(unsigned global_mode,bool facing_flip,
                                     int raw_x,int raw_y,int raw_z,
                                     int raw_y_bias,int raw_z_bias,
                                     arcade_ringside_state2_probe_t *out,
                                     bool *route_known){
 if(route_known)*route_known=false;
 if(!out)return false;
 out->contact_code=0;out->raw_dx=0;out->raw_dy=0;out->raw_dz=0;out->collision_flags=0;
 arcade_ringside_resolver_route_t route;unsigned raw_handler=0;
 if(!arcade_ringside_object_resolver_route(global_mode,&route,&raw_handler))return false;
 (void)raw_handler;if(route_known)*route_known=true;
 if(route==ARCADE_RESOLVER_ROUTE_RTS)return false;
 unsigned accumulated_flags=0;
 for(unsigned probe=0;probe<2;probe++){
  int offset=probe?-(int)ARCADE_OBJECT_STATE2_PROBE:(int)ARCADE_OBJECT_STATE2_PROBE;
  if(facing_flip)offset=-offset;
  arcade_ringside_state2_probe_t p;
  bool contact=route==ARCADE_RESOLVER_ROUTE_28288?
   arcade_ringside_resolver_28288(raw_x+offset,raw_y+raw_y_bias,raw_z+raw_z_bias,raw_z_bias,&p):
   arcade_ringside_resolver_2851e(raw_x+offset,raw_y+raw_y_bias,raw_z+raw_z_bias,raw_z_bias,&p);
  accumulated_flags|=p.collision_flags;p.collision_flags=accumulated_flags;*out=p;
  if(contact)return true;
 }
 return false;
}

/* Test69: ROM $E002->$DF96, category $11. All 12 action tables carry
 * {$1E,$1E,$1E}; action $1F belongs to the recovered CPU weighted path. */
unsigned arcade_ringside_human_weapon_action(unsigned fresh_buttons){unsigned m=fresh_buttons&3U;return m?0x1eU:0U;}
