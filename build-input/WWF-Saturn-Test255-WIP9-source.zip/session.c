#include "session.h"
#include <string.h>
static const unsigned grid[10]={0,7,2,8,6,9,1,3,4,5};
void session_reset(session_t *s,unsigned held){memset(s,0,sizeof(*s));s->mode=1;s->previous=held;s->entropy=0x9e3779b9U^(held*0x45d9f3bU);}
void session_entropy_mix(session_t *s,unsigned value){if(s)s->entropy=(s->entropy^(value+0x9e3779b9U+(s->entropy<<6)+(s->entropy>>2)))*1664525U+1013904223U;}
unsigned session_character(const session_t *s){return grid[s->cursor];}
unsigned session_highlight(const session_t *s,unsigned cursor){unsigned ch=grid[cursor%10];return (s->confirmed&(1U<<ch))?(s->flash[ch]?1:2):0;}
static void confirm(session_t *s,unsigned ch){s->confirmed|=1U<<ch;s->flash[ch]=60;}
unsigned session_cpu_cursor(const session_t *s){
 unsigned ch=s->characters[s->tick<120?1:3];
 for(unsigned i=0;i<10;i++)if(grid[i]==ch)return i;
 return 0;
}
unsigned session_page(const session_t *s){return (s->phase==SESSION_CPU?session_cpu_cursor(s):s->cursor)%5>=3;}
static void roster(session_t *s){
 unsigned used=1U<<s->selected[0],seed=s->entropy^(s->selected[0]*0x85ebca6bU);s->characters[0]=s->selected[0];
 if(s->mode){s->characters[2]=s->selected[1];used|=1U<<s->selected[1];seed^=s->selected[1]*0xc2b2ae35U;}
 /* Test110 hardware exposed the old fixed next=2 walk (Jake/Bossman every
  * TAG start). Until the arcade RNG source is recovered, use accumulated
  * menu timing entropy to permute the complete ten-wrestler roster. */
 unsigned start=seed%10U,step=((seed>>8)%5U)*2U+1U;
 for(unsigned i=1;i<(s->mode?4U:10U);i++){
  if(s->mode&&i==2)continue;
  unsigned pick=10;for(unsigned k=0;k<10;k++){unsigned c=grid[(start+k*step)%10U];if(!(used&(1U<<c))){pick=c;start=(start+(k+1)*step)%10U;break;}}
  if(pick>=10)pick=0;s->characters[i]=pick;used|=1U<<pick;
 }
}
unsigned session_tag_announce_wrestler(const session_t *s){
 if(!s||!s->mode||s->phase!=SESSION_ANNOUNCE)return 4;
 unsigned n=s->tick/TAG_ANNOUNCE_WRESTLER_TICKS;return n<4?n:4;
}
unsigned session_tag_announce_local_tick(const session_t *s){return s?s->tick%TAG_ANNOUNCE_WRESTLER_TICKS:0;}

bool session_tag_presenter_exiting(const session_t *s){
 if(!s||!s->mode||s->phase!=SESSION_ANNOUNCE)return false;
 return s->tick>4U*TAG_ANNOUNCE_WRESTLER_TICKS;
}
unsigned session_tag_presenter_pose(const session_t *s){
 if(!s||!s->mode||s->phase!=SESSION_ANNOUNCE)return 0;
 unsigned exit_start=4U*TAG_ANNOUNCE_WRESTLER_TICKS;
 if(s->tick<=exit_start)return (s->tick/18U)%7U;
 unsigned t=s->tick-exit_start;
 /* Test242: stop cycling the front-facing announce loop once she leaves.
  * Frame 4 is used as a brief turn cue, then 5/6 alternate while moving to
  * the rear rope. Exact rear-view artwork is not present in the recovered
  * seven-frame presenter bank, so the turn-frame identity remains PROVISIONAL. */
 if(t<18U)return 4U;
 return 5U+((t/10U)&1U);
}
int session_tag_presenter_y(const session_t *s){
 if(!s||!s->mode||s->phase!=SESSION_ANNOUNCE)return 168;
 unsigned exit_start=4U*TAG_ANNOUNCE_WRESTLER_TICKS;if(s->tick<=exit_start)return 168;
 unsigned t=s->tick-exit_start;if(t>TAG_ANNOUNCE_EXIT_TICKS)t=TAG_ANNOUNCE_EXIT_TICKS;
 /* Test215: hardware feedback + arcade reference: the presenter leaves through
  * the upper side of the ring.  Saturn screen Y therefore decreases during
  * the exit instead of increasing toward the foreground. */
 return 168-(int)(t*80U/TAG_ANNOUNCE_EXIT_TICKS);
}
bool session_tick(session_t *s,unsigned buttons){
 session_entropy_mix(s,buttons+s->tick*33U+s->phase*257U);
 unsigned fire=buttons&~s->previous,oldpage=session_page(s);s->previous=buttons;
 for(unsigned i=0;i<10;i++)if(s->flash[i])--s->flash[i];
 if(s->phase==SESSION_PLAY)return false;
 if(s->phase>=SESSION_HALL){unsigned duration=s->phase==SESSION_HALL?HALL_TICKS:s->phase==SESSION_RING?RING_ENTRY_TICKS:(s->mode?TAG_ANNOUNCE_TICKS:ANNOUNCE_TICKS);if(++s->tick>=duration||(fire&MENU_OK)){s->phase=s->phase==SESSION_HALL?SESSION_ANNOUNCE:s->phase+1;s->tick=0;return true;}return false;}
 if(s->phase==SESSION_CPU){++s->tick;if(s->tick==1)confirm(s,s->characters[1]);if(s->tick==120)confirm(s,s->characters[3]);if(s->tick>=240){s->phase=SESSION_HALL;s->tick=0;return true;}return oldpage!=session_page(s);}
 ++s->tick;
 if(s->phase==SESSION_MODE){if(fire&(MENU_LEFT|MENU_RIGHT))s->mode^=1;if(fire&MENU_OK){s->phase=SESSION_SELECT;s->count=0;s->cursor=0;return true;}return false;}
 if(fire&MENU_BACK){s->confirmed=0;memset(s->flash,0,sizeof(s->flash));if(s->count)s->count=0;else{s->phase=SESSION_MODE;return true;}}
 unsigned col=s->cursor%5,row=s->cursor/5;
 if(fire&MENU_LEFT)col=(col+4)%5;if(fire&MENU_RIGHT)col=(col+1)%5;
 if(fire&(MENU_UP|MENU_DOWN))row^=1;s->cursor=row*5+col;
 if(fire&MENU_OK){unsigned c=session_character(s);if(!s->count||s->selected[0]!=c){confirm(s,c);s->selected[s->count++]=c;if(s->count==(s->mode?2U:1U)){roster(s);s->phase=s->mode?SESSION_CPU:SESSION_HALL;s->tick=0;return true;}}}
 return oldpage!=session_page(s);
}
