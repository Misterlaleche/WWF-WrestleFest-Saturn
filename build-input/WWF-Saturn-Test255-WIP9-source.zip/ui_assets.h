#ifndef WWF_UI_ASSETS_H
#define WWF_UI_ASSETS_H
#define UI_TEXTURE_BYTES 10112U
#define UI_FONT_OFFSET 2880U
#define UI_TIMER_OFFSET 9024U
static inline unsigned presentation_pose(unsigned ch,unsigned elapsed){switch(ch){
case 0:
if(elapsed<7)return 91;elapsed-=7;
if(elapsed<7)return 90;elapsed-=7;
if(elapsed<7)return 89;elapsed-=7;
if(elapsed<7)return 91;elapsed-=7;
if(elapsed<7)return 90;elapsed-=7;
if(elapsed<7)return 89;elapsed-=7;
if(elapsed<7)return 91;elapsed-=7;
if(elapsed<7)return 90;elapsed-=7;
if(elapsed<7)return 89;elapsed-=7;
if(elapsed<7)return 92;elapsed-=7;
if(elapsed<33)return 93;elapsed-=33;
return 93;
case 1:
if(elapsed<17)return 89;elapsed-=17;
if(elapsed<17)return 90;elapsed-=17;
if(elapsed<17)return 89;elapsed-=17;
if(elapsed<17)return 90;elapsed-=17;
return 90;
case 2:
if(elapsed<9)return 89;elapsed-=9;
if(elapsed<9)return 90;elapsed-=9;
if(elapsed<9)return 91;elapsed-=9;
if(elapsed<17)return 90;elapsed-=17;
return 90;
case 3:
if(elapsed<17)return 89;elapsed-=17;
if(elapsed<33)return 90;elapsed-=33;
return 90;
case 6:
if(elapsed<17)return 89;elapsed-=17;
if(elapsed<33)return 90;elapsed-=33;
return 90;
case 7:
if(elapsed<9)return 89;elapsed-=9;
if(elapsed<9)return 90;elapsed-=9;
if(elapsed<9)return 91;elapsed-=9;
if(elapsed<17)return 90;elapsed-=17;
return 90;
case 8:
if(elapsed<92)return 89;elapsed-=92;
if(elapsed<9)return 90;elapsed-=9;
return 90;
case 9:
if(elapsed<9)return 89;elapsed-=9;
if(elapsed<9)return 90;elapsed-=9;
if(elapsed<9)return 89;elapsed-=9;
if(elapsed<9)return 90;elapsed-=9;
if(elapsed<9)return 89;elapsed-=9;
if(elapsed<17)return 90;elapsed-=17;
return 90;
default:return 0;}}
/* Test221 PROVISIONAL: post-match winner celebration reuses the already
 * recovered character presentation gestures.  This makes the winners animate
 * after they meet at centre without claiming these gestures are the exact
 * arcade victory-clap descriptor.  Unsupported characters deliberately stay
 * on idle raw pose 0 rather than fabricate art. */
static inline unsigned postmatch_winner_pose(unsigned ch,unsigned elapsed){
 return presentation_pose(ch,elapsed);
}
#endif
