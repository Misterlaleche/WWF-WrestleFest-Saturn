#pragma once
/* Original descriptor durations plus the underflow tick:
   $181ec: poses110/111, $181fc: poses112/113, $11e36: pose104.
   This preserves pose durations, not every original transition callback. */
enum { ARCADE_RISE_FIRST=13,ARCADE_RISE_SECOND=13,ARCADE_RISE_SETTLE=17,
       ARCADE_RISE_TICKS=ARCADE_RISE_FIRST+ARCADE_RISE_SECOND+ARCADE_RISE_SETTLE };
