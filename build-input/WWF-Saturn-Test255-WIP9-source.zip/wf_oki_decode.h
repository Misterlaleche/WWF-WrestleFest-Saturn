#ifndef WF_OKI_DECODE_H
#define WF_OKI_DECODE_H
#include <stddef.h>
#include <stdint.h>
size_t wf_oki_decode_pcm8(const uint8_t *src,size_t src_bytes,int8_t *dst,size_t dst_capacity);
#endif
