#!/usr/bin/env python3
"""Audit actual packed assets with the shared C painter plan. Not a console capture."""
import ctypes as c
import hashlib,json,struct,subprocess,tempfile
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from preview_combat_moves import Pack,Cache

def rgb(w):
    return np.stack([(w&31)*255//31,((w>>5)&31)*255//31,((w>>10)&31)*255//31],axis=-1).astype(np.uint8)

def main():
    root=Path(__file__).resolve().parents[1]
    palette=np.zeros((2048,3),np.uint8)
    for first,name in [(256,'ROSTER.PAL'),(512,'ENV.PAL')]:
        colors=rgb(np.frombuffer((root/'assets'/name).read_bytes(),dtype='>u2'));palette[first:first+len(colors)]=colors
    world=rgb(np.frombuffer((root/'cd/RING.PAL').read_bytes(),dtype='>u2'))[np.frombuffer((root/'cd/RING.BIN').read_bytes(),np.uint8).reshape(512,512)]
    env=(root/'cd/ENV.TEX').read_bytes();owners={};packs={};decoded={};cache=Cache()
    with tempfile.TemporaryDirectory(prefix='wwf-layer-audit-') as tmp:
        binary=Path(tmp)/'trace';shared=Path(tmp)/'decoder.so'
        subprocess.run(['gcc','-std=c11','-O1','-fsanitize=address,undefined','-g','-I.', 'game.c','arcade_animation.c','roster_pack.c','codec.c','tools/trace_layers.c','-o',str(binary)],cwd=root,check=True)
        import os
        trace=subprocess.check_output([str(binary)],cwd=root,text=True,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0'))
        subprocess.run(['gcc','-shared','-fPIC','-std=c11','-O2','-I.','roster_pack.c','codec.c','-o',str(shared)],cwd=root,check=True)
        lib=c.CDLL(str(shared));lib.roster_pack_open.argtypes=[c.POINTER(Pack),c.POINTER(c.c_uint8),c.c_size_t,c.c_uint];lib.roster_pack_open.restype=c.c_bool
        lib.roster_pack_tile.argtypes=[c.POINTER(Pack),c.c_uint,c.POINTER(c.c_uint8),c.POINTER(Cache)];lib.roster_pack_tile.restype=c.c_bool
        def tile(source,index):
            key=(source,index)
            if key not in decoded:
                if not source:data=env[index*128:index*128+128]
                else:
                    ch=source-1
                    if ch not in packs:
                        raw=(root/f'cd/C{ch:02}.PAK').read_bytes();owners[ch]=c.create_string_buffer(raw);packs[ch]=Pack()
                        assert lib.roster_pack_open(c.byref(packs[ch]),c.cast(owners[ch],c.POINTER(c.c_uint8)),len(raw),207)
                    out=(c.c_uint8*128)();assert lib.roster_pack_tile(c.byref(packs[ch]),index,out,c.byref(cache));data=bytes(out)
                a=np.frombuffer(data,np.uint8).reshape(16,8);p=np.empty((16,16),np.uint8);p[:,::2]=a>>4;p[:,1::2]=a&15;decoded[key]=p
            return decoded[key]
        pictures={};records=[]
        for line in trace.splitlines():
            code,*values=line.split();v=list(map(int,values))
            if code=='S':
                test,legacy,view,cx,cy=v;dst=world[cy+141:cy+381,cx+130:cx+450].copy();assert dst.shape==(240,320,3)
                commands=0;unique=set();layers=[]
            elif code=='L':layers.append(v[0])
            elif code=='T':
                source,index,x,y,pal,flip,eight,opaque=v;assert not eight
                a=tile(source,index);commands+=1
                if source:unique.add((source,index))
                if flip&1:a=a[:,::-1]
                if flip&2:a=a[::-1,:]
                x0=max(x,0);y0=max(y,0);x1=min(320,x+16);y1=min(240,y+16)
                cut=a[y0-y:y1-y,x0-x:x1-x];mask=np.ones(cut.shape,bool) if opaque else cut!=0
                dst[y0:y1,x0:x1][mask]=palette[pal+cut[mask].astype(np.uint16)]
            else:
                assert code=='E';assert commands+3+14<1024 and len(unique)<=512
                pictures[(test,legacy,view)]=dst.copy()
                records.append({'case':test,'legacy_v0024':bool(legacy),'view':view,'layers':layers,'sprite_commands':commands,'dynamic_tiles':len(unique)})
        labels=['Pin: compañero cercano delante de la composición','Derribo: profundidad de suelo sin salto al levantarse','Exterior trasero: detrás del árbitro, sin primer plano forzado','Esquina CPU: composición entera delante de cuerdas']
        sheet=Image.new('RGB',(1280,1160),(18,23,31));d=ImageDraw.Draw(sheet)
        try:font=ImageFont.truetype('DejaVuSans.ttf',16);small=ImageFont.truetype('DejaVuSans.ttf',13)
        except OSError:font=small=ImageFont.load_default()
        d.text((18,12),'Test15 · auditoría de capas con recursos reales',font=font,fill='white')
        d.text((18,39),'Reconstrucción software: no es una captura de Saturn. Sin HUD para inspeccionar las piezas.',font=small,fill=(175,193,210))
        d.text((18,65),'Antes: V0.024',font=font,fill=(235,190,110));d.text((658,65),'Después: Test15 V0.025',font=font,fill=(100,235,160))
        # Pixel-perfect source images, nearest-neighbour enlargement only in the report.
        differences=[]
        for test in range(4):
            y=92+test*266
            before=pictures[(test,1,0)];after=pictures[(test,0,0)]
            changed=int(np.any(before!=after,axis=2).sum());differences.append(changed)
            for column,a in enumerate([before,after]):
                # 1x image plus a magnified overlapping region: full frame stays intact.
                im=Image.fromarray(a);sheet.paste(im,(column*640,y))
                crop=im.crop((60,20,220,140) if test==2 else ((160,120,320,240) if test==3 else (60,90,220,210)))
                sheet.paste(crop.resize((320,240),Image.Resampling.NEAREST),(column*640+320,y))
            d.text((18,y+243),labels[test]+f' · {changed} píxeles cambian',font=small,fill='white')
        target=root/'docs/layers-preview.png';sheet.save(target)
        assert all(n>0 for n in differences[:3]),differences
        assert differences[3]==0,differences
        record={'source':'shared game_render_plan/render_fighter_pose + shipped assets + native C roster decoder',
                'console_capture':False,'asan_ubsan_trace':True,'pair_piece_coverage':'all ten banks, all three pair clips',
                'frames':records,'changed_pixels':differences,'preview_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
                'scope':'nine constructed frames, not exhaustive hardware command-budget certification'}
        (root/'docs/layers-visual.json').write_text(json.dumps(record,indent=2)+'\n')
        (root/'docs/layers-trace.txt').write_text(trace)
        print(json.dumps({'changed_pixels':differences,'max_sprite_commands':max(r['sprite_commands'] for r in records),'max_dynamic_tiles':max(r['dynamic_tiles'] for r in records),'path':str(target)},indent=2))

if __name__=='__main__':main()
