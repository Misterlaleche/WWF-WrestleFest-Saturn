#include "arcade_stamina.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned char *load(size_t*n){FILE*f=fopen("program.bin","rb");assert(f);fseek(f,0,SEEK_END);*n=(size_t)ftell(f);rewind(f);unsigned char*b=malloc(*n);assert(b&&fread(b,1,*n,f)==*n);fclose(f);return b;}
static unsigned be32(const unsigned char*p){return ((unsigned)p[0]<<24)|((unsigned)p[1]<<16)|((unsigned)p[2]<<8)|p[3];}
int main(void){size_t n;unsigned char*b=load(&n);
 assert(be32(b+0x12850)==0x00012888U); /* action $00 descriptor callback */
 const unsigned char impact[]={0x31,0x7c,0x00,0x04,0x00,0x20,0x31,0x7c,0x00,0x17,0x00,0x64,0x31,0x7c,0x00,0x03,0x00,0x68};
 assert(!memcmp(b+0x1295a,impact,sizeof(impact)));
 assert(ARCADE_STATIONARY_PUNCH_DAMAGE==3U);
 free(b);puts("PASS: Test134 arcade stationary Punch action $00 writes exact 3-point stamina damage on its valid-hit callback path");}
