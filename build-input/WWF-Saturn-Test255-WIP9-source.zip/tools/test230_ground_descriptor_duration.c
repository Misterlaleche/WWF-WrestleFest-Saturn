#include <assert.h>
#include <stdio.h>
#include "arcade_animation.h"
int main(void){
 assert(arcade_animation_finite_ticks(0x1603aU)==61U);
 assert(arcade_animation_finite_ticks(0x16116U)==68U);
 assert(arcade_animation_finite_ticks(0x15ce0U)==0U);
 assert(arcade_animation_finite_ticks(0x1623cU)==0U);
 puts("PASS Test230: finite ground timings are derived from ROM descriptors; callback-held STOMP/FIST remain explicitly unresolved");
}
