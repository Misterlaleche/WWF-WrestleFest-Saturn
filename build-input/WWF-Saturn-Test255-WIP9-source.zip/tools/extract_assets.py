#!/usr/bin/env python3
"""Generate native Saturn data from the user's ROM and captured composition metadata."""
from pathlib import Path
import argparse,json,struct,zipfile,zlib,hashlib
import numpy as np
from PIL import Image

ROM_SPECS=[('31j3.ic9','e395cf1d'),('31j2.ic8','b5a97465'),('31j5.ic11','2ce545e8'),('31j4.ic10','00edb66a'),('31j6.ic12','79956cf8'),('31j7.ic13','74d774c3'),('31j9.ic15','dd387289'),('31j8.ic14','44abe127')]
def fnv(data):
 h=2166136261
 for b in data:h=((h^b)*16777619)&0xffffffff
 return h

def extract(rom,root):
 root=Path(root);m=json.loads((root/'model.json').read_text())
 with zipfile.ZipFile(rom) as z:
  chunks=[]
  for name,crc in ROM_SPECS:
   d=z.read(name)
   assert len(d)==0x100000 and f'{zlib.crc32(d):08x}'==crc,name
   chunks.append(d)
  region=b''.join(chunks)
  font=z.read('31e12-0.ic33');assert len(font)==0x20000 and zlib.crc32(font)==0x06f22615
  bg=z.read('31j1.ic2')+z.read('31j0.ic1')
  assert len(bg)==0x80000
  assert zlib.crc32(bg[:0x40000])==0x82ed7155 and zlib.crc32(bg[0x40000:])==0x8a12b450
 raw=np.frombuffer(region,np.uint8).reshape(4,65536,32)
 pixels=[]
 for kind,code in m['textures']:
  if kind=='spr':
   bits=np.unpackbits(raw[:,code,:],axis=1).reshape(4,2,16,8).transpose(0,2,1,3).reshape(4,16,16)
   tile=np.sum(bits*np.array([8,4,2,1],np.uint8)[:,None,None],axis=0,dtype=np.uint8)
  elif kind=='fg4':
   tile=np.zeros((16,16),np.uint8)
   for j in range(4):
    cell=(code>>(12*j))&4095
    for y in range(8):
     for x in range(8):
      byte=font[cell*32+(x//2)*8+y]
      for p in range(4):tile[(j//2)*8+y,(j%2)*8+x]|=((byte>>(7-(1-x%2)-p*2))&1)<<(3-p)
  else:
   tile=np.zeros((16,16),np.uint8)
   for y in range(16):
    for x in range(16):
     off=(code%4096)*64+y*2+(32 if x>=8 else 0)
     for p,plane in enumerate([1,0,0x40001,0x40000]):tile[y,x]|=((bg[off+plane]>>(7-x%8))&1)<<(3-p)
  pixels.append(tile)
 emit(root,m,pixels)

def emit(root,m,pixels):
 root=Path(root)
 palettes=[list(p) for p in m['palettes']]
 # UI palette is separate from all captured game palettes.
 palettes.append([0,0xfff,0x0f0,0x00f,0x0ff,0x444]+[0]*10)
 def color555(v):
  r=v&15;g=(v>>4)&15;b=(v>>8)&15
  r=(r<<1)|(r>>3);g=(g<<1)|(g>>3);b=(b<<1)|(b>>3)
  return 0x8000|(b<<10)|(g<<5)|r
 pal555=np.array([[color555(v) for v in p] for p in palettes],dtype=np.uint16)
 pal8=np.stack([(pal555&31)*255//31,((pal555>>5)&31)*255//31,((pal555>>10)&31)*255//31],axis=2).astype(np.uint8)
 # Render exactly the same 16x16 pieces that the Saturn receives.
 def draw(records,width=320,height=240,transparent=True,anchor=(0,0)):
  rgb=np.zeros((height,width,3),np.uint8);mask=np.zeros((height,width),bool);colors=np.zeros((height,width),np.uint16)
  for t,x,y,p,f in records:
   tile=pixels[t]
   if f&1:tile=tile[:,::-1]
   if f&2:tile=tile[::-1,:]
   x+=anchor[0];y+=anchor[1]
   x0=max(0,x);y0=max(0,y);x1=min(width,x+16);y1=min(height,y+16)
   if x0>=x1 or y0>=y1:continue
   cut=tile[y0-y:y1-y,x0-x:x1-x];use=(cut!=0) if transparent else np.ones(cut.shape,bool)
   rgb[y0:y1,x0:x1][use]=pal8[p][cut[use]]
   colors[y0:y1,x0:x1][use]=pal555[p][cut[use]]
   mask[y0:y1,x0:x1][use]=True
  return rgb,mask,colors
 world,mask,base555=draw(m['base'],width=512,height=512,transparent=False)
 base=world[141:381,130:450]
 assert mask.all(), 'Background has gaps'
 unique,inverse=np.unique(base555,return_inverse=True)
 assert len(unique)<=256,'Ring requires more than 256 exact colors'
 padded=inverse.reshape(512,512).astype(np.uint8)
 ringpal=np.full(256,0x8000,np.uint16);ringpal[:len(unique)]=unique
 assert np.array_equal(ringpal[padded],base555)
 tex=b''.join(((p[:,::2]<<4)|p[:,1::2]).tobytes() for p in pixels)
 assets=root/'assets';docs=root/'docs';assets.mkdir(exist_ok=True);docs.mkdir(exist_ok=True)
 files={'SPRITES.TEX':tex,'PALETTES.PAL':pal555.astype('>u2').tobytes(),'RING.BIN':padded.tobytes(),'RING.PAL':ringpal.astype('>u2').tobytes()}
 for name,data in files.items():(assets/name).write_bytes(data)
 Image.fromarray(base).save(docs/'ring_base_reference.png')
 Image.fromarray(world).save(docs/'arena_background.png')
 sides,smask,_=draw(m['front'][:m['arena']['static_side_commands']])
 front,frontmask,_=draw(m['front'][m['arena']['static_side_commands']:])
 for i,c in enumerate(m['clips']):
  actor,amask,_=draw(c['frames'][0],anchor=(120,80) if i==6 else (160,202))
  Image.fromarray(np.dstack((actor,amask.astype(np.uint8)*255))).save(docs/f'figure_{i+1:02d}.png')
  scene=base.copy();scene[smask]=sides[smask];scene[amask]=actor[amask];scene[frontmask]=front[frontmask]
  Image.fromarray(scene).save(docs/f'scene_{i+1:02d}_no_hud.png')
 # C tables describe VDP1 commands; no M68000 emulation or MAME code is linked.
 records=[];frames=[];clips=[]
 for c in m['clips']:
  first=len(frames)
  for fr in c['frames']:
   frames.append((len(records),len(fr)));records.extend(fr)
  clips.append((first,len(c['frames']),c['name']))
 normal=sum(max(map(len,c['frames'])) for c in m['clips'][:2])
 paired=max(len(fr) for c in m['clips'][2:5] for fr in c['frames'])
 referee=max(map(len,m['clips'][5]['frames']))
 cap=3+max(normal,paired)+referee+max(map(len,m['clips'][6]['frames']))+len(m['front'])+2+4+1
 lines=['/* Generated from model.json and verified ROMs. */','#pragma once',
  'typedef struct { uint16_t tile; int16_t x,y; uint16_t pal,flip; } piece_t;',
  'typedef struct { uint16_t first,count; } frame_t;',
  'typedef struct { uint16_t first,count; const char *name; } clip_t;',
  f'#define TEXTURE_BYTES {len(tex)}',f'#define PALETTE_BYTES {len(files["PALETTES.PAL"])}',
  f'#define RINGPAL_BYTES {len(files["RING.PAL"])}',f'#define RINGPAL_HASH 0x{fnv(files["RING.PAL"]):08x}UL',f'#define RING_BYTES {len(files["RING.BIN"])}',f'#define CMD_CAPACITY {cap}',
  f'#define SIDE_ROPE_COUNT {m["arena"]["static_side_commands"]}',f'#define CLIP_COUNT {len(clips)}',f'#define FRONT_COUNT {len(m["front"])}',
  f'#define UI_PAL_INDEX {256+(len(palettes)-1)*16}',
  f'#define TEX_HASH 0x{fnv(tex):08x}UL',f'#define RING_HASH 0x{fnv(files["RING.BIN"]):08x}UL',
  f'#define PAL_HASH 0x{fnv(files["PALETTES.PAL"]):08x}UL',
  'static const piece_t pieces[] = {' ]
 lines.extend(' {'+','.join(map(str,r))+'},' for r in records);lines+=['};','static const piece_t foreground[] = {']
 lines.extend(' {'+','.join(map(str,r))+'},' for r in m['front']);lines+=['};','static const frame_t frames[] = {']
 lines.extend(' {%d,%d},'%r for r in frames);lines+=['};','static const clip_t clips[] = {']
 lines.extend(' {%d,%d,"%s"},'%r for r in clips);lines+=['};']
 pair=m['pair']
 rules=['/* Generated from the shared composition in model.json. */','#pragma once',
  '#define PAIR_THROW_FRAMES %d'%(len(m['clips'][2]['frames'])-1),
  '#define PAIR_FRAME_TICKS %d'%pair['frame_ticks'],
  '#define PAIR_IMPACT_TICK 56']
 for key,label in [('hold_offset','HOLD'),('land_offset','LAND')]:
  for axis,value in zip('XY',pair[key]):rules.append(f'#define PAIR_{label}_{axis} {value}')
 for label,value in zip(['MIN_X','MAX_X','MIN_Y','MAX_Y'],pair['bounds']):rules.append(f'#define PAIR_{label} {value}')
 for label,value in zip(['MIN_X','MAX_X','MIN_Y','MAX_Y'],m['pin']['bounds']):rules.append(f'#define PIN_{label} {value}')
 motion=m['motion']
 for i,value in enumerate(motion['jake_rise_poses']):rules.append(f'#define JAKE_RISE_POSE_{i} {value}')
 for i,value in enumerate(motion['hulk_uncover_poses']):rules.append(f'#define HULK_UNCOVER_POSE_{i} {value}')
 for label,value in zip(['MIN_X','MAX_X','MIN_Y','MAX_Y'],m['cpu_pin']['bounds']):rules.append(f'#define CPU_PIN_{label} {value}')
 rules.append(f"#define HULK_PRONE_Y {m['cpu_pin']['prone_y_offset']}")
 for key,label in [('hulk_rise_poses','HULK_RISE'),('jake_uncover_poses','JAKE_UNCOVER')]:
  for i,value in enumerate(motion[key]):rules.append(f'#define {label}_POSE_{i} {value}')
 for i,label in enumerate(m['clips'][5]['poses']):rules.append(f'#define REF_POSE_{label.upper()} {i}')
 rules.append('#define REF_CLIP 5')
 for i,v in enumerate(m['arena']['climb_poses']):rules.append(f'#define HULK_CLIMB_{i} {v}')
 for i,v in enumerate(m['arena']['dive_poses']):rules.append(f'#define HULK_DIVE_{i} {v}')
 (root/'pair_rules.h').write_text('\n'.join(rules)+'\n')
 (root/'model_data.h').write_text('\n'.join(lines)+'\n')
 manifest={'source':'WWF WrestleFest ROMs supplied by user; MAME 0.264 composition capture',
  'textures':len(pixels),'palettes':len(palettes),'clips':len(clips),'poses_per_fighter':[len(c['frames']) for c in m['clips']],
  'commands_capacity':cap,'background':'VDP2 NBG0 512x512 indexed 8bpp; 100 exact RGB555 colors; camera crop 320x240, 1:1',
  'foreground':'VDP1 transparent tiles drawn after wrestler',
  'files':{n:{'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest(),'fnv1a':f'{fnv(d):08x}'} for n,d in files.items()},
  'quantization':'Original RGB444 palette channels expanded to RGB555 using bit replication',
  'validation':m['validation']}
 (docs/'assets.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print(json.dumps(manifest,indent=2))

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('rom',type=Path);p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);a=p.parse_args();extract(a.rom,a.root)
