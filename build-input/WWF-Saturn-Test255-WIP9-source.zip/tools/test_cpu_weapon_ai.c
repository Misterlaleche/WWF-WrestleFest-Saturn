#include <assert.h>
#include <stdio.h>
#include "game.h"
static void prep(game_t *g){unsigned r[6]={0,2,1,3,0,0};game_match_start_arcade(g,GAME_TAG,r,1,0);g->fighters[1].outside=true;g->fighters[1].x=0;g->fighters[1].y=224*256;g->ringside_objects[0].x=-20*256;g->ringside_objects[0].y=224*256;g->ringside_objects[1].x=80*256;g->ringside_objects[1].y=224*256;}
int main(void){game_t g;bool known=false;prep(&g);
 /* logical char2 -> internal2; stage1 seek chance 20%. nearest X is object0 */
 assert(game_cpu_choose_ringside_object(&g,1,19,&known)==0&&known&&g.fighters[1].ringside_target==1);
 prep(&g);assert(game_cpu_choose_ringside_object(&g,1,20,&known)==-1&&known&&!g.fighters[1].ringside_target);
 prep(&g);g.ringside_objects[0].holder=1;g.ringside_objects[1].x=40*256;
 assert(game_cpu_choose_ringside_object(&g,1,0,&known)==1&&g.fighters[1].ringside_target==2);
 prep(&g);g.ringside_objects[0].state=2;g.ringside_objects[1].state=2;assert(game_cpu_choose_ringside_object(&g,1,0,&known)==-1);
 /* $1C796: even a successful character/stage roll is skipped when the
    nearest object is not strictly closer in X than the current rival. */
 prep(&g);g.fighters[0].x=10*256;g.ringside_objects[0].x=-20*256;g.ringside_objects[1].x=80*256;known=true;
 assert(game_cpu_choose_ringside_object(&g,1,0,&known)==-1&&!known&&!g.fighters[1].ringside_target);
 puts("PASS: CPU ringside AI uses nearest object, exact $B0 opponent-distance gate and ROM seek roll");}
