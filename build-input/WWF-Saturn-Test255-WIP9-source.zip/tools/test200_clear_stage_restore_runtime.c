#include "game.h"
#include "arcade_stamina.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 unsigned roster[6]={0,1,2,3,4,5}; game_t g;game_match_start(&g,GAME_TAG,roster);g.mode=GAME_TAG;g.roster_count=4;
 g.fighters[0].max_health=110;g.fighters[0].health=80;g.fighters[0].stamina_pending=0;
 g.fighters[1].max_health=115;g.fighters[1].health=50;g.fighters[1].stamina_pending=0;
 g.fighters[2].max_health=98; g.fighters[2].health=90;g.fighters[2].stamina_pending=0;
 g.fighters[3].max_health=100;g.fighters[3].health=40;g.fighters[3].stamina_pending=0;
 game_clear_stage_restore(&g,0);
 assert(g.fighters[0].health==104 && g.fighters[0].stamina_pending==24);
 assert(g.fighters[2].health==98  && g.fighters[2].stamina_pending==8);
 assert(g.fighters[1].health==50 && g.fighters[1].stamina_pending==0);
 assert(g.fighters[3].health==40 && g.fighters[3].stamina_pending==0);
 assert(arcade_clear_stage_restore(0)==24 && arcade_clear_stage_restore(1)==32 && arcade_clear_stage_restore(2)==12 && arcade_clear_stage_restore(3)==0);
 puts("PASS Test200: native TAG clear-stage restore matches ROM $90D6 human-role exclusion, exact 24/32/12/0 table, max clamp and queued stamina delta semantics");
 return 0;
}
