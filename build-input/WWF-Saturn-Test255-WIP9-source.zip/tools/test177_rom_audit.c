#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void seq(long o,const uint8_t*p,size_t n){FILE*f=fopen("program.bin","rb");assert(f);uint8_t*b=malloc(n);assert(b);assert(fseek(f,o,SEEK_SET)==0&&fread(b,1,n,f)==n);fclose(f);assert(!memcmp(b,p,n));free(b);}
int main(void){
 const uint8_t p[]={0x48,0xe7,0x00,0xe0,0x08,0x39,0x00,0x00,0x00,0x1c,0x01,0x61,0x66,0x00,0x00,0x5a,0x22,0x68,0x00,0x26,0x08,0xa9,0x00,0x00,0x00,0x34};seq(0x213a6,p,sizeof p);
 puts("PASS Test177: $213A6 splits on the TAG/Royal mode bit; TAG follows +$26 and clears linked +$34 bit0");return 0;}
