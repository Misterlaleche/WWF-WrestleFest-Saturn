#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void seq(long o,const uint8_t*p,size_t n){FILE*f=fopen("program.bin","rb");assert(f);uint8_t*b=malloc(n);assert(b);assert(fseek(f,o,SEEK_SET)==0&&fread(b,1,n,f)==n);fclose(f);assert(!memcmp(b,p,n));free(b);}
int main(void){
 const uint8_t p[]={0x41,0xf9,0x00,0x1c,0x05,0xb0,0x72,0x03,0x08,0x28,0x00,0x00,0x00,0xff,0x66,0x30};seq(0x90da,p,sizeof p); const uint8_t q[]={0xd1,0xfc,0x00,0x00,0x01,0x0c,0x51,0xc9,0xff,0xc0};seq(0x911a,q,sizeof q);
 puts("PASS Test196: $90D6 iterates exactly four actor records from $1C05B0 at stride $10C and skips records with +$FF bit0 set");return 0;}
