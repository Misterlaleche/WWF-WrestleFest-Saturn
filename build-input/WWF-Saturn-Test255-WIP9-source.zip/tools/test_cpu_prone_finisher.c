#include "finisher_runtime.h"
#include <assert.h>
#include <stdio.h>
#define FP 256
static void prep(game_t *g,unsigned cpu_ch){unsigned r[6]={2,cpu_ch,7,3,4,5};game_match_start(g,GAME_TAG,r);g->cpu=true;fighter_t *p=&g->fighters[0],*q=&g->fighters[1];p->health=18;p->stamina_tier=2;p->state=ST_DOWN;p->tick=20;p->rise_y=p->y=200*FP;p->x=150*FP;q->x=110*FP;q->y=180*FP;q->facing=1;q->cooldown=0;}
static void one(unsigned ch){game_t g;prep(&g,ch);unsigned before=g.fighters[0].health;assert(game_finisher_probe(&g,1)==FINISHER_PROBE_READY);game_tick(&g,0,0);assert(g.fighters[1].state==ST_FINISHER&&g.pair==PAIR_NONE);for(unsigned i=0;i<300&&g.fighters[1].state==ST_FINISHER;i++)game_tick(&g,0,0);assert(g.fighters[1].state!=ST_FINISHER&&g.finishers==1&&g.hits[1]==1&&g.fighters[0].health<before);}
int main(void){one(0);game_t g;prep(&g,8);assert(game_finisher_probe(&g,1)==FINISHER_PROBE_UNMAPPED);puts("PASS: CPU prone finisher keeps Hogan and gates the contradictory Earthquake candidate");}
