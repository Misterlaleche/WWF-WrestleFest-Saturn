#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void seq(const unsigned char*r,size_t n,size_t o,const unsigned char*s,size_t z){assert(o+z<=n);assert(!memcmp(r+o,s,z));}
int main(void){FILE*f=fopen("program.bin","rb");assert(f);fseek(f,0,SEEK_END);long ln=ftell(f);rewind(f);size_t n=(size_t)ln;unsigned char*r=malloc(n);assert(r&&fread(r,1,n,f)==n);fclose(f);
 const unsigned char a0role[]={0x42,0x28,0x00,0x56,0x08,0xe8,0x00,0x01,0x00,0x33};seq(r,n,0x6f98,a0role,sizeof a0role);const unsigned char a0pair[]={0x21,0x4a,0x00,0x86};seq(r,n,0x6fb8,a0pair,sizeof a0pair);
 const unsigned char a2role[]={0x42,0x2a,0x00,0x56,0x00,0x2a,0x00,0x40,0x00,0x56};seq(r,n,0x702e,a2role,sizeof a2role);const unsigned char a2pair[]={0x25,0x48,0x00,0x86};seq(r,n,0x7042,a2pair,sizeof a2pair);
 free(r);puts("PASS Test87: ROM initialization creates reciprocal actor pair link +$86 (A0<->A2) while differentiating roles with A0 +$56=0 and A2 +$56 bit6 set");return 0;}
