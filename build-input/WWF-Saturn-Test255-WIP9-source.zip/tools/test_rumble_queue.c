#include "session.h"
#include <assert.h>
#include <stdio.h>
static void press(session_t*s,unsigned k){session_tick(s,0);session_tick(s,k);} 
int main(void){session_t s;session_reset(&s,0);press(&s,MENU_LEFT);press(&s,MENU_OK);press(&s,MENU_OK);unsigned mask=0;for(unsigned i=0;i<10;i++){assert(s.characters[i]<10);assert(!(mask&(1U<<s.characters[i])));mask|=1U<<s.characters[i];}assert(s.characters[0]==s.selected[0]);puts("PASS Test115: Rumble session constructs a complete ten-wrestler unique entrant queue with human selection first; entropy order remains provisional");}
