#include <assert.h>
#include <stdio.h>
#include "game.h"
int main(void){
 unsigned r[6]={0,1,2,3,4,5}; game_t g; game_match_start(&g,GAME_TAG,r); g.cpu=false;
 g.fighters[0].x=30*256; g.fighters[0].y=170*256; g.tag_cooldown=0; g.support_phase[0]=SUPPORT_WAIT;
 unsigned outgoing=g.fighters[0].character,incoming=g.fighters[2].character;
 game_tick(&g,0,INPUT_KICK);
 for(unsigned i=0;i<80&&g.tag_phase[0]!=TAG_PHASE_ENTRY;i++)game_tick(&g,0,0);
 assert(g.tag_phase[0]==TAG_PHASE_ENTRY);
 assert(g.fighters[0].character==outgoing&&g.fighters[2].character==incoming);
 assert(g.fighters[0].state==ST_RING_EXIT&&g.fighters[2].state==ST_RING_ENTER);
 int oldx=g.fighters[0].x,newx=g.fighters[2].x;
 for(unsigned i=0;i<8;i++)game_tick(&g,0,0);
 assert(g.fighters[0].x<oldx&&g.fighters[2].x>newx);
 assert(g.fighters[0].character==outgoing&&g.fighters[2].character==incoming);
 for(unsigned i=0;i<80&&g.tags==0;i++)game_tick(&g,0,0);
 assert(g.tags==1&&g.tag_phase[0]==TAG_PHASE_NONE);
 assert(g.fighters[0].character==incoming&&g.fighters[2].character==outgoing);
 assert(g.fighters[0].x==30*256&&g.fighters[2].x==-46*256);
 puts("PASS Test210: TAG palmada now performs simultaneous outgoing/incoming rope traversal and swaps legal identity only after both crossings complete");
}
