#!/usr/bin/env python3
"""Build the Yaul ISO/CUE using the locally configured toolchain. No uploads."""
import argparse,json,os,subprocess
from pathlib import Path
from verify_iso import verify

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--sdk',required=True,type=Path);p.add_argument('--xorrisofs',required=True,type=Path)
    p.add_argument('--host-libs',type=Path);a=p.parse_args();root=Path(__file__).resolve().parents[1]
    env=dict(os.environ,YAUL_INSTALL_ROOT=str(a.sdk.resolve()),YAUL_ARCH_SH_PREFIX='sh2eb-elf',
             YAUL_PROG_SH_PREFIX='',YAUL_ARCH_M68K_PREFIX='m68keb-elf',YAUL_OPTION_MALLOC_IMPL='tlsf',
             SILENT='1',NOCOLOR='1',MAKE_ISO_XORRISOFS=str(a.xorrisofs.absolute()))
    env['PATH']=str(a.sdk.resolve()/'bin')+os.pathsep+env.get('PATH','')
    if a.host_libs:env['LD_LIBRARY_PATH']=str(a.host_libs.resolve())
    result=subprocess.run(['make','-C',str(root)],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    print(result.stdout,end='');(root/'docs/disc-build.log').write_text(result.stdout);result.check_returncode();verify(root)

if __name__=='__main__':main()
