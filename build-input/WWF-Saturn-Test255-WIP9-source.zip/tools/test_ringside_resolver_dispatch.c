#include "arcade_ringside.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 static const unsigned expected[7]={0x28288,0x2818c,0x2851e,0x2818c,0x2818c,0x28288,0x2851e};
 static const arcade_ringside_resolver_route_t route[7]={
  ARCADE_RESOLVER_ROUTE_28288,ARCADE_RESOLVER_ROUTE_RTS,ARCADE_RESOLVER_ROUTE_2851E,
  ARCADE_RESOLVER_ROUTE_RTS,ARCADE_RESOLVER_ROUTE_RTS,ARCADE_RESOLVER_ROUTE_28288,
  ARCADE_RESOLVER_ROUTE_2851E};
 for(unsigned mode=0;mode<7;mode++){
  unsigned raw=0;arcade_ringside_resolver_route_t r=ARCADE_RESOLVER_ROUTE_UNKNOWN;
  assert(arcade_ringside_object_resolver_route(mode,&r,&raw));
  assert(raw==expected[mode]);assert(r==route[mode]);
 }
 unsigned raw=0xdead;arcade_ringside_resolver_route_t r=ARCADE_RESOLVER_ROUTE_RTS;
 assert(!arcade_ringside_object_resolver_route(7,&r,&raw));
 assert(r==ARCADE_RESOLVER_ROUTE_UNKNOWN&&raw==0);
 assert(!arcade_ringside_object_resolver_route(99,0,0));
 puts("PASS: ROM $280DC/$28128 object dispatch is exact for bounded global modes 0..6; mode 7 remains explicitly unknown");
 return 0;
}
