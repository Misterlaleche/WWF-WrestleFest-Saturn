#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void seq(long o,const uint8_t*p,size_t n){FILE*f=fopen("program.bin","rb");assert(f);uint8_t*b=malloc(n);assert(b);assert(fseek(f,o,SEEK_SET)==0&&fread(b,1,n,f)==n);fclose(f);assert(!memcmp(b,p,n));free(b);}
int main(void){
 const uint8_t p[]={0xd1,0x68,0x00,0x66,0xd1,0x68,0x00,0x6a};seq(0x9102,p,sizeof p);
 puts("PASS Test198: $90D6 adds the same clear-stage restore amount to actor +$66 live stamina and +$6A queued stamina delta");return 0;}
