#!/usr/bin/env bash
set -euo pipefail
url="https://raw.githubusercontent.com/yaul-org/libyaul-examples/develop/scsp-ponesound-pcm8/assets/sdrv.bin"
dst="assets/SDRV.BIN"
expected_blob="e62e4ade1691f766af9d04b58d72b723079694d1"
expected_size=8732
curl -L --fail --retry 3 "$url" -o "$dst"
size="$(wc -c < "$dst" | tr -d ' ')"
test "$size" = "$expected_size"
actual_blob="$({ printf 'blob %s\0' "$size"; cat "$dst"; } | sha1sum | awk '{print $1}')"
test "$actual_blob" = "$expected_blob"
echo "Verified poneSound driver: $size bytes / $actual_blob"
