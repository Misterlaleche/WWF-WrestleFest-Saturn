#!/usr/bin/env python3
from pathlib import Path
import struct, sys
rom=Path(sys.argv[1] if len(sys.argv)>1 else 'program.bin').read_bytes()
target=b'\x00\x1c\x00\x7e'
refs=[i for i in range(len(rom)-3) if rom[i:i+4]==target]
# 68k MOVE.w #imm,<abs.l> encoding: 33 FC ii ii aa aa aa aa
writes=[]
for addr in refs:
    if addr>=4 and rom[addr-4:addr-2]==b'\x33\xfc':
        imm=struct.unpack('>H',rom[addr-2:addr])[0]
        writes.append((addr-4,imm))
expected=[
 (0x748,3),(0x7d6,3),(0x127e,3),(0x1b7a,4),(0x5310,3),(0x58fe,3),
 (0x5944,3),(0x69e0,3),(0x7bd0,4),(0x81d0,3),(0x84a6,3),(0xae56,4),(0xb646,4),
]
if writes!=expected:
    raise SystemExit(f'direct-write set changed: {writes!r}')
if {v for _,v in writes}!={3,4}:
    raise SystemExit(f'unexpected direct values: {writes!r}')
print(f'PASS global $1C007E direct absolute writes: {len(writes)} sites, values only 3/4')
print('sites: '+' '.join(f'${a:05X}=${v}' for a,v in writes))
print(f'all absolute-long references found: {len(refs)} (reads/compares included; indirect producers remain unproven)')
