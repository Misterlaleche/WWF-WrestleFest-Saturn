#include "game.h"
#include <assert.h>
#include <stdio.h>
#define FP 256
static void ready(game_t *g,int x0,int x1){
 game_reset(g);g->fighters[0].arcade_motion=g->fighters[1].arcade_motion=true;
 g->fighters[0].x=x0*FP;g->fighters[1].x=x1*FP;g->fighters[0].y=g->fighters[1].y=190*FP;
 g->fighters[0].facing=x1>x0?1:-1;g->fighters[1].facing=-g->fighters[0].facing;
}
static void tick(game_t *g,unsigned held,unsigned pressed){game_tick(g,held,pressed);}
int main(void){
 game_t g;
 /* Original grapple transition: K from the hold launches a forced run. */
 ready(&g,120,180);tick(&g,0,INPUT_GRAB);assert(g.pair==PAIR_HOLD);
 int start=g.fighters[1].x;tick(&g,INPUT_RIGHT,INPUT_KICK);
 assert(g.pair==PAIR_NONE&&g.irish_whips==1&&g.fighters[1].whipped);
 assert(g.fighters[1].state==ST_RUN&&g.fighters[1].facing==1&&g.fighters[1].motion_x0==start);
 unsigned saw_rebound=0,saw_return=0;
 for(unsigned n=0;n<500&&g.fighters[1].whipped;n++){
   /* Input cannot cancel or steer the forced run. */
   tick(&g,INPUT_LEFT|INPUT_UP,INPUT_PUNCH|INPUT_KICK|INPUT_GRAB);
   if(g.fighters[1].state==ST_REBOUND)saw_rebound=1;
   if(saw_rebound&&g.fighters[1].facing==-1)saw_return=1;
 }
 assert(saw_rebound&&saw_return&&!g.fighters[1].whipped);
 assert(g.fighters[1].x==start&&g.fighters[1].state==ST_RUN_STOP);

 /* Direction can be selected at release; left-side whip uses the same cycle. */
 ready(&g,200,140);tick(&g,INPUT_LEFT,INPUT_GRAB);assert(g.pair==PAIR_HOLD);
 start=g.fighters[1].x;tick(&g,INPUT_LEFT,INPUT_KICK);assert(g.fighters[1].facing==-1&&g.fighters[1].whipped);
 saw_rebound=0;
 for(unsigned n=0;n<500&&g.fighters[1].whipped;n++){tick(&g,INPUT_RIGHT,0);saw_rebound|=g.fighters[1].state==ST_REBOUND;}
 assert(saw_rebound&&g.fighters[1].x==start&&!g.fighters[1].whipped);

 /* P+K remains an explicit native cancel, separate from the arcade K whip. */
 ready(&g,120,180);tick(&g,0,INPUT_GRAB);tick(&g,0,INPUT_PUNCH|INPUT_KICK);
 assert(g.pair==PAIR_NONE&&g.irish_whips==0&&!g.fighters[1].whipped);

 /* A strike interrupts the returning runner rather than letting forced motion
    overwrite the hit reaction. */
 ready(&g,120,180);tick(&g,0,INPUT_GRAB);tick(&g,INPUT_RIGHT,INPUT_KICK);
 bool returning=false,hit=false;
 for(unsigned n=0;n<500&&!hit;n++){
   fighter_t *q=&g.fighters[1];
   if(q->whip_rebounds&&q->state==ST_RUN&&q->facing==-1)returning=true;
   unsigned press=0;
   if(returning&&q->x-g.fighters[0].x>=20*FP&&q->x-g.fighters[0].x<=48*FP)press=INPUT_PUNCH;
   tick(&g,0,press);
   if(g.hits[0])hit=true;
 }
 assert(hit&&g.hits[0]==1&&!g.fighters[1].whipped);
 assert(g.fighters[1].state==ST_HIT||g.fighters[1].state==ST_RECOVER||g.fighters[1].state==ST_DOWN);

 /* Whip is an in-ring grapple transition only; existing ringside boundary stays. */
 ready(&g,120,180);g.fighters[1].outside=true;tick(&g,0,INPUT_GRAB);
 assert(g.pair==PAIR_NONE&&g.irish_whips==0);
 puts("PASS: Irish Whip grapple transition, chosen direction, forced rope rebound/return, cancel, hit interruption and ring boundary");
 return 0;
}
