#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void seq(long o,const uint8_t*p,size_t n){FILE*f=fopen("program.bin","rb");assert(f);uint8_t*b=malloc(n);assert(b);assert(fseek(f,o,SEEK_SET)==0&&fread(b,1,n,f)==n);fclose(f);assert(!memcmp(b,p,n));free(b);}
int main(void){
 const uint8_t p[]={0x48,0xe7,0x00,0xc0,0x08,0xe8,0x00,0x07,0x00,0xb6};seq(0x21358,p,sizeof p);
 puts("PASS Test172: $21358 preserves registers then unconditionally sets actor +$B6 bit7");return 0;}
