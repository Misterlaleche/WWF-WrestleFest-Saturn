#include "game.h"
#include "arcade_moves.h"
#include "pair_rules.h"
#include <assert.h>
#include <stdio.h>

#define FP 256
static void ready(game_t *g){
    game_reset(g);g->fighters[0].x=120*FP;g->fighters[0].y=180*FP;g->fighters[0].facing=1;
    g->fighters[1].x=180*FP;g->fighters[1].y=180*FP;g->fighters[1].facing=-1;
    g->fighters[0].arcade_motion=g->fighters[1].arcade_motion=true;
}
static void ticks(game_t *g,unsigned n){while(n--)game_tick(g,0,0);}

int main(void){
    game_t g;
    /* CPU captures P1. GRAB/L during the committed window reverses ownership
       without changing the midpoint/role contact of the original pair art. */
    ready(&g);g.cpu=true;game_tick(&g,0,0);
    assert(g.pair==PAIR_HOLD&&g.pair_attacker==1&&g.cpu_grabs==1);
    ticks(&g,8);int p0x=g.fighters[0].x,p1x=g.fighters[1].x;
    int p0y=g.fighters[0].y,p1y=g.fighters[1].y;
    game_tick(&g,0,INPUT_GRAB);
    assert(g.pair==PAIR_HOLD&&g.pair_attacker==0&&g.pair_reversed);
    assert(g.grapple_reversals==1&&g.cpu_reversals==0&&g.grapple_escape==0);
    assert(g.fighters[0].x==p0x&&g.fighters[1].x==p1x);
    assert(g.fighters[0].y==p0y&&g.fighters[1].y==p1y);
    assert(game_pair_anchor(&g)==0&&game_pair_fighter(&g,0)==0&&game_pair_fighter(&g,1)==1);
    game_tick(&g,0,INPUT_PUNCH);assert(g.pair==PAIR_THROW&&g.pair_attacker==0);
    ticks(&g,PAIR_IMPACT_TICK-1);assert(g.hits[0]==0&&g.fighters[1].health==100);
    game_tick(&g,0,0);assert(g.hits[0]==1&&g.fighters[1].health==100-arcade_move_native_damage(AMOVE_BODY_SLAM));
    ticks(&g,PAIR_THROW_FRAMES*PAIR_FRAME_TICKS-PAIR_IMPACT_TICK);
    assert(g.pair==PAIR_NONE&&g.grapple_reversals==1&&!g.pair_reversed);

    /* Too-early and too-late GRAB presses do not become counters. */
    ready(&g);g.cpu=true;game_tick(&g,0,0);assert(g.pair_attacker==1);
    game_tick(&g,0,INPUT_GRAB);assert(g.pair_attacker==1&&g.grapple_reversals==0);
    ticks(&g,30);game_tick(&g,0,INPUT_GRAB);assert(g.pair_attacker==1&&g.grapple_reversals==0);

    /* A/B keeps its older mash-escape role and does not silently reverse. */
    ready(&g);g.cpu=true;game_tick(&g,0,0);ticks(&g,10);
    for(unsigned i=0;i<6;i++)game_tick(&g,0,i&1?INPUT_KICK:INPUT_PUNCH);
    assert(g.pair==PAIR_NONE&&g.grapple_reversals==0);

    /* Provisional native CPU reversal: one deterministic opportunity after a
       player stalls in a hold. The same hold cannot reverse back again. */
    ready(&g);g.cpu=true;g.fighters[1].attack_serial=1; /* 1+character(2)==3 */
    game_tick(&g,0,INPUT_GRAB);assert(g.pair==PAIR_HOLD&&g.pair_attacker==0);
    ticks(&g,60);assert(g.pair_attacker==0&&!g.pair_reversed);
    game_tick(&g,0,0);assert(g.pair_attacker==1&&g.pair_reversed);
    assert(g.grapple_reversals==1&&g.cpu_reversals==1);
    ticks(&g,20);game_tick(&g,0,INPUT_GRAB); /* locked: no ping-pong */
    assert(g.pair_attacker==1&&g.grapple_reversals==1);
    ticks(&g,22);assert(g.pair==PAIR_THROW&&g.pair_attacker==1);
    ticks(&g,PAIR_IMPACT_TICK);assert(g.hits[1]==1&&g.fighters[0].health<100);
    ticks(&g,PAIR_THROW_FRAMES*PAIR_FRAME_TICKS-PAIR_IMPACT_TICK);
    assert(g.pair==PAIR_NONE&&g.grapple_reversals==1&&g.cpu_reversals==1);

    /* Pause freezes the reversal window exactly like every other pair state. */
    ready(&g);g.cpu=true;game_tick(&g,0,0);ticks(&g,8);unsigned t=g.pair_tick;
    g.paused=true;game_tick(&g,0,INPUT_GRAB);assert(g.pair_tick==t&&g.pair_attacker==1);
    g.paused=false;game_tick(&g,0,INPUT_GRAB);assert(g.pair_attacker==0&&g.grapple_reversals==1);

    puts("PASS: grapple counter window, role swap, exact-once slam, mash escape, CPU reversal lock and pause");
    return 0;
}
