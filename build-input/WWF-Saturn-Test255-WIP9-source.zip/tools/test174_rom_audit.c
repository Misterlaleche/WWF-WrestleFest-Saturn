#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void seq(long o,const uint8_t*p,size_t n){FILE*f=fopen("program.bin","rb");assert(f);uint8_t*b=malloc(n);assert(b);assert(fseek(f,o,SEEK_SET)==0&&fread(b,1,n,f)==n);fclose(f);assert(!memcmp(b,p,n));free(b);}
int main(void){
 const uint8_t p[]={0x0c,0x28,0x00,0x53,0x00,0x61,0x66,0x20,0x22,0x68,0x00,0x26,0x08,0xe9,0x00,0x07,0x00,0xb6};seq(0x21378,p,sizeof p);
 puts("PASS Test174: $21358 has an exact +$61==$53 branch that follows +$26 and sets that actor +$B6 bit7");return 0;}
