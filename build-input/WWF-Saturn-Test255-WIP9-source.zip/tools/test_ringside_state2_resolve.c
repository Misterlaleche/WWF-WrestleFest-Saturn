#include <assert.h>
#include <stdio.h>
#include "arcade_ringside.h"
int main(void){
 arcade_ringside_state2_probe_t p;bool known=false;
 /* Modes 3/4 select the bounded RTS route: known, no contact. */
 assert(!arcade_ringside_state2_resolve(3,false,0x300,0x120,0x120,0,0,&p,&known));
 assert(known&&p.contact_code==0&&p.collision_flags==0);
 assert(!arcade_ringside_state2_resolve(4,true,0x300,0x120,0x120,0,0,&p,&known));
 assert(known&&p.contact_code==0);
 /* Mode 2 uses $2851E.  First +$20 probe hits the right Y/contact-4 window. */
 assert(arcade_ringside_state2_resolve(2,false,0x300,0x150,0x100,0,0,&p,&known));
 assert(known&&p.contact_code==4&&p.raw_dy==-0x10&&(p.collision_flags&0x04));
 /* The +$2E bit-7 facing flag reverses probe order.  Pick a left-wall point
  * where the first reversed (-$20) probe contacts but +$20 would not. */
 assert(arcade_ringside_state2_resolve(2,true,0x1e0,0x120,0x100,0,0,&p,&known));
 assert(p.contact_code==3&&p.raw_dx==0x08&&(p.collision_flags&0x02));
 /* Mode 0 uses the sloped $28288 family. */
 assert(arcade_ringside_state2_resolve(0,false,0x120,0x160,0x100,0,0,&p,&known));
 assert(known&&p.contact_code==3&&(p.collision_flags&0x02));
 /* Mode 7 remains deliberately unbounded: this is not treated as RTS. */
 assert(!arcade_ringside_state2_resolve(7,false,0,0,0,0,0,&p,&known));
 assert(!known);
 puts("PASS state2 exact bounded two-probe resolver orchestration");
 return 0;
}
