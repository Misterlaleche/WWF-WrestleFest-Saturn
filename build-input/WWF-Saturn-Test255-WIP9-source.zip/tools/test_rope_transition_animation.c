#include "game.h"
#include <assert.h>
#include <stdio.h>
int main(void){fighter_t f={0};f.arcade_motion=true;f.state=ST_RING_ENTER;int a=-1,b=-1;for(unsigned t=0;t<44;t++){f.tick=t;int p=game_arcade_pose(&f);assert(p>=0);if(a<0)a=p;if(p!=a)b=p;}assert(b>=0);f.state=ST_RING_EXIT;f.tick=20;assert(game_arcade_pose(&f)>=0);puts("PASS Test105: rope enter/exit no longer render as static idle slides; verified locomotion descriptor animates the provisional transition");}
