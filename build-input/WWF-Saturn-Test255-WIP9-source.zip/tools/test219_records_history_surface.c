#include "../match_result.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
int main(void){
 match_history_t h;memset(&h,0,sizeof(h));
 h.count=2;h.next=2;
 h.records[0].winner=0;h.records[0].roster_count=4;h.records[0].reason=FINISH_PIN;h.records[0].fighters[0].character=0;
 h.records[1].winner=1;h.records[1].roster_count=4;h.records[1].reason=FINISH_COUNTOUT;h.records[1].fighters[1].character=6;
 const match_result_t *latest=match_history_recent(&h,0),*older=match_history_recent(&h,1);
 assert(latest&&latest->fighters[latest->winner].character==6&&!strcmp(match_result_reason(latest),"COUNT OUT"));
 assert(older&&older->fighters[older->winner].character==0&&!strcmp(match_result_reason(older),"PIN FALL"));
 assert(!match_history_recent(&h,2));
 puts("PASS Test219: Records screen reads newest-first real match-history records and finish reasons");return 0;
}
