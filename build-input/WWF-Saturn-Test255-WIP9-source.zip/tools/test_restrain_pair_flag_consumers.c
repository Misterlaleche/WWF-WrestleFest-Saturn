#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void seq(const unsigned char*r,size_t n,size_t o,const unsigned char*s,size_t z){assert(o+z<=n);assert(!memcmp(r+o,s,z));}
static int count(const unsigned char*r,size_t n,const unsigned char*p,size_t z){int c=0;for(size_t i=0;i+z<=n;i++)if(!memcmp(r+i,p,z))c++;return c;}
int main(void){FILE*f=fopen("program.bin","rb");assert(f);fseek(f,0,SEEK_END);long ln=ftell(f);rewind(f);size_t n=(size_t)ln;unsigned char*r=malloc(n);assert(r&&fread(r,1,n,f)==n);fclose(f);
 const unsigned char set[]={0x08,0xe8,0x00,0x06,0x00,0x33,0x08,0xea,0x00,0x06,0x00,0x33};seq(r,n,0x158e0,set,sizeof set);
 const unsigned char tA1[]={0x08,0x29,0x00,0x06,0x00,0x33};const unsigned char tA2[]={0x08,0x2a,0x00,0x06,0x00,0x33};assert(count(r,n,tA1,sizeof tA1)>=8);assert(count(r,n,tA2,sizeof tA2)>=2);
 seq(r,n,0x1c408,tA1,sizeof tA1);seq(r,n,0x1ca00,tA2,sizeof tA2);seq(r,n,0x1cbb4,tA1,sizeof tA1);seq(r,n,0x1ce06,tA1,sizeof tA1);seq(r,n,0x1d9bc,tA1,sizeof tA1);seq(r,n,0x1e2de,tA1,sizeof tA1);
 free(r);puts("PASS Test85: Restrain sets shared actor +$33 bit6 and ROM AI/control code consumes that exact flag at multiple independent branches; partner/apron ownership of those consumers remains intentionally unclaimed");return 0;}
