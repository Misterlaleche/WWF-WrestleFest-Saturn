#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include "graphics_dma.h"

int main(void)
{
    /* The exact invalid upload route from the first Test10 release. */
    assert(!graphics_dma_source_valid(0x00200000UL, 153088));
    assert(!graphics_dma_source_valid(0x20200000UL, 153088));
    assert(!graphics_dma_source_valid(0x002fff80UL, 128));

    /* The high-RAM heap and its cache-through alias used by Yaul. */
    assert(graphics_dma_source_valid(0x06050000UL, 153088));
    assert(graphics_dma_source_valid(0x26050000UL, 153088));
    assert(graphics_dma_source_valid(0x06000000UL, 1048576));
    assert(graphics_dma_source_valid(0x060fff80UL, 128));
    assert(graphics_dma_source_valid(0x260fff80UL, 128));

    /* Reject buffers crossing the end, empty transfers and invalid aliases. */
    assert(!graphics_dma_source_valid(0x060fff80UL, 129));
    assert(!graphics_dma_source_valid(0x260fff80UL, 129));
    assert(!graphics_dma_source_valid(0x06100000UL, 128));
    assert(!graphics_dma_source_valid(0x26100000UL, 128));
    assert(!graphics_dma_source_valid(0x06050000UL, 0));
    assert(!graphics_dma_source_valid(0x06050000UL, SIZE_MAX));
    assert(!graphics_dma_source_valid(0x46050000UL, 128));
    assert(!graphics_dma_source_valid(0x25c00000UL, 128));
    assert(!graphics_dma_source_valid(0, 128));
    puts("PASS: reject Test10 low-RAM DMA route; allow bounded high-RAM staging");
    return 0;
}
