#!/usr/bin/env python3
"""Independent CUE read via libcdio, bitwise EDC, and optional MAME ECC tables.
Does not import the disc writer, boot a console or certify MODE firmware.
"""
import argparse,ctypes as c,ctypes.util,hashlib,json,re,struct
from pathlib import Path

def slow_edc(data):
    value=0
    for byte in data:
        value^=byte
        for _ in range(8):value=(value>>1)^ (0xd8018001 if value&1 else 0)
    return value

def verify(iso,cue,mame_source=None):
    iso=Path(iso);cue=Path(cue).resolve();expected=iso.read_bytes()
    name=re.search(r'FILE "([^"]+)" BINARY',cue.read_text()).group(1)
    binary=cue.parent/name;raw=binary.read_bytes();sectors=len(expected)//2048
    assert len(raw)==sectors*2352
    library=ctypes.util.find_library('cdio')
    if not library:raise RuntimeError('libcdio not installed')
    lib=c.CDLL(library);lib.cdio_open_bincue.argtypes=[c.c_char_p];lib.cdio_open_bincue.restype=c.c_void_p
    lib.cdio_read_mode1_sectors.argtypes=[c.c_void_p,c.c_void_p,c.c_int32,c.c_bool,c.c_uint32];lib.cdio_read_mode1_sectors.restype=c.c_int
    lib.cdio_get_track_lsn.argtypes=[c.c_void_p,c.c_uint8];lib.cdio_get_track_lsn.restype=c.c_int32
    lib.cdio_destroy.argtypes=[c.c_void_p]
    handle=lib.cdio_open_bincue(str(cue).encode());assert handle,'CUE rejected by libcdio'
    try:
        assert lib.cdio_get_track_lsn(handle,1)==0
        assert lib.cdio_get_track_lsn(handle,0xaa)==sectors
        output=c.create_string_buffer(len(expected))
        assert lib.cdio_read_mode1_sectors(handle,output,0,False,sectors)==0
        assert output.raw==expected,'Independent CUE reader payload mismatch'
    finally:lib.cdio_destroy(handle)
    tables=None
    if mame_source:
        source=Path(mame_source).read_text()
        def numbers(name):
            body=re.search(r'cdrom_file::'+name+r'\[[^;]+?=\s*\{(.*?)\n\};',source,re.S).group(1)
            return [int(x,16) for x in re.findall(r'0x([0-9a-fA-F]+)',body)]
        low,high,po,qo=[numbers(n) for n in ['ecclow','ecchigh','poffsets','qoffsets']]
        assert len(low)==len(high)==256 and len(po)==86*24 and len(qo)==52*43
        tables=(low,high,po,qo)
    for lba in range(sectors):
        block=raw[lba*2352:(lba+1)*2352]
        assert block[:12]==b'\0'+b'\xff'*10+b'\0' and block[15]==1
        msf=[(v>>4)*10+(v&15) for v in block[12:15]]
        assert msf[0]*4500+msf[1]*75+msf[2]==lba+150 and msf[1]<60 and msf[2]<75
        assert block[2068:2076]==bytes(8)
        assert slow_edc(block[:2064])==struct.unpack_from('<I',block,2064)[0]
        if tables:
            for offsets,width,rowlen,start in [(po,86,24,2076),(qo,52,43,2248)]:
                for row in range(width):
                    a=b=0
                    for pos in offsets[row*rowlen:(row+1)*rowlen]:
                        v=block[12+pos];a=low[a^v];b^=v
                    a=high[low[a]^b]
                    assert block[start+row]==a and block[start+width+row]==a^b
    record={'independent_reader':library,'cue_payload_matches_iso':True,'sectors_checked':sectors,
            'edc_bitwise_all_sectors':True,'ecc_mame_tables_all_sectors':bool(tables),
            'bin_sha256':hashlib.sha256(raw).hexdigest(),'boot_test':False}
    if mame_source:record['mame_source_sha256']=hashlib.sha256(Path(mame_source).read_bytes()).hexdigest()
    target=cue.parent/'disc-independent-validation.json';target.write_text(json.dumps(record,indent=2)+'\n')
    return record

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('iso',type=Path);p.add_argument('cue',type=Path);p.add_argument('--mame-source',type=Path)
    a=p.parse_args();print(json.dumps(verify(a.iso,a.cue,a.mame_source),indent=2))
