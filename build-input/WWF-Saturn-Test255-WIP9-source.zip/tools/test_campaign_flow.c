#include "campaign_runtime.h"
#include "arcade_stamina.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 campaign_t c;campaign_reset(&c,CAMPAIGN_TAG,5,0,ARCADE_DIFFICULTY_NORMAL);campaign_set_players(&c,0,7);
 game_t g;unsigned roster[6]={0};
 campaign_start_game(&c,&g,roster,1,100);unsigned first_a=roster[1],first_b=roster[3];
 g.fighters[0].health=50;g.fighters[2].health=70;
 assert(campaign_commit_win(&c,&g)&&c.stage==1);
 campaign_start_game(&c,&g,roster,100,100);assert(g.stage_index==1&&g.fighters[0].health==74&&g.fighters[2].health==94);
 assert(roster[1]!=roster[3]);
 /* A loss/Continue does not call campaign_commit_win: restart retains stage and
    the exact current opponents, while restoring the pre-match carried state. */
 unsigned a=roster[1],b=roster[3];g.fighters[0].health=1;campaign_restart_game(&c,&g,roster);
 assert(c.stage==1&&roster[1]==a&&roster[3]==b&&g.fighters[0].health==74);
 (void)first_a;(void)first_b;
 puts("PASS: presentation-equivalent win advances/stores stamina; Continue restarts same stage/roster without committing loss damage");
}
