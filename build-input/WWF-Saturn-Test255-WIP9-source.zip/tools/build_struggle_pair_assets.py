#!/usr/bin/env python3
"""Build exact partner-dependent action-$29 grapple-struggle compositions.

ROM proof chain:
  category $08 ($E180..$E1AC): linked raw state $0B + fresh P/K -> action $29
  action $29 descriptor $1656A / callback $16582
  visual: pose245 21 ticks, pose246 9, pose247 15, pose466 15 = 60 ticks
  callback: first FE completion -> both raw $0B; second -> attacker $0C, target $FF

Only original program.bin composition records and validated gfx2 are used.
"""
from pathlib import Path
import hashlib,json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import arcade_composition as comp
import build_exact_ground_assets as common
ROOT=Path(__file__).resolve().parents[1]
PROGRAM=ROOT/'program.bin';GFX=ROOT/'gfx2.bin'
PROGRAM_SHA256='265ac89deeb7e708ac6fda724356bfd6af1c9012928a4e551e6e2faa424c2306'
GFX_SHA256='a3b5e1fedd6c41cd398ba0cb437cddb2f50b3ae0a0dc178a10b70a7ed5d010ba'
POSES=[245,246,247,466]

def main():
 assert hashlib.sha256(PROGRAM.read_bytes()).hexdigest()==PROGRAM_SHA256
 assert hashlib.sha256(GFX.read_bytes()).hexdigest()==GFX_SHA256
 comp.load_program(PROGRAM);tile=common.make_tile_decoder()
 sizes=[[0]*10 for _ in range(10)];hashes=[[0]*10 for _ in range(10)];frames_n=[[0]*10 for _ in range(10)]
 mapping={};runs={};detail=[];max_bytes=0;total_bytes=0
 for a in range(10):
  for p in range(10):
   if a==p:continue
   frames=[];textures=[];lookup={}
   for pose in POSES:
    pcs=comp.commands(a,pose,partner=p);assert pcs,(a,p,pose)
    rec=[];rr=[];last=None;banks=[]
    for q in pcs:
     assert q['bank'] in (a,p),(a,p,pose,q['bank'])
     role=0 if q['bank']==a else 1;banks.append(q['bank']);px=tile(q['code'])
     if not any(px):continue
     if px not in lookup:lookup[px]=len(textures);textures.append(px)
     rec.append([lookup[px],*common.geom(q)])
     if last==role:rr[-1][1]+=1
     else:rr.append([role,1]);last=role
    assert rec and any(r[0]==0 for r in rr) and any(r[0]==1 for r in rr),(a,p,pose,rr)
    fr=len(frames);frames.append(rec);mapping[(a,p,pose)]=fr;runs[(a,p,fr)]=rr
    detail.append(dict(attacker=a,partner=p,pose=pose,frame=fr,pieces=len(rec),runs=rr,banks=sorted(set(banks))))
   data=common.pack(frames,textures,32);name=f'S{a}{p}.PAK';(ROOT/'cd'/name).write_bytes(data)
   sizes[a][p]=len(data);hashes[a][p]=common.fnv(data);frames_n[a][p]=len(frames);max_bytes=max(max_bytes,len(data));total_bytes+=len(data)
 out=['#ifndef WWF_STRUGGLE_PAIR_ASSETS_H','#define WWF_STRUGGLE_PAIR_ASSETS_H','#include "finisher_assets.h"',
      f'#define STRUGGLE_PAIR_OVERLAY_MAX_BYTES {max_bytes}U']
 out.append('static const unsigned struggle_pair_bytes[10][10]={'+','.join('{'+','.join(map(str,row))+'}' for row in sizes)+'};')
 out.append('static const unsigned struggle_pair_hash[10][10]={'+','.join('{'+','.join(str(x)+'U' for x in row)+'}' for row in hashes)+'};')
 out.append('static const unsigned struggle_pair_frames[10][10]={'+','.join('{'+','.join(map(str,row))+'}' for row in frames_n)+'};')
 out.append('static inline unsigned struggle_pair_asset_frame(unsigned a,unsigned p,unsigned pose){')
 for (a,p,pose),fr in sorted(mapping.items()):out.append(f' if(a=={a}U&&p=={p}U&&pose=={pose}U)return {fr}U;')
 out+=[' return 0xffffU;','}']
 for (a,p,fr),rr in sorted(runs.items()):out.append(f'static const finisher_run_t spr_{a}_{p}_{fr}[]={{'+','.join('{%d,%d}'%tuple(x) for x in rr)+'};')
 out.append('static inline const finisher_run_t *struggle_pair_asset_runs(unsigned a,unsigned p,unsigned frame,unsigned *count){')
 for (a,p,fr),rr in sorted(runs.items()):out.append(f' if(a=={a}U&&p=={p}U&&frame=={fr}U){{*count={len(rr)}U;return spr_{a}_{p}_{fr};}}')
 out+=[' *count=0;return 0;','}','#endif']
 (ROOT/'struggle_pair_assets.h').write_text('\n'.join(out)+'\n')
 report=dict(test=253,version='V0.268',classification='ROM-EXACT',program_sha256=PROGRAM_SHA256,gfx2_sha256=GFX_SHA256,
  raw_category='0x08',raw_action='0x29',descriptor='0x1656a',callback='0x16582',poses=POSES,ticks=[21,9,15,15],finite_ticks=60,
  callback_terminal='first FE completion returns both to raw 0x0B; second gives attacker 0x0C and target 0xFF',
  packs=90,max_pack_bytes=max_bytes,total_pack_bytes=total_bytes,detail=detail,
  note='Partner banks and piece order are preserved exactly; no wrestler or partner pixels are synthesized.')
 (ROOT/'docs'/'test253-struggle-pair-build.json').write_text(json.dumps(report,indent=2)+'\n')
 print('PASS Test253 struggle assets:',90,'packs max',max_bytes,'total',total_bytes)
if __name__=='__main__':main()
