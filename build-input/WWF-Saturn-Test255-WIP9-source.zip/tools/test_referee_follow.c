#include "game.h"
#include <assert.h>
#include <stdio.h>
static unsigned r[6]={0,2,7,1,4,5};
int main(void){game_t g;game_match_start(&g,GAME_TAG,r);g.cpu=false;g.fighters[0].x=30*256;g.fighters[1].x=90*256;g.fighters[0].y=g.fighters[1].y=240*256;int ox=g.referee.x,oy=g.referee.y;for(int i=0;i<80;i++)game_tick(&g,0,0);assert(g.referee.x!=ox||g.referee.y!=oy);assert(g.referee.state==REF_IDLE||g.referee.state==REF_WALK);puts("PASS Test108: referee tracks live wrestler action instead of remaining statically at ring centre");}
