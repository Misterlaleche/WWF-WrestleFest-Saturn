#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "arcade_action_map.h"
#include "arcade_animation.h"
#include "arcade_pair_state.h"
#include "roster_pack.h"
#include "struggle_pair_assets.h"
static uint8_t *read_all(const char *name,size_t *size){FILE*f=fopen(name,"rb");assert(f);fseek(f,0,SEEK_END);long n=ftell(f);assert(n>0);rewind(f);uint8_t*p=malloc((size_t)n);assert(p&&fread(p,1,(size_t)n,f)==(size_t)n);fclose(f);*size=(size_t)n;return p;}
int main(void){
 assert(arcade_action_descriptor_address(0x29U)==0x1656aU);assert(arcade_action_callback_address(0x29U)==0x16582U);assert(arcade_animation_finite_ticks(0x1656aU)==60U);
 assert(arcade_animation_sample(0x1656aU,0)==245U);assert(arcade_animation_sample(0x1656aU,20)==245U);assert(arcade_animation_sample(0x1656aU,21)==246U);assert(arcade_animation_sample(0x1656aU,29)==246U);assert(arcade_animation_sample(0x1656aU,30)==247U);assert(arcade_animation_sample(0x1656aU,44)==247U);assert(arcade_animation_sample(0x1656aU,45)==466U);assert(arcade_animation_sample(0x1656aU,59)==466U);
 for(unsigned ch=0;ch<12;ch++)for(unsigned b=1;b<=3;b++)assert(arcade_action_for_buttons_internal(ch,8,b)==0x29U);
 unsigned packs=0,max=0;const unsigned poses[4]={245,246,247,466};
 for(unsigned a=0;a<10;a++)for(unsigned p=0;p<10;p++)if(a!=p){char name[32];sprintf(name,"cd/S%u%u.PAK",a,p);size_t n;uint8_t*data=read_all(name,&n);assert(n==struggle_pair_bytes[a][p]);assert(n<=STRUGGLE_PAIR_OVERLAY_MAX_BYTES);roster_pack_t pack={0};assert(roster_pack_open(&pack,data,n,4));for(unsigned i=0;i<4;i++){unsigned fr=struggle_pair_asset_frame(a,p,poses[i]),nr=0;assert(fr<4);const finisher_run_t*r=struggle_pair_asset_runs(a,p,fr,&nr);assert(r&&nr);unsigned c0=0,c1=0;for(unsigned k=0;k<nr;k++){if(r[k].role)c1+=r[k].count;else c0+=r[k].count;}assert(c0&&c1);}if(n>max)max=(unsigned)n;free(data);packs++;}
 assert(packs==90U&&max==STRUGGLE_PAIR_OVERLAY_MAX_BYTES);
 arcade_pair29_state_t st={.target_52=0};assert(arcade_pair29_apply_terminal(&st,0x80,0xfe)&&st.target_52==1&&st.attacker_state==0x0b&&st.target_state==0x0b);assert(arcade_pair29_apply_terminal(&st,0x80,0xfe)&&st.target_52==2&&st.attacker_state==0x0c&&st.target_state==0xff);
 puts("PASS Test253: 90 exact Sxy partner packs cover action $29 poses 245/246/247/466; universal P/K mapping, 60-tick clock and two-completion terminal are ROM-backed");
}
