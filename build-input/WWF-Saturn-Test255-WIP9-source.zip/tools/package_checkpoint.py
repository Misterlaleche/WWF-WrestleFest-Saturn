#!/usr/bin/env python3
"""Save sources, required data assets and reports, without executable/disc images."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile
from package_release import source_files


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', type=Path)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    root = args.root.resolve()
    paths = sorted(set(source_files(root)))
    manifest = []
    for path in paths:
        relative = path.relative_to(root)
        if (path.suffix.lower() in ('.iso', '.cue', '.elf', '.o') or
                path.name.upper() in ('A.BIN', '0.BIN', 'IP.BIN') or
                'build' in relative.parts):
            raise RuntimeError(f'Executable/disc output included: {relative}')
        manifest.append(hashlib.sha256(path.read_bytes()).hexdigest() + '  ' + relative.as_posix())
    args.output.parent.mkdir(parents=True, exist_ok=True)
    # Exclusive creation protects an earlier checkpoint from accidental replacement.
    with zipfile.ZipFile(args.output, 'x', zipfile.ZIP_DEFLATED) as archive:
        for path in paths:
            archive.write(path, path.relative_to(root))
        archive.writestr('SOURCE-SHA256.txt', '\n'.join(manifest) + '\n')
    with zipfile.ZipFile(args.output) as archive:
        bad = archive.testzip()
        if bad:
            raise RuntimeError(f'ZIP CRC check failed: {bad}')
    print(json.dumps({'path': str(args.output.resolve()), 'source_files': len(paths),
                      'bytes': args.output.stat().st_size,
                      'sha256': hashlib.sha256(args.output.read_bytes()).hexdigest(),
                      'disc_images': False}, indent=2))


if __name__ == '__main__':
    main()
