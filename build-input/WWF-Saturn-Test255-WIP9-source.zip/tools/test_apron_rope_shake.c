#include "game.h"
#include <assert.h>
#include <stdio.h>
static const unsigned roster[6]={0,2,7,1,4,5};
int main(void){
 game_t g;game_match_start(&g,GAME_TAG,roster);g.cpu=false;
 fighter_t *m=&g.fighters[2];m->health=m->max_health;m->power_meter=479;
 game_tick(&g,0,0);
 assert(m->power_up&&m->rope_shakes==1&&m->apron_state==APRON_ROPE_SHAKE&&m->apron_anim_tick>0);
 int p0=game_arcade_pose(m);for(unsigned i=0;i<20;i++)game_tick(&g,0,0);int p1=game_arcade_pose(m);
 assert(p0>=0&&p1>=0&&p0!=p1);
 for(unsigned i=0;i<80;i++)game_tick(&g,0,0);
 assert(m->power_up&&m->rope_shakes==1&&m->apron_state==APRON_POWER&&m->apron_anim_tick==0);
 /* Power does not retrigger every frame. */for(unsigned i=0;i<500;i++)game_tick(&g,0,0);assert(m->rope_shakes==1);
 puts("PASS: Power Up raises one rope-shake apron event with bounded animation state");
}