#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arcade_animation.h"
#include "ring_transition_assets.h"
#include "roster_pack.h"
static uint8_t *read_all(const char *name,size_t *n){FILE*f=fopen(name,"rb");assert(f);fseek(f,0,SEEK_END);long z=ftell(f);assert(z>0);rewind(f);uint8_t*p=malloc((size_t)z);assert(p&&fread(p,1,(size_t)z,f)==(size_t)z);fclose(f);*n=(size_t)z;return p;}
static unsigned fnv(const uint8_t*p,size_t n){uint32_t h=2166136261U;while(n--){h^=*p++;h*=16777619U;}return h;}
int main(void){
 size_t n=0;uint8_t*p=read_all("cd/RING14.PAK",&n);assert(n==RING_TRANSITION_PACK_BYTES);assert(fnv(p,n)==RING_TRANSITION_PACK_HASH);
 roster_pack_t pack={0};assert(roster_pack_open(&pack,p,n,RING_TRANSITION_PACK_FRAMES));assert(pack.frames==210U);
 size_t pn=0;uint8_t*pal=read_all("assets/RING14.PAL",&pn);assert(pn==32U);uint8_t*rom=read_all("program.bin",&pn);assert(pn==0x80000U);assert(!memcmp(pal, (const uint8_t[]){0x80,0x00,0x80,0x00,0xa9,0x4a,0xff,0xff,0xd6,0xb5,0xfe,0x60,0xc4,0xc0,0xfc,0xc6,0xa8,0x40,0xff,0x6e,0xfe,0x71,0x80,0x0a,0x80,0x17,0xce,0x7f,0xdd,0x44,0x80,0x1f},32));
 /* Exit/entry identity and callback side bit are proven in program.bin. */
 assert(arcade_action_descriptor_address(0x69U)==0x199fcU);assert(arcade_action_callback_address(0x69U)==0x19a20U);assert(arcade_animation_finite_ticks(0x199fcU)==91U);
 assert(!memcmp(rom+0x19a90,(const uint8_t[]){0x08,0xa8,0x00,0x02,0x00,0x33},6));
 assert(arcade_action_descriptor_address(0x6cU)==0x19c28U);assert(arcade_action_callback_address(0x6cU)==0x19c48U);assert(!memcmp(rom+0x19c54,(const uint8_t[]){0x08,0xe8,0x00,0x02,0x00,0x33},6));
 for(unsigned ch=0;ch<10;ch++){
  for(unsigned pose=32;pose<=41;pose++){unsigned fr=ring_transition_asset_frame(ch,pose),nr=0;assert(fr<210U);const ring_transition_run_t*r=ring_transition_asset_runs(fr,&nr);assert(r&&nr);unsigned has14=0;for(unsigned k=0;k<nr;k++)has14|=r[k].palette==14U;assert(has14);}
  for(unsigned pose=42;pose<=43;pose++){unsigned fr=ring_transition_asset_frame(ch,pose),nr=0;const ring_transition_run_t*r=ring_transition_asset_runs(fr,&nr);assert(fr<210U&&r&&nr);}
 }
 free(rom);free(pal);free(p);
 puts("PASS Test253: RING14 preserves exact bank-14 rope compositions/palette; raw $69 exit and $6C front-entry descriptors plus inside-bit callbacks are ROM-backed");
}
