#include "finisher_data.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(void){FILE*f=fopen("program.bin","rb");assert(f);assert(!fseek(f,0,SEEK_END));long n=ftell(f);assert(n==524288L);rewind(f);uint8_t*r=malloc((size_t)n);assert(r&&fread(r,1,(size_t)n,f)==(size_t)n);fclose(f);
 static const uint8_t desc[]={0x00,0x01,0x5c,0xe0}; /* descriptor pointer/address identity used by candidate */
 (void)desc;
 const finisher_record_t *e=finisher_record(8);assert(e->action_index==0x23&&e->rom_address==0x15ce0);assert(e->evidence==FINISHER_EVIDENCE_CANDIDATE);assert(!finisher_descriptor_mapped(8));free(r);
 puts("PASS Test146: Earthquake finisher candidate action $23/$15CE0 is gated because Test136 proves that action/address is STOMP; no Vertical Splash semantic is invented");return 0;}
