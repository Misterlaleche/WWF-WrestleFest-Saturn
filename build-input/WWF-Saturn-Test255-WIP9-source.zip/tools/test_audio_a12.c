#include <assert.h>
#include <string.h>
#include "../wf_audio_event.h"

static wf_audio_event_t ev[32];
static unsigned n;
static void emit(wf_audio_event_t e,void *u){(void)u;assert(n<32);ev[n++]=e;}

int main(void){
    game_t g; memset(&g,0,sizeof(g));
    g.fighters[0].health=100;
    wf_audio_observer_t o; wf_audio_observer_reset(&o,2);

    wf_audio_observe_game(&o,&g,emit,0);
    assert(n==1 && ev[0].command==0x0C && ev[0].klass==WF_AUDIO_CLASS_MUSIC);

    g.fighters[0].health=23;
    wf_audio_observe_game(&o,&g,emit,0);
    assert(n==2 && ev[1].command==0x0B);
    wf_audio_observe_game(&o,&g,emit,0);
    assert(n==2); /* latch */
    g.fighters[0].health=24; wf_audio_observe_game(&o,&g,emit,0);
    assert(n==3 && ev[2].command==0x0C); /* recovered stage restore */
    g.fighters[0].health=0;  wf_audio_observe_game(&o,&g,emit,0);
    assert(n==4 && ev[3].command==0x0B);

    for(unsigned c=17;c<=20;c++){g.ringout_count=c;wf_audio_observe_game(&o,&g,emit,0);}
    assert(ev[n-4].command==0x65);
    assert(ev[n-3].command==0x66);
    assert(ev[n-2].command==0x67);
    assert(ev[n-1].command==0x68);

    unsigned before=n;
    g.finisher_impact=true;wf_audio_observe_game(&o,&g,emit,0);
    assert(n==before+1 && ev[n-1].command==0x32);
    wf_audio_observe_game(&o,&g,emit,0);
    assert(n==before+1);
    return 0;
}
