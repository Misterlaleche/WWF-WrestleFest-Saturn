#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void seq(long o,const uint8_t*p,size_t n){FILE*f=fopen("program.bin","rb");assert(f);uint8_t*b=malloc(n);assert(b);assert(fseek(f,o,SEEK_SET)==0&&fread(b,1,n,f)==n);fclose(f);assert(!memcmp(b,p,n));free(b);}
int main(void){
 const uint8_t p[]={0x30,0x28,0x00,0x66,0xb0,0x68,0x00,0x72,0x65,0x06,0x31,0x68,0x00,0x72,0x00,0x66};seq(0x910a,p,sizeof p);
 puts("PASS Test199: $90D6 clamps live +$66 to actor maximum +$72 after restore while preserving the separately queued +$6A addition");return 0;}
