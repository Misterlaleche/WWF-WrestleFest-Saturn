#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static unsigned occurrences(const uint8_t *p,size_t n,const uint8_t *pat,size_t m){
 unsigned c=0; for(size_t i=0;i+m<=n;i++) if(!memcmp(p+i,pat,m)) ++c; return c;
}
int main(void){
 FILE *f=fopen("program.bin","rb"); assert(f);
 assert(fseek(f,0,SEEK_END)==0); long sz=ftell(f); assert(sz==524288L); rewind(f);
 uint8_t *rom=(uint8_t*)malloc((size_t)sz); assert(rom); assert(fread(rom,1,(size_t)sz,f)==(size_t)sz); fclose(f);
 static const uint8_t read109[]={0x10,0x28,0x01,0x09};              /* $1E45C MOVE.b +$109(A0),D0 */
 static const uint8_t inc109[] ={0x52,0x2A,0x01,0x09};              /* $2006C ADDQ.b #1,+$109(A2) */
 static const uint8_t cmp109[] ={0x0C,0x28,0x00,0x05,0x01,0x09};   /* $2128A CMPI.b #$05,+$109(A0) */
 assert(!memcmp(rom+0x1E45C,read109,sizeof read109));
 assert(!memcmp(rom+0x2006C,inc109,sizeof inc109));
 assert(!memcmp(rom+0x2128A,cmp109,sizeof cmp109));
 assert(occurrences(rom,(size_t)sz,read109,sizeof read109)==1);
 assert(occurrences(rom,(size_t)sz,inc109,sizeof inc109)==1);
 assert(occurrences(rom,(size_t)sz,cmp109,sizeof cmp109)==1);
 free(rom);
 puts("PASS Test140: bounded ROM audit pins explicit +$109 read/increment/compare sites; semantic label remains unclaimed");
 return 0;
}
