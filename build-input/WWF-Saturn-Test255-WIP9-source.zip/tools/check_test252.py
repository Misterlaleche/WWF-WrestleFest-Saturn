#!/usr/bin/env python3
"""Focused Test252 host regression; does not build a Saturn disc image."""
from pathlib import Path
import os,subprocess,sys,tempfile
root=Path(__file__).resolve().parents[1]
sanitize='--sanitize' in sys.argv
flags=['-fsanitize=address,undefined','-fno-omit-frame-pointer','-g'] if sanitize else []
tests={
 'test245_fallback_scope':['tools/test245_fallback_scope.c'],
 'test247_fallback_reduction':['tools/test247_fallback_reduction.c'],
 'test251_full_gfx2_ground_coverage':['tools/test251_full_gfx2_ground_coverage.c'],
 'test252_object_bank15_assets':['roster_pack.c','codec.c','tools/test252_object_bank15_assets.c'],
}
env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1') if sanitize else os.environ
log=[]
with tempfile.TemporaryDirectory(prefix='wwf-test252-') as td:
 for name,sources in tests.items():
  out=Path(td)/name
  subprocess.run(['gcc','-std=c11','-O1','-I.',*flags,*sources,'-o',str(out)],cwd=root,check=True)
  r=subprocess.run([str(out)],cwd=root,check=True,env=env,text=True,capture_output=True)
  print(r.stdout,end='');log.append(name+'\n'+r.stdout)
# Source-level guard for the now-large root directory. The generated CD input
# has 125 files at Test252, so the old 64-entry CDFS list was insufficient.
main=(root/'main.c').read_text()
assert 'CDFS_FILE_CAPACITY=160' in main and 'cdfs_filelist_init(&files,file_entries,CDFS_FILE_CAPACITY)' in main
assert len([p for p in (root/'cd').iterdir() if p.is_file()])<=160
summary='PASS Test252 focused host regression'+(' (ASan/UBSan)' if sanitize else '')
print(summary)
log.append(summary+'\n')
(root/'docs'/('test252-sanitized.log' if sanitize else 'test252-host.log')).write_text('\n'.join(log))
