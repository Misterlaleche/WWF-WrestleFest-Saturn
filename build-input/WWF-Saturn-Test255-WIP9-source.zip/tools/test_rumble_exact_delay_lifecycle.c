#include "game.h"
#include "arcade_rumble.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 unsigned r[10]={0,1,2,3,4,5,6,7,8,9};game_t g;game_match_start_rumble_queue(&g,r,10);g.cpu=false;
 assert(game_rumble_active_count(&g)==6&&g.rumble_next==6);
 g.fighters[3].outside=true;game_tick(&g,0,0);
 assert(!(g.active_mask&(1U<<3)));assert(g.rumble_pending_eliminations==1);assert(g.rumble_entry_delay==0);assert(!game_rumble_announcement_visible(&g));
 for(unsigned i=1;i<ARCADE_RUMBLE_ENTRY_DELAY;i++){game_tick(&g,0,0);assert(!game_rumble_announcement_visible(&g));assert(g.rumble_pending_eliminations==1);}
 game_tick(&g,0,0);
 assert(g.rumble_pending_eliminations==0);assert(g.rumble_entry_delay==0);assert(game_rumble_announcement_visible(&g));
 /* Reverse free-slot scan sees slot 3 as the highest free active slot. */
 assert(g.rumble_pending_slot==3);assert(game_rumble_announced_character(&g)==6);
 puts("PASS Test124: canonical Rumble replacement lifecycle now waits the ROM-exact $0126 ticks and uses the exact six-slot reverse free scan before the provisional callout/entry phases");
}
