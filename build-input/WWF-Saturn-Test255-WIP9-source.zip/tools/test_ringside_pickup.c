#include <assert.h>
#include <stdio.h>
#include "game.h"
#include "arcade_ringside.h"
int main(void){
 game_t g;unsigned r[6]={0,2,1,3,0,0};game_match_start(&g,GAME_TAG,r);
 assert(g.ringside_object_count==2&&g.ringside_objects[0].type==0&&g.ringside_objects[1].type==1);
 assert(g.ringside_objects[0].native_position_provisional&&g.ringside_objects[1].native_position_provisional);
 g.fighters[0].outside=true;g.fighters[0].x=g.ringside_objects[0].x;g.fighters[0].y=g.ringside_objects[0].y;
 assert(game_try_ringside_pickup(&g,0));assert(g.fighters[0].held_object==1&&g.ringside_objects[0].holder==1&&g.ringside_objects[0].state==ARCADE_OBJECT_HELD_STATE);
 assert(g.fighters[0].state==ST_OBJECT_PICKUP&&game_arcade_pose(&g.fighters[0])==114);
 g.fighters[0].x+=10*256;game_tick(&g,0,0);assert(g.ringside_objects[0].x==g.fighters[0].x);
 for(unsigned i=1;i<ARCADE_OBJECT_PICKUP_TICKS;i++)game_tick(&g,0,0);assert(g.fighters[0].state==ST_IDLE);
 assert(!game_try_ringside_pickup(&g,1));
 game_drop_ringside_object(&g,0);assert(!g.fighters[0].held_object&&!g.ringside_objects[0].holder&&g.ringside_objects[0].state==2);
 /* input path uses the same exact contact predicate */
 g.ringside_objects[0].state=3;g.ringside_objects[0].x=g.fighters[0].x;g.ringside_objects[0].y=g.fighters[0].y;
 game_tick(&g,0,INPUT_PUNCH);assert(g.fighters[0].held_object==1&&g.fighters[0].state==ST_OBJECT_PICKUP);
 puts("PASS: TAG ringside object ownership, exact pickup state/pose clock, tracking and explicit provisional placement");
}
