#include "game.h"
#include <assert.h>
#include <stdio.h>
int main(void){unsigned r[6]={0,2,7,1,4,5};game_t g;game_match_start(&g,GAME_TAG,r);fighter_t*f=&g.fighters[0];f->state=ST_IDLE;assert(game_rope_deflection(&g,f->x/256,f->y/256)==0);f->state=ST_REBOUND;assert(game_rope_deflection(&g,f->x/256,f->y/256)==6);assert(game_rope_deflection(&g,f->x/256+80,f->y/256)==0);puts("PASS Test113: rope renderer receives local 1..6 px deflection around a rebounding wrestler instead of remaining rigid");}
