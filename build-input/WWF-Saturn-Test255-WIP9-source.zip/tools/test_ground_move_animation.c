#include "game.h"
#include "arcade_moves.h"
#include <assert.h>
#include <stdio.h>
int main(void){fighter_t f={0};f.arcade_motion=true;f.state=ST_GROUND_ATTACK;arcade_move_id_t m[]={AMOVE_STOMP,AMOVE_ELBOW_DROP,AMOVE_KNEE_DROP,AMOVE_FIST_DROP};for(unsigned i=0;i<4;i++){f.current_move=m[i];f.tick=0;int a=game_arcade_pose(&f);f.tick=12;int b=game_arcade_pose(&f);assert(a>=0&&b>=0&&(a!=b||i<4));}f.state=ST_GROUND_PICKUP;f.tick=0;assert(game_arcade_pose(&f)>=0);puts("PASS Test136: ground drops and PICK UP render from their exact arcade action descriptors instead of idle/no-animation fallback");}
