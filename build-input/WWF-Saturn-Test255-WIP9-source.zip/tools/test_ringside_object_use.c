#include <assert.h>
#include <stdio.h>
#include "game.h"
#include "arcade_ringside.h"
static const unsigned roster[6]={0,2,7,1,4,5};
static void tickn(game_t *g,unsigned n){while(n--)game_tick(g,0,0);}
int main(void){game_t g;game_match_start(&g,GAME_TAG,roster);g.cpu=false;
 fighter_t *p=&g.fighters[0];p->outside=true;p->x=g.ringside_objects[0].x;p->y=g.ringside_objects[0].y;p->rise_y=p->y;
 assert(game_try_ringside_pickup(&g,0));tickn(&g,ARCADE_OBJECT_PICKUP_TICKS);assert(p->state==ST_IDLE&&p->held_object==1);
 assert(game_try_ringside_object_use(&g,0));assert(p->state==ST_OBJECT_USE&&game_arcade_pose(p)==116);
 tickn(&g,9);assert(game_arcade_pose(p)==117);tickn(&g,9);assert(game_arcade_pose(p)==118);
 tickn(&g,9);assert(p->state==ST_IDLE&&!p->held_object&&g.ringside_objects[0].state==ARCADE_OBJECT_THROWN_STATE&&!g.ringside_objects[0].holder);
 assert(g.ringside_objects[0].x==p->x+p->facing*ARCADE_OBJECT_USE_RAW_X*256);
 assert(g.ringside_objects[0].y==p->y&&g.ringside_objects[0].z==ARCADE_OBJECT_USE_RAW_Z*256);
 /* Type 1 selects the separate 121/122/123 sequence. */
 g.ringside_objects[1].state=ARCADE_OBJECT_AVAILABLE_STATE;g.ringside_objects[1].x=p->x;g.ringside_objects[1].y=p->y;
 assert(game_try_ringside_pickup(&g,0));assert(p->held_object==2&&game_arcade_pose(p)==119);tickn(&g,ARCADE_OBJECT_PICKUP_TICKS);
 assert(game_try_ringside_object_use(&g,0));assert(game_arcade_pose(p)==121);
 puts("PASS: live ringside pickup/use states select each object's original wrestler animation and release to state 2");}
