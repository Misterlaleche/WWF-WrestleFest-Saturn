#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include "arcade_ringside.h"
int main(void){
 bool init=false;unsigned timer=0,phase=0,state=4;
 state=arcade_ringside_state4_step(&init,&timer,&phase);
 assert(state==4&&init&&timer==0x10&&phase==1);
 unsigned calls=1;
 while(state!=ARCADE_OBJECT_AVAILABLE_STATE&&calls<100){
  state=arcade_ringside_state4_step(&init,&timer,&phase);++calls;
 }
 assert(state==ARCADE_OBJECT_AVAILABLE_STATE);
 assert(phase==4&&timer==0x10&&calls==49);
 puts("PASS: ROM $FF54 state-4 clock uses $10 reloads and returns object to available state 3 on phase 4 after 49 handler calls");
 return 0;
}
