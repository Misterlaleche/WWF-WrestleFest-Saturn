#include "game.h"
#include "arcade_moves.h"
#include <assert.h>
#include <stdio.h>
static const unsigned r[6]={0,2,7,1,4,5};
static void prep(game_t *g,unsigned ch){game_match_start(g,GAME_TAG,r);g->cpu=false;fighter_t *p=&g->fighters[0],*q=&g->fighters[1];p->character=ch;p->x=120*256;p->y=200*256;q->x=155*256;q->rise_y=200*256;q->y=217*256;q->state=ST_RECOVER;q->tick=20;}
int main(void){
 for(unsigned ch=0;ch<10;ch++){game_t g;prep(&g,ch);unsigned hp=g.fighters[1].health;game_tick(&g,0,INPUT_PUNCH|INPUT_KICK);assert(g.fighters[0].state==ST_GROUND_ATTACK);assert(g.fighters[0].current_move==(unsigned)arcade_move_set(ch)->ground_drop);for(unsigned i=0;i<12;i++)game_tick(&g,0,0);assert(g.fighters[1].health<hp);unsigned after=g.fighters[1].health;for(unsigned i=0;i<90&&g.fighters[0].state==ST_GROUND_ATTACK;i++)game_tick(&g,0,0);assert(g.fighters[1].health==after&&g.fighters[0].state==ST_IDLE);}
 game_t g;prep(&g,0);g.fighters[0].power_up=true;unsigned hp=g.fighters[1].health;game_tick(&g,0,INPUT_PUNCH|INPUT_KICK);for(unsigned i=0;i<12;i++)game_tick(&g,0,0);assert(hp-g.fighters[1].health==2*arcade_move_native_damage(arcade_move_set(0)->ground_drop));
 puts("PASS: all ten wrestlers execute their catalogued ground drop with one impact and Power Up doubling");
}