#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static int scan(const unsigned char*r,size_t n,const unsigned char*p,size_t z,size_t*out,size_t cap){int c=0;for(size_t i=0;i+z<=n;i++)if(!memcmp(r+i,p,z)){if((size_t)c<cap)out[c]=i;c++;}return c;}
int main(void){FILE*f=fopen("program.bin","rb");assert(f);fseek(f,0,SEEK_END);long ln=ftell(f);rewind(f);size_t n=(size_t)ln;unsigned char*r=malloc(n);assert(r&&fread(r,1,n,f)==n);fclose(f);
 const unsigned char call[]={0x4e,0xb9,0x00,0x00,0xf5,0x60};size_t o[4];assert(scan(r,n,call,sizeof call,o,4)==2);assert(o[0]==0x0fd0&&o[1]==0x1080);
 const unsigned char split[]={0x08,0x39,0x00,0x00,0x00,0x1c,0x00,0x83,0x66,0x00,0x00,0xa6};assert(!memcmp(r+0x0fa4,split,sizeof split));
 const unsigned char inner[]={0x61,0x00,0x00,0x12};assert(!memcmp(r+0xf560,inner,sizeof inner));
 free(r);puts("PASS Test83: global frame-loop branches both call $F560, which immediately invokes $F574 pair candidate resolver; raw $0B/$0C/$29 machine is not a Restrain-only callback path");return 0;}
