#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void seq(long o,const uint8_t*p,size_t n){FILE*f=fopen("program.bin","rb");assert(f);uint8_t*b=malloc(n);assert(b);assert(fseek(f,o,SEEK_SET)==0&&fread(b,1,n,f)==n);fclose(f);assert(!memcmp(b,p,n));free(b);}
int main(void){
 const uint8_t p[]={0x11,0x7c,0xff,0xf0,0x00,0x19,0x11,0x7c,0x00,0x28,0x00,0x1b,0x0c,0x28,0x00,0x47,0x00,0x61,0x66,0x0c,0x11,0x7c,0xff,0xf8,0x00,0x19,0x11,0x7c,0xff,0xf0,0x00,0x1b};seq(0x144d0,p,sizeof p);
 puts("PASS Test182: action-$47 has exact phase-1 sprite offsets $F8/$F0 instead of the neighbouring default $F0/$28");return 0;}
