#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "arcade_earthquake_raw.h"
static uint16_t be16(const unsigned char *p){return (uint16_t)((p[0]<<8)|p[1]);}
int main(void){
 FILE *f=fopen("program.bin","rb"); assert(f); unsigned char b[8];
 assert(fseek(f,0x2764,SEEK_SET)==0); assert(fread(b,1,8,f)==8); fclose(f);
 assert(be16(b)==0x0038U&&be16(b+2)==0xfff8U); /* selector 2 */
 assert(be16(b+4)==0x0058U&&be16(b+6)==0xfff8U); /* selector 3: adjacency guard */
 f=fopen("program.bin","rb"); assert(f); assert(fseek(f,0x2770,SEEK_SET)==0); assert(fread(b,1,4,f)==4); fclose(f);
 assert(be16(b)==0x0040U&&be16(b+2)==0xffffU); /* selector 5 */
 puts("PASS Test150: action-$47 selectors 2/5 resolve exact $26AE table vectors {+$38,-8}/{+$40,-1}; raw visual/effect semantics only");
 return 0;
}
