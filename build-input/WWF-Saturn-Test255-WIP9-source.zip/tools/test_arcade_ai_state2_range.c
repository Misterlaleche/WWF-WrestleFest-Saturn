#include "arcade_ai.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned char *load(size_t*n){FILE*f=fopen("program.bin","rb");assert(f);fseek(f,0,SEEK_END);*n=(size_t)ftell(f);rewind(f);unsigned char*b=malloc(*n);assert(b&&fread(b,1,*n,f)==*n);fclose(f);return b;}
int main(void){size_t n;unsigned char*b=load(&n);
 const unsigned char dispatch[]={0x00,0x01,0xd7,0xb6};assert(!memcmp(b+0x1c1fc,dispatch,4));
 const unsigned char range[]={0x30,0x28,0x00,0xbc,0xb0,0x68,0x00,0xb0,0x65,0x1c};assert(!memcmp(b+0x1d902,range,sizeof(range)));
 assert(arcade_ai_state2_range_transition(0xa1,0xa0,0)==2);
 assert(arcade_ai_state2_range_transition(0xa0,0xa0,0)==3);
 assert(arcade_ai_state2_range_transition(0x50,0xa0,0)==3);
 assert(arcade_ai_state2_range_transition(0xa0,0xa0,1)==5);
 assert(arcade_ai_state2_range_transition(0x50,0,1)==2);
 free(b);puts("PASS: Test132 raw state 2 remains active beyond +$BC range and transitions to state 3/5 once +$B0 reaches it");}
