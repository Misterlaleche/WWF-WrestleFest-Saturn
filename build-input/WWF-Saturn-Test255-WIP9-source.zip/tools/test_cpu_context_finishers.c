#include "finisher_runtime.h"
#include <assert.h>
#include <stdio.h>
#define FP 256
static void base(game_t *g,unsigned cpu_ch){unsigned r[6]={0,cpu_ch,7,2,4,5};game_match_start(g,GAME_TAG,r);g->cpu=true;fighter_t *p=&g->fighters[0],*q=&g->fighters[1];p->health=18;p->stamina_tier=2;p->x=150*FP;p->y=200*FP;q->x=120*FP;q->y=200*FP;q->cooldown=0;}
static void finish(game_t *g){unsigned before=g->fighters[0].health;game_tick(g,0,0);assert(g->pair==PAIR_FINISHER&&g->pair_attacker==1);for(unsigned i=0;i<500&&g->pair==PAIR_FINISHER;i++)game_tick(g,0,0);assert(g->pair!=PAIR_FINISHER&&g->finishers==1&&g->fighters[0].health<before);}
int main(void){game_t g;base(&g,3);g.fighters[0].state=ST_RUN;g.fighters[0].whipped=true;g.fighters[0].run_speed=40;assert(game_finisher_probe(&g,1)==FINISHER_PROBE_READY);finish(&g);for(unsigned k=0;k<2;k++){unsigned ch=k?9:6;base(&g,ch);g.fighters[0].facing=g.fighters[1].facing=1;assert(game_finisher_probe(&g,1)==FINISHER_PROBE_READY);finish(&g);}puts("PASS: provisional CPU opportunity policy executes recovered Boss Man and behind finishers");}
