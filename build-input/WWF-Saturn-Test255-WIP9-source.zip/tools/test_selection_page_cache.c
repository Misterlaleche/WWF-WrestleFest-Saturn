#include "intro.h"
#include "intro_data.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
static unsigned load(const char*n,unsigned char**p){FILE*f=fopen(n,"rb");assert(f);fseek(f,0,SEEK_END);long z=ftell(f);rewind(f);*p=malloc(z);assert(*p&&fread(*p,1,z,f)==(size_t)z);fclose(f);return (unsigned)z;}
int main(void){unsigned char *p[2],*bmp=malloc(INTRO_BITMAP_BYTES);assert(bmp);unsigned n0=load("cd/SELECT0.RLE",&p[0]),n1=load("cd/SELECT1.RLE",&p[1]);assert(n0<65536&&n1<65536);assert(intro_unpack(p[0],n0,bmp,INTRO_BITMAP_BYTES));unsigned a=bmp[1000];assert(intro_unpack(p[1],n1,bmp,INTRO_BITMAP_BYTES));unsigned b=bmp[1000];(void)a;(void)b;free(p[0]);free(p[1]);free(bmp);puts("PASS Test111: both selection pages fit the 64 KiB RAM caches and decode directly from memory; page changes no longer require CD reads");}
