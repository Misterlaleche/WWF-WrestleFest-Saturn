#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void seq(long o,const uint8_t*p,size_t n){FILE*f=fopen("program.bin","rb");assert(f);uint8_t*b=malloc(n);assert(b);assert(fseek(f,o,SEEK_SET)==0&&fread(b,1,n,f)==n);fclose(f);assert(!memcmp(b,p,n));free(b);}
int main(void){const uint8_t a[]={0x35,0x7c,0x00,0x2a,0x00,0x64,0x06,0x2a,0x00,0x05,0x00,0xc7,0x35,0x7c,0x00,0x16,0x00,0x68};seq(0x17100,a,sizeof a);const uint8_t b[]={0x08,0xea,0x00,0x03,0x00,0x32,0x08,0xea,0x00,0x05,0x00,0x64};seq(0x17112,b,sizeof b);puts("PASS Test191: Boss Man Slam impact writes victim +$64=$2A, increments +$C7 by 5, exact +$68=$16 (22), then sets bits3/5");return 0;}
