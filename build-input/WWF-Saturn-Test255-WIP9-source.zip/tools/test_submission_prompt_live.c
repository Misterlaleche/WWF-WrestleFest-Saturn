#include "game.h"
#include "arcade_moves.h"
#include <assert.h>
#include <stdio.h>
int main(void){unsigned r[6]={0,2,1,3,4,5};game_t g;game_match_start(&g,GAME_TAG,r);g.cpu=false;g.pair=PAIR_SUBMISSION;g.pair_attacker=1;g.pair_move=AMOVE_BOSTON_CRAB;g.fighters[0].health=30;assert(game_escape_prompt_visible(&g));unsigned e=g.grapple_escape;game_tick(&g,0,INPUT_PUNCH);assert(g.grapple_escape==e+1);for(unsigned i=0;i<7&&g.pair==PAIR_SUBMISSION;i++){game_tick(&g,0,(i&1)?INPUT_PUNCH:INPUT_KICK);}assert(g.pair==PAIR_NONE);puts("PASS Test135: player-victim submission exposes mash prompt and fresh action presses escape the hold before submission loss");}
