#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void seq(long o,const uint8_t*p,size_t n){FILE*f=fopen("program.bin","rb");assert(f);uint8_t*b=malloc(n);assert(b);assert(fseek(f,o,SEEK_SET)==0&&fread(b,1,n,f)==n);fclose(f);assert(!memcmp(b,p,n));free(b);}
int main(void){
 const uint8_t p[]={0x35,0x7c,0x00,0x05,0x00,0x20,0x35,0x7c,0x00,0x77,0x00,0x60,0x35,0x7c,0x00,0x0a,0x00,0x68};seq(0x1459c,p,sizeof p); const uint8_t q[]={0x06,0x2a,0x00,0x01,0x00,0xc7};seq(0x145c2,q,sizeof q);
 puts("PASS Test186: action-$47 contact branch B writes victim state 5, +$60=$77, +$68=10 and increments +$C7");return 0;}
