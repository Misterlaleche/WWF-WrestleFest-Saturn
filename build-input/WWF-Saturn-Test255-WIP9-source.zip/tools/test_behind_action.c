#include <assert.h>
#include <stdio.h>
#include "arcade_action_map.h"
#include "arcade_moves.h"
int main(void){for(unsigned s=0;s<12;++s){assert(arcade_action_behind(s,1)==0x1c);assert(arcade_action_behind(s,2)==0x1d);assert(arcade_action_behind(s,3)==0xff);}assert(arcade_behind_button_select(1)==AMOVE_SLEEPER);assert(arcade_behind_button_select(2)==AMOVE_RESTRAIN);assert(arcade_behind_button_select(3)==AMOVE_NONE);assert(arcade_behind_context_raw(0x4f,0x0f,1,1));assert(!arcade_behind_context_raw(0x50,0x0f,1,1));assert(!arcade_behind_context_raw(0x4f,0x10,1,1));assert(!arcade_behind_context_raw(1,1,1,-1));puts("PASS Test72: behind category $10 geometry; button1=$1C Sleeper, button2=$1D Restrain, both=$FF");}
