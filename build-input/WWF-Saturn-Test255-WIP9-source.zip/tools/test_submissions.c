#include "game.h"
#include "arcade_moves.h"
#include <assert.h>
#include <stdio.h>
static void prep(game_t *g,unsigned attacker_char,unsigned hp){unsigned r[6]={attacker_char,2,1,3,4,5};game_match_start(g,GAME_TAG,r);g->cpu=false;g->fighters[0].x=100*256;g->fighters[1].x=130*256;g->fighters[0].y=g->fighters[1].y=180*256;g->fighters[1].health=hp;g->fighters[1].stamina_tier=2;g->fighters[0].grapple_serial=1;}
int main(void){game_t g;prep(&g,6,3);game_tick(&g,0,INPUT_GRAB);game_tick(&g,0,INPUT_PUNCH);assert(g.pair==PAIR_SUBMISSION&&g.pair_move==AMOVE_COBRA_CLUTCH);for(unsigned i=0;i<60&&!g.finished;i++)game_tick(&g,0,0);assert(g.finished&&g.winner==0&&g.finish_reason==FINISH_SUBMISSION&&g.submission_pulses==3);
 prep(&g,6,40);g.cpu=true;g.fighters[2].health=g.fighters[3].health=0;game_tick(&g,0,INPUT_GRAB);game_tick(&g,0,INPUT_PUNCH);for(unsigned i=0;i<210&&g.pair==PAIR_SUBMISSION;i++)game_tick(&g,0,0);assert(g.pair==PAIR_NONE&&!g.finished);
 /* Earthquake and DiBiase fourth grapples are typed submissions too. */assert(arcade_move_submission(arcade_move_set(8)->grapple[3]));assert(arcade_move_submission(arcade_move_set(9)->grapple[3]));
 puts("PASS: live grapple submissions drain until escape or zero-stamina victory");}
