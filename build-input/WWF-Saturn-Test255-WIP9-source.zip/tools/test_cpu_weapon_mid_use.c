#include <assert.h>
#include <stdio.h>
#include "game.h"
#include "arcade_ringside.h"

static void setup(game_t *g,int dx){
 unsigned r[6]={0,2,1,3,0,0}; game_match_start(g,GAME_TAG,r); g->cpu=true;
 fighter_t *p=&g->fighters[0],*q=&g->fighters[1];
 p->outside=q->outside=true;p->state=q->state=ST_IDLE;
 q->x=100*256;q->y=220*256;p->x=(100+dx)*256;p->y=220*256;
 ringside_object_t *o=&g->ringside_objects[0];o->state=ARCADE_OBJECT_HELD_STATE;o->holder=2;q->held_object=1;
}
int main(void){
 assert(arcade_ringside_cpu_weapon_mid_use(0x68,0,0));
 assert(arcade_ringside_cpu_weapon_mid_use(0x8f,0,49));
 assert(!arcade_ringside_cpu_weapon_mid_use(0x68,0,50));
 assert(!arcade_ringside_cpu_weapon_mid_use(0x90,0,0));
 assert(!arcade_ringside_cpu_weapon_mid_use(0x67,0,0));
 assert(!arcade_ringside_cpu_weapon_mid_use(0x68,0x0c,0));
 game_t g; setup(&g,0x68); g.ticks=99; /* game tick increments to 100: (100*37)%100 = 0 */
 game_tick(&g,0,0); assert(g.fighters[1].state==ST_OBJECT_USE);
 setup(&g,0x68); g.ticks=49; /* increments to 50: (50*37)%100 = 50 */
 game_tick(&g,0,0); assert(g.fighters[1].state!=ST_OBJECT_USE);
 puts("PASS: CPU mid-range weapon branch reproduces ROM $68..$8F bounds and $1D066 50/50 action-$1F decision");
}
