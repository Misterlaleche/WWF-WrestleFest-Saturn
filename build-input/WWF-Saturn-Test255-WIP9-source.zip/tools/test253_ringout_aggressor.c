#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arcade_animation.h"
#include "ring_transition_assets.h"

static uint8_t *read_all(const char *name,size_t *size){
 FILE *f=fopen(name,"rb");assert(f);assert(!fseek(f,0,SEEK_END));long n=ftell(f);assert(n>=0);rewind(f);
 uint8_t *p=malloc((size_t)n);assert(p&&fread(p,1,(size_t)n,f)==(size_t)n);fclose(f);*size=(size_t)n;return p;
}
int main(void){
 size_t n=0;uint8_t *p=read_all("program.bin",&n);
 const uint8_t producer[]={0x35,0x7c,0x00,0x05,0x00,0x20,0x35,0x7c,0xc0,0x06,0x00,0x60};
 unsigned hits=0;for(size_t i=0;i+sizeof(producer)<=n;i++)if(!memcmp(p+i,producer,sizeof(producer)))++hits;
 assert(hits==4U);
 assert(arcade_action_descriptor_address(0x06U)==0x13020U);
 assert(arcade_action_callback_address(0x06U)==0x13034U);
 assert(arcade_animation_finite_ticks(0x13020U)==91U);
 assert(arcade_animation_sample(0x13020U,0)==175U);
 assert(arcade_animation_sample(0x13020U,32)==175U);
 assert(arcade_animation_sample(0x13020U,33)==176U);
 assert(arcade_animation_sample(0x13020U,57)==176U);
 assert(arcade_animation_sample(0x13020U,58)==0U);
 assert(arcade_animation_sample(0x13020U,90)==0U);
 for(unsigned ch=0;ch<10;ch++){assert(ring_transition_asset_frame(ch,175U)<RING_TRANSITION_PACK_FRAMES);assert(ring_transition_asset_frame(ch,176U)<RING_TRANSITION_PACK_FRAMES);}
 free(p);
 puts("PASS Test253: all four linked ring-out producers assign aggressor raw $06; $13020 is exact 175(33)->176(25)->0(33), 91 ticks, with exact compositions resident");
 return 0;
}
