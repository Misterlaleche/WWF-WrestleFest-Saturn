#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "arcade_action_map.h"
#include "arcade_stamina.h"
static uint32_t be32(const uint8_t *p){return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3];}
int main(void){FILE *f=fopen("program.bin","rb");assert(f);uint8_t *rom=malloc(0x80000);assert(rom);assert(fread(rom,1,0x80000,f)==0x80000);fclose(f);for(unsigned in=0;in<12;++in){uint32_t t=be32(rom + 0xe4fe + in*4);for(unsigned cat=0;cat<21;++cat)for(unsigned b=1;b<=3;++b)assert(arcade_action_for_buttons_internal(in,cat,b)==rom[t+cat*3+(b-1)]);}for(unsigned sel=0;sel<12;++sel)for(unsigned cat=0;cat<21;++cat)for(unsigned b=1;b<=3;++b)assert(arcade_action_for_buttons(sel,cat,b)==arcade_action_for_buttons_internal(arcade_stamina_internal_id(sel),cat,b));free(rom);puts("PASS Test70: complete 756-byte ROM contextual-action matrix matches all 12x21x3 entries");}
