#include "game.h"
#include <stdio.h>
static void sample(const game_t *g,unsigned n,unsigned run) {
 printf("%u,%ld,%ld,%u,%d,%u,%ld,%ld,%u,%d,%u,%d,%d,%d,%d,%u,%u,%u,%u,%u,%d,%u,%u,%d,",n,
 (long)g->fighters[0].x/256,(long)g->fighters[0].y/256,game_pose(&g->fighters[0]),g->fighters[0].facing,g->fighters[0].health,
 (long)g->fighters[1].x/256,(long)g->fighters[1].y/256,game_pose(&g->fighters[1]),g->fighters[1].facing,g->fighters[1].health,
 g->cpu,g->finished,g->pair,game_pair_pose(g),game_pair_clip(g),game_pair_anchor(g),g->pin_count,g->pin_message,run,game_pair_facing(g),g->escape_progress,g->escape_required,g->winner);
 printf("%ld,%ld,%u,%d,%u,%u,%u,",(long)g->referee.x/256,(long)g->referee.y/256,game_referee_pose(g),g->referee.facing,g->referee.state,g->referee.slaps,g->referee.tick);
 printf("%u,%u,%d,%u,",game_escape_prompt_visible(g),game_escape_prompt_pose(g),game_escape_prompt_x(g),g->escape_pulse);
 printf("%d,%d,%d,%d,%u,%u,%u,%d,",g->camera_x,g->camera_y,game_fighter_lift(&g->fighters[0]),game_fighter_lift(&g->fighters[1]),game_over_ropes(&g->fighters[0]),game_over_ropes(&g->fighters[1]),g->fighters[0].state,game_corner_near(&g->fighters[0]));
 unsigned order[8],count=game_draw_order(g,order),packed=0;
 for(unsigned i=0;i<count;i++)packed|=order[i]<<(4*i);
 printf("%u\n",packed);
}
int main(void) {
 puts("tick,x0,y0,pose0,dir0,hp0,x1,y1,pose1,dir1,hp1,cpu,finished,pair,shared_pose,shared_clip,anchor,pin_count,pin_message,run,pair_dir,escape_progress,escape_required,winner,refx,refy,refpose,refdir,refstate,refslaps,reftick,prompt,prompt_pose,prompt_x,effort_pulse,camera_x,camera_y,lift0,lift1,over0,over1,state0,corner_near,draw_order");
 for(unsigned run=0;run<24;run++) {
  game_t g;game_reset(&g);unsigned after_win=0;
  if(run==1){g.fighters[0].x=200*256;g.fighters[0].facing=-1;g.fighters[1].x=140*256;g.fighters[1].facing=1;}
  if(run>=2&&run<9)g.cpu=true;
  if(run==5){g.fighters[0].x=220*256;g.fighters[1].x=110*256;g.fighters[0].facing=-1;g.fighters[1].facing=1;}
  if(run>=6&&run<9) {
   unsigned attacker=run==7?1:0;fighter_t *q=&g.fighters[1-attacker],*p=&g.fighters[attacker];
   g.cpu=attacker;q->x=(run==7?42:278)*256;q->rise_y=(run==8?RING_TOP:RING_BOTTOM)*256;
   q->y=q->rise_y+(attacker?25:17)*256;q->state=ST_DOWN;q->tick=24;q->health=0;q->facing=run==6?-1:1;
   p->x=(run==7?90:230)*256;p->y=q->rise_y;
  }
  if(run>=9&&run<16&&run!=13) {
   int c=(run-9)%4,y=c<2?RING_TOP:RING_BOTTOM,x=(c&1)?game_ring_right(y):game_ring_left(y);
   g.fighters[0].x=x*256;g.fighters[0].y=y*256;g.fighters[0].rise_y=y*256;
   g.fighters[1].x=(x+((c&1)?-120:120))*256;g.fighters[1].y=(y+(c<2?40:-40))*256;g.fighters[1].rise_y=g.fighters[1].y;
   g.fighters[1].facing=(c&1)?1:-1;
   g.camera_x=x-160;if(g.camera_x<CAMERA_MIN_X)g.camera_x=CAMERA_MIN_X;if(g.camera_x>CAMERA_MAX_X)g.camera_x=CAMERA_MAX_X;
   g.camera_y=y-180;
  }
  if(run>=16&&run<20) {
   int y=RING_BOTTOM-1;
   g.fighters[0].x=((run&1)?game_ring_right(y):game_ring_left(y))*256;
   g.fighters[0].y=y*256;g.fighters[0].rise_y=y*256;
   g.fighters[0].facing=(run&1)?-1:1;
   g.fighters[1].x=126*256;g.fighters[1].y=210*256;
  }
  if(run>=20) {
   unsigned who=run>=22?1:0;g.cpu=who;int dir=(run&1)?-1:1;
   fighter_t *q=&g.fighters[1-who],*p=&g.fighters[who];
   q->x=126*256;q->rise_y=220*256;q->y=(220+(who?25:17))*256;
   q->health=0;q->state=ST_DOWN;q->tick=24;q->facing=-dir;
   p->x=q->x+(who?1:-1)*dir*50*256;p->y=220*256;p->facing=dir;
  }
  unsigned escape_key=0;
  for(unsigned n=0;n<(run==2?180:(run==13?1800:(run>=6?360:2000)));n++) {
   unsigned held=0,pressed=0;
   if(!g.finished&&run<2) {
    if(g.pair==PAIR_HOLD)pressed=INPUT_PUNCH;
    else if(g.pair==PAIR_NONE) {
     fighter_t *p=&g.fighters[0],*q=&g.fighters[1];
     if(q->state==ST_RECOVER||q->state==ST_DOWN) {
      if(!p->cooldown&&((q->state==ST_DOWN&&q->tick>=12)||q->tick<RECOVER_PRONE_TICKS))pressed=INPUT_PIN;
     } else if(q->state==ST_IDLE||q->state==ST_WALK) {
      int dx=q->x-p->x;
      if(dx>60*256)held=INPUT_RIGHT;
      else if(dx<-60*256)held=INPUT_LEFT;
      else if(!p->cooldown)pressed=INPUT_GRAB;
     }
    }
   }
   if(!g.finished&&run>=4&&g.pair==PAIR_PIN&&g.pin_attacker==1&&g.pair_tick>=CPU_PIN_SETUP_TICKS&&g.escape_required&&n%6==0)
    pressed=run==4?(INPUT_PUNCH|INPUT_KICK):((escape_key++%2)?INPUT_KICK:INPUT_PUNCH);
   if(run>=6&&run<9&&run!=7&&n==0)pressed=INPUT_PIN;
   if(run==8&&g.pair==PAIR_PIN&&g.pin_count==1)pressed=INPUT_KICK;
   if(run>=9&&run<16&&run!=13) {
    if(n==20)pressed=INPUT_GRAB;
    if(n==100)pressed=run==14?INPUT_KICK:INPUT_PUNCH;
    if(run==15&&n==100)held=INPUT_DOWN;
    if(n==175&&run<13)pressed=INPUT_PIN;
   }
   if(run==13){unsigned dirs[4]={INPUT_LEFT|INPUT_UP,INPUT_RIGHT|INPUT_UP,INPUT_RIGHT|INPUT_DOWN,INPUT_LEFT|INPUT_DOWN};held=dirs[(n/450)%4];}
   if(run>=16&&run<20) {
    held=n<160?INPUT_UP:INPUT_DOWN;
    if(run<18)held|=(run&1)?INPUT_RIGHT:INPUT_LEFT;
   }
   if(run>=20&&run<22&&n==0)pressed=INPUT_PIN;
   game_tick(&g,held,pressed);
   if(n%2==0)sample(&g,n,run);
   if(g.finished&&++after_win>=60)break;
  }
 }
}
