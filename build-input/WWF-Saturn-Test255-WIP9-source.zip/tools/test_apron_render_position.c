#include "game.h"
#include <assert.h>
#include <stdio.h>
int main(void){unsigned r[6]={0,2,7,1,4,5};game_t g;game_match_start(&g,GAME_TAG,r);int x,y;
 game_fighter_draw_position(&g,2,&x,&y);assert(x==g.fighters[2].x/256-16&&y==g.fighters[2].y/256);
 game_fighter_draw_position(&g,3,&x,&y);assert(x==g.fighters[3].x/256+16);
 g.support_phase[0]=SUPPORT_RUN;game_fighter_draw_position(&g,2,&x,&y);assert(x==g.fighters[2].x/256);
 puts("PASS Test104: waiting TAG reserves receive isolated render-only outward correction; live support/gameplay coordinates remain unchanged");}
