#include <assert.h>
#include <stdio.h>
#include "arcade_ringside.h"
int main(void){
 arcade_ringside_state2_probe_t p;
 assert(!arcade_ringside_resolver_2851e(0x300,0x120,0x120,0,&p));
 assert(p.contact_code==0&&p.collision_flags==0&&p.raw_dx==0&&p.raw_dy==0&&p.raw_dz==0);
 assert(arcade_ringside_resolver_2851e(0x300,0x100,0x0f0,0x08,&p));
 assert(p.contact_code==1&&p.raw_dy==0x10&&p.raw_dz==0x18);
 assert((p.collision_flags&(0x08|0x10))==(0x08|0x10));
 assert(arcade_ringside_resolver_2851e(0x300,0x150,0x100,0,&p));
 assert(p.contact_code==4&&p.raw_dy==-0x10&&(p.collision_flags&0x04));
 assert(arcade_ringside_resolver_2851e(0x180,0x120,0x100,0,&p));
 assert(p.contact_code==3&&p.raw_dx==0x48&&(p.collision_flags&0x02));
 assert(arcade_ringside_resolver_2851e(0x480,0x120,0x100,0,&p));
 assert(p.contact_code==3&&p.raw_dx==-0x10&&(p.collision_flags&0x01));
 assert(arcade_ringside_resolver_2851e(0x180,0x150,0x0f0,-4,&p));
 assert(p.contact_code==3&&p.raw_dx==0x48&&p.raw_dy==-0x10&&p.raw_dz==0x0c);
 assert((p.collision_flags&0x16)==0x16);
 puts("PASS ringside resolver $2851E exact corrections");
 return 0;
}
