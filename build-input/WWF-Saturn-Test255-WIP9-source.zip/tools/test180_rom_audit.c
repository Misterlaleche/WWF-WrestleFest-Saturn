#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void seq(long o,const uint8_t*p,size_t n){FILE*f=fopen("program.bin","rb");assert(f);uint8_t*b=malloc(n);assert(b);assert(fseek(f,o,SEEK_SET)==0&&fread(b,1,n,f)==n);fclose(f);assert(!memcmp(b,p,n));free(b);}
int main(void){
 const uint8_t p[]={0x4a,0xa8,0x00,0x7e,0x67,0x0a,0x22,0x68,0x00,0x7e,0x08,0xa9,0x00,0x07,0x00,0xb5};seq(0x2140e,p,sizeof p);
 puts("PASS Test180: Royal cleanup at $2140E follows non-null +$7E and clears its +$B5 bit7 before returning");return 0;}
