#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(void){FILE*f=fopen("program.bin","rb");assert(f);uint8_t b[30];assert(fseek(f,0x26d0,SEEK_SET)==0);assert(fread(b,1,sizeof b,f)==sizeof b);fclose(f);
 const uint8_t q[]={0x34,0x28,0x00,0x5c,0x32,0x28,0x00,0x5e,0x02,0x82,0x00,0x00,0xff,0xff,0x84,0xc1,0x02,0x82,0x00,0x00,0xff,0xff,0xe3,0x4a,0x4a,0x82,0x67,0x00,0x00,0x6a};
 assert(!memcmp(b,q,sizeof q));puts("PASS Test152: ROM $26AE derives its raw trajectory divisor from unsigned (+$5C/+$5E), masks to 16 bits, doubles it, and exits if the result is zero");return 0;}
