#include "session.h"
#include <assert.h>
#include <stdio.h>
int main(void){session_t s;session_reset(&s,0);s.mode=1;s.phase=SESSION_ANNOUNCE;
 for(unsigned w=0;w<4;w++){s.tick=w*TAG_ANNOUNCE_WRESTLER_TICKS;assert(session_tag_announce_wrestler(&s)==w&&session_tag_announce_local_tick(&s)==0);}
 s.tick=4*TAG_ANNOUNCE_WRESTLER_TICKS;assert(session_tag_announce_wrestler(&s)==4&&session_tag_presenter_y(&s)==168);s.tick=TAG_ANNOUNCE_TICKS-1;assert(session_tag_presenter_y(&s)<120);
 s.tick=0;for(unsigned i=0;i<TAG_ANNOUNCE_TICKS-1;i++){assert(!session_tick(&s,0));}assert(session_tick(&s,0)&&s.phase==SESSION_PLAY);
 puts("PASS Test107: TAG announce has four 180-tick wrestler windows plus 180-tick presenter exit (900 ticks total) for future audio sync");}
