#include "../game.h"
#include <assert.h>
#include <stdio.h>
int main(void){unsigned r[6]={0,2,7,1,4,5};game_t g;game_match_start(&g,GAME_TAG,r);g.finished=true;g.winner=0;game_tick(&g,0,0);assert(game_postmatch_role(&g,0)==1&&game_postmatch_role(&g,2)==1);assert(game_postmatch_role(&g,1)==-1&&game_postmatch_role(&g,3)==-1);g.winner=1;assert(game_postmatch_role(&g,1)==1&&game_postmatch_role(&g,3)==1&&game_postmatch_role(&g,0)==-1);puts("PASS Test220: post-match winner/defeated roles follow the resolved TAG side without inferred pose semantics");}
