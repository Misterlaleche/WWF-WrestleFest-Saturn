#include "arcade_behind_pair.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
static uint32_t be32(const uint8_t *p){return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3];}
static void seq(const uint8_t *rom,unsigned at,const uint8_t *s,unsigned n){for(unsigned i=0;i<n;++i)assert(rom[at+i]==s[i]);}
int main(void){
 FILE *f=fopen("program.bin","rb");assert(f);uint8_t *rom=malloc(0x80000);assert(rom);assert(fread(rom,1,0x80000,f)==0x80000);fclose(f);
 const arcade_behind_pair_profile_t *s=arcade_behind_pair_profile(0x1c),*r=arcade_behind_pair_profile(0x1d);assert(s&&r&&!arcade_behind_pair_profile(0x1e));
 assert(be32(rom+s->descriptor_address)==s->callback_address);assert(be32(rom+r->descriptor_address)==r->callback_address);
 const uint8_t s_link[]={0x15,0x7c,0x00,0xc0,0x00,0x60}; seq(rom,0x156a0,s_link,sizeof s_link);
 const uint8_t s_state[]={0x35,0x7c,0x00,0x05,0x00,0x20,0x15,0x7c,0x00,0x52,0x00,0x61,0x42,0x6a,0x00,0x44};seq(rom,0x15730,s_state,sizeof s_state);
 const uint8_t r_link[]={0x15,0x7c,0x00,0x80,0x00,0x60};seq(rom,0x1589e,r_link,sizeof r_link);
 const uint8_t r_state[]={0x35,0x7c,0x00,0x05,0x00,0x20,0x15,0x7c,0x00,0x53,0x00,0x61,0x42,0x6a,0x00,0x44};seq(rom,0x158ec,r_state,sizeof r_state);
 assert(s->target_link_byte==0xc0&&s->target_state20==5&&s->target_pose61==0x52&&s->clears_target44&&s->copies_attacker_facing&&!s->sets_pair_status33);
 assert(r->target_link_byte==0x80&&r->target_state20==5&&r->target_pose61==0x53&&r->clears_target44&&!r->copies_attacker_facing&&r->sets_pair_status33);
 free(rom);puts("PASS Test77: ROM action $1C/$1D descriptors and exact Sleeper/Restrain acquisition signatures recovered");
}
