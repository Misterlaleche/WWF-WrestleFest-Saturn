#include "game.h"
#include "arcade_moves.h"
#include <assert.h>
#include <stdio.h>
static const unsigned r[6]={0,2,7,1,4,5};
static void prep(game_t *g,unsigned ch){game_match_start(g,GAME_TAG,r);g->cpu=false;fighter_t *p=&g->fighters[0],*q=&g->fighters[1];p->character=ch;p->x=120*256;p->y=200*256;q->x=150*256;q->rise_y=200*256;q->y=217*256;q->state=ST_RECOVER;q->tick=30;}
int main(void){
 for(unsigned ch=0;ch<10;ch++){game_t g;prep(&g,ch);game_tick(&g,0,INPUT_GRAB);assert(g.pair==PAIR_SUBMISSION&&g.pair_attacker==0);assert(g.pair_move==(unsigned)arcade_move_set(ch)->ground_submission);assert(arcade_move_submission((arcade_move_id_t)g.pair_move));unsigned hp=g.fighters[1].health;for(unsigned i=0;i<18;i++)game_tick(&g,0,0);assert(g.fighters[1].health==hp-1&&g.submission_pulses==1);}
 game_t g;prep(&g,7);g.fighters[1].health=2;g.fighters[1].stamina_tier=2;game_tick(&g,0,INPUT_GRAB);for(unsigned i=0;i<40&&!g.finished;i++)game_tick(&g,0,0);assert(g.finished&&g.finish_reason==FINISH_SUBMISSION&&g.winner==0);
 puts("PASS: all ten ground submissions enter live drain state and can finish at zero stamina");
}