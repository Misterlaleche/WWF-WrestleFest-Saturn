#include "hud.h"
#include <assert.h>
#include <stdio.h>
int main(int argc,char **argv){
 for(unsigned hp=0;hp<256;hp++)for(unsigned slot=0;slot<4;slot++)for(unsigned col=0;col<6;col++){
  unsigned top=hud_bar_tile(hp,col,slot,false),bottom=hud_bar_tile(hp,col,slot,true);
  unsigned remaining=hp>col*16?hp-col*16:0,fill=remaining>=16?8:remaining/2;
  assert(top==(fill?(slot<2?0xad9:0xaf2)+fill:0xb33));
  assert(bottom==top+(fill?(slot<2?11:14):7));
 }
 assert(hud_health_step(100,50,1)==98&&hud_health_step(50,100,1)==52);
 assert(hud_health_step(100,0,500)==0&&hud_health_step(0,100,500)==100);
 assert(hud_health_step(50,100,0)==50);
 hud_slot_t slots[4]={{.character=0,.health=108,.player=0,.status=HUD_ACTIVE,.message=HUD_BUTTON},
 {.player=1,.status=HUD_JOIN},{.player=2,.status=HUD_JOIN},{.player=3,.status=HUD_JOIN}};
 if(argc==3){
  unsigned ch[4]={0,7,2,1},hp[4]={100,72,50,34};
  for(unsigned i=0;i<4;i++)slots[i]=(hud_slot_t){.character=ch[i],.health=hp[i],.status=(i&1)?HUD_WAITING:HUD_ACTIVE,.message=HUD_NEUTRAL,.grayscale=(i&1)!=0,.cpu=i>=2};
 }
 hud_cell_t cells[160];uint8_t pixels[HUD_BYTES];uint16_t colors[256];
 hud_map(slots,cells);hud_pixels(cells,pixels);hud_palettes(colors);
 if(argc!=3){
  /* P1 portrait/stamina plus three original cabinet BUY-IN panels. */
  assert(cells[1].tile==0xb0f&&cells[4].tile==0xaed);
  assert(cells[41].tile==0x1d0);
  assert(cells[10].tile==0xca3&&cells[21].tile==0xca3&&cells[30].tile==0xca3);
 }
 if(argc>=2){FILE *f=fopen(argv[1],"wb");assert(f);assert(fwrite(pixels,1,sizeof(pixels),f)==sizeof(pixels));assert(fwrite(colors,1,sizeof(colors),f)==sizeof(colors));fclose(f);}
 puts("PASS: arcade P1 HUD, P2-P4 BUY-IN, 256 stamina values, segmented bars and gradual display update");
}
