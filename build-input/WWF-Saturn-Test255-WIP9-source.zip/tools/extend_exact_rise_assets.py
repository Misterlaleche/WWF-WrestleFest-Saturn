#!/usr/bin/env python3
"""Extend current WFC2 roster packs with ROM-exact RISE compositions recoverable
from already-captured legacy frames. No sprite ROM is needed because these exact
tiles are already resident in the packs.
"""
from pathlib import Path
import struct,re,json,hashlib,itertools,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import lz4_codec

ROOT=Path(__file__).resolve().parents[1]
POSES=[104,110,111,112,113]
# pose -> (legacy frame, transform, delta-x)
# transform 0: x'=x+dx, flip unchanged; 1: x'=-x-16+dx, flip xor 1
ALIASES={
 0:{104:(14,0,-15),112:(16,0,-46),113:(17,0,-40)},
 2:{104:(39,1,-10),110:(40,1,-62),111:(41,1,-46)},
}

def be16(b,o): return int.from_bytes(b[o:o+2],'big')
def be32(b,o): return int.from_bytes(b[o:o+4],'big')
def fnv(data):
 h=2166136261
 for x in data:h=((h^x)*16777619)&0xffffffff
 return h

def unpack(path):
 b=path.read_bytes(); assert be32(b,0)==0x57464332
 frames,records,tiles,off,block_tiles,blocks=[be32(b,o) for o in (4,8,12,16,24,28)]
 idx=[(be16(b,32+i*4),be16(b,34+i*4)) for i in range(frames)]
 ro=32+frames*4
 rec=[list(struct.unpack_from('>HhhH',b,ro+i*8)) for i in range(records)]
 tex=[]
 for bi in range(blocks):
  eo=off+bi*12; pos,stored,raw=be32(b,eo),be32(b,eo+4),be32(b,eo+8)
  chunk=lz4_codec.decompress(b[pos:pos+stored],raw)
  tex.extend(chunk[i:i+128] for i in range(0,len(chunk),128))
 assert len(tex)==tiles
 out=[]
 for first,count in idx: out.append([r[:] for r in rec[first:first+count]])
 return out,tex,block_tiles

def pack(frames,textures,block_tiles):
 indexes=[];records=[]
 for f in frames:indexes.append((len(records),len(f)));records.extend(f)
 body=b''.join(struct.pack('>HH',*x) for x in indexes)+b''.join(struct.pack('>HhhH',*r) for r in records)
 off=(32+len(body)+31)&~31
 raw=b''.join(textures); entries=[]; payload=[]; chunks=[]
 for first in range(0,len(textures),block_tiles):
  chunk=b''.join(textures[first:first+block_tiles]); comp=lz4_codec.compress(chunk); assert lz4_codec.decompress(comp,len(chunk))==chunk; chunks.append((chunk,comp))
 pos=off+len(chunks)*12
 for chunk,comp in chunks:
  entries.append(struct.pack('>III',pos,len(comp),len(chunk)));payload.append(comp);pos+=len(comp)
 hdr=struct.pack('>8I',0x57464332,len(frames),len(records),len(textures),off,fnv(raw),block_tiles,len(chunks))
 return hdr+body+bytes(off-32-len(body))+b''.join(entries)+b''.join(payload)

def main():
 sizes=[]; hashes=[]; report=[]
 for ch in range(10):
  path=ROOT/'cd'/f'C{ch:02}.PAK'; frames,tex,bt=unpack(path); assert len(frames)==207
  added=[]
  amap=ALIASES.get(ch,{})
  for pose in POSES:
   if pose not in amap: frames.append([]); continue
   src,mode,dx=amap[pose]; nr=[]
   for tile,x,y,flip in frames[src]:
    nx=x+dx if mode==0 else -x-16+dx
    nf=flip if mode==0 else flip^1
    nr.append([tile,nx,y,nf])
   frames.append(nr); added.append(dict(pose=pose,frame=207+POSES.index(pose),source_frame=src,records=len(nr),mirror_transform=bool(mode),x_adjust=dx))
  data=pack(frames,tex,bt);path.write_bytes(data);sizes.append(len(data));hashes.append(fnv(data));report.append(dict(character=ch,added=added,bytes=len(data)))
 h=(ROOT/'roster_data.h').read_text();h=h.replace('#define ROSTER_FRAMES 207','#define ROSTER_FRAMES 212')
 h=re.sub(r'static const unsigned roster_bytes\[10\]=\{.*?\};','static const unsigned roster_bytes[10]={'+','.join(map(str,sizes))+'};',h)
 h=re.sub(r'static const unsigned roster_hash\[10\]=\{.*?\};','static const unsigned roster_hash[10]={'+','.join(str(x)+'U' for x in hashes)+'};',h)
 # Generic legacy map stays unchanged; exact RISE aliases are character-specific.
 insert='''\nstatic inline unsigned roster_arcade_frame_character(unsigned character,unsigned pose){\n switch(character){\n case 0: switch(pose){case 104:return 207;case 112:return 210;case 113:return 211;default:break;} break;\n case 2: switch(pose){case 104:return 207;case 110:return 208;case 111:return 209;default:break;} break;\n default:break;\n }\n return roster_arcade_frame(pose);\n}\n'''
 h=h.rstrip()+insert
 (ROOT/'roster_data.h').write_text(h)
 aligned=[(x+2047)&~2047 for x in sizes]; worst=max(sum(aligned[i] for i in c) for c in itertools.combinations(range(10),6))
 assert worst<=1048576
 doc=dict(test=232,frames_per_pack=212,added_pose_slots=POSES,exact_aliases=report,worst_six_low_ram_bytes=worst,low_ram_capacity=1048576,
  evidence='ROM composition decoder + exact legacy captured frame tile-code identity; no fabricated sprite pixels',
  unresolved='Other characters and GROUND PICK UP / GROUND ATTACK / object poses still require sprite-region recovery or an already-captured identical composition.')
 (ROOT/'docs/test232-exact-rise-assets.json').write_text(json.dumps(doc,indent=2)+'\n')
 print(json.dumps(doc,indent=2))
if __name__=='__main__':main()
