#include "game.h"
#include "arcade_moves.h"
#include <assert.h>
#include <stdio.h>
static void prep(game_t*g){unsigned r[6]={0,2,1,3,4,5};game_match_start(g,GAME_TAG,r);g->cpu=false;fighter_t*p=&g->fighters[0],*q=&g->fighters[1];p->x=120*256;q->x=155*256;p->y=q->y=200*256;p->facing=q->facing=1;p->state=q->state=ST_IDLE;p->cooldown=q->cooldown=0;}
int main(void){game_t g;prep(&g);unsigned hp=g.fighters[1].health;game_tick(&g,0,INPUT_KICK);for(int i=0;i<170&&g.restrain_assists==0;i++)game_tick(&g,0,0);assert(g.restrain_assists==1);assert(g.fighters[1].health<hp);assert(g.pair==PAIR_HOLD&&g.pair_move==AMOVE_RESTRAIN);puts("PASS Test97: reserve lands one live assist strike on restrained victim without breaking the hold");}
