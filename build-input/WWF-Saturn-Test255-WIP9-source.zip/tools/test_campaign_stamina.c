#include "campaign.h"
#include "arcade_stamina.h"
#include "game.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 campaign_t c;campaign_reset(&c,CAMPAIGN_TAG,5,0,ARCADE_DIFFICULTY_NORMAL);
 campaign_set_players(&c,0,7); /* Hogan + Perfect */
 assert(campaign_player_stamina(&c,0)==110&&campaign_player_stamina(&c,7)==102);
 campaign_capture_player_stamina(&c,0,61);campaign_capture_player_stamina(&c,7,80);
 campaign_clear_stage_power_up(&c);
 assert(campaign_player_stamina(&c,0)==85&&campaign_player_stamina(&c,7)==102);
 /* A captured value is keyed by character, not active/tag slot. */
 campaign_capture_player_stamina(&c,7,55);assert(campaign_player_stamina(&c,7)==55);
 campaign_capture_player_stamina(&c,99,1);assert(campaign_player_stamina(&c,0)==85);

 unsigned r[6]={0,1,7,3,4,5};game_t g;game_match_start(&g,GAME_TAG,r);g.cpu=false;
 g.fighters[0].health=60;g.fighters[1].health=60;g.fighters[2].health=60;g.fighters[3].health=60;
 game_clear_stage_restore(&g,0);
 assert(g.fighters[0].health==84&&g.fighters[2].health==84);
 assert(g.fighters[1].health==60&&g.fighters[3].health==60); /* ROM role-bit CPU skip */
 puts("PASS: TAG stamina persists by character, clear-stage restore caps humans only, CPU roles skipped like $90D6");
}
