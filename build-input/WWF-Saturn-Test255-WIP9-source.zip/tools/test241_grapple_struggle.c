#include "../game.h"
#include <assert.h>
#include <stdio.h>
static void close_pair(game_t *g){
 g->fighters[0].x=100*256;g->fighters[0].y=200*256;g->fighters[0].facing=1;g->fighters[0].state=ST_IDLE;g->fighters[0].cooldown=0;
 g->fighters[1].x=130*256;g->fighters[1].y=200*256;g->fighters[1].facing=-1;g->fighters[1].state=ST_IDLE;g->fighters[1].cooldown=0;
}
static void finish_cycle(game_t *g){unsigned guard=0;while(g->pair==PAIR_STRUGGLE&&g->grapple_action_tick&&guard++<70)game_tick(g,0,0);assert(guard<70);}
int main(void){
 unsigned r[6]={0,2,7,1,4,5}; game_t g;
 game_match_start(&g,GAME_TAG,r);g.cpu=false;close_pair(&g);
 game_tick(&g,0,INPUT_GRAB);assert(g.pair==PAIR_STRUGGLE);assert(game_pair_pose(&g)==0&&game_pair_clip(&g)==2);
 /* Category $08 maps P, K and P+K to one action $29: simultaneous P+K is one
    accepted struggle action, not two synthetic score points. */
 game_tick(&g,0,INPUT_PUNCH|INPUT_KICK);assert(g.grapple_action_tick==1&&g.grapple_score[0]==0);assert(game_pair_struggle_raw_pose(&g)==245);
 finish_cycle(&g);assert(g.pair==PAIR_STRUGGLE&&g.grapple_score[0]==1);
 game_tick(&g,0,INPUT_PUNCH);assert(g.grapple_action_tick==1);finish_cycle(&g);
 assert(g.pair==PAIR_HOLD&&g.pair_attacker==0);
 game_match_start(&g,GAME_TAG,r);g.cpu=true;close_pair(&g);game_tick(&g,0,INPUT_GRAB);assert(g.pair==PAIR_STRUGGLE);
 for(int i=0;i<180&&g.pair==PAIR_STRUGGLE;i++)game_tick(&g,0,0);
 assert(g.pair==PAIR_HOLD&&g.pair_attacker==1);
 puts("PASS Test241/253: neutral grapple uses exact category-$08 action-$29 cycles; two completed cycles decide ownership, while CPU edge timing remains provisional");
}
