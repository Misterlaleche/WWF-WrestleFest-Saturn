#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include "../wf_oki_decode.h"
int main(int argc,char **argv){
 if(argc!=4)return 2;
 FILE *f=fopen(argv[1],"rb");assert(f);fseek(f,0,SEEK_END);long n=ftell(f);rewind(f);
 uint8_t *src=malloc((size_t)n);assert(src);assert(fread(src,1,(size_t)n,f)==(size_t)n);fclose(f);
 f=fopen(argv[2],"rb");assert(f);fseek(f,0,SEEK_END);long m=ftell(f);rewind(f);
 int8_t *want=malloc((size_t)m),*got=malloc((size_t)m);assert(want&&got);
 assert(fread(want,1,(size_t)m,f)==(size_t)m);fclose(f);
 assert(wf_oki_decode_pcm8(src,(size_t)n,got,(size_t)m)==(size_t)m);
 assert(memcmp(got,want,(size_t)m)==0);
 free(src);free(want);free(got);return 0;
}
