#include "game.h"
#include "arcade_animation.h"
#include "arcade_stamina.h"
#include <assert.h>
#include <stdio.h>

static const unsigned cast[6]={0,2,7,1,4,5};
static void ticks(game_t *g,unsigned n){while(n--)game_tick(g,0,0);}
static void outside_pair(game_t *g){
 game_match_start(g,GAME_TAG,cast);g->cpu=false;
 g->fighters[0].outside=g->fighters[1].outside=true;
 g->fighters[0].x=100*256;g->fighters[1].x=150*256;
 g->fighters[0].y=g->fighters[1].y=320*256;
 g->fighters[0].rise_y=g->fighters[0].y;g->fighters[1].rise_y=g->fighters[1].y;
 g->fighters[0].facing=1;g->fighters[1].facing=-1;
}
static void basic_hits(void){
 game_t g;outside_pair(&g);
 game_tick(&g,0,INPUT_PUNCH);ticks(&g,40);
 assert(g.hits[0]==1&&g.fighters[1].health==g.fighters[1].max_health-ARCADE_STATIONARY_PUNCH_DAMAGE&&g.fighters[1].outside);
 assert(game_ringside_valid(g.fighters[1].x/256,g.fighters[1].y/256));
 ticks(&g,40);g.fighters[0].x=90*256;g.fighters[1].x=150*256;
 game_tick(&g,0,INPUT_KICK);ticks(&g,45);
 assert(g.hits[0]==2&&g.fighters[1].health==g.fighters[1].max_health-(ARCADE_STATIONARY_PUNCH_DAMAGE+25));
}
static void simultaneous(void){
 game_t g;outside_pair(&g);
 /* Arcade punch becomes active as the update advances 22 -> 23. */
 g.fighters[0].state=g.fighters[1].state=ST_PUNCH;
 g.fighters[0].tick=g.fighters[1].tick=22;
 game_tick(&g,0,0);
 assert(g.hits[0]==1&&g.hits[1]==1);
 assert(g.fighters[0].health==g.fighters[0].max_health-ARCADE_STATIONARY_PUNCH_DAMAGE&&g.fighters[1].health==g.fighters[1].max_health-ARCADE_STATIONARY_PUNCH_DAMAGE&&g.freeze==3);
}
static void boundary_and_recovery(void){
 game_t g;outside_pair(&g);
 g.fighters[0].x=310*256;g.fighters[1].x=355*256;
 g.fighters[0].health=100;g.fighters[1].health=ARCADE_STATIONARY_PUNCH_DAMAGE;
 game_tick(&g,0,INPUT_PUNCH);ticks(&g,35);
 assert(g.fighters[1].health==0&&g.fighters[1].outside);
 assert(g.fighters[1].state==ST_RECOVER||g.fighters[1].state==ST_RISE);
 assert(game_ringside_valid(g.fighters[1].x/256,g.fighters[1].rise_y/256));
 assert(g.fighters[1].x/256<=364);
 ticks(&g,220);
 assert(g.fighters[1].state==ST_IDLE&&g.fighters[1].outside);
 assert(game_ringside_valid(g.fighters[1].x/256,g.fighters[1].y/256));
}
static void cpu_chase(void){
 game_t g;outside_pair(&g);g.cpu=true;
 g.fighters[0].x=40*256;g.fighters[1].x=250*256;
 /* Isolate ordinary pursuit: the arcade legitimately diverts to a closer
    available object, which is covered by test_cpu_weapon_ai. */
 g.ringside_objects[0].state=g.ringside_objects[1].state=2;
 int before=g.fighters[1].x-g.fighters[0].x;
 ticks(&g,120);
 int after=g.fighters[1].x-g.fighters[0].x;
 assert(after<before);
 assert(g.hits[1]>0||after<80*256);
 assert(game_ringside_valid(g.fighters[1].x/256,g.fighters[1].y/256));
}
static void rope_boundary(void){
 game_t g;game_match_start(&g,GAME_TAG,cast);g.cpu=false;
 g.fighters[0].outside=true;g.fighters[0].x=100*256;g.fighters[0].y=320*256;g.fighters[0].rise_y=g.fighters[0].y;
 g.fighters[1].outside=false;g.fighters[1].x=145*256;g.fighters[1].y=273*256;g.fighters[1].rise_y=g.fighters[1].y;
 g.fighters[0].facing=1;game_tick(&g,0,INPUT_PUNCH);ticks(&g,50);
 assert(g.hits[0]==0&&g.fighters[1].health==g.fighters[1].max_health);
}
static void stress(void){
 unsigned total=0;
 for(unsigned ch=0;ch<10;ch++){
  game_t g;outside_pair(&g);g.cpu=true;
  /* Long deterministic movement/combat stress is deliberately isolated from
     the TAG referee count-out clock now tested separately. */
  g.mode=GAME_TRAINING;
  g.fighters[0].character=ch;g.fighters[1].character=(ch+3)%10;
  for(unsigned t=0;t<2000;t++,total++){
   unsigned held=0,pressed=0;
   switch((t/90)%4){case 0:held=INPUT_LEFT;break;case 1:held=INPUT_RIGHT;break;case 2:held=INPUT_UP;break;default:held=INPUT_DOWN;break;}
   if(t%71==0)pressed=INPUT_PUNCH;else if(t%113==0)pressed=INPUT_KICK;
   game_tick(&g,held,pressed);
   for(unsigned i=0;i<2;i++){
    fighter_t *f=&g.fighters[i];
    assert(f->outside);
    assert(game_ringside_valid(f->x/256,(f->state==ST_RECOVER||f->state==ST_DOWN?f->rise_y:f->y)/256));
    if(f->health<30&&f->state==ST_IDLE)f->health=f->max_health;
   }
   assert(!g.finished);
  }
 }
 assert(total==20000);
}
int main(void){basic_hits();simultaneous();boundary_and_recovery();cpu_chase();rope_boundary();stress();puts("PASS: ringside strikes, simultaneous hits, bounds, zero-stamina recovery, CPU pursuit, rope boundary and 20000 deterministic ticks");}
