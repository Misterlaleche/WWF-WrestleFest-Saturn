/* Packed-asset command trace, not a Saturn emulator. The prior path below
   reproduces V0.024 main.c:ring_scene solely for the before/after audit. */
#include "game.h"
#include "model_data.h"
#include "render_pose.h"
#include "pair_order.h"
#include "roster_pack.h"
#include "layer_view.h"
#include "pair_rules.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

static uint8_t *data[10];static roster_pack_t packs[10];
static unsigned r16(const uint8_t *p){return (unsigned)p[0]*256+p[1];}
static void tile(unsigned source,unsigned id,int x,int y,unsigned palette,unsigned flip,bool eight,bool opaque){
    if(x>=320||x+16<=0||y>=240||y+16<=0)return;
    printf("T %u %u %d %d %u %u %u %u\n",source,id,x,y,palette,flip,eight,opaque);
}
static void piece(const piece_t *p,int x,int y,bool mirror){
    tile(0,p->tile,x+(mirror?-p->x-16:p->x),y+p->y,512+p->pal*16,p->flip^(mirror?1:0),false,false);
}
static unsigned actor_count(unsigned ch,unsigned frame){assert(ch<10&&frame<ROSTER_FRAMES);return r16(data[ch]+32+frame*4+2);}
static void actor_part(unsigned ch,unsigned frame,int x,int y,bool mirror,unsigned first,unsigned end){
    unsigned offset=r16(data[ch]+32+frame*4),count=actor_count(ch,frame);if(end>count)end=count;
    for(unsigned i=first;i<end;i++){
        const uint8_t *r=data[ch]+32+ROSTER_FRAMES*4+(offset+i)*8;
        int px=(int16_t)r16(r+2),py=(int16_t)r16(r+4);
        tile(ch+1,r16(r),x+(mirror?-px-16:px),y+py,256+ch*16,r16(r+6)^(mirror?1:0),false,false);
    }
}
static void draw_object(const game_t *g,unsigned object){
    printf("L %u\n",object);int who=game_draw_fighter(object);
    if(who>=0){const fighter_t *f=&g->fighters[who];render_pose_t p=render_fighter_pose(f);
        actor_part(f->character,p.frame,f->x/256-g->camera_x,f->y/256-g->camera_y-p.lift,p.mirror,0,65535);return;}
    if(object==DRAW_SIDE_ROPES||object==DRAW_FRONT_ROPES){
        unsigned first=object==DRAW_SIDE_ROPES?0:SIDE_ROPE_COUNT,end=object==DRAW_SIDE_ROPES?SIDE_ROPE_COUNT:FRONT_COUNT;
        for(unsigned i=first;i<end;i++)piece(&foreground[i],-g->camera_x,-g->camera_y,false);
    }else if(object==DRAW_REFEREE||object==DRAW_PROMPT){
        unsigned clip=object==DRAW_REFEREE?5:6,pose=object==DRAW_REFEREE?game_referee_pose(g):game_escape_prompt_pose(g);
        const frame_t *f=&frames[clips[clip].first+pose];
        for(unsigned i=0;i<f->count;i++)piece(&pieces[f->first+i],object==DRAW_REFEREE?g->referee.x/256-g->camera_x:game_escape_prompt_x(g),object==DRAW_REFEREE?g->referee.y/256-g->camera_y:106,object==DRAW_REFEREE&&g->referee.facing<0);
    }else if(object==DRAW_PAIR){
        unsigned clip=game_pair_clip(g),pose=game_pair_pose(g),pos[2]={0},total[2]={0};
        const fighter_t *a=&g->fighters[game_pair_anchor(g)];const pair_run_t *runs=pair_runs[clip-2][pose];
        for(unsigned i=0;i<8&&runs[i].count;i++)total[runs[i].role]+=runs[i].count;
        for(unsigned i=0;i<8&&runs[i].count;i++){
            unsigned role=runs[i].role,ch=g->fighters[game_pair_fighter(g,role)].character,frame=roster_parts[clip][pose][role],count=actor_count(ch,frame);
            unsigned first=pos[role]*count/total[role];pos[role]+=runs[i].count;
            actor_part(ch,frame,a->x/256-g->camera_x,a->y/256-g->camera_y,game_pair_facing(g)<0,first,pos[role]*count/total[role]);
        }
    }
}
static unsigned old_plan(const game_t *g,unsigned *out){
    unsigned n=0,order[7],count=0;int depth[7];
    for(unsigned i=2;i<g->roster_count;i++)if(game_partner_waiting(g,i))out[n++]=DRAW_FIGHTER_2+i-2;
    out[n++]=DRAW_SIDE_ROPES;bool front=g->referee.state>=REF_KNEEL;
    for(unsigned i=0;i<g->roster_count;i++){
        if(!(g->active_mask&(1U<<i))&&g->mode!=GAME_TAG)continue;
        if(game_partner_waiting(g,i)||(g->pair!=PAIR_NONE&&i<2)||game_over_ropes(&g->fighters[i]))continue;
        depth[i]=g->fighters[i].y;order[count++]=i;
    }
    depth[6]=g->referee.y;if(!front)order[count++]=6;
    for(unsigned i=1;i<count;i++)for(unsigned j=i;j&&depth[order[j]]<depth[order[j-1]];j--){unsigned t=order[j];order[j]=order[j-1];order[j-1]=t;}
    for(unsigned i=0;i<count;i++)out[n++]=order[i]==6?DRAW_REFEREE:order[i]<2?DRAW_HULK+order[i]:DRAW_FIGHTER_2+order[i]-2;
    if(g->pair!=PAIR_NONE)out[n++]=DRAW_PAIR;if(front)out[n++]=DRAW_REFEREE;out[n++]=DRAW_FRONT_ROPES;
    for(unsigned i=0;i<g->roster_count;i++)if(!game_partner_waiting(g,i)&&((g->active_mask&(1U<<i))||g->mode==GAME_TAG)&&game_over_ropes(&g->fighters[i]))out[n++]=i<2?DRAW_HULK+i:DRAW_FIGHTER_2+i-2;
    if(game_escape_prompt_visible(g))out[n++]=DRAW_PROMPT;assert(n<=GAME_DRAW_CAPACITY);return n;
}
static void sample(const game_t *g,unsigned test,bool legacy,unsigned view){
    printf("S %u %u %u %d %d\n",test,legacy,view,g->camera_x,g->camera_y);
    if(layer_view_crowd(view))for(unsigned i=0;i<CROWD_COUNT;i++){
        const piece_t *p=&crowds[(g->ticks/8)%3][i];tile(0,p->tile,p->x-g->camera_x,p->y-g->camera_y,512+p->pal*16,p->flip,false,true);
    }
    unsigned order[GAME_DRAW_CAPACITY],count=legacy?old_plan(g,order):game_render_plan(g,order);
    for(unsigned i=0;i<count;i++)if(layer_view_object(view,order[i]))draw_object(g,order[i]);puts("E");
}
int main(void){
    for(unsigned ch=0;ch<10;ch++){
        char name[32];sprintf(name,"cd/C%02u.PAK",ch);FILE *f=fopen(name,"rb");assert(f);
        data[ch]=malloc(roster_bytes[ch]);assert(data[ch]);assert(fread(data[ch],1,roster_bytes[ch],f)==roster_bytes[ch]);fclose(f);
        assert(roster_pack_open(&packs[ch],data[ch],roster_bytes[ch],ROSTER_FRAMES));
    }
    const unsigned cast[6]={0,2,7,1,4,5};game_t g;
    for(unsigned test=0;test<4;test++){
        game_match_start(&g,GAME_TAG,cast);g.cpu=false;g.camera_x=-34;g.camera_y=30;
        g.fighters[0].x=120*256;g.fighters[0].y=205*256;g.fighters[0].rise_y=g.fighters[0].y;
        g.fighters[1].x=165*256;g.fighters[1].y=205*256;g.fighters[1].rise_y=g.fighters[1].y;
        if(test==0){
            g.pair=PAIR_PIN;g.pin_attacker=0;g.pair_tick=40;
            g.fighters[1].state=ST_RECOVER;g.fighters[1].y+=17*256;
            g.support_phase[0]=SUPPORT_RUN;g.fighters[2].x=150*256;g.fighters[2].y=220*256;
            g.referee.x=92*256;g.referee.y=195*256;g.referee.state=REF_COUNT;
        }else if(test==1){
            g.fighters[0].state=ST_RECOVER;g.fighters[0].y+=25*256;
            g.fighters[1].x=136*256;g.fighters[1].y=218*256;
        }else if(test==2){
            g.fighters[0].outside=true;g.fighters[0].x=126*256;g.fighters[0].y=128*256;g.camera_y=0;
            assert(game_ringside_valid(g.fighters[0].x/256,g.fighters[0].y/256));
            g.support_phase[0]=SUPPORT_RUN;g.fighters[2].x=130*256;g.fighters[2].y=220*256;
        }else {g.fighters[1].state=ST_CORNER;g.fighters[1].x=318*256;g.fighters[1].y=273*256;g.camera_x=62;g.camera_y=70;}
        sample(&g,test,true,VIEW_ALL);sample(&g,test,false,VIEW_ALL);
        if(test==3)sample(&g,4,false,VIEW_NO_ROPES);
    }
    /* All shipped paired pieces must be covered exactly once by run splitting. */
    for(unsigned ch=0;ch<10;ch++)for(unsigned clip=2;clip<5;clip++)for(unsigned pose=0;pose<clips[clip].count;pose++){
        const pair_run_t *runs=pair_runs[clip-2][pose];unsigned total[2]={0},used[2]={0},end[2]={0};
        for(unsigned i=0;i<8&&runs[i].count;i++)total[runs[i].role]+=runs[i].count;
        for(unsigned i=0;i<8&&runs[i].count;i++){
            unsigned r=runs[i].role,c=actor_count(ch,roster_parts[clip][pose][r]);
            assert(total[r]&&end[r]==used[r]*c/total[r]);used[r]+=runs[i].count;end[r]=used[r]*c/total[r];
        }
        for(unsigned r=0;r<2;r++)if(total[r])assert(end[r]==actor_count(ch,roster_parts[clip][pose][r]));
    }
    for(unsigned ch=0;ch<10;ch++)free(data[ch]);
    return 0;
}
