#include "../session.h"
#include <assert.h>
#include <stdio.h>
int main(void){session_t s;session_reset(&s,0);s.mode=1;s.phase=SESSION_ANNOUNCE;
 unsigned start=4U*TAG_ANNOUNCE_WRESTLER_TICKS;s.tick=start;assert(!session_tag_presenter_exiting(&s));assert(session_tag_presenter_y(&s)==168);
 s.tick=start+1;assert(session_tag_presenter_exiting(&s));assert(session_tag_presenter_pose(&s)==4);
 s.tick=start+30;unsigned p=session_tag_presenter_pose(&s);assert(p==5||p==6);assert(session_tag_presenter_y(&s)<168);
 s.tick=TAG_ANNOUNCE_TICKS-1;assert(session_tag_presenter_y(&s)<100);
 puts("PASS Test242: presenter stops front announce loop, enters a turn cue, then alternates exit walk frames while moving to the rear rope");}
