#include "arcade_ai.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 struct {unsigned lo,hi,b;} r[]={{128,255,0},{101,127,1},{80,100,2},{64,79,3},{37,63,4},{1,36,5},{0,0,8}};
 for(unsigned i=0;i<sizeof(r)/sizeof(r[0]);i++)for(unsigned v=r[i].lo;v<=r[i].hi;v++){
  assert(arcade_ai_stamina_bucket(v)==r[i].b);
  assert(arcade_ai_stamina_gate_match(v,r[i].b));
  assert(!arcade_ai_stamina_gate_match(v,(r[i].b+1)&255));
  if(v==r[i].hi)break;
 }
 puts("PASS Test138-139: ROM-exact stamina buckets and +$109 equality predicate");
}
