#include "model_data.h"
#include "roster_data.h"
#include "intro_data.h"
#include "ui_assets.h"
#include "presentation_assets.h"
#include "hud.h"
#include <assert.h>
#include <stdio.h>
static unsigned max(unsigned a,unsigned b){return a>b?a:b;}
int main(void){
    unsigned maxima[10]={0};
    for(unsigned ch=0;ch<10;ch++){
        char name[32];sprintf(name,"cd/C%02u.PAK",ch);FILE *f=fopen(name,"rb");assert(f);assert(!fseek(f,32,SEEK_SET));
        for(unsigned i=0;i<ROSTER_FRAMES;i++){unsigned char r[4];assert(fread(r,1,4,f)==4);maxima[ch]=max(maxima[ch],(unsigned)r[2]*256+r[3]);}
        fclose(f);
    }
    for(unsigned i=1;i<10;i++)for(unsigned j=i;j&&maxima[j]>maxima[j-1];j--){unsigned t=maxima[j];maxima[j]=maxima[j-1];maxima[j-1]=t;}
    unsigned actors=0;for(unsigned i=0;i<6;i++)actors+=maxima[i];
    unsigned referee=0,prompt=0;
    for(unsigned i=0;i<clips[5].count;i++)referee=max(referee,frames[clips[5].first+i].count);
    for(unsigned i=0;i<clips[6].count;i++)prompt=max(prompt,frames[clips[6].first+i].count);
    /* No clipping/dedup assumed: six largest whole frames, all crowd/ropes,
       referee and prompt, 12 HUD/timer cmds, 120 for result text/panel, plus
       three setup commands and END. Overestimates valid simultaneous poses. */
    unsigned bound=actors+CROWD_COUNT+FRONT_COUNT+referee+prompt+12+120+4;
    assert(bound<CMD_CAPACITY);
    assert(actors<512); /* Each piece a different dynamic tile, pessimistically. */
    /* Earlier actor_part soft guard must not reject the last foreground body. */
    assert(3+CROWD_COUNT+FRONT_COUNT+referee+actors<CMD_CAPACITY-160);
    unsigned textures=TEXTURE_BYTES+PROMPT_BYTES+UI_TEXTURE_BYTES+HUD_BYTES+ENTRY_OVERLAY_BYTES+DYNAMIC_TEXTURE_BYTES;
    assert(textures%32==0&&textures+CMD_CAPACITY*32+32<=524288);
    assert(DYNAMIC_TEXTURE_BYTES>=512*128);
    printf("PASS: conservative combat bound %u/%u commands; %u/512 dynamic tiles; %u texture bytes plus command table fit VDP1\n",bound,CMD_CAPACITY,actors,textures);
    puts("Scope: shipped combat assets; not a framerate, bus throughput or future-asset guarantee");
}
