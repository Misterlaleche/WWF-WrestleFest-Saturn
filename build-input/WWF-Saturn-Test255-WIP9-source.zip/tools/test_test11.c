#include "game.h"
#include "session.h"
#include "presentation.h"
#include "timing.h"
#include <assert.h>
#include <stdio.h>

static const unsigned roster[6]={0,2,7,1,4,5};
static void ticks(game_t *g,unsigned count){while(count--)game_tick(g,0,0);}
static void cover(game_t *g,unsigned attacker){
 game_match_start(g,GAME_TAG,roster);g->cpu=false;
 for(unsigned i=0;i<2;i++){g->fighters[i].x=(130+(int)i*40)*256;g->fighters[i].y=180*256;g->fighters[i].rise_y=180*256;g->fighters[i].health=10;}
 g->pair=PAIR_PIN;g->pin_attacker=attacker;g->pair_tick=0;
}
int main(void){
 for(unsigned c=0;c<10;c++){ui_rect_t r=roster_cursor_rect(c);unsigned v=c==9?8:c;assert(r.x>=0&&r.x+r.w<=320&&r.y+r.h<=240);assert(r.x==27-(v%5>=3?16:0)+96*(int)(v%5-(v%5>=3?2:0)));assert(r.y==35+96*(int)(c/5));}
 assert(cursor_luminance(0)==12&&cursor_luminance(29)==31&&cursor_luminance(59)==12);
 assert(hud_fighter(0)==0&&hud_fighter(1)==2&&hud_fighter(2)==1&&hud_fighter(3)==3);
 unsigned a=0,b=0,fast=0,slow=0;
 for(unsigned i=0;i<600;i++)fast+=timing_steps(&a,1);
 for(unsigned i=0;i<300;i++)slow+=timing_steps(&b,2);
 assert(fast==574&&slow==fast&&a==b);
 assert(timing_steps(&a,1000)<=8);
 game_t g;game_match_start(&g,GAME_TAG,roster);g.cpu=false;
 assert(g.fighters[2].facing==1&&g.fighters[3].facing==-1);
 assert(game_partner_waiting(&g,2)&&game_partner_waiting(&g,3));
 assert(g.time_left==300);g.clock_phase=56445;game_tick(&g,0,0);assert(g.time_left==299&&g.clock_phase==0);
 g.paused=true;ticks(&g,100);assert(g.time_left==299&&g.clock_phase==0);g.paused=false;
 g.time_left=1;g.clock_phase=56445;game_tick(&g,0,0);assert(g.timed_out&&g.finished&&g.time_left==0&&g.winner==-1);
 for(unsigned attacker=0;attacker<2;attacker++){
  cover(&g,attacker);g.fighters[attacker+2].health=0;
  for(unsigned i=0;i<210&&!g.rescues&&!g.finished;i++)game_tick(&g,0,0);
  assert(g.rescues==1&&!g.finished&&g.pair==PAIR_NONE);
  ticks(&g,400);assert(game_partner_waiting(&g,2)&&game_partner_waiting(&g,3));
  assert(g.fighters[2].facing==1&&g.fighters[3].facing==-1);
 }
 cover(&g,0);g.support_phase[0]=g.support_phase[1]=SUPPORT_RUN;
 g.fighters[2].x=100*256;g.fighters[3].x=120*256;
 g.fighters[2].y=g.fighters[3].y=180*256;
 game_tick(&g,0,0);assert(g.blocks==0&&g.rescues==0&&(g.fighters[2].state==ST_PUNCH||g.fighters[2].state==ST_KICK));
 for(unsigned t=0;t<40&&!g.blocks;t++)game_tick(&g,0,0);
 assert(g.blocks==1&&g.rescues==0&&g.fighters[3].state==ST_HIT);
 g.pair=PAIR_NONE;ticks(&g,400);assert(game_partner_waiting(&g,2)&&game_partner_waiting(&g,3));
 cover(&g,0);g.fighters[2].health=g.fighters[3].health=0;ticks(&g,210);assert(g.finished&&g.winner==0&&g.pin_count==3&&g.rescues==0);
 for(unsigned d=0;d<4;d++){
  game_match_start(&g,GAME_TAG,roster);g.cpu=false;
  g.fighters[0].x=100*256;g.fighters[1].x=150*256;g.fighters[0].y=g.fighters[1].y=215*256;g.pair=PAIR_HOLD;
  unsigned direction=d==0?INPUT_LEFT:d==1?INPUT_RIGHT:d==2?INPUT_UP:INPUT_DOWN;
  game_tick(&g,direction,INPUT_RING);assert(g.throws==1&&g.pair==PAIR_NONE&&g.fighters[1].state==ST_TOSSED);
  unsigned tick=g.fighters[1].tick,sec=g.time_left;g.paused=true;ticks(&g,100);assert(g.fighters[1].tick==tick&&g.time_left==sec);g.paused=false;
  int oldx=g.fighters[0].x;game_tick(&g,INPUT_RIGHT,0);assert(g.fighters[0].x>oldx);
  ticks(&g,47);assert(g.fighters[1].outside&&g.fighters[1].health==g.fighters[1].max_health-15&&game_ringside_valid(g.fighters[1].x/256,g.fighters[1].y/256));
  ticks(&g,200);assert(!g.fighters[1].outside&&game_on_floor(g.fighters[1].x/256,g.fighters[1].y/256));
 }
 game_match_start(&g,GAME_RUMBLE,roster);g.cpu=false;g.pair=PAIR_HOLD;
 game_tick(&g,INPUT_RIGHT,INPUT_RING);ticks(&g,48);assert(g.eliminated==1&&!g.finished);
 puts("PASS Test13: cursor geometry/pulse, four HUD slots, frame-independent logic, timer/pause/time-up, partner rescues and protection, return behind ropes, four throw directions, recovery/reentry and Rumble elimination");
}
