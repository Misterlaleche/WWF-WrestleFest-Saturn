#include <assert.h>
#include <stdio.h>
#include "arcade_earthquake_raw.h"
int main(void){
 arcade_quake47_prelude_t r=arcade_quake47_prelude(0,0,0x7f,5,0x61);
 assert(!r.early_out&&r.actor_byte1==0&&r.actor_5c==0x0600&&r.actor_5e==0x0048&&r.effect_selector==5);
 r=arcade_quake47_prelude(0,0,0x55,5,0x60); assert(!r.early_out&&r.effect_selector==2);
 r=arcade_quake47_prelude(0x80,0,0x33,5,0x61); assert(r.early_out&&r.actor_byte1==0x33&&r.actor_5c==0);
 r=arcade_quake47_prelude(0,0x80,0x44,5,0x61); assert(r.early_out&&r.actor_byte1==0x44&&r.actor_5e==0);
 puts("PASS Test148: action $47 callback $14458 exact raw prelude/branches and target-dependent D0 selector recovered");
 return 0;
}
