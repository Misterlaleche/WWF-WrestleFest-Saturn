#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void read_at(long off,void *dst,size_t n){FILE*f=fopen("program.bin","rb");assert(f);assert(fseek(f,off,SEEK_SET)==0);assert(fread(dst,1,n,f)==n);fclose(f);}
static uint32_t be32(const uint8_t*p){return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3];}
int main(void){
 /* Dispatcher: D0=actor +$1D, *4, table at $1FB1A, then JSR through pointer. */
 const uint8_t dispatch[]={0x70,0x00,0x10,0x28,0x00,0x1d,0xe5,0x40,0x43,0xf9,0x00,0x01,0xfb,0x1a,0x24,0x71,0x00,0x00,0x4e,0x92,0x4e,0x75};
 uint8_t got[sizeof dispatch];read_at(0x1fb04,got,sizeof got);assert(!memcmp(got,dispatch,sizeof got));
 uint8_t tab[44];read_at(0x1fb1a,tab,sizeof tab);
 const uint32_t expect[11]={0x1fb46,0x1fc22,0x1fc22,0x1fd5e,0x1fc22,0x1ff52,0x20022,0x202ba,0x20354,0x203ee,0x1ff52};
 for(unsigned i=0;i<11;i++)assert(be32(tab+i*4)==expect[i]);
 assert(expect[6]==0x20022);
 puts("PASS Test161: ROM dispatcher indexes actor +$1D through 11-entry table $1FB1A; raw +$109 producer $20022 is exact state-entry 6");
 return 0;
}
