#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void seq(long o,const uint8_t*p,size_t n){FILE*f=fopen("program.bin","rb");assert(f);uint8_t*b=malloc(n);assert(b);assert(fseek(f,o,SEEK_SET)==0&&fread(b,1,n,f)==n);fclose(f);assert(!memcmp(b,p,n));free(b);}
int main(void){
 const uint8_t p[]={0x4a,0x28,0x00,0x25,0x66,0x10,0x4a,0x68,0x00,0x22,0x66,0x0a,0x11,0x7c,0x00,0x02,0x00,0x01};seq(0x144ac,p,sizeof p);
 puts("PASS Test181: action-$47 callback phase 0 with zero +$22 writes actor +$01=2");return 0;}
