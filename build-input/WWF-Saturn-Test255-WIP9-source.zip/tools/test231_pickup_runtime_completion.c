#include <assert.h>
#include <stdio.h>
#include "game.h"
static void prep(game_t*g){unsigned r[6]={0,1,2,3,4,5};game_match_start(g,GAME_TAG,r);g->cpu=false;fighter_t*p=&g->fighters[0],*q=&g->fighters[1];p->x=120*256;p->y=200*256;p->state=ST_IDLE;q->x=150*256;q->y=200*256;q->rise_y=q->y;q->state=ST_RECOVER;q->tick=24;}
int main(void){game_t g;prep(&g);game_tick(&g,0,INPUT_PUNCH|INPUT_KICK);assert(g.fighters[0].state==ST_GROUND_PICKUP);for(unsigned i=0;i<97;i++)game_tick(&g,0,0);assert(g.fighters[0].state==ST_GROUND_PICKUP);game_tick(&g,0,0);assert(g.fighters[0].state==ST_IDLE);puts("PASS Test231: live PICK UP no longer snaps back to idle at 36 ticks; it completes the full ROM visual clock");}
