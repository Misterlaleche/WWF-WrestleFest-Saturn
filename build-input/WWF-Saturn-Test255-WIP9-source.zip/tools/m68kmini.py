#!/usr/bin/env python3
from pathlib import Path
import sys
B=Path(sys.argv[1]).read_bytes(); pc=int(sys.argv[2],0); end=pc+int(sys.argv[3],0) if len(sys.argv)>3 else pc+0x200

def w(a): return int.from_bytes(B[a:a+2],'big')
def l(a): return int.from_bytes(B[a:a+4],'big')
def sw(x): return x-0x10000 if x&0x8000 else x
def sb(x): return x-0x100 if x&0x80 else x

def ea(mode,reg,size,p):
    # returns text,newp
    if mode==0:return f'D{reg}',p
    if mode==1:return f'A{reg}',p
    if mode==2:return f'(A{reg})',p
    if mode==3:return f'(A{reg})+',p
    if mode==4:return f'-(A{reg})',p
    if mode==5:
        d=sw(w(p));return f'{d:+#x}(A{reg})',p+2
    if mode==6:
        ext=w(p); d=sb(ext&0xff); ix='A' if ext&0x8000 else 'D'; ir=(ext>>12)&7; il='.L' if ext&0x800 else '.W';sc=1<<((ext>>9)&3)
        return f'{d:+#x}(A{reg},{ix}{ir}{il}*{sc})',p+2
    if mode==7:
        if reg==0:
            a=sw(w(p));return f'${a&0xffff:04X}.W',p+2
        if reg==1:
            a=l(p);return f'${a:08X}.L',p+4
        if reg==2:
            d=sw(w(p));return f'${(p+d)&0xffffff:06X}(PC)',p+2
        if reg==3:
            ext=w(p);d=sb(ext&0xff);ix='A' if ext&0x8000 else 'D';ir=(ext>>12)&7;il='.L' if ext&0x800 else '.W';sc=1<<((ext>>9)&3)
            return f'{d:+#x}(PC,{ix}{ir}{il}*{sc})',p+2
        if reg==4:
            if size=='B': return f'#${w(p)&0xff:02X}',p+2
            if size=='W': return f'#${w(p):04X}',p+2
            return f'#${l(p):08X}',p+4
    return f'<ea {mode},{reg}>',p

cc=['RA','SR','HI','LS','CC','CS','NE','EQ','VC','VS','PL','MI','GE','LT','GT','LE']

def dec(a):
    op=w(a); p=a+2
    # fixed/system
    if op==0x4e75:return 'RTS',p
    if op==0x4e71:return 'NOP',p
    if op==0x4e73:return 'RTE',p
    if op==0x4e77:return 'RTR',p
    if op==0x4eb9:
        x=l(p); return f'JSR ${x:06X}',p+4
    if (op&0xfff8)==0x4e90:return f'JSR (A{op&7})',p
    if op==0x4ef9:
        x=l(p); return f'JMP ${x:06X}',p+4
    if (op&0xfff8)==0x4ed0:return f'JMP (A{op&7})',p
    # branches
    if (op&0xf000)==0x6000:
        c=(op>>8)&15; d=op&0xff
        if d==0: d=sw(w(p)); p+=2
        else:d=sb(d)
        target=(a+2+d)&0xffffff
        n='BRA' if c==0 else 'BSR' if c==1 else 'B'+cc[c]
        return f'{n} ${target:06X}',p
    # MOVEQ
    if (op&0xf100)==0x7000:return f'MOVEQ #{sb(op&255)},D{(op>>9)&7}',p
    # LEA
    if (op&0xf1c0)==0x41c0:
        src,p=ea((op>>3)&7,op&7,'L',p);return f'LEA {src},A{(op>>9)&7}',p
    # PEA
    if (op&0xffc0)==0x4840:
        src,p=ea((op>>3)&7,op&7,'L',p);return f'PEA {src}',p
    # LINK/UNLK
    if (op&0xfff8)==0x4e50:
        d=sw(w(p));return f'LINK A{op&7},#{d}',p+2
    if (op&0xfff8)==0x4e58:return f'UNLK A{op&7}',p
    # MOVE / MOVEA
    top=op>>12
    if top in (1,2,3):
        size={1:'B',2:'L',3:'W'}[top]
        sm=(op>>3)&7; sr=op&7; dm=(op>>6)&7; dr=(op>>9)&7
        src,p1=ea(sm,sr,size,p)
        if dm==1 and size!='B': return f'MOVEA.{size} {src},A{dr}',p1
        dst,p2=ea(dm,dr,size,p1)
        return f'MOVE.{size} {src},{dst}',p2
    # immediate bit operations
    if (op&0xff00)==0x0800:
        names=['BTST','BCHG','BCLR','BSET']; bit=w(p)&0xff;p+=2; dst,p=ea((op>>3)&7,op&7,'B',p)
        return f'{names[(op>>6)&3]} #{bit},{dst}',p
    # dynamic bit ops 01xx
    if (op&0xf100)==0x0100:
        names=['BTST','BCHG','BCLR','BSET'];dst,p=ea((op>>3)&7,op&7,'B',p)
        return f'{names[(op>>6)&3]} D{(op>>9)&7},{dst}',p
    # immediate ALU ORI/ANDI/SUBI/ADDI/EORI/CMPI
    imap={0x0000:'ORI',0x0200:'ANDI',0x0400:'SUBI',0x0600:'ADDI',0x0a00:'EORI',0x0c00:'CMPI'}
    k=op&0xff00
    if k in imap and (op&0x003f)!=0x003c:
        sc=(op>>6)&3
        if sc<3:
            size=['B','W','L'][sc]
            if size=='B': imm=w(p)&0xff;p+=2
            elif size=='W':imm=w(p);p+=2
            else:imm=l(p);p+=4
            dst,p=ea((op>>3)&7,op&7,size,p)
            return f'{imap[k]}.{size} #${imm:X},{dst}',p
    # CLR/NEG/NOT/TST
    base=op&0xff00
    for mask,name in [(0x4200,'CLR'),(0x4400,'NEG'),(0x4600,'NOT'),(0x4a00,'TST')]:
        if base==mask:
            sc=(op>>6)&3
            if sc<3:
                size=['B','W','L'][sc];dst,p=ea((op>>3)&7,op&7,size,p);return f'{name}.{size} {dst}',p
    # SWAP/EXT
    if (op&0xfff8)==0x4840:return f'SWAP D{op&7}',p
    if (op&0xffb8)==0x4880:
        return f"EXT.{('W' if not(op&0x40) else 'L')} D{op&7}",p
    # DBcc/Scc
    if (op&0xf0f8)==0x50c8:
        d=sw(w(p));p+=2;return f'DB{cc[(op>>8)&15]} D{op&7},${(a+2+d)&0xffffff:06X}',p
    if (op&0xf0c0)==0x50c0:
        dst,p=ea((op>>3)&7,op&7,'B',p);return f'S{cc[(op>>8)&15]} {dst}',p
    # ADDQ/SUBQ
    if (op&0xf000)==0x5000 and (op&0x00c0)!=0x00c0:
        n=(op>>9)&7;n=8 if n==0 else n; name='SUBQ' if op&0x0100 else 'ADDQ';sc=(op>>6)&3;size=['B','W','L'][sc]
        dst,p=ea((op>>3)&7,op&7,size,p);return f'{name}.{size} #{n},{dst}',p
    # CMP family
    if (op&0xf000)==0xb000:
        dn=(op>>9)&7;opmode=(op>>6)&7
        if opmode in (0,1,2):
            size=['B','W','L'][opmode];src,p=ea((op>>3)&7,op&7,size,p);return f'CMP.{size} {src},D{dn}',p
        if opmode in (3,7):
            size='W' if opmode==3 else 'L';src,p=ea((op>>3)&7,op&7,size,p);return f'CMPA.{size} {src},A{dn}',p
        if opmode in (4,5,6):
            size=['B','W','L'][opmode-4];dst,p=ea((op>>3)&7,op&7,size,p);return f'EOR.{size} D{dn},{dst}',p
    # ADD/SUB/AND/OR families
    fam={0xd000:'ADD',0x9000:'SUB',0xc000:'AND',0x8000:'OR'}
    fk=op&0xf000
    if fk in fam:
        dn=(op>>9)&7; om=(op>>6)&7;name=fam[fk]
        if om in (0,1,2):
            size=['B','W','L'][om];src,p=ea((op>>3)&7,op&7,size,p);return f'{name}.{size} {src},D{dn}',p
        if om in (4,5,6):
            size=['B','W','L'][om-4];dst,p=ea((op>>3)&7,op&7,size,p);return f'{name}.{size} D{dn},{dst}',p
        if name in ('ADD','SUB') and om in (3,7):
            size='W' if om==3 else 'L';src,p=ea((op>>3)&7,op&7,size,p);return f'{name}A.{size} {src},A{dn}',p
    # shifts register
    if (op&0xf000)==0xe000:
        sc=(op>>6)&3
        if sc<3:
            size=['B','W','L'][sc];typ=['AS','LS','ROX','RO'][(op>>3)&3];direc='L' if op&0x100 else 'R';reg=op&7
            if op&0x20:cnt=f'D{(op>>9)&7}'
            else:
                n=(op>>9)&7;cnt=f'#{8 if n==0 else n}'
            return f'{typ}{direc}.{size} {cnt},D{reg}',p
    # EXG common
    if (op&0xf1f8)==0xc140:return f'EXG D{(op>>9)&7},D{op&7}',p
    if (op&0xf1f8)==0xc148:return f'EXG A{(op>>9)&7},A{op&7}',p
    if (op&0xf1f8)==0xc188:return f'EXG D{(op>>9)&7},A{op&7}',p
    # MUL/DIV
    if (op&0xf1c0)==0xc0c0:
        src,p=ea((op>>3)&7,op&7,'W',p);return f'MULU.W {src},D{(op>>9)&7}',p
    if (op&0xf1c0)==0xc1c0:
        src,p=ea((op>>3)&7,op&7,'W',p);return f'MULS.W {src},D{(op>>9)&7}',p
    if (op&0xf1c0)==0x80c0:
        src,p=ea((op>>3)&7,op&7,'W',p);return f'DIVU.W {src},D{(op>>9)&7}',p
    if (op&0xf1c0)==0x81c0:
        src,p=ea((op>>3)&7,op&7,'W',p);return f'DIVS.W {src},D{(op>>9)&7}',p
    return f'DC.W ${op:04X}',p

while pc<end and pc+1<len(B):
    a=pc
    try:s,pc=dec(pc)
    except Exception as e:s=f'<ERR {e}>';pc=a+2
    raw=B[a:pc].hex(' ')
    print(f'{a:06X}: {raw:<24} {s}')
