#include "arcade_ai.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned char *load(size_t*n){FILE*f=fopen("program.bin","rb");assert(f);fseek(f,0,SEEK_END);*n=(size_t)ftell(f);rewind(f);unsigned char*b=malloc(*n);assert(b&&fread(b,1,*n,f)==*n);fclose(f);return b;}
int main(void){size_t n;unsigned char*b=load(&n);
 const unsigned char kernel[]={0x02,0x80,0x00,0x00,0x00,0xff,0xe2,0x48,0x0c,0x40,0x00,0x64};
 assert(!memcmp(b+0x24d6,kernel,sizeof(kernel)));
 const uint8_t a[2]={20,80},b50[2]={50,50};
 assert(arcade_ai_weighted_choice(a,0)==0);assert(arcade_ai_weighted_choice(a,20)==0);assert(arcade_ai_weighted_choice(a,21)==1);assert(arcade_ai_weighted_choice(a,99)==1);
 assert(arcade_ai_weighted_choice(b50,50)==0);assert(arcade_ai_weighted_choice(b50,51)==1);
 free(b);puts("PASS: Test129 reproduces ROM $24CC weighted selector after its 1..99 random normalization");}
