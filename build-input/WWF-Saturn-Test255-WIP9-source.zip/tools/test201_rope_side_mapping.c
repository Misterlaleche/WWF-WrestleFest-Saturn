#include "game.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 unsigned r[6]={0,2,1,3,4,5};game_t g;game_match_start(&g,GAME_TAG,r);g.cpu=false;
 fighter_t *f=&g.fighters[0];f->state=ST_REBOUND;f->x=game_ring_left(220)*256;f->y=220*256;
 assert(game_rope_deflection(&g,game_ring_left(220),220)>0);
 assert(game_rope_deflection(&g,126,RING_BOTTOM)==0);
 f->x=126*256;f->y=RING_BOTTOM*256;
 assert(game_rope_deflection(&g,126,RING_BOTTOM)>0);
 assert(game_rope_deflection(&g,game_ring_left(220),220)==0);
 puts("PASS Test201: rebound deflection is bound to the contacted trapezoid side, so lateral rebounds cannot animate the south rope");
}
