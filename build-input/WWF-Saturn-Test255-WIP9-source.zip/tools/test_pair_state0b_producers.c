#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static int scan(const unsigned char*r,size_t n,const unsigned char*p,size_t z,size_t*out,size_t cap){int c=0;for(size_t i=0;i+z<=n;i++)if(!memcmp(r+i,p,z)){if((size_t)c<cap)out[c]=i;c++;}return c;}
int main(void){FILE*f=fopen("program.bin","rb");assert(f);fseek(f,0,SEEK_END);long ln=ftell(f);rewind(f);size_t n=(size_t)ln;unsigned char*r=malloc(n);assert(r&&fread(r,1,n,f)==n);fclose(f);
 const unsigned char a0[]={0x31,0x7c,0x00,0x0b,0x00,0x20};const unsigned char a1[]={0x33,0x7c,0x00,0x0b,0x00,0x20};const unsigned char a2[]={0x35,0x7c,0x00,0x0b,0x00,0x20};size_t o[4];
 assert(scan(r,n,a0,sizeof a0,o,4)==2&&o[0]==0xf726&&o[1]==0x165e4);assert(scan(r,n,a1,sizeof a1,o,4)==1&&o[0]==0xf72c);assert(scan(r,n,a2,sizeof a2,o,4)==1&&o[0]==0x165ea);
 const unsigned char geom[]={0x0c,0x43,0x00,0x48,0x64,0xac};assert(!memcmp(r+0xf5c4,geom,sizeof geom));const unsigned char geomy[]={0x0c,0x43,0x00,0x10,0x64,0x98};assert(!memcmp(r+0xf5d8,geomy,sizeof geomy));
 free(r);puts("PASS Test81: exhaustive direct-immediate raw-state-$0B audit finds only initial pair producer $F726/$F72C and action-$29 reentry $165E4/$165EA; initial producer is gated by |dx|<$48 and |dy|<$10");return 0;}
