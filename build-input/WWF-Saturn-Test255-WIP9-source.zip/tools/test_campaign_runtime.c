#include "campaign_runtime.h"
#include "arcade_stamina.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 campaign_t c;campaign_reset(&c,CAMPAIGN_TAG,5,0,ARCADE_DIFFICULTY_NORMAL);campaign_set_players(&c,0,7);
 unsigned chars[6]={0};game_t g;campaign_start_game(&c,&g,chars,1,100);
 assert(chars[0]==0&&chars[2]==7&&chars[1]!=chars[3]&&chars[1]<10&&chars[3]<10);
 assert(g.stage_index==0&&g.fighters[0].health==110&&g.fighters[2].health==102);
 assert(g.fighters[1].max_health==115&&g.fighters[3].max_health==100);
 /* Tag swaps identities but campaign capture follows character identity. */
 g.fighters[0].character=7;g.fighters[0].health=40;g.fighters[2].character=0;g.fighters[2].health=50;
 assert(campaign_commit_win(&c,&g)&&c.stage==1);
 assert(campaign_player_stamina(&c,7)==64&&campaign_player_stamina(&c,0)==74);
 campaign_start_game(&c,&g,chars,100,100);
 assert(g.stage_index==1&&g.fighters[0].health==74&&g.fighters[2].health==64);
 assert(g.fighters[1].max_health==145&&g.fighters[3].max_health==130);
 /* Retry same roster/stage does not reroll opponents or lose carried stamina. */
 unsigned saved1=chars[1],saved3=chars[3];g.fighters[0].health=1;
 campaign_restart_game(&c,&g,chars);assert(chars[1]==saved1&&chars[3]==saved3&&g.fighters[0].health==74);
 puts("PASS: campaign bridge rolls stage opponents, carries identity stamina, stage CPU maxima and stable retries");
}
