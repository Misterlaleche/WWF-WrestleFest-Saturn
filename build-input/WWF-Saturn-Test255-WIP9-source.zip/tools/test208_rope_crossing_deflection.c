#include "game.h"
#include "session.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 unsigned r[6]={0,2,1,3,4,5};game_t g;game_match_start(&g,GAME_TAG,r);g.cpu=false;
 fighter_t *f=&g.fighters[0];f->state=ST_RING_EXIT;f->tick=12;f->x=game_ring_left(215)*256;f->y=215*256;
 int west=game_rope_deflection(&g,game_ring_left(215),215);int south=game_rope_deflection(&g,150,RING_BOTTOM);
 assert(west>0&&south==0);
 f->state=ST_TOSSED;f->x=game_ring_right(215)*256;f->y=215*256;
 int east=game_rope_deflection(&g,game_ring_right(215),215);south=game_rope_deflection(&g,150,RING_BOTTOM);
 assert(east>0&&south==0);
 puts("PASS Test208: ring traversal/toss deflects the actual crossed rope side; unrelated south rope stays rigid");
}
