#include "hud.h"
#include <assert.h>
#include <stdio.h>
int main(void){unsigned ch[4]={0,2,7,1},hp[4]={91,83,64,55};hud_slot_t s[4];hud_tag_slots(ch,hp,s);
 assert(s[0].character==0&&s[0].health==91&&s[0].status==HUD_ACTIVE&&!s[0].cpu);
 assert(s[1].character==7&&s[1].health==64&&s[1].status==HUD_WAITING&&!s[1].cpu);
 assert(s[2].character==2&&s[2].health==83&&s[2].status==HUD_ACTIVE&&s[2].cpu);
 assert(s[3].character==1&&s[3].health==55&&s[3].status==HUD_WAITING&&s[3].cpu);
 assert(!s[1].grayscale&&!s[3].grayscale);
 puts("PASS Test103: TAG HUD exposes active+reserve stamina for both teams in panel order 0,2,1,3 without forced grayscale portraits");}
