#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void seq(const unsigned char*r,size_t n,size_t o,const unsigned char*s,size_t z){assert(o+z<=n);assert(!memcmp(r+o,s,z));}
int main(void){FILE*f=fopen("program.bin","rb");assert(f);fseek(f,0,SEEK_END);long ln=ftell(f);rewind(f);size_t n=(size_t)ln;unsigned char*r=malloc(n);assert(r&&fread(r,1,n,f)==n);fclose(f);
 const unsigned char pair[]={0x22,0x68,0x00,0x86};seq(r,n,0x20f30,pair,sizeof pair);
 const unsigned char gates[]={0x08,0x29,0x00,0x01,0x00,0x33,0x66,0x20,0x08,0x28,0x00,0x01,0x00,0x33};seq(r,n,0x20f64,gates,sizeof gates);
 const unsigned char handoff[]={0x08,0xa9,0x00,0x06,0x00,0x56,0x08,0xa8,0x00,0x01,0x00,0x33,0x08,0xe9,0x00,0x01,0x00,0x33};seq(r,n,0x20f74,handoff,sizeof handoff);
 free(r);puts("PASS Test90: ROM handoff to +$86 partner clears partner +$56 bit6, clears current actor +$33 bit1 and sets partner +$33 bit1");return 0;}
