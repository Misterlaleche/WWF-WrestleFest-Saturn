#include "session.h"
#include "game.h"
#include <assert.h>
#include <stdio.h>
static void press(session_t *s,unsigned key){session_tick(s,0);session_tick(s,key);}
static void tick(game_t *g,unsigned n){while(n--)game_tick(g,0,0);}
int main(void){
 session_t s;session_reset(&s,MENU_OK);assert(!session_tick(&s,MENU_OK)&&s.phase==SESSION_MODE);press(&s,MENU_OK);assert(s.phase==SESSION_SELECT);
 for(unsigned c=0;c<10;c++){s.cursor=c;assert(session_character(&s)<10);assert(session_page(&s)==(c%5>=3));}
 s.cursor=0;press(&s,MENU_OK);assert(s.count==1&&s.phase==SESSION_SELECT);press(&s,MENU_OK);assert(s.count==1);press(&s,MENU_RIGHT);press(&s,MENU_OK);assert(s.phase==SESSION_CPU&&s.selected[0]==0&&s.selected[1]==7);
 unsigned first=session_cpu_cursor(&s);
 for(unsigned i=0;i<119;i++)session_tick(&s,0);
 assert(session_cpu_cursor(&s)==first);session_tick(&s,0);assert(session_cpu_cursor(&s)!=first);
 for(unsigned i=0;i<120;i++)session_tick(&s,0);
 assert(s.phase==SESSION_HALL);
 unsigned mask=0;for(unsigned i=0;i<4;i++){assert(!(mask&(1U<<s.characters[i])));mask|=1U<<s.characters[i];}
 press(&s,MENU_OK);assert(s.phase==SESSION_ANNOUNCE);press(&s,MENU_OK);assert(s.phase==SESSION_PLAY);
 game_t g;game_match_start(&g,GAME_TAG,s.characters);g.cpu=false;
 for(unsigned edge=0;edge<4;edge++){
  game_match_start(&g,GAME_TAG,s.characters);g.cpu=false;fighter_t *p=&g.fighters[0];int y=edge==0?RING_TOP:edge==1?RING_BOTTOM:215;
  p->y=y*256;p->x=(edge==2?game_ring_left(y):edge==3?game_ring_right(y):126)*256;
  assert(game_ring_exit_near(p));game_tick(&g,0,INPUT_RING);assert(p->state==ST_RING_EXIT);tick(&g,48);assert(p->outside&&game_ringside_valid(p->x/256,p->y/256));
  tick(&g,16);game_tick(&g,0,INPUT_RING);assert(p->state==ST_RING_ENTER);tick(&g,48);assert(!p->outside&&game_on_floor(p->x/256,p->y/256));
 }
 game_match_start(&g,GAME_TAG,s.characters);g.cpu=false;g.fighters[0].x=24*256;g.fighters[0].y=170*256;game_tick(&g,0,INPUT_TAG);assert(g.fighters[0].character==7&&g.fighters[2].character==0&&g.tags==1);game_tick(&g,0,INPUT_TAG);assert(g.tags==1);
 session_reset(&s,0);press(&s,MENU_LEFT);assert(!s.mode);press(&s,MENU_OK);press(&s,MENU_OK);assert(s.phase==SESSION_HALL);
 mask=0;for(unsigned i=0;i<6;i++){assert(!(mask&(1U<<s.characters[i])));mask|=1U<<s.characters[i];}
 game_match_start(&g,GAME_RUMBLE,s.characters);assert(g.active_mask==63&&g.roster_count==6);
 for(unsigned i=0;i<3000;i++){game_tick(&g,(i/100)%2?INPUT_RIGHT:INPUT_LEFT,i%40==0?INPUT_PUNCH:0);for(unsigned a=0;a<6;a++)assert(g.fighters[a].health<=g.fighters[a].max_health);}
 puts("PASS: session edge input, ten choices, duplicate partner, roster uniqueness, entrance skip, four exits/reentries, tag preservation/cooldown, six-fighter simulation");
}
