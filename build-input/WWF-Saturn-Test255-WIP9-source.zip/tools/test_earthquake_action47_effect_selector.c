#include <assert.h>
#include <stdio.h>
#include "arcade_earthquake_raw.h"
int main(void){
 assert(arcade_effect_table_address(2)==0x2764U);
 assert(arcade_effect_table_address(5)==0x2770U);
 assert(!arcade_quake47_selector_is_damage_semantic());
 puts("PASS Test149: $26AE proves action-$47 D0 values 2/5 are 4-byte effect-table selectors, not damage values");
 return 0;
}
