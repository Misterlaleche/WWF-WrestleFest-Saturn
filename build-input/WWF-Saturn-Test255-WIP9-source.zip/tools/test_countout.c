#include "game.h"
#include <assert.h>
#include <stdio.h>
static const unsigned roster[6]={0,1,2,3,4,5};
static void tickn(game_t *g,unsigned n){for(unsigned i=0;i<n;i++)game_tick(g,0,0);}
static void prep(game_t *g){game_match_start(g,GAME_TAG,roster);g->cpu=false;g->time_left=9999;g->fighters[0].state=ST_IDLE;g->fighters[1].state=ST_IDLE;}
int main(void){
 game_t g;
 prep(&g);g.fighters[0].outside=true;g.fighters[0].y=320*256;g.fighters[0].rise_y=g.fighters[0].y;
 tickn(&g,79);assert(!g.ringout_count&&g.ringout_tick==79&&!g.finished);
 game_tick(&g,0,0);assert(g.ringout_count==1&&!g.ringout_tick&&!g.finished);
 tickn(&g,80*18);assert(g.ringout_count==19&&!g.finished);
 tickn(&g,79);assert(!g.finished);game_tick(&g,0,0);assert(g.finished&&g.finish_reason==FINISH_COUNTOUT&&g.winner==1&&g.ringout_count==20);
 prep(&g);g.fighters[0].outside=true;g.fighters[0].y=320*256;tickn(&g,160);assert(g.ringout_count==2);g.fighters[0].outside=false;game_tick(&g,0,0);assert(!g.ringout_count&&!g.ringout_tick&&!g.finished);
 prep(&g);g.fighters[0].outside=g.fighters[1].outside=true;g.fighters[0].y=g.fighters[1].y=320*256;tickn(&g,80*20);assert(g.finished&&g.finish_reason==FINISH_COUNTOUT&&g.winner==-1);
 game_match_start(&g,GAME_RUMBLE,roster);g.fighters[0].outside=false;g.fighters[1].outside=false;g.ringout_count=7;game_tick(&g,0,0);assert(!g.ringout_count);
 puts("PASS: exact 80-tick/20-count TAG ring-out clock, reset and single/double count-out result");
}
