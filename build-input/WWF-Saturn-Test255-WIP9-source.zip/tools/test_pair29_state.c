#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arcade_pair_state.h"
static void seq(const unsigned char*r,size_t n,size_t o,const unsigned char*s,size_t z){assert(o+z<=n);assert(!memcmp(r+o,s,z));}
int main(void){FILE*f=fopen("program.bin","rb");assert(f);fseek(f,0,SEEK_END);long ln=ftell(f);rewind(f);size_t n=(size_t)ln;unsigned char*r=malloc(n);assert(r&&fread(r,1,n,f)==n);fclose(f);
 const unsigned char head[]={0x08,0x28,0x00,0x07,0x00,0x1c};seq(r,n,0x16582,head,sizeof head);
 const unsigned char terminal[]={0x0c,0x28,0x00,0xfe,0x00,0x25,0x66,0x4e};seq(r,n,0x165bc,terminal,sizeof terminal);
 const unsigned char first[]={0x31,0x7c,0x00,0x0b,0x00,0x20,0x35,0x7c,0x00,0x0b,0x00,0x20,0x42,0x68,0x00,0x44,0x35,0x7c,0x80,0x00,0x00,0x44};seq(r,n,0x165e4,first,sizeof first);
 const unsigned char second[]={0x31,0x7c,0x00,0x0c,0x00,0x20,0x31,0x7c,0x20,0x00,0x00,0x44,0x35,0x7c,0x00,0xff,0x00,0x20,0x42,0x6a,0x00,0x44};seq(r,n,0x165fc,second,sizeof second);
 arcade_pair29_state_t s={.attacker_state=9,.target_state=9,.attacker_44=0x80,.target_44=0,.target_52=0};assert(arcade_pair29_apply_terminal(&s,0,0));assert(!(s.attacker_44&0x80)&&s.target_44&0x80&&s.target_state==0xff);
 s=(arcade_pair29_state_t){.attacker_state=9,.target_state=9,.target_52=0,.target_c7=7};assert(arcade_pair29_apply_terminal(&s,0x80,0xfe));assert(s.target_68==1&&s.target_c7==8&&s.target_54==0x100&&s.target_52==1);assert(s.attacker_state==0x0b&&s.target_state==0x0b&&s.attacker_44==0&&s.target_44==0x8000);
 assert(arcade_pair29_apply_terminal(&s,0x80,0xfe));assert(s.target_52==2&&s.attacker_state==0x0c&&s.attacker_44==0x2000&&s.target_state==0xff&&s.target_44==0);
 arcade_pair29_state_t hold={.attacker_state=3};assert(!arcade_pair29_apply_terminal(&hold,0x80,1)&&hold.attacker_state==3);
 free(r);puts("PASS Test82: action $29 callback $16582 exact pair-state terminal/reentry path modeled: first FE completion -> both $0B, second -> attacker $0C + target $FF; non-bit7 path transfers flag7 and ends target");return 0;}
