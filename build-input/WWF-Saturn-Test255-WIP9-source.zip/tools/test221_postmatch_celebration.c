#include "../ui_assets.h"
#include <assert.h>
#include <stdio.h>
int main(void){unsigned a=postmatch_winner_pose(0,0),b=postmatch_winner_pose(0,8);assert(a!=b);assert(postmatch_winner_pose(4,20)==0);puts("PASS Test221: winner staging animates only through existing recovered presentation gestures; unsupported characters remain idle");}
