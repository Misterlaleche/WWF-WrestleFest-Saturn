#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
int main(void){FILE*f=fopen("program.bin","rb");assert(f);uint8_t b[14];assert(fseek(f,0x20120,SEEK_SET)==0&&fread(b,1,sizeof b,f)==sizeof b);fclose(f);
 const uint8_t p[]={0x42,0x79,0x00,0x1c,0x16,0x9e,0x4e,0xb9,0x00,0x00,0x90,0xd6,0x4e,0x75};assert(!memcmp(b,p,sizeof p));
 puts("PASS Test171: Royal phase-6 cleanup clears global $1C169E then calls exact stamina restore routine $90D6 before return; this path is now bounded without assigning extra semantics to +$109");return 0;}
