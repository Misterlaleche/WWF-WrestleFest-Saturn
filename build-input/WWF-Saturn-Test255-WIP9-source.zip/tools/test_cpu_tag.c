#include "game.h"
#include <assert.h>
#include <stdio.h>
static unsigned roster[6]={0,2,7,1,4,5};
static void setup(game_t *g){game_match_start(g,GAME_TAG,roster);g->fighters[0].x=30*256;g->fighters[0].y=240*256;g->fighters[1].health=25;g->fighters[1].stamina_tier=2;g->fighters[1].x=120*256;g->fighters[1].y=240*256;}
static void wait_tag(game_t *g,unsigned limit){for(unsigned t=0;t<limit&&!g->tags;t++)game_tick(g,0,0);}
int main(void){
 game_t g;setup(&g);wait_tag(&g,420);
 assert(g.tags==1&&g.fighters[1].character==1&&g.fighters[1].health==g.fighters[1].max_health&&g.fighters[3].character==2&&g.fighters[3].health>=25);
 assert(game_partner_waiting(&g,3)&&g.fighters[3].facing==-1);
 setup(&g);g.fighters[1].x=230*256;g.fighters[1].y=170*256;g.paused=true;
 game_tick(&g,0,0);assert(g.tags==0&&g.tag_phase[1]==TAG_PHASE_NONE);g.paused=false;g.tag_cooldown=50;
 game_tick(&g,0,0);assert(g.tags==0&&g.tag_phase[1]==TAG_PHASE_NONE);g.tag_cooldown=0;g.fighters[3].health=20;g.fighters[3].stamina_tier=2;
 game_tick(&g,0,0);assert(g.tags==0&&g.tag_phase[1]==TAG_PHASE_NONE);
 setup(&g);g.fighters[1].health=55;g.fighters[1].stamina_tier=1;g.fighters[3].power_up=true;g.fighters[1].x=230*256;g.fighters[1].y=170*256;wait_tag(&g,180);assert(g.tags==1&&g.fighters[1].power_up);
 setup(&g);g.fighters[1].power_up=true;g.fighters[1].stamina_tier=2;for(unsigned t=0;t<120;t++)game_tick(&g,0,0);assert(!g.tags&&g.tag_phase[1]==TAG_PHASE_NONE);
 setup(&g);g.cpu=false;for(unsigned t=0;t<200;t++)game_tick(&g,0,0);assert(!g.tags&&g.tag_phase[1]==TAG_PHASE_NONE);
 puts("PASS: CPU TAG uses stamina tiers/reserve Power Up and now completes through staged TAG phases; cooldown, powered legal wrestler, weak reserve and CPU-off inhibit tag");
}
