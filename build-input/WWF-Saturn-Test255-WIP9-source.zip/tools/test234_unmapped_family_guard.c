#include <assert.h>
#include <stdio.h>
#include "../roster_data.h"
int main(void){
 assert(roster_arcade_frame_character(0,104)<ROSTER_FRAMES);
 assert(roster_arcade_frame_character(2,110)<ROSTER_FRAMES);
 assert(roster_arcade_frame_character(1,104)==ROSTER_FRAMES);
 assert(roster_arcade_frame_character(0,395)==ROSTER_FRAMES);
 assert(roster_arcade_frame_character(0,263)==ROSTER_FRAMES);
 assert(roster_arcade_frame_character(0,114)==ROSTER_FRAMES);
 puts("PASS Test234: exact recovered RISE aliases bypass fallback while unresolved rise/ground/object poses remain explicitly guarded");
}
