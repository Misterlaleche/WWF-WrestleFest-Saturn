#include "game.h"
#include "recovery_timing.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 fighter_t f={0};f.arcade_motion=true;f.state=ST_RISE;
 for(unsigned role=0;role<2;role++){
  f.actor=role;f.throw_recovery=false;
  for(unsigned t=0;t<ARCADE_RISE_TICKS;t++){
   f.tick=t;int p=game_arcade_pose(&f);
   if(t<13)assert(p==(int)(role?110:112));
   else if(t<26)assert(p==(int)(role?111:113));
   else assert(p==104);
  }
 }
 puts("PASS Test141: live renderer uses exact arcade rise descriptors 13/13/17");
}
