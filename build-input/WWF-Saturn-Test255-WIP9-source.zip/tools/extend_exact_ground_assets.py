#!/usr/bin/env python3
"""Test235: recover Earthquake STOMP frames 470/471 from the exact F08 overlay
already present in the validated Test200 disc image and fold them into C08.PAK.
No sprite pixels are fabricated; texture bytes and records are copied exactly.
"""
from pathlib import Path
import struct,re,itertools,json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import lz4_codec
ROOT=Path(__file__).resolve().parents[1]

def be16(b,o): return int.from_bytes(b[o:o+2],'big')
def be32(b,o): return int.from_bytes(b[o:o+4],'big')
def fnv(data):
 h=2166136261
 for x in data:h=((h^x)*16777619)&0xffffffff
 return h

def unpack(path):
 b=path.read_bytes(); assert be32(b,0)==0x57464332
 frames,records,tiles,off,block_tiles,blocks=[be32(b,o) for o in (4,8,12,16,24,28)]
 idx=[(be16(b,32+i*4),be16(b,34+i*4)) for i in range(frames)]
 ro=32+frames*4
 rec=[list(struct.unpack_from('>HhhH',b,ro+i*8)) for i in range(records)]
 tex=[]
 for bi in range(blocks):
  eo=off+bi*12; pos,stored,raw=be32(b,eo),be32(b,eo+4),be32(b,eo+8)
  chunk=lz4_codec.decompress(b[pos:pos+stored],raw)
  tex.extend(chunk[i:i+128] for i in range(0,len(chunk),128))
 assert len(tex)==tiles
 return [[r[:] for r in rec[first:first+count]] for first,count in idx],tex,block_tiles

def pack(frames,textures,block_tiles):
 indexes=[];records=[]
 for f in frames:indexes.append((len(records),len(f)));records.extend(f)
 body=b''.join(struct.pack('>HH',*x) for x in indexes)+b''.join(struct.pack('>HhhH',*r) for r in records)
 off=(32+len(body)+31)&~31
 raw=b''.join(textures); chunks=[]
 for first in range(0,len(textures),block_tiles):
  chunk=b''.join(textures[first:first+block_tiles]); comp=lz4_codec.compress(chunk); assert lz4_codec.decompress(comp,len(chunk))==chunk;chunks.append((chunk,comp))
 pos=off+len(chunks)*12; directory=[]; payload=[]
 for chunk,comp in chunks:directory.append(struct.pack('>III',pos,len(comp),len(chunk)));payload.append(comp);pos+=len(comp)
 hdr=struct.pack('>8I',0x57464332,len(frames),len(records),len(textures),off,fnv(raw),block_tiles,len(chunks))
 return hdr+body+bytes(off-32-len(body))+b''.join(directory)+b''.join(payload)

def main():
 f08_frames,f08_tex,_=unpack(ROOT/'cd/F08.PAK')
 assert len(f08_frames)==2, len(f08_frames)
 sizes=[]; hashes=[]; report=[]
 for ch in range(10):
  path=ROOT/'cd'/f'C{ch:02}.PAK'; frames,tex,bt=unpack(path); assert len(frames)==212
  added=[]
  if ch==8:
   lookup={t:i for i,t in enumerate(tex)}
   for phase,pose in enumerate((470,471)):
    nr=[]
    for ti,x,y,flip in f08_frames[phase]:
     px=f08_tex[ti]
     if px not in lookup: lookup[px]=len(tex); tex.append(px)
     nr.append([lookup[px],x,y,flip])
    frames.append(nr); added.append({'pose':pose,'frame':212+phase,'records':len(nr),'source_overlay':'F08.PAK','source_frame':phase})
  else:
   frames.extend([[],[]])
  data=pack(frames,tex,bt);path.write_bytes(data);sizes.append(len(data));hashes.append(fnv(data));report.append({'character':ch,'bytes':len(data),'added':added})
 h=(ROOT/'roster_data.h').read_text().replace('#define ROSTER_FRAMES 212','#define ROSTER_FRAMES 214')
 h=re.sub(r'static const unsigned roster_bytes\[10\]=\{.*?\};','static const unsigned roster_bytes[10]={'+','.join(map(str,sizes))+'};',h)
 h=re.sub(r'static const unsigned roster_hash\[10\]=\{.*?\};','static const unsigned roster_hash[10]={'+','.join(str(x)+'U' for x in hashes)+'};',h)
 old='case 8: switch(pose){'
 if old not in h:
  h=h.replace(' default:break;\n }\n return roster_arcade_frame(pose);',' case 8: switch(pose){case 470:return 212;case 471:return 213;default:break;} break;\n default:break;\n }\n return roster_arcade_frame(pose);')
 else: raise SystemExit('unexpected preexisting case 8')
 (ROOT/'roster_data.h').write_text(h)
 aligned=[(x+2047)&~2047 for x in sizes]; worst=max(sum(aligned[i] for i in c) for c in itertools.combinations(range(10),6))
 assert worst<=1048576
 doc={'test':235,'frames_per_pack':214,'recovered':report,'worst_six_low_ram_bytes':worst,'capacity':1048576,'evidence':'exact F08.PAK from validated Test200 disc; frame records + 128-byte texture payloads copied bit-identically into C08','semantics':'poses 470/471 are non-pair Earthquake action $23 STOMP composition; callback-held duration remains separately provisional'}
 (ROOT/'docs/test235-exact-earthquake-stomp-assets.json').write_text(json.dumps(doc,indent=2)+'\n')
 print(json.dumps(doc,indent=2))
if __name__=='__main__':main()
