"""Offline decoder of WrestleFest composition tables, no CPU emulation."""
from pathlib import Path
import struct
P=b''
def load_program(path):
 global P
 P=Path(path).read_bytes()
def u16(p):return struct.unpack_from('>H',P,p)[0]
def u32(p):return struct.unpack_from('>I',P,p)[0]
def s8(x):return (x+128)%256-128
def pose_addr(char,pose):
 o=u16(0x38f14+u16(0x38f14+char*2)+(pose&0x7fff)*2)
 return None if o in (0xfffe,0xffff) else u32(0x38fb8+char*4)+o

def pair_metadata(char,pose):
 a=pose_addr(char,pose)
 if a is None:return None
 h=u16(a);kind=h>>14
 out={"kind":kind,"address":a,"partner_pose":None,"offsets":[]}
 if kind!=2:return out
 p=a+2;out["partner_pose"]=u16(p);p+=4
 # Kind-2 records carry one signed x/y pair per partner table.
 out["offsets"]=[(s8(P[p+i*2]),s8(P[p+i*2+1])) for i in range(12)]
 return out

def rows(addr,base,partner=2,depth=0):
 assert depth<8
 h=u16(addr);p=addr+2;kind=h>>14;n=h&255
 if kind==3:
  out=[]
  for i in range(n):out+=rows(base+u16(p+i*2),base,partner,depth+1)
  return out
 if kind==2:
  otherpose=u16(p);own=base+u16(p+2);p+=4
  other=pose_addr(partner,otherpose)
  if other is None:return []
  dx,dy=P[p+partner*2:p+partner*2+2]
  def segments(a,b):
   hh=u16(a)
   return [rows(b+u16(a+2+i*2),b,partner,depth+1) for i in range(hh&255)] if hh>>14==3 else [rows(a,b,partner,depth+1)]
  parts=[segments(own,base),segments(other,u32(0x38fb8+partner*4))]
  for seg in parts[1]:
   for r in seg:r[0]=(r[0]+dx)&255;r[1]=(r[1]+dy)&255
  out=[];j=[0,0];bits=h&0x3fff
  while any(j[i]<len(parts[i]) for i in range(2)):
   k=bits&1;bits>>=1
   if j[k]>=len(parts[k]):k=1-k
   out+=parts[k][j[k]];j[k]+=1
  return out
 def reference(p,tail):
  count=P[p];flags=P[p+1];target=u32(p)&0xfffff;p+=4;offset=[0,0,0]
  for i,bit in enumerate([64,32,16]):
   if flags&bit:offset[i]=P[p];p+=1
  rr=rows(target,base,partner,depth+1);rr=rr[-count:] if tail else rr[:count]
  for r in rr:
   for i,k in enumerate([0,1,3]):r[k]=(r[k]+offset[i])&255
  return rr,p
 before=[];after=[]
 if h&0x200:before,p=reference(p,False)
 if kind==0:out=[list(P[p+i*6:p+i*6+6]) for i in range(n)];p+=n*6
 else:
  p=(p+1)&~1;fmt=u16(p);p+=2;cols=[]
  for c in range(6):
   mode=(fmt>>(2*c))&3
   if mode==0:col=list(P[p:p+n]);p+=n
   elif mode==1:col=[P[p]]*n;p+=1
   else:
    p=(p+1)&~1;off=0x6b0b0+u16(p)+(0x8000 if mode==3 else 0);p+=2;col=list(P[off:off+n])
   cols.append(col)
  out=[list(r) for r in zip(*cols)]
 if h&0x100:after,p=reference((p+1)&~1,True)
 return before+out+after

def commands(char,pose,partner=2,x=160,y=96):
 a=pose_addr(char,pose)
 if a is None:return []
 out=[]
 for dx,dy,attr,bank,hi,lo in rows(a,u32(0x38fb8+char*4),partner):
  xx=x+(-s8(dx) if pose&0x8000 else s8(dx));yy=232-y-s8(dy);chain=(attr>>5)&7
  fx=bool(attr&16)^bool(pose&0x8000);fy=bool(attr&8)
  for c in range(chain+1):
   out.append(dict(code=hi*256+lo+c,bank=bank,x=xx,y=yy-chain*16+c*16 if fy else yy-c*16,fx=fx,fy=fy))
 return out
if __name__=='__main__':
 for c in [0,1,2,7]:print(c,commands(c,0)[:3])
