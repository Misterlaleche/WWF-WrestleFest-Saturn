#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static char *load_text(const char *path){
 FILE *f=fopen(path,"rb");assert(f);fseek(f,0,SEEK_END);long n=ftell(f);assert(n>0);rewind(f);
 char *s=malloc((size_t)n+1);assert(s);assert(fread(s,1,(size_t)n,f)==(size_t)n);fclose(f);s[n]=0;return s;
}
int main(void){
 char *s=load_text("main.c");
 char *a=strstr(s,"if(match_flow.phase==FLOW_RESULT)");assert(a);
 char *z=strstr(a,"}else if(match_flow.phase==FLOW_CONTINUE)");assert(z);*z=0;
 assert(strstr(a,"rectangle(&list[(*n)++],48,271,8,55,0x8000);"));
 assert(!strstr(a,"rectangle(&list[(*n)++],32,287,88,187,0x8000);"));
 assert(strstr(a,"arcade keeps\n   * celebrating/defeated actors on screen"));
 free(s);
 puts("PASS Test143: result phase keeps the ring centre unobscured; exact arcade typography/layout remains pending");
 return 0;
}
