#!/usr/bin/env python3
from pathlib import Path
import argparse,hashlib,re,shutil,zipfile

def program_name(root):
    return re.search(r'^SH_PROGRAM\s*:=\s*(\S+)', (root/'Makefile').read_text(), re.M).group(1)

def source_files(root):
    yield root/'layer_view.h'
    yield root/'render_pose.h'
    for name in ['combat_moves.h','roster_pack.c','roster_pack.h','finisher_assets.h','finisher_data.h','finisher_runtime.h','ground_pair_assets.h','object_assets.h']:yield root/name
    for name in ['match_result.c','match_result.h','recovery_timing.h']:yield root/name
    for name in ['match_flow.c','match_flow.h','presentation_assets.h']:yield root/name
    for name in ['hud.c','hud.h','hud_assets.h']:yield root/name
    for name in ['arcade_animation.c','arcade_animation.h','arcade_animation_data.h','autoplay.h','ui_assets.h']:yield root/name
    names=['main.c','graphics_dma.h','timing.h','presentation.h','session.c','session.h','codec.c','codec.h','roster_data.h','pair_order.h','title_data.h','intro.c','intro.h','intro_data.h','intro_sources.zip','game.c','game.h','pair_rules.h','arcade_moves.c','arcade_moves.h','arcade_rumble.c','arcade_rumble.h','arcade_ai.c','arcade_ai.h','arcade_ringside.c','arcade_ringside.h','arcade_stamina.c','arcade_stamina.h','arcade_input.c','arcade_input.h','arcade_action_map.c','arcade_action_map.h','arcade_behind_pair.c','arcade_behind_pair.h','arcade_pair_state.c','arcade_pair_state.h','campaign.c','campaign.h','campaign_runtime.c','campaign_runtime.h','program.bin','Makefile','README.md','model.json','model_data.h','build-docker.sh']
    for name in names: yield root/name
    for folder in ['assets','cd','docs','tools']:
        for p in sorted((root/folder).iterdir()):
            if folder=='docs' and (p.name=='capture_evidence.zip' or
                (p.suffix in ['.png','.gif'] and p.name not in ['scene_reference.png','intro_sequence.png','combat-moves-preview.png','layers-preview.png'])):
                continue
            if p.is_file() and p.name not in ['0.BIN','IP.BIN','A.BIN'] and p.suffix!='.gif':yield p

def package(root,out):
    root=Path(root);out=Path(out);out.mkdir(parents=True,exist_ok=True)
    stem=program_name(root)
    for name in [stem+'.iso',stem+'.cue','README.md']:
        shutil.copy2(root/name,out/name)
    shutil.copytree(root/'docs',out/'docs',dirs_exist_ok=True)
    with zipfile.ZipFile(out/(stem+'-source.zip'),'w',zipfile.ZIP_DEFLATED) as z:
        for p in source_files(root):z.write(p,p.relative_to(root))
    entries=[]
    for p in sorted(out.rglob('*')):
        if p.is_file() and p.name!='SHA256.txt':entries.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(out).as_posix())
    (out/'SHA256.txt').write_text('\n'.join(entries)+'\n')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root');p.add_argument('out');a=p.parse_args();package(a.root,a.out)
