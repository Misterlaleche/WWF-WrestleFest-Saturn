#include "arcade_rumble.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
int main(void){
 static const uint8_t sig[24]={0x02,0x40,0x01,0x20,0x02,0xd0,0x01,0x20,0x02,0x30,0x01,0x50,0x02,0xc0,0x01,0x50,0x02,0x40,0x01,0x80,0x02,0xb0,0x01,0x80};
 FILE *f=fopen("program.bin","rb");assert(f);assert(fseek(f,0x10acc,SEEK_SET)==0);uint8_t got[24];assert(fread(got,1,sizeof(got),f)==sizeof(got));fclose(f);
 for(unsigned i=0;i<24;i++)assert(got[i]==sig[i]);
 for(unsigned i=0;i<6;i++){assert(arcade_rumble_raw_positions[i].x==((unsigned)sig[i*4]<<8|sig[i*4+1]));assert(arcade_rumble_raw_positions[i].y==((unsigned)sig[i*4+2]<<8|sig[i*4+3]));}
 puts("PASS Test115: ROM $10ACC exposes the exact six raw Royal Rumble opening anchors");
}
