#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arcade_action_map.h"
int main(void){
 FILE *f=fopen("program.bin","rb");assert(f);uint8_t *rom=malloc(0x80000);assert(rom);assert(fread(rom,1,0x80000,f)==0x80000);fclose(f);
 const uint8_t e0b8[]={0x22,0x68,0x00,0x7a,0x08,0x28,0x00,0x01,0x00,0x34};
 const uint8_t cat5[]={0x0c,0x29,0x00,0x08,0x00,0x65};
 const uint8_t e110[]={0x22,0x68,0x00,0x7a,0x08,0x28,0x00,0x01,0x00,0x34};
 const uint8_t split[]={0x0c,0x69,0x00,0x00,0x00,0x70};
 assert(!memcmp(rom+0xe0b8,e0b8,sizeof e0b8));assert(!memcmp(rom+0xe0ec,cat5,sizeof cat5));
 assert(!memcmp(rom+0xe110,e110,sizeof e110));assert(!memcmp(rom+0xe158,split,sizeof split));
 assert(arcade_prone_category_raw(0,0,0,4,8,0)==5);assert(arcade_prone_category_raw(0,1,0,4,6,123)==5);
 assert(arcade_prone_category_raw(0,0,0,4,9,0)==6);assert(arcade_prone_category_raw(0,1,0,4,7,0)==6);
 assert(arcade_prone_category_raw(0,0,0,4,9,1)==7);assert(arcade_prone_category_raw(0,1,0,4,7,0xffff)==7);
 assert(arcade_prone_category_raw(2,0,0,4,8,0)<0);assert(arcade_prone_category_raw(0,2,0,4,8,0)<0);
 assert(arcade_prone_category_raw(0,0,1,4,8,0)<0);assert(arcade_prone_category_raw(0,0,0,3,8,0)<0);assert(arcade_prone_category_raw(0,0,0,4,5,0)<0);
 free(rom);puts("PASS Test75: ROM $E0B8/$E110 exact raw classifier distinguishes prone categories $05/$06/$07");
}
