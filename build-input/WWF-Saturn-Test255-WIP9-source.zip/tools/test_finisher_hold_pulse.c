#include "finisher_data.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void at(const uint8_t *rom,size_t off,const uint8_t *p,size_t n){assert(!memcmp(rom+off,p,n));}
int main(void){
 FILE *f=fopen("program.bin","rb");assert(f);assert(!fseek(f,0,SEEK_END));long sz=ftell(f);assert(sz==524288L);rewind(f);
 uint8_t *rom=malloc((size_t)sz);assert(rom&&fread(rom,1,(size_t)sz,f)==(size_t)sz);fclose(f);
 /* Sgt. Slaughter $17ECE and Ted DiBiase $179C0: MOVE.w #$0005,+$68(A2), followed by JSR $111C8. */
 static const uint8_t pulse[]={0x35,0x7c,0x00,0x05,0x00,0x68,0x4e,0xb9,0x00,0x01,0x11,0xc8};
 at(rom,0x17ece,pulse,sizeof pulse);at(rom,0x179c0,pulse,sizeof pulse);free(rom);
 assert(finisher_hold_pulse_damage_exact(6)&&finisher_hold_pulse_damage(6)==5);
 assert(finisher_hold_pulse_damage_exact(9)&&finisher_hold_pulse_damage(9)==5);
 for(unsigned ch=0;ch<10;ch++)if(ch!=6&&ch!=9){assert(!finisher_hold_pulse_damage_exact(ch));assert(finisher_hold_pulse_damage(ch)==0);}
 puts("PASS Test145: Cobra Clutch and Million Dollar Dream callbacks carry an exact 5-point hold pulse; total/repeat semantics remain unclaimed");
 return 0;
}
