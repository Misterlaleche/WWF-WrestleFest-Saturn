#include <assert.h>
#include <stdio.h>
#include "game.h"
#include "arcade_moves.h"
static const unsigned roster[6]={0,2,7,1,4,5};
static void prep(game_t *g){game_match_start(g,GAME_TAG,roster);g->cpu=false;fighter_t *p=&g->fighters[0],*q=&g->fighters[1];p->x=120*256;p->y=210*256;p->state=ST_IDLE;p->cooldown=0;q->x=155*256;q->rise_y=210*256;q->y=q->rise_y;q->state=ST_RECOVER;q->tick=30;}
int main(void){game_t g;prep(&g);game_tick(&g,0,INPUT_KICK);assert(g.pair==PAIR_PIN&&g.pin_attacker==0);prep(&g);game_tick(&g,0,INPUT_PUNCH);assert(g.pair!=PAIR_PIN);prep(&g);game_tick(&g,0,INPUT_PUNCH|INPUT_KICK);assert(g.pair!=PAIR_PIN&&g.fighters[0].state==ST_GROUND_PICKUP&&g.fighters[0].current_move==AMOVE_PICK_UP);puts("PASS Test74+214: live ground K enters pin; Hogan P+K follows exact category-$05 action $22 PICK UP");}
