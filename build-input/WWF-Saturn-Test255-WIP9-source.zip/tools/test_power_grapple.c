#include "game.h"
#include <assert.h>
#include <stdio.h>
static const unsigned roster[6]={0,2,7,1,4,5};
int main(void){
 game_t g;game_match_start(&g,GAME_TAG,roster);g.cpu=false;
 g.fighters[0].x=120*256;g.fighters[1].x=160*256;g.fighters[0].y=g.fighters[1].y=200*256;
 g.fighters[0].facing=1;g.fighters[1].facing=-1;
 /* A powered intended victim steals ownership immediately. */
 g.fighters[1].power_up=true;game_tick(&g,0,INPUT_GRAB);
 assert(g.pair==PAIR_HOLD&&g.pair_attacker==1);
 /* A powered current owner cannot be reversed by an unpowered opponent. */
 for(unsigned i=0;i<70;i++)game_tick(&g,0,INPUT_GRAB);
 assert(g.pair_attacker==1);
 /* When both are powered, the initiator keeps normal ownership. */
 game_match_start(&g,GAME_TAG,roster);g.cpu=false;
 g.fighters[0].x=120*256;g.fighters[1].x=160*256;g.fighters[0].y=g.fighters[1].y=200*256;
 g.fighters[0].facing=1;g.fighters[1].facing=-1;g.fighters[0].power_up=g.fighters[1].power_up=true;
 game_tick(&g,0,INPUT_GRAB);assert(g.pair==PAIR_HOLD&&g.pair_attacker==0);
 puts("PASS: Power Up wins grapple ownership and blocks unpowered reversals");
}