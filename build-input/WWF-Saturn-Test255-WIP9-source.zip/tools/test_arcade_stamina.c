#include "arcade_stamina.h"
#include "game.h"
#include <assert.h>
#include <stdio.h>

int main(void){
 static const unsigned ids[10]={0,7,2,8,6,9,1,3,10,11};
 static const unsigned maximum[10]={110,104,98,100,106,96,106,102,104,96};
 for(unsigned i=0;i<10;i++){
  assert(arcade_stamina_internal_id(i)==ids[i]);
  assert(arcade_stamina_human_max(i)==maximum[i]);
  assert(arcade_stamina_tier(maximum[i],maximum[i])==0);
  assert(arcade_stamina_tier(24,maximum[i])==2);
  assert(arcade_stamina_tier(25,maximum[i])==(25<=2*(maximum[i]/3)?1:0));
 }

 assert(arcade_difficulty_from_raw_dip(2)==ARCADE_DIFFICULTY_EASY);
 assert(arcade_difficulty_from_raw_dip(3)==ARCADE_DIFFICULTY_NORMAL);
 assert(arcade_difficulty_from_raw_dip(1)==ARCADE_DIFFICULTY_HARD);
 assert(arcade_difficulty_from_raw_dip(0)==ARCADE_DIFFICULTY_HARDEST);
 assert(arcade_stamina_cpu_max(0,false,0)==115);
 assert(arcade_stamina_cpu_max(0,true,0)==100);
 assert(arcade_stamina_cpu_max(9,false,1)==185);
 assert(arcade_stamina_cpu_max(9,false,2)==215);
 assert(arcade_stamina_cpu_max(9,false,3)==230);
 assert(arcade_clear_stage_restore(0)==24&&arcade_clear_stage_restore(1)==32);
 assert(arcade_clear_stage_restore(2)==12&&arcade_clear_stage_restore(3)==0);
 assert(arcade_stamina_low_warning(23)&&!arcade_stamina_low_warning(24));
 unsigned roster[6]={0,1,2,3,4,5}; game_t g;game_match_start(&g,GAME_TAG,roster);g.cpu=false;
 assert(g.fighters[0].health==110&&g.fighters[0].max_health==110);
 assert(g.fighters[1].health==115&&g.fighters[1].max_health==115);
 assert(g.fighters[2].health==98&&g.fighters[3].health==100); /* stage0 secondary CPU = 115-15 */
 g.fighters[0].health=70;g.fighters[1].health=90;g.fighters[2].health=60;g.fighters[3].health=70;game_clear_stage_restore(&g,0);
 assert(g.fighters[0].health==94&&g.fighters[2].health==84);
 assert(g.fighters[1].health==90&&g.fighters[3].health==70);
 game_clear_stage_restore(&g,1);assert(g.fighters[0].health==110&&g.fighters[2].health==98);
 assert(g.fighters[1].health==90&&g.fighters[3].health==70);
 game_match_start_arcade(&g,GAME_TAG,roster,9,ARCADE_DIFFICULTY_HARDEST);
 assert(g.fighters[1].health==230&&g.fighters[3].health==215);
 game_match_start_arcade(&g,GAME_TAG,roster,0,ARCADE_DIFFICULTY_NORMAL);g.cpu=false;
 g.fighters[0].health=100;for(unsigned i=0;i<256;i++)game_tick(&g,0,0);assert(g.fighters[0].health==100);
 game_match_start_arcade(&g,GAME_RUMBLE,roster,9,ARCADE_DIFFICULTY_HARDEST);
 assert(g.fighters[0].health==110);for(unsigned i=1;i<6;i++)assert(g.fighters[i].health==ARCADE_RUMBLE_CPU_STAMINA);g.cpu=false;
 g.fighters[0].health=100;g.fighters[0].display_health=110;g.fighters[0].stamina_tier=arcade_stamina_tier(100,110);
 game_tick(&g,0,0);assert(g.fighters[0].display_health==108);
 for(unsigned i=0;i<4;i++)game_tick(&g,0,0);assert(g.fighters[0].display_health==100);
 /* Restart the exact natural-recovery cadence after the display-only ticks. */
 g.fighters[0].stamina_recovery=0;
 for(unsigned i=0;i<127;i++)game_tick(&g,0,0);
 assert(g.fighters[0].health==100&&g.fighters[0].stamina_recovery==127);
 game_tick(&g,0,0);assert(g.fighters[0].health==101&&g.fighters[0].stamina_recovery==0);
 for(unsigned i=0;i<128*20;i++)game_tick(&g,0,0);
 assert(g.fighters[0].health==110&&g.fighters[0].stamina_recovery==0);
 puts("PASS: ROM stamina tables, CPU formula, clear-stage restore and Rumble-only +1/128 recovery gate");
}
