#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
int main(void){FILE*f=fopen("program.bin","rb");assert(f);fseek(f,0,SEEK_END);long ln=ftell(f);rewind(f);size_t n=(size_t)ln;unsigned char*r=malloc(n);assert(r&&fread(r,1,n,f)==n);fclose(f);assert(n>0x10718);
 int16_t v[8];for(int i=0;i<8;i++)v[i]=(int16_t)((r[0x10708+i*2]<<8)|r[0x10709+i*2]);
 assert(v[0]==0x240&&v[1]==0x150&&v[2]==0x220&&v[3]==0x160);assert(v[4]==0x2c0&&v[5]==0x150&&v[6]==0x2e0&&v[7]==0x160);
 assert(v[2]-v[0]==-0x20&&v[3]-v[1]==0x10);assert(v[6]-v[4]==0x20&&v[7]-v[5]==0x10);
 free(r);puts("PASS Test93: TAG pair start table $10708 places reserves 0x20 outward in X and +0x10 Y from their active pair member");return 0;}
