#include <assert.h>
#include <stdio.h>
#include "game.h"
#include "arcade_moves.h"
#include "arcade_action_map.h"
int main(void){
 unsigned r[6]={0,2,1,3,4,5}; game_t g; game_match_start(&g,GAME_TAG,r); g.cpu=false;
 fighter_t *p=&g.fighters[0],*q=&g.fighters[1];
 p->character=0; /* Hogan: ROM category $05, both physical buttons -> action $22. */
 assert(arcade_action_for_buttons(p->character,5,3)==0x22);
 p->x=120*256;p->y=200*256;p->state=ST_IDLE;p->cooldown=0;
 q->x=150*256;q->rise_y=200*256;q->y=217*256;q->state=ST_RECOVER;q->tick=24;q->health=80;
 game_tick(&g,0,INPUT_PUNCH|INPUT_KICK);
 assert(p->state==ST_GROUND_PICKUP);assert(p->current_move==AMOVE_PICK_UP);
 for(unsigned i=0;i<18;i++)game_tick(&g,0,0);
 assert(q->state==ST_RISE);
 /* Jake's category-$05 both-button result is raw $09, not $22: do not fabricate PICK UP. */
 assert(arcade_action_for_buttons(2,5,3)==0x09);
 puts("PASS Test214: ROM prone category-$05 both-button action $22 reaches human PICK UP without inventing a third cabinet button");
}
