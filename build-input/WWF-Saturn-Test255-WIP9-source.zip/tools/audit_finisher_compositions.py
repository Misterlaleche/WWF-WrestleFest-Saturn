#!/usr/bin/env python3
"""Recover exact pair metadata/command coverage for mapped finishers.

Requires only the user's assembled main program to recover pair relationships;
with --sprites it also validates every referenced sprite code against the
assembled sprite region.  It does not write WFC2 banks, making this a safe
preflight before the bank expander materializes original attacker/victim art.
"""
from pathlib import Path
import argparse,hashlib,json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import arcade_composition as comp
from plan_finisher_assets import FINISHERS,ROOT

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--program',type=Path,required=True)
 ap.add_argument('--sprites',type=Path)
 a=ap.parse_args();comp.load_program(a.program)
 sprite_size=a.sprites.stat().st_size if a.sprites else None
 rows=[]
 for f in FINISHERS:
  fr=[]
  for pose in f['poses']:
   meta=comp.pair_metadata(f['character'],pose)
   variants=[]
   for partner in range(10):
    if partner==f['character']:continue
    cmds=comp.commands(f['character'],pose,partner=partner)
    banks={}
    for c in cmds:banks[c['bank']]=banks.get(c['bank'],0)+1
    variants.append(dict(partner=partner,commands=len(cmds),commands_by_bank=banks,
                         offset=(meta['offsets'][partner] if meta and meta['kind']==2 else None)))
   fr.append(dict(pose=pose,pair=meta,variants=variants))
  rows.append(dict(character=f['character'],name=f['name'],descriptor=f['descriptor'],frames=fr))
 out=dict(program_sha256=hashlib.sha256(a.program.read_bytes()).hexdigest(),sprite_size=sprite_size,
          finishers=rows)
 (ROOT/'docs/finisher-composition-audit.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps(out,indent=2))
if __name__=='__main__':main()
