#include "game.h"
#include "arcade_stamina.h"
#include <assert.h>
#include <stdio.h>
static void setup(game_t*g,unsigned cpu_ch){unsigned r[6]={0,cpu_ch,2,3,4,5};game_match_start_arcade(g,GAME_TAG,r,0,ARCADE_DIFFICULTY_NORMAL);g->fighters[0].x=40*256;g->fighters[0].y=180*256;g->fighters[1].x=220*256;g->fighters[1].y=180*256;g->fighters[0].state=ST_IDLE;g->fighters[1].state=ST_IDLE;g->fighters[1].cooldown=0;g->ticks=1;}
int main(void){game_t g;
 setup(&g,4);game_tick(&g,0,0);assert(g.fighters[1].state==ST_RUN); /* roll=2 <= Smash far weight 35 */
 setup(&g,6);game_tick(&g,0,0);assert(g.fighters[1].state!=ST_RUN); /* roll=16 > Slaughter far weight 10 */
 puts("PASS: Test133 live CPU far-run entry uses exact wrestler-specific arcade weights; native far band/RNG remain provisional");}
