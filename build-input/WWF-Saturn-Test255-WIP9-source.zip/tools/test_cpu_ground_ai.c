#include "game.h"
#include "arcade_moves.h"
#include <assert.h>
#include <stdio.h>
static const unsigned r[6]={0,2,7,1,4,5};
static void prep(game_t *g,unsigned cpu_ch,unsigned hp,unsigned tier,unsigned serial,unsigned ticks){game_match_start(g,GAME_TAG,r);g->cpu=true;g->ticks=ticks;fighter_t *p=&g->fighters[0],*q=&g->fighters[1];q->character=cpu_ch;q->attack_serial=serial;p->health=hp;p->stamina_tier=tier;p->state=ST_RECOVER;p->tick=30;p->rise_y=200*256;p->y=217*256;p->x=140*256;q->x=180*256;q->y=200*256;q->cooldown=0;}
int main(void){
 game_t g;
 /* choice 1/2 -> wrestler-specific ground drop */prep(&g,0,45,1,1,60);game_tick(&g,0,0);assert(g.fighters[1].state==ST_GROUND_ATTACK);assert(g.fighters[1].current_move==(unsigned)arcade_move_set(0)->ground_drop);
 /* choice 0 + weakened target -> submission */prep(&g,7,45,1,2,60);game_tick(&g,0,0);assert(g.pair==PAIR_SUBMISSION&&g.pair_attacker==1);assert(g.pair_move==(unsigned)arcade_move_set(7)->ground_submission);
 /* Zero stamina always remains a pin priority. */prep(&g,4,0,2,2,60);game_tick(&g,0,0);assert(g.pair==PAIR_PIN&&g.pin_attacker==1);
 puts("PASS: TAG CPU chooses wrestler-specific ground drops/submissions and still prioritises zero-stamina covers");
}