#include "arcade_moves.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
int main(void){
 assert(!strcmp(arcade_move_name(arcade_move_set(0)->grapple[3]),"SUPLEX"));
 assert(arcade_move_set(1)->grapple[3]==AMOVE_GORILLA_PRESS);
 assert(arcade_move_set(2)->grapple[3]==AMOVE_DDT);
 assert(arcade_move_set(3)->anti_running[1]==AMOVE_BOSS_MAN_SLAM);
 assert(arcade_move_set(4)->grapple[3]==AMOVE_SUPLEX);
 assert(arcade_move_set(5)->grapple[3]==AMOVE_SHOULDER_BREAKER);
 assert(arcade_move_submission(arcade_move_set(6)->grapple[3]));
 assert(arcade_move_set(7)->grapple[3]==AMOVE_PERFECT_PLEX);
 assert(arcade_move_set(8)->diagonal==AMOVE_VERTICAL_SPLASH);
 assert(arcade_move_submission(arcade_move_set(9)->grapple[3]));
 for(unsigned ch=0;ch<10;ch++){
  assert(arcade_grapple_select(ch,0,0,false)==arcade_move_set(ch)->grapple[0]);
  assert(arcade_grapple_select(ch,0,1,false)==arcade_move_set(ch)->grapple[1]);
  assert(arcade_grapple_select(ch,1,0,false)==arcade_move_set(ch)->grapple[2]);
  assert(arcade_grapple_select(ch,2,1,false)==arcade_move_set(ch)->grapple[3]);
  assert(arcade_running_select(ch,0)==arcade_move_set(ch)->running[0]);
  assert(arcade_running_select(ch,2)==arcade_move_set(ch)->running[1]);
 }
 puts("PASS: ten-character arcade move catalog and stamina-tier grapple/running selectors");
}
