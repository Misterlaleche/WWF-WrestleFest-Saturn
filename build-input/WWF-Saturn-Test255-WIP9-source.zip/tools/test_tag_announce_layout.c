#include "presentation.h"
#include <assert.h>
#include <stdio.h>
int main(void){unsigned order[4];for(unsigned i=0;i<4;i++)order[i]=tag_announce_fighter(i);assert(order[0]==2&&order[1]==3&&order[2]==0&&order[3]==1);assert(tag_announce_x(2)<tag_announce_x(0)&&tag_announce_x(3)>tag_announce_x(1));assert(tag_announce_y(2)<tag_announce_y(0)&&tag_announce_y(3)<tag_announce_y(1));puts("PASS Test106: TAG presentation uses rear-reserve-first draw order and separated rear/front anchors matching hardware reference composition");}
