#include "../render_pose.h"
#include <assert.h>
#include <stdio.h>
int main(void){fighter_t f={0};
 for(unsigned raw=0;raw<600;raw++)assert(!render_pose_registered_fallback(&f,raw));
 puts("PASS Test245 scope regression: Test252 audit leaves no legacy Test212 fallback registrations");
}
