#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void seq(const unsigned char*r,size_t n,size_t o,const unsigned char*s,size_t z){assert(o+z<=n);assert(!memcmp(r+o,s,z));}
int main(void){FILE*f=fopen("program.bin","rb");assert(f);fseek(f,0,SEEK_END);long ln=ftell(f);rewind(f);size_t n=(size_t)ln;unsigned char*r=malloc(n);assert(r&&fread(r,1,n,f)==n);fclose(f);
 const unsigned char retarget[]={0x21,0x69,0x00,0x86,0x00,0x7a,0x61,0x00,0xf8,0x34};seq(r,n,0x1c9ec,retarget,sizeof retarget);
 const unsigned char resolve[]={0x4e,0xb9,0x00,0x01,0x0b,0xe8,0x24,0x68,0x00,0x7a};seq(r,n,0x1c9f6,resolve,sizeof resolve);
 const unsigned char restrain[]={0x08,0x2a,0x00,0x06,0x00,0x33,0x67,0x7a,0x08,0xe8,0x00,0x05,0x00,0xb6,0x42,0x68,0x00,0x20};seq(r,n,0x1ca00,restrain,sizeof restrain);
 free(r);puts("PASS Test91: CPU state-1 branch retargets through current target +$86, tests paired target +$33 bit6 (Restrain flag), sets actor +$B6 bit5 and resets actor raw +$20");return 0;}
