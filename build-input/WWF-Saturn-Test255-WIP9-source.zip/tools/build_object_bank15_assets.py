#!/usr/bin/env python3
"""Build ROM-exact object-use compositions for raw poses 114..123.

Evidence source:
- program.bin: sprite composition tables and the palette-loader table at 0x2f22.
- gfx2.bin: exact 8 MiB sprite region reconstructed from the eight original gfx ROMs.

The generated OBJ15.PAK keeps the original piece order for all ten wrestlers and
all ten object poses.  Palette selection is not flattened into the wrestler
palette: object_assets.h records a run-length stream of the original palette
bank byte for every frame.  Bank 15 is emitted separately as OBJECT15.PAL.
"""
from pathlib import Path
import hashlib,json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import arcade_composition as comp
import build_exact_ground_assets as common

ROOT=Path(__file__).resolve().parents[1]
PROGRAM=ROOT/'program.bin'
GFX=ROOT/'gfx2.bin'
POSES=list(range(114,124))
PALETTE_TABLE=0x2F22
PALETTE_BANK=15
PALETTE_OFFSET=PALETTE_TABLE+PALETTE_BANK*32
PROGRAM_SHA256='265ac89deeb7e708ac6fda724356bfd6af1c9012928a4e551e6e2faa424c2306'
GFX_SHA256='a3b5e1fedd6c41cd398ba0cb437cddb2f50b3ae0a0dc178a10b70a7ed5d010ba'

def rgb444_to_rgb555(v):
 r=v&15;g=(v>>4)&15;b=(v>>8)&15
 r=(r<<1)|(r>>3);g=(g<<1)|(g>>3);b=(b<<1)|(b>>3)
 return 0x8000|(b<<10)|(g<<5)|r

def main():
 p=PROGRAM.read_bytes();g=GFX.read_bytes()
 assert hashlib.sha256(p).hexdigest()==PROGRAM_SHA256
 assert hashlib.sha256(g).hexdigest()==GFX_SHA256
 # ROM $2B26: LEA $00002F22,A3.  The following code masks the bank to 8 bits,
 # shifts it by five, adds it to A3, clears color 0 and copies 15 source words.
 assert p[0x2B26:0x2B2C]==bytes.fromhex('47 f9 00 00 2f 22')
 assert p[0x2B2C:0x2B36]==bytes.fromhex('02 80 00 00 00 ff eb 88 d7 c0')
 src=[int.from_bytes(p[PALETTE_OFFSET+i*2:PALETTE_OFFSET+i*2+2],'big') for i in range(16)]
 # First source word is also zero; on arcade hardware color 0 is explicitly
 # cleared by the loader.  Saturn VDP1 treats pixel index 0 as transparent.
 assert src[0]==0
 pal555=[rgb444_to_rgb555(v) for v in src]
 pal_bytes=b''.join(v.to_bytes(2,'big') for v in pal555)
 (ROOT/'assets'/'OBJECT15.PAL').write_bytes(pal_bytes)

 comp.load_program(PROGRAM);tile=common.make_tile_decoder()
 frames=[];textures=[];lookup={};runs={};report_frames=[];required_mask=0
 for ch in range(10):
  for pose in POSES:
   meta=comp.pair_metadata(ch,pose)
   assert meta and meta['kind']!=2
   pieces=comp.commands(ch,pose,partner=(ch+1)%10)
   assert pieces
   rec=[];rr=[];last=None;banks=[]
   for q in pieces:
    bank=q['bank'];assert 0<=bank<16
    required_mask|=1<<bank;banks.append(bank)
    px=tile(q['code'])
    if px not in lookup:lookup[px]=len(textures);textures.append(px)
    rec.append([lookup[px],*common.geom(q)])
    if last==bank:rr[-1][1]+=1
    else:rr.append([bank,1]);last=bank
   # Every object pose must actually contain bank-15 prop pixels/commands.
   assert PALETTE_BANK in banks
   frame=len(frames);frames.append(rec);runs[frame]=rr
   report_frames.append(dict(character=ch,pose=pose,frame=frame,pieces=len(rec),
                             banks={str(b):banks.count(b) for b in sorted(set(banks))},runs=rr))

 # The recovered set uses wrestler palette banks 0..9 plus the dedicated
 # object bank 15, and nothing from the unresolved 10..14 range.
 assert required_mask & ~(((1<<10)-1)|(1<<15)) == 0
 data=common.pack(frames,textures,32)
 pack_path=ROOT/'cd'/'OBJ15.PAK';pack_path.write_bytes(data)
 pack_hash=common.fnv(data)
 aligned=(len(data)+2047)&~2047

 out=['#ifndef WWF_OBJECT_ASSETS_H','#define WWF_OBJECT_ASSETS_H','#include <stdint.h>',
      'typedef struct {uint8_t palette,count;} object_run_t;',
      f'#define OBJECT_PALETTE_BANK {PALETTE_BANK}U',
      f'#define OBJECT_PALETTE_SOURCE_OFFSET 0x{PALETTE_OFFSET:08X}U',
      f'#define OBJECT_REQUIRED_PALETTE_MASK 0x{required_mask:04X}U',
      f'#define OBJECT_PACK_FRAMES {len(frames)}U',
      f'#define OBJECT_PACK_BYTES {len(data)}U',
      f'#define OBJECT_PACK_ALIGNED_BYTES {aligned}U',
      f'#define OBJECT_PACK_HASH {pack_hash}U',
      'static inline unsigned object_asset_frame(unsigned ch,unsigned pose){',
      ' if(ch>=10U||pose<114U||pose>123U)return 0xffffU;',
      ' return ch*10U+(pose-114U);','}']
 for fr in range(len(frames)):
  rr=runs[fr]
  out.append(f'static const object_run_t object_runs_{fr}[]={{'+','.join('{%d,%d}'%tuple(x) for x in rr)+'};')
 out.append('static inline const object_run_t *object_asset_runs(unsigned frame,unsigned *count){')
 out.append(' switch(frame){')
 for fr in range(len(frames)):
  out.append(f' case {fr}U:*count={len(runs[fr])}U;return object_runs_{fr};')
 out += [' default:*count=0;return 0;',' }','}','#endif']
 (ROOT/'object_assets.h').write_text('\n'.join(out)+'\n')

 report=dict(test=252,version='V0.267',classification='ROM-EXACT',
  program_sha256=PROGRAM_SHA256,gfx2_sha256=GFX_SHA256,
  palette_loader=dict(code_offset='0x2b26',table='0x2f22',bank=15,source_offset='0x3102'),
  palette_rgb444=[f'{v:03x}' for v in src],palette_rgb555=[f'{v:04x}' for v in pal555],
  object_palette_sha256=hashlib.sha256(pal_bytes).hexdigest(),
  object_pack_bytes=len(data),object_pack_aligned_bytes=aligned,object_pack_fnv1a=pack_hash,
  object_pack_sha256=hashlib.sha256(data).hexdigest(),frames=len(frames),textures=len(textures),
  records=sum(len(x) for x in frames),max_pieces=max(map(len,frames)),required_palette_mask=f'0x{required_mask:04x}',
  frames_detail=report_frames,
  note='Complete visible/object composition retains original per-piece palette-bank ordering; bank 15 is never recolored with the wrestler palette.')
 (ROOT/'docs'/'test252-bank15-object-build.json').write_text(json.dumps(report,indent=2)+'\n')
 print(f'PASS Test252 object build: {len(frames)} frames, {len(textures)} tiles, {len(data)} bytes, bank15 @ 0x{PALETTE_OFFSET:x}, mask 0x{required_mask:04x}')

if __name__=='__main__':main()
