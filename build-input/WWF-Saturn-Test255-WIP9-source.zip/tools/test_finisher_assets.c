#include "finisher_assets.h"
#include "roster_data.h"
#include "roster_pack.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
static unsigned be16(const unsigned char *p){return ((unsigned)p[0]<<8)|p[1];}
static unsigned pop(unsigned x){unsigned n=0;while(x){n+=x&1U;x>>=1;}return n;}
static unsigned frame_count(const unsigned char *data,unsigned frame){return be16(data+34+frame*4);}
static unsigned fnv(const unsigned char *p,unsigned n){unsigned h=2166136261U;while(n--)h=(h^*p++)*16777619U;return h;}
int main(void){
 assert(ROSTER_FRAMES==207);unsigned core_worst=0;
 for(unsigned mask=0;mask<(1U<<10);mask++)if(pop(mask)==6){unsigned total=0;for(unsigned ch=0;ch<10;ch++)if(mask&(1U<<ch))total+=(roster_bytes[ch]+2047U)&~2047U;if(total>core_worst)core_worst=total;}
 assert(core_worst==915456U);
 unsigned max_overlay=0;
 for(unsigned ch=0;ch<10;ch++){
  char name[32];sprintf(name,"cd/F%02u.PAK",ch);FILE *f=fopen(name,"rb");assert(f);unsigned bytes=finisher_overlay_bytes[ch];unsigned char *data=malloc(bytes);assert(data);assert(fread(data,1,bytes,f)==bytes);fclose(f);assert(fnv(data,bytes)==finisher_overlay_hash[ch]);
  roster_pack_t p;assert(roster_pack_open(&p,data,bytes,finisher_overlay_frames[ch]));assert(p.block_tiles==32);if(bytes>max_overlay)max_overlay=bytes;
  for(unsigned frame=0;frame<p.frames;frame++){unsigned n=0,total=0;const finisher_run_t *runs=finisher_asset_runs(ch,frame,&n);assert(runs&&n);for(unsigned i=0;i<n;i++){assert(runs[i].role<=1&&runs[i].count);total+=runs[i].count;}assert(total==frame_count(data,frame));}
  free(data);
 }
 assert(max_overlay==FINISHER_OVERLAY_MAX_BYTES);assert(core_worst+((max_overlay+2047U)&~2047U)<=1048576U);
 for(unsigned ch=0;ch<10;ch++){unsigned phases=finisher_asset_phase_count(ch);assert(phases);for(unsigned p=0;p<phases;p++){unsigned f=finisher_asset_frame(ch,ch,p);if(finisher_asset_pair(ch))assert(f==0xffffU);else assert(f<finisher_overlay_frames[ch]);}}
 assert(finisher_asset_frame(5,4,0)==0xffffU);
 printf("PASS: ten on-demand overlays, 207-frame compact core, mixed 16/32-tile WFC2 compatibility and %u-byte worst core + %u-byte max overlay fit standard LWRAM\n",core_worst,max_overlay);return 0;
}
