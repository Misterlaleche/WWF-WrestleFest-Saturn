#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void seq(long o,const uint8_t*p,size_t n){FILE*f=fopen("program.bin","rb");assert(f);uint8_t*b=malloc(n);assert(b);assert(fseek(f,o,SEEK_SET)==0&&fread(b,1,n,f)==n);fclose(f);assert(!memcmp(b,p,n));free(b);}
int main(void){
 const uint8_t p[]={0x30,0x3c,0x31,0x09,0x0c,0x79,0x00,0x04,0x00,0x1c,0x01,0x62,0x67,0x0e,0x0c,0x79,0x00,0x09,0x00,0x1c,0x01,0x62,0x67,0x04,0x30,0x3c,0x31,0x05};seq(0x20156,p,sizeof p);
 puts("PASS Test176: $20156 selects raw effect $3109 only for global +$1C0162 values 4 or 9, otherwise $3105");return 0;}
