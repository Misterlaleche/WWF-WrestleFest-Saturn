#include "arcade_attract_bio.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static uint16_t be16(const uint8_t*p){return (uint16_t)((p[0]<<8)|p[1]);}
int main(void){FILE*f=fopen("program.bin","rb");assert(f);uint8_t*b=malloc(0x8eb8);assert(b);assert(fread(b,1,0x8eb8,f)==0x8eb8);fclose(f);
 /* $8D6C-$8D98: text 6, then state-2+7, then state-2+$40. */
 const uint8_t textprefix[]={0x30,0x3c,0x00,0x06,0x4e,0xb9,0x00,0x02,0x50,0x3c,0x30,0x39,0x00,0x1c,0x01,0x66,0x04,0x40,0x00,0x02,0x06,0x40,0x00,0x07};
 assert(!memcmp(b+0x8d6c,textprefix,sizeof textprefix));
 /* $8DD2: table lookup $8E9A; +$30 composition set. $8DEC subtracts $20 => palette $10+id. */
 const uint8_t portrait[]={0x32,0x39,0x00,0x1c,0x01,0x66,0xe3,0x41,0x43,0xf9,0x00,0x00,0x8e,0x9a,0x31,0x71,0x10,0x00,0x00,0x02,0x06,0x68,0x00,0x30,0x00,0x02};
 assert(!memcmp(b+0x8dd2,portrait,sizeof portrait));
 /* $8E02/$8E3E: pose2 at $0100, remove at $0200; random reload = (rng&$f)+8. */
 const uint8_t force2[]={0x0c,0x79,0x01,0x00,0x00,0x1c,0x00,0x82,0x65,0x06,0x31,0x7c,0x00,0x02,0x00,0x04};assert(!memcmp(b+0x8e02,force2,sizeof force2));
 const uint8_t remove[]={0x0c,0x79,0x02,0x00,0x00,0x1c,0x00,0x82,0x65,0x50};assert(!memcmp(b+0x8e3e,remove,sizeof remove));
 for(unsigned st=2;st<14;st++){arcade_attract_bio_desc_t d;assert(arcade_attract_bio_desc(st,&d));unsigned ch=be16(b+0x8e9a+st*2);assert(d.character==ch&&d.composition_set==0x30+ch&&d.character_palette==0x10+ch&&d.common_palette==0x1e);assert(d.text_ids[0]==6&&d.text_ids[1]==7+st-2&&d.text_ids[2]==0x40+st-2);}
 arcade_attract_bio_desc_t h,a;assert(arcade_attract_bio_desc(10,&h)&&h.character==10&&h.composition_set==0x3a);assert(arcade_attract_bio_desc(11,&a)&&a.character==11&&a.composition_set==0x3b);
 free(b);puts("PASS Test255: biography text selectors, portrait sets/palettes, $0100 pose2 and $0200 removal policy match ROM");return 0;}
