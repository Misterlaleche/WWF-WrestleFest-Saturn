#include "arcade_rumble.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
int main(void){
 FILE *f=fopen("program.bin","rb");assert(f);uint8_t sig[36];assert(fseek(f,0xbb80,SEEK_SET)==0);assert(fread(sig,1,sizeof(sig),f)==sizeof(sig));fclose(f);
 /* Actor loop starts at $1C05B0 and tests +$56 bit5 before balancing pools. */
 assert(sig[0]==0x41&&sig[1]==0xf9&&sig[2]==0x00&&sig[3]==0x1c&&sig[4]==0x05&&sig[5]==0xb0);
 assert(arcade_rumble_preferred_pool(3,2)==1);assert(arcade_rumble_preferred_pool(2,3)==0);assert(arcade_rumble_preferred_pool(2,2)==0);
 unsigned rolls[4]={0,0,0,0};uint16_t used=0;
 /* lower preferred on tie: first random hit is ID 0. */
 assert(arcade_rumble_select_entrant(used,2,2,rolls)==0);
 /* Four collisions on ID0 fall back to highest free lower ID, matching reverse scan. */
 used=1U<<0;assert(arcade_rumble_select_entrant(used,2,2,rolls)==5);
 /* If lower pool is full, fall back to upper and apply the +6 identity offset. */
 used=0x003fU;assert(arcade_rumble_select_entrant(used,2,2,rolls)==6);
 /* Fewer upper-half actors makes upper preferred. */
 assert(arcade_rumble_select_entrant(0,4,1,rolls)==6);
 puts("PASS Test118: $BB80/$BC00 pool balancing and four-try + reverse-scan entrant selection are modeled");
}
