#include <assert.h>
#include <stdio.h>
#include "arcade_action_map.h"
int main(void){for(unsigned s=0;s<12;++s){assert(arcade_action_stationary(s,1)==0x00);assert(arcade_action_stationary(s,2)==0x72);assert(arcade_action_stationary(s,3)==0xff);}puts("PASS Test73: stationary category 0 is button1=$00 button2=$72 P+K=$FF for all wrestlers");}
