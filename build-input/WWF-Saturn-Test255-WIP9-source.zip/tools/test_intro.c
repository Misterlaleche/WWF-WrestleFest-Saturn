#include "intro.h"
#include "intro_data.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static uint32_t hash(const uint8_t *p,size_t n)
{
    uint32_t h=2166136261U;while(n--)h=(h^*p++)*16777619U;return h;
}
int main(int argc,char **argv)
{
    intro_t state;intro_reset(&state);assert(state.screen==INTRO_WARNING);
    for(unsigned i=0;i<100;i++)assert(!intro_tick(&state,true));
    assert(state.screen==INTRO_WARNING); /* Held during boot is not a skip. */
    unsigned visible=0;
    for(unsigned i=0;i<60;i++){visible+=intro_prompt_visible(&state);assert(!intro_tick(&state,false));}
    assert(visible==0); /* No PRESS START on the three legal/company plates. */
    for(unsigned next=INTRO_LEGAL;next<=INTRO_GAME;next++) {
        assert(intro_tick(&state,true));assert(state.screen==next&&state.blink==0);
        for(unsigned i=0;i<60;i++)assert(!intro_tick(&state,true));
        assert(state.screen==next);assert(!intro_tick(&state,false));
        visible=0;for(unsigned i=0;i<60;i++){visible+=intro_prompt_visible(&state);assert(!intro_tick(&state,false));}
        assert(visible==(next==INTRO_TITLE?42U:0U));
    }
    assert(!intro_prompt_visible(&state));
    for(unsigned i=0;i<10000;i++)assert(!intro_tick(&state,(i&1)!=0));
    assert(state.screen==INTRO_GAME);
    assert(!state.demo);
    intro_reset(&state);
    for(unsigned screen=INTRO_WARNING;screen<=INTRO_TITLE;screen++){
        unsigned limit=screen==INTRO_TITLE?INTRO_TITLE_TICKS:INTRO_PLATE_TICKS;
        for(unsigned i=1;i<limit;i++){assert(!intro_tick(&state,false));assert(state.screen==screen);}
        assert(intro_tick(&state,false));assert(state.screen==screen+1&&state.elapsed==0);
    }
    assert(state.demo&&state.screen==INTRO_GAME);
    intro_reset(&state);state.screen=INTRO_TITLE;state.elapsed=INTRO_TITLE_TICKS-1;state.start_down=false;
    assert(intro_tick(&state,true)&&!state.demo); /* START wins on timeout frame. */
    puts("PASS: 3.5-second plates, 20-second title, fresh START skips, no legal prompts, attract timeout and START priority");

    uint8_t raw[]={2,10,20,30,0x82,40,0,50};
    uint8_t small[9];memset(small,0xaa,sizeof(small));
    assert(intro_unpack(raw,sizeof(raw),small+1,7));
    assert(small[0]==0xaa&&small[8]==0xaa);
    const uint8_t expected[]={10,20,30,40,40,40,50};assert(!memcmp(small+1,expected,7));
    assert(!intro_unpack(raw,sizeof(raw),small+1,6));
    assert(!intro_unpack(raw,sizeof(raw),small+1,8));
    assert(!intro_unpack(raw,sizeof(raw)-1,small+1,7));
    assert(!intro_unpack(raw+4,1,small+1,7));
    assert(!intro_unpack(NULL,1,small,9));assert(!intro_unpack(raw,1,NULL,9));

    FILE *f=fopen("assets/INTRO.RLE","rb");assert(f);
    uint8_t *data=malloc(INTRO_DATA_BYTES),*output=malloc(INTRO_BITMAP_BYTES+32);assert(data&&output);
    assert(fread(data,1,INTRO_DATA_BYTES,f)==INTRO_DATA_BYTES);assert(fgetc(f)==EOF);fclose(f);
    assert(hash(data,INTRO_DATA_BYTES)==INTRO_DATA_HASH);
    for(unsigned screen=0;screen<INTRO_GAME;screen++) {
        const intro_asset_t *a=&intro_assets[screen];
        assert(a->offset+a->size<=INTRO_DATA_BYTES && a->palette_offset+512<=INTRO_DATA_BYTES);
        assert(a->palette_offset%4==0);memset(output,0x5a,INTRO_BITMAP_BYTES+32);
        assert(intro_unpack(data+a->offset,a->size,output+16,INTRO_BITMAP_BYTES));
        for(unsigned i=0;i<16;i++)assert(output[i]==0x5a&&output[INTRO_BITMAP_BYTES+16+i]==0x5a);
        assert(hash(output+16,INTRO_BITMAP_BYTES)==a->bitmap_hash);
        assert(hash(data+a->palette_offset,512)==a->palette_hash);
        if(argc==2) {
            char path[1024];snprintf(path,sizeof(path),"%s/intro%u.bin",argv[1],screen);
            f=fopen(path,"wb");assert(f);assert(fwrite(output+16,1,INTRO_BITMAP_BYTES,f)==INTRO_BITMAP_BYTES);fclose(f);
        }
        assert(!intro_unpack(data+a->offset,a->size-1,output+16,INTRO_BITMAP_BYTES));
        assert(!intro_unpack(data+a->offset,a->size,output+16,INTRO_BITMAP_BYTES-1));
        assert(!intro_unpack(data+a->offset,a->size,output+16,INTRO_BITMAP_BYTES+1));
    }
    /* Deterministic malformed input under ASan/UBSan checks both stream bounds. */
    uint32_t random=19;uint8_t fuzz[512];
    for(unsigned trial=0;trial<2000;trial++) {
        for(unsigned j=0;j<sizeof(fuzz);j++){random=random*1664525U+1013904223U;fuzz[j]=(uint8_t)(random>>24);}
        size_t n=trial%sizeof(fuzz),cap=trial%2048;
        uint8_t *guard=malloc(cap?cap:1);assert(guard);intro_unpack(fuzz,n,guard,cap);free(guard);
    }
    free(data);free(output);
    puts("PASS: literal/repeat RLE, malformed streams, all four shipped bitmaps/palettes, DMA alignment, bounded decode");
    return 0;
}
