#!/usr/bin/env python3
from pathlib import Path
import sys,struct,re,itertools,hashlib,json
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
import arcade_composition as comp, lz4_codec
ROOT=Path(__file__).resolve().parents[1]
GFX=ROOT/'gfx2.bin'
NONPAIR=[104,110,111,112,113,395,266,267]
PAIR=[206,207,208,209,210,248,263,264,265,292,293,294,516,517,518,519,520]

def be16(b,o):return int.from_bytes(b[o:o+2],'big')
def be32(b,o):return int.from_bytes(b[o:o+4],'big')
def fnv(data):
 h=2166136261
 for x in data:h=((h^x)*16777619)&0xffffffff
 return h

def unpack(path):
 b=path.read_bytes();assert be32(b,0)==0x57464332
 nf,nr,nt,off,bt,nb=[be32(b,o) for o in (4,8,12,16,24,28)]
 idx=[(be16(b,32+i*4),be16(b,34+i*4)) for i in range(nf)]
 ro=32+nf*4;rec=[list(struct.unpack_from('>HhhH',b,ro+i*8)) for i in range(nr)]
 tex=[]
 for bi in range(nb):
  eo=off+bi*12;pos,stored,raw=be32(b,eo),be32(b,eo+4),be32(b,eo+8)
  chunk=lz4_codec.decompress(b[pos:pos+stored],raw);tex += [chunk[i:i+128] for i in range(0,len(chunk),128)]
 assert len(tex)==nt
 return [[r[:] for r in rec[a:a+n]] for a,n in idx],tex,bt

def pack(frames,textures,bt=32):
 idx=[];rec=[]
 for f in frames:idx.append((len(rec),len(f)));rec.extend(f)
 body=b''.join(struct.pack('>HH',*x) for x in idx)+b''.join(struct.pack('>HhhH',*r) for r in rec)
 off=(32+len(body)+31)&~31;raw=b''.join(textures);chunks=[]
 for first in range(0,len(textures),bt):
  u=b''.join(textures[first:first+bt]);z=lz4_codec.compress(u);assert lz4_codec.decompress(z,len(u))==u;chunks.append((u,z))
 pos=off+len(chunks)*12;d=[];pay=[]
 for u,z in chunks:d.append(struct.pack('>III',pos,len(z),len(u)));pay.append(z);pos+=len(z)
 return struct.pack('>8I',0x57464332,len(frames),len(rec),len(textures),off,fnv(raw),bt,len(chunks))+body+bytes(off-32-len(body))+b''.join(d)+b''.join(pay)

def geom(p):return (155-p['x'],p['y']-150,(int(p['fx'])|(int(p['fy'])<<1))^1)

def make_tile_decoder():
 region=np.frombuffer(GFX.read_bytes(),np.uint8).reshape(4,65536,32);cache={}
 def tile(code):
  if code not in cache:
   bits=np.unpackbits(region[:,code,:],axis=1).reshape(4,2,16,8).transpose(0,2,1,3).reshape(4,16,16)
   px=np.sum(bits*np.array([8,4,2,1],np.uint8)[:,None,None],axis=0,dtype=np.uint8)
   cache[code]=((px[:,::2]<<4)|px[:,1::2]).tobytes()
  return cache[code]
 return tile

def main():
 assert hashlib.sha256(GFX.read_bytes()).hexdigest()=='a3b5e1fedd6c41cd398ba0cb437cddb2f50b3ae0a0dc178a10b70a7ed5d010ba'
 comp.load_program(ROOT/'program.bin');tile=make_tile_decoder();report={'resident':[],'pair':[]}
 # Exact resident actor art. Object poses keep actor bank only; bank15 prop remains separately registered.
 c_sizes=[];c_hash=[];maps={}
 for ch in range(10):
  path=ROOT/'cd'/f'C{ch:02}.PAK';frames,tex,bt=unpack(path);lookup={x:i for i,x in enumerate(tex)};mp={}
  for pose in NONPAIR:
   meta=comp.pair_metadata(ch,pose)
   if not meta or meta['kind']==2:continue
   pcs=[p for p in comp.commands(ch,pose,partner=0 if ch else 1) if p['bank']==ch]
   if not pcs:continue
   rec=[]
   for p in pcs:
    px=tile(p['code'])
    if not any(px):continue
    if px not in lookup:lookup[px]=len(tex);tex.append(px)
    rec.append([lookup[px],*geom(p)])
   if rec:
    fr=len(frames);frames.append(rec);mp[pose]=fr;report['resident'].append([ch,pose,fr,len(rec)])
  data=pack(frames,tex,bt);path.write_bytes(data);c_sizes.append(len(data));c_hash.append(fnv(data));maps[ch]=mp
 # Generate small exact matchup packs Gxy.PAK, loaded only when needed.
 g_bytes=[[0]*10 for _ in range(10)];g_hash=[[0]*10 for _ in range(10)];g_frames=[[0]*10 for _ in range(10)]
 gmap={};gruns={};maxg=0
 for a in range(10):
  for p in range(10):
   if a==p:continue
   frames=[];tex=[];lookup={}
   for pose in PAIR:
    meta=comp.pair_metadata(a,pose)
    if not meta or meta['kind']!=2:continue
    pcs=[q for q in comp.commands(a,pose,partner=p) if q['bank'] in (a,p)]
    if not pcs:continue
    rec=[];runs=[];last=None
    for q in pcs:
     role=0 if q['bank']==a else 1;px=tile(q['code'])
     if not any(px):continue
     if px not in lookup:lookup[px]=len(tex);tex.append(px)
     rec.append([lookup[px],*geom(q)])
     if last==role:runs[-1][1]+=1
     else:runs.append([role,1]);last=role
    if rec:
     fr=len(frames);frames.append(rec);gmap[(a,p,pose)]=fr;gruns[(a,p,fr)]=runs;report['pair'].append([a,p,pose,fr,len(rec),runs])
   if frames:
    data=pack(frames,tex,32);name=f'G{a}{p}.PAK';(ROOT/'cd'/name).write_bytes(data)
    g_bytes[a][p]=len(data);g_hash[a][p]=fnv(data);g_frames[a][p]=len(frames);maxg=max(maxg,len(data))
 # Update roster header sizes/hashes/mapping.
 h=(ROOT/'roster_data.h').read_text();maxframes=max(len(unpack(ROOT/'cd'/f'C{i:02}.PAK')[0]) for i in range(10))
 h=re.sub(r'#define ROSTER_FRAMES \d+',f'#define ROSTER_FRAMES {maxframes}',h)
 h=re.sub(r'static const unsigned roster_bytes\[10\]=\{.*?\};','static const unsigned roster_bytes[10]={'+','.join(map(str,c_sizes))+'};',h)
 h=re.sub(r'static const unsigned roster_hash\[10\]=\{.*?\};','static const unsigned roster_hash[10]={'+','.join(str(x)+'U' for x in c_hash)+'};',h)
 s=h.index('static inline unsigned roster_arcade_frame_character');e=h.index('\n}',s)+2
 lines=['static inline unsigned roster_arcade_frame_character(unsigned ch,unsigned pose){',' switch(ch){']
 oldknown={0:{104:207,112:210,113:211},2:{104:207,110:208,111:209,267:214},3:{267:214},8:{470:212,471:213,267:214}}
 for ch in range(10):
  mp=dict(oldknown.get(ch,{}));mp.update(maps[ch])
  if mp:lines.append(f' case {ch}: switch(pose){{'+''.join(f'case {po}:return {fr};' for po,fr in sorted(mp.items()))+'default:break;} break;')
 lines+=[' default:break;',' }',' return roster_arcade_frame(pose);','}'];h=h[:s]+'\n'.join(lines)+h[e:]
 (ROOT/'roster_data.h').write_text(h)
 # Generated matchup metadata and exact composition runs.
 out=['#ifndef WWF_GROUND_PAIR_ASSETS_H','#define WWF_GROUND_PAIR_ASSETS_H','#include "finisher_assets.h"',f'#define GROUND_PAIR_OVERLAY_MAX_BYTES {maxg}U']
 out.append('static const unsigned ground_pair_bytes[10][10]={'+','.join('{'+','.join(map(str,row))+'}' for row in g_bytes)+'};')
 out.append('static const unsigned ground_pair_hash[10][10]={'+','.join('{'+','.join(str(x)+'U' for x in row)+'}' for row in g_hash)+'};')
 out.append('static const unsigned ground_pair_frames[10][10]={'+','.join('{'+','.join(map(str,row))+'}' for row in g_frames)+'};')
 out.append('static inline unsigned ground_pair_asset_frame(unsigned a,unsigned p,unsigned pose){')
 for (a,p,po),fr in sorted(gmap.items()):out.append(f' if(a=={a}U&&p=={p}U&&pose=={po}U)return {fr}U;')
 out+=[' return 0xffffU;','}','static inline int ground_pair_asset_available(unsigned a,unsigned p,unsigned pose){return ground_pair_asset_frame(a,p,pose)!=0xffffU;}']
 for (a,p,fr),runs in sorted(gruns.items()):out.append(f'static const finisher_run_t gpr_{a}_{p}_{fr}[]={{'+','.join('{%d,%d}'%tuple(r) for r in runs)+'};')
 out.append('static inline const finisher_run_t *ground_pair_asset_runs(unsigned a,unsigned p,unsigned frame,unsigned *count){')
 for (a,p,fr),runs in sorted(gruns.items()):out.append(f' if(a=={a}U&&p=={p}U&&frame=={fr}U){{*count={len(runs)}U;return gpr_{a}_{p}_{fr};}}')
 out+=[' *count=0;return 0;','}','#endif']
 (ROOT/'ground_pair_assets.h').write_text('\n'.join(out)+'\n')
 report.update(dict(gfx2_sha256=hashlib.sha256(GFX.read_bytes()).hexdigest(),resident_frames=maxframes,ground_pair_max_bytes=maxg,ground_pair_files=sum(1 for a in range(10) for p in range(10) if g_bytes[a][p]),ground_pair_exact_frames=len(report['pair']),object_note='poses 114-123 remain unresolved as complete compositions because they mix wrestler bank with bank15 prop/palette; not forced into resident actor art'))
 (ROOT/'docs/test249-250-full-gfx2.json').write_text(json.dumps(report,indent=2)+'\n')
 print('PASS exact asset build',report['resident_frames'],report['ground_pair_files'],report['ground_pair_exact_frames'],maxg)
if __name__=='__main__':main()
