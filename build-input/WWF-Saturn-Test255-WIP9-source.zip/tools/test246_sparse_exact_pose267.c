#include <assert.h>
#include <stdio.h>
#include "../roster_data.h"
int main(void){
 assert(ROSTER_FRAMES==215);
 assert(roster_arcade_frame_character(2,267)==214);
 assert(roster_arcade_frame_character(3,267)==214);
 assert(roster_arcade_frame_character(8,267)==214);
 assert(roster_arcade_frame_character(0,267)==ROSTER_FRAMES);
 puts("PASS Test246: exact raw pose267 is resident for Jake, Boss Man and Earthquake only");
 return 0;
}
