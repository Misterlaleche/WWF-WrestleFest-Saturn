#include <assert.h>
#include <stdio.h>
#include "../ground_pair_assets.h"

static void roles(unsigned ch,unsigned partner,unsigned pose){
 unsigned frame=ground_pair_asset_frame(ch,partner,pose),n=0;assert(frame!=0xffffU);
 const finisher_run_t *r=finisher_asset_runs(ch,frame,&n);assert(r&&n);
 unsigned seen=0;for(unsigned i=0;i<n;i++){assert(r[i].count);seen|=1U<<r[i].role;}
 assert((seen&3U)==3U); /* exact composition contains attacker + victim */
}
int main(void){
 for(unsigned p=0;p<10;p++)if(p!=1){roles(1,p,263);roles(1,p,264);}
 for(unsigned p=0;p<10;p++)if(p!=9)roles(9,p,248);
 assert(ground_pair_asset_frame(1,0,265)==0xffffU);
 assert(ground_pair_asset_frame(9,0,292)==0xffffU);
 assert(ground_pair_asset_frame(0,1,263)==0xffffU);
 puts("PASS Test238: Warrior 263/264 and DiBiase 248 use exact opponent-specific Fxx compositions with both role runs; unresolved poses remain guarded");
 return 0;
}
