#include "game.h"
#include "arcade_moves.h"
#include "pair_rules.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static int draw_index(const game_t *g,unsigned layer) {
 unsigned order[8],n=game_draw_order(g,order);assert(n<=8);
 int found=-1;
 for(unsigned i=0;i<n;i++)if(order[i]==layer){assert(found==-1);found=(int)i;}
 return found;
}
static void ticks(game_t *g,int n,unsigned held) {while(n-->0)game_tick(g,held,0);}
static void ready(game_t *g,int dx,int dy) {game_reset(g);g->fighters[0].y=180*256;g->fighters[0].x=120*256;g->fighters[1].x=(120+dx)*256;g->fighters[1].y=(180+dy)*256;}
static void punch(game_t *g) {game_tick(g,0,INPUT_PUNCH);ticks(g,45,0);}
static void pin_ready(game_t *g,unsigned hp) {
 ready(g,60,0);g->fighters[1].health=hp;
 g->fighters[1].state=hp?ST_RECOVER:ST_DOWN;
 g->fighters[1].tick=hp?0:12;g->fighters[1].rise_y=180*256;
 g->fighters[1].y=197*256;
}
static void cpu_pin_ready(game_t *g,unsigned hp,int dir) {
 game_reset(g);g->cpu=true;
 fighter_t *h=&g->fighters[0],*j=&g->fighters[1];
 h->x=160*256;h->rise_y=170*256;h->y=(170+HULK_PRONE_Y)*256;
 h->health=hp;h->state=hp?ST_RECOVER:ST_DOWN;h->tick=24;h->facing=-dir;
 j->x=(160-dir*50)*256;j->y=170*256;j->facing=dir;
 game_tick(g,0,0);assert(g->pair==PAIR_PIN&&g->pin_attacker==1);
}
static void escape(game_t *g,unsigned count) {
 for(unsigned n=0;n<count;n++) {
  game_tick(g,0,n%2?INPUT_KICK:INPUT_PUNCH);game_tick(g,0,0);
 }
}
int main(void) {
 game_t g;
 ready(&g,40,0);punch(&g);assert(g.hits[0]==1&&g.fighters[1].health==80);
 ticks(&g,100,INPUT_PUNCH);assert(g.hits[0]==1); /* Holding is not a new press. */
 ready(&g,70,0);punch(&g);assert(g.hits[0]==0);
 ready(&g,-40,0);punch(&g);assert(g.hits[0]==0);
 ready(&g,40,16);punch(&g);assert(g.hits[0]==0);
 ready(&g,40,0);game_tick(&g,0,INPUT_PUNCH);ticks(&g,5,0);assert(g.hits[0]==0);game_tick(&g,0,0);assert(g.hits[0]==1);
 ready(&g,40,0);g.paused=true;punch(&g);assert(g.ticks==0&&g.fighters[0].state==ST_IDLE);g.paused=false;punch(&g);assert(g.hits[0]==1);
 game_reset(&g);ticks(&g,2000,INPUT_LEFT|INPUT_UP);assert(g.fighters[0].x==10*256&&g.fighters[0].y==RING_TOP*256);
 ticks(&g,2000,INPUT_RIGHT|INPUT_DOWN);assert(g.fighters[0].x==286*256&&g.fighters[0].y==RING_BOTTOM*256);
 ready(&g,40,0);ticks(&g,200,INPUT_RIGHT);assert(g.fighters[1].x-g.fighters[0].x>=28*256);
 ready(&g,40,0);ticks(&g,200,INPUT_UP|INPUT_RIGHT);assert(g.fighters[0].x>g.fighters[1].x); /* Passing on another depth is allowed. */
 ready(&g,40,0);
 for(int i=0;i<5;i++){g.fighters[0].x=g.fighters[1].x-40*256;punch(&g);}
 assert(!g.finished&&g.fighters[1].state==ST_DOWN&&g.hits[0]==5);
 ticks(&g,150,0);assert(game_pose(&g.fighters[1])==9);
 game_reset(&g);g.cpu=true;ticks(&g,2500,0);assert(g.finished&&g.winner==1&&g.hits[1]==3&&g.pair==PAIR_PIN&&g.pin_count==3);
 ready(&g,40,0);g.fighters[0].health=g.fighters[1].health=20;
 for(int i=0;i<2;i++){g.fighters[i].state=ST_PUNCH;g.fighters[i].tick=5;}
 game_tick(&g,0,0);assert(g.finished&&g.winner==-1&&g.hits[0]==1&&g.hits[1]==1);
 game_reset(&g);assert(!g.finished&&!g.cpu&&!g.paused&&g.fighters[0].health==100&&g.fighters[1].health==100);
 ready(&g,60,0);game_tick(&g,0,INPUT_KICK);ticks(&g,50,0);assert(g.hits[0]==1&&g.fighters[1].health==75);
 ready(&g,60,0);punch(&g);assert(g.hits[0]==0);
 ready(&g,72,0);game_tick(&g,0,INPUT_KICK);ticks(&g,50,0);assert(g.hits[0]==0);
 ready(&g,-40,0);game_tick(&g,0,INPUT_KICK);ticks(&g,50,0);assert(g.hits[0]==0);
 ready(&g,40,14);game_tick(&g,0,INPUT_KICK);ticks(&g,50,0);assert(g.hits[0]==0);
 ready(&g,60,0);game_tick(&g,0,INPUT_KICK);ticks(&g,9,0);assert(g.hits[0]==0);game_tick(&g,0,0);assert(g.hits[0]==1);
 ticks(&g,100,INPUT_KICK);assert(g.hits[0]==1);
 ready(&g,-40,0);game_tick(&g,INPUT_LEFT,INPUT_KICK);assert(g.fighters[0].facing==-1);ticks(&g,50,0);assert(g.hits[0]==1);
 ready(&g,80,0);game_tick(&g,0,INPUT_PUNCH);ticks(&g,27,0);game_tick(&g,0,INPUT_KICK);ticks(&g,6,0);
 assert(g.fighters[0].state==ST_KICK&&g.fighters[0].tick==0&&g.fighters[0].queued_attack==0);
 ready(&g,80,0);game_tick(&g,0,INPUT_PUNCH);game_tick(&g,0,INPUT_KICK);ticks(&g,60,0);assert(g.fighters[0].state==ST_IDLE);
 ready(&g,80,0);game_tick(&g,0,INPUT_PUNCH);ticks(&g,28,INPUT_LEFT);assert(g.fighters[0].state==ST_WALK&&g.fighters[0].x<120*256);
 ready(&g,40,0);game_tick(&g,0,INPUT_PUNCH|INPUT_KICK);assert(g.fighters[0].state==ST_KICK);
 ready(&g,40,0);g.fighters[0].state=ST_PUNCH;g.fighters[0].tick=5;g.fighters[1].state=ST_KICK;g.fighters[1].tick=9;
 game_tick(&g,0,0);assert(g.fighters[0].health==75&&g.fighters[1].health==80); /* Preserve both pre-hit attack types. */
 ready(&g,40,0);g.fighters[0].state=ST_HIT;game_tick(&g,0,INPUT_KICK);ticks(&g,50,0);assert(g.hits[0]==0&&g.fighters[0].queued_attack==0);
 ready(&g,80,0);g.freeze=2;game_tick(&g,0,INPUT_KICK);assert(g.fighters[0].queued_attack==INPUT_KICK);ticks(&g,2,0);assert(g.fighters[0].state==ST_KICK);
 ready(&g,60,0);
 for(int i=0;i<4;i++){g.fighters[0].x=g.fighters[1].x-60*256;game_tick(&g,0,INPUT_KICK);ticks(&g,60,0);}
 assert(!g.finished&&g.fighters[1].state==ST_DOWN&&g.hits[0]==4);
 puts("PASS: Test02 regressions plus kick range/damage/startup, new facing, late buffer, expiry, recovery movement, simultaneous attack types, hit-stun and hit-stop inputs");
 /* Paired hold/throw rules and Test03 regressions above use the same engine. */
 ready(&g,60,0);game_tick(&g,0,INPUT_GRAB);assert(g.pair==PAIR_HOLD&&game_pair_pose(&g)==0);
 int gx=g.fighters[0].x,gy=g.fighters[0].y;
 ticks(&g,20,INPUT_LEFT|INPUT_DOWN);assert(g.fighters[0].x==gx&&g.fighters[0].y==gy);
 g.paused=true;unsigned tick=g.pair_tick;game_tick(&g,0,INPUT_PUNCH);assert(g.pair==PAIR_HOLD&&g.pair_tick==tick);g.paused=false;
 game_tick(&g,0,INPUT_PUNCH);assert(g.pair==PAIR_THROW&&game_pair_pose(&g)==1);
 ticks(&g,55,0);assert(g.hits[0]==0&&g.fighters[1].health==100);
 game_tick(&g,0,INPUT_PUNCH|INPUT_KICK|INPUT_GRAB);assert(g.hits[0]==1&&g.fighters[1].health==100-arcade_move_native_damage(AMOVE_BODY_SLAM));
 ticks(&g,31,INPUT_RIGHT);assert(g.pair==PAIR_THROW&&game_pair_pose(&g)==44);
 game_tick(&g,0,0);assert(g.pair==PAIR_NONE&&g.fighters[1].state==ST_RECOVER&&game_pose(&g.fighters[1])==9);
 assert(g.fighters[1].x==gx+73*256&&g.fighters[1].y==gy+17*256);
 ticks(&g,RECOVER_PRONE_TICKS-1,0);assert(game_pose(&g.fighters[1])==9);ticks(&g,1,0);assert(g.fighters[1].state==ST_RISE&&game_pose(&g.fighters[1])==JAKE_RISE_POSE_0&&g.fighters[1].y==gy);
 ticks(&g,RISE_TICKS,0);assert(g.fighters[1].state==ST_IDLE&&!g.finished&&g.hits[0]==1);
 ready(&g,-60,0);g.fighters[0].x=200*256;g.fighters[1].x=140*256;game_tick(&g,INPUT_LEFT,INPUT_GRAB);assert(g.pair==PAIR_HOLD&&g.fighters[0].facing==-1);
 gx=g.fighters[0].x;game_tick(&g,0,INPUT_PUNCH);ticks(&g,88,0);assert(g.fighters[1].x==gx-73*256&&g.hits[0]==1);
 ready(&g,65,0);game_tick(&g,0,INPUT_GRAB);assert(g.pair==PAIR_NONE);
 ready(&g,60,9);game_tick(&g,0,INPUT_GRAB);assert(g.pair==PAIR_NONE);
 ready(&g,-60,0);game_tick(&g,0,INPUT_GRAB);assert(g.pair==PAIR_NONE);
 ready(&g,60,0);g.fighters[1].state=ST_PUNCH;game_tick(&g,0,INPUT_GRAB);assert(g.pair==PAIR_NONE);
 ready(&g,60,0);g.fighters[0].state=ST_HIT;game_tick(&g,0,INPUT_GRAB);assert(g.pair==PAIR_NONE);
 ready(&g,60,0);g.fighters[0].cooldown=2;game_tick(&g,0,INPUT_GRAB);assert(g.pair==PAIR_NONE);
 ready(&g,60,0);g.fighters[0].y=g.fighters[1].y=RING_BOTTOM*256;game_tick(&g,0,INPUT_GRAB);assert(g.pair==PAIR_HOLD&&g.fighters[0].y==(RING_BOTTOM-17)*256);
 ready(&g,60,0);g.fighters[0].x=210*256;g.fighters[1].x=270*256;game_tick(&g,0,INPUT_GRAB);assert(g.pair==PAIR_HOLD&&g.fighters[0].x==(game_ring_right(180)-73)*256);
 ready(&g,60,0);game_tick(&g,0,INPUT_GRAB);game_tick(&g,0,INPUT_KICK|INPUT_PUNCH);assert(g.pair==PAIR_NONE&&g.hits[0]==0);
 ticks(&g,100,0);assert(g.hits[0]==0&&g.fighters[0].queued_attack==0);
 ready(&g,60,0);game_tick(&g,0,INPUT_GRAB);ticks(&g,120,0);assert(g.pair==PAIR_NONE&&g.hits[0]==0);
 ready(&g,60,0);g.cpu=true;game_tick(&g,0,INPUT_GRAB);ticks(&g,25,0);assert(g.pair==PAIR_HOLD&&g.hits[1]==0);
 game_tick(&g,0,INPUT_PUNCH);ticks(&g,88,0);assert(g.hits[1]==0);g.cpu=false;
 ready(&g,60,0);g.fighters[1].health=20;g.fighters[1].stamina_tier=2;game_tick(&g,0,INPUT_GRAB);game_tick(&g,0,INPUT_PUNCH);ticks(&g,88,0);
 assert(!g.finished&&g.fighters[1].state==ST_DOWN&&game_pose(&g.fighters[1])==9);
 ticks(&g,180,0);assert(g.fighters[1].state==ST_DOWN&&g.hits[0]==1);
 game_reset(&g);assert(g.pair==PAIR_NONE&&!g.pair_impact&&!g.finished&&game_pair_pose(&g)==-1);
 puts("PASS: Test05-R1 grab conditions, both directions, locked movement, pause, exact-once landing damage, release/timeout, CPU, recovery and KO");
 pin_ready(&g,65);game_tick(&g,0,INPUT_PIN);assert(g.pair==PAIR_PIN&&game_pair_clip(&g)==3&&game_pair_anchor(&g)==1);
 assert(game_pair_pose(&g)==0);gx=g.fighters[0].x;gy=g.fighters[1].y;
 ticks(&g,PIN_SETUP_TICKS,INPUT_LEFT|INPUT_UP);assert(game_pair_pose(&g)==3&&g.pin_count==0&&g.fighters[0].x==gx&&g.fighters[1].y==gy);
 ticks(&g,PIN_COUNT_TICKS-1,0);assert(g.pin_count==0);game_tick(&g,0,0);assert(g.pin_count==1);
 g.paused=true;tick=g.pair_tick;ticks(&g,100,INPUT_KICK);assert(g.pair_tick==tick&&g.pair==PAIR_PIN);g.paused=false;
 ticks(&g,17,0);assert(g.pair==PAIR_PIN);game_tick(&g,0,INPUT_PUNCH|INPUT_PIN);
 assert(g.pair==PAIR_NONE&&g.pin_message==PIN_MSG_KICKOUT&&!g.finished&&g.fighters[1].health==65&&g.hits[0]==0);
 assert(g.fighters[1].state==ST_RISE&&g.fighters[1].y==180*256);
 ticks(&g,RISE_TICKS,0);assert(g.fighters[1].state==ST_IDLE);
 pin_ready(&g,30);game_tick(&g,0,INPUT_PIN);ticks(&g,PIN_SETUP_TICKS+2*PIN_COUNT_TICKS,0);assert(g.pin_count==2&&g.pair==PAIR_PIN);
 ticks(&g,18,0);assert(g.pair==PAIR_NONE&&!g.finished&&g.pin_message==PIN_MSG_KICKOUT);
 for(unsigned hp=0;hp<=20;hp+=20) {
  pin_ready(&g,hp);game_tick(&g,0,INPUT_PIN);ticks(&g,PIN_SETUP_TICKS+3*PIN_COUNT_TICKS-1,0);assert(!g.finished&&g.pin_count==2);
  game_tick(&g,0,0);assert(g.finished&&g.winner==0&&g.pin_count==3&&g.pair==PAIR_PIN);
  tick=g.pair_tick;ticks(&g,200,INPUT_RIGHT|INPUT_KICK);assert(g.finished&&g.pin_count==3&&g.pair_tick==tick);
 }
 pin_ready(&g,21);game_tick(&g,0,INPUT_PIN);ticks(&g,200,0);assert(!g.finished&&g.pin_count==2);
 pin_ready(&g,50);game_tick(&g,0,INPUT_PIN);ticks(&g,100,0);assert(g.pair==PAIR_PIN&&g.pin_count==1);
 pin_ready(&g,51);game_tick(&g,0,INPUT_PIN);ticks(&g,100,0);assert(g.pair==PAIR_NONE&&g.pin_count==1);
 pin_ready(&g,30);game_tick(&g,0,INPUT_PIN);game_tick(&g,0,INPUT_KICK);assert(g.pair==PAIR_NONE&&g.pin_message==PIN_MSG_RELEASED&&!g.finished&&g.fighters[1].health==30);
 assert(!g.fighters[0].queued_attack&&!g.fighters[1].queued_attack);
 game_tick(&g,0,INPUT_PIN);assert(g.pair==PAIR_NONE); /* No renewed ground timer through cancellation. */
 pin_ready(&g,0);game_tick(&g,0,INPUT_PIN);game_tick(&g,0,INPUT_KICK);assert(g.fighters[1].state==ST_DOWN&&!g.finished);
 ticks(&g,20,0);game_tick(&g,0,INPUT_PIN);assert(g.pair==PAIR_PIN);
 pin_ready(&g,30);g.fighters[0].x=250*256;g.fighters[1].x=190*256;g.fighters[1].facing=1;
 game_tick(&g,0,INPUT_PIN);assert(g.pair==PAIR_PIN&&g.fighters[0].facing==-1);
 pin_ready(&g,30);g.fighters[0].x=42*256;game_tick(&g,0,INPUT_PIN);assert(g.pair==PAIR_NONE);
 pin_ready(&g,30);g.fighters[0].y=145*256;game_tick(&g,0,INPUT_PIN);assert(g.pair==PAIR_NONE);
 pin_ready(&g,30);g.fighters[1].state=ST_IDLE;game_tick(&g,0,INPUT_PIN);assert(g.pair==PAIR_NONE);
 pin_ready(&g,30);g.fighters[1].tick=RECOVER_PRONE_TICKS;game_tick(&g,0,INPUT_PIN);assert(g.pair==PAIR_NONE);
 pin_ready(&g,0);g.fighters[1].tick=11;game_tick(&g,0,INPUT_PIN);assert(g.pair==PAIR_NONE);
 pin_ready(&g,30);g.fighters[0].state=ST_PUNCH;game_tick(&g,0,INPUT_PIN);assert(g.pair==PAIR_NONE);
 pin_ready(&g,30);g.fighters[0].x=230*256;g.fighters[1].x=278*256;game_tick(&g,0,INPUT_PIN);assert(g.pair==PAIR_PIN&&g.fighters[1].x==(game_ring_right(180)-PIN_MAX_X)*256);
 pin_ready(&g,0);g.cpu=true;game_tick(&g,0,INPUT_PIN);ticks(&g,200,0);assert(g.finished&&g.winner==0&&g.hits[1]==0);
 game_reset(&g);assert(g.pair==PAIR_NONE&&g.pin_count==0&&g.pin_message==0&&!g.finished);
 /* End-to-end: a depleted opponent is coverable after the actual body slam. */
 ready(&g,60,0);g.fighters[1].health=20;game_tick(&g,0,INPUT_GRAB);game_tick(&g,0,INPUT_PUNCH);ticks(&g,88,0);
 assert(!g.finished&&g.fighters[1].health==0);ticks(&g,20,0);game_tick(&g,0,INPUT_PIN);assert(g.pair==PAIR_PIN);
 ticks(&g,PIN_SETUP_TICKS+3*PIN_COUNT_TICKS,0);assert(g.finished&&g.winner==0);
 puts("PASS: Test05-R1 cover eligibility/orientation, count boundaries, high/medium/low-health escapes, pause, cancellation, no automatic player KO win, reset and slam-to-pin victory");
 /* Complete original walk cycle, with no idle pose inside the moving loop. */
 game_reset(&g);fighter_t *j=&g.fighters[1];j->state=ST_WALK;
 unsigned phases[4]={0};
 for(unsigned t=1;t<=44;t++){j->walk_tick=t;unsigned pose=game_pose(j);assert(pose>=1&&pose<=4);phases[pose-1]++;}
 assert(phases[0]==12&&phases[1]==10&&phases[2]==12&&phases[3]==10);
 j->walk_tick=45;assert(game_pose(j)==1);
 pin_ready(&g,65);game_tick(&g,0,INPUT_PIN);ticks(&g,PIN_SETUP_TICKS+PIN_COUNT_TICKS+18,0);
 assert(g.fighters[1].state==ST_RISE&&g.fighters[0].state==ST_UNCOVER);
 assert(game_pose(&g.fighters[1])==JAKE_RISE_POSE_0&&game_pose(&g.fighters[0])==HULK_UNCOVER_POSE_0);
 int startx=g.fighters[0].x,targetx=g.fighters[0].motion_x1;
 g.paused=true;ticks(&g,60,INPUT_RIGHT);assert(g.fighters[0].x==startx&&g.fighters[1].tick==0);g.paused=false;
 ticks(&g,6,INPUT_RIGHT);assert(game_pose(&g.fighters[0])==HULK_UNCOVER_POSE_1&&g.fighters[0].x<startx&&g.fighters[0].x>targetx);
 ticks(&g,6,0);assert(g.fighters[0].x==targetx&&g.fighters[0].state==ST_IDLE);
 ticks(&g,2,0);assert(game_pose(&g.fighters[1])==JAKE_RISE_POSE_1);
 game_tick(&g,0,INPUT_PIN);assert(g.pair==PAIR_NONE);ticks(&g,13,0);assert(game_pose(&g.fighters[1])==JAKE_RISE_POSE_2);
 ticks(&g,20,0);assert(g.fighters[1].state==ST_IDLE&&game_pose(&g.fighters[1])==0);
 game_reset(&g);g.cpu=true;unsigned seen=0;
 for(unsigned t=0;t<100;t++){game_tick(&g,0,0);if(g.fighters[1].state==ST_WALK)seen|=1u<<game_pose(&g.fighters[1]);}
 assert((seen&30)==30);
 puts("PASS: R1 complete Jake walk phases, full rise sequence, smooth Hogan withdrawal, paused motion and CPU animation");
 /* CPU cover uses its own shared clip, defender anchor and whole-pair facing. */
 for(int dir=-1;dir<=1;dir+=2) {
  cpu_pin_ready(&g,40,dir);
  assert(game_pair_clip(&g)==4&&game_pair_anchor(&g)==0&&game_pair_facing(&g)==dir);
  assert(g.escape_required==8&&game_pair_pose(&g)==0);
  ticks(&g,7,0);assert(game_pair_pose(&g)==0);game_tick(&g,0,INPUT_PUNCH);assert(game_pair_pose(&g)==1&&g.escape_progress==1);
  ticks(&g,6,0);assert(game_pair_pose(&g)==2);ticks(&g,8,0);assert(game_pair_pose(&g)==3&&g.pin_count==0);
  game_tick(&g,0,INPUT_KICK);assert(g.pair==PAIR_PIN&&g.escape_progress==2);
  game_tick(&g,0,INPUT_KICK);assert(g.escape_progress==3); /* A new B press is accepted. */
  game_tick(&g,0,INPUT_PUNCH|INPUT_KICK);assert(g.escape_progress==5&&game_pair_pose(&g)==4);
  ticks(&g,10,INPUT_PUNCH|INPUT_KICK);assert(g.escape_progress==5&&game_pair_pose(&g)==3);
  g.paused=true;tick=g.pair_tick;escape(&g,8);assert(g.pair_tick==tick&&g.escape_progress==5);g.paused=false;
  g.cpu=false;
  escape(&g,3);assert(g.pair==PAIR_NONE&&!g.finished&&g.pin_message==PIN_MSG_HULK_ESCAPED);
  assert(g.fighters[0].health==40&&g.fighters[0].state==ST_RISE&&g.fighters[1].state==ST_UNCOVER);
  assert(g.fighters[0].y==170*256&&game_pose(&g.fighters[0])==HULK_RISE_POSE_0);
  assert(game_pose(&g.fighters[1])==JAKE_UNCOVER_POSE_0);
  assert(!g.fighters[0].queued_attack&&!g.fighters[1].queued_attack);
  ticks(&g,6,0);assert(game_pose(&g.fighters[1])==JAKE_UNCOVER_POSE_1);
  ticks(&g,6,0);assert(g.fighters[1].state==ST_IDLE);
  ticks(&g,1,0);assert(game_pose(&g.fighters[0])==HULK_RISE_POSE_1);
  ticks(&g,14,0);assert(game_pose(&g.fighters[0])==HULK_RISE_POSE_2);
  ticks(&g,20,0);assert(g.fighters[0].state==ST_IDLE);
  /* Input from escape does not leak into a queued attack after standing up. */
  ticks(&g,30,0);assert(g.hits[0]==0&&g.fighters[0].queued_attack==0);
 }
 cpu_pin_ready(&g,20,1);ticks(&g,CPU_PIN_SETUP_TICKS,0);assert(g.escape_required==12);
 escape(&g,10);assert(g.pair==PAIR_PIN&&g.escape_progress==10);escape(&g,2);assert(g.pair==PAIR_NONE&&!g.finished);
 cpu_pin_ready(&g,40,-1);ticks(&g,CPU_PIN_SETUP_TICKS+PIN_COUNT_TICKS-1,0);assert(g.pin_count==0);
 game_tick(&g,0,0);assert(g.pin_count==1);ticks(&g,PIN_COUNT_TICKS,0);assert(g.pin_count==2);
 ticks(&g,PIN_COUNT_TICKS-1,0);assert(!g.finished);game_tick(&g,0,INPUT_KICK);
 assert(g.finished&&g.winner==1&&g.pin_count==3);tick=g.pair_tick;escape(&g,20);assert(g.pair_tick==tick&&g.finished);
 /* Escape just before the third count succeeds; on the third count it is late. */
 for(unsigned late=0;late<2;late++) {
  cpu_pin_ready(&g,40,1);ticks(&g,CPU_PIN_SETUP_TICKS,0);escape(&g,6);game_tick(&g,0,INPUT_PUNCH);
  assert(g.escape_progress==7);
  unsigned target=CPU_PIN_SETUP_TICKS+3*PIN_COUNT_TICKS-2+late;
  while(g.pair_tick<target)game_tick(&g,0,0);
  game_tick(&g,0,INPUT_KICK);
  assert(late?(g.finished&&g.winner==1):(g.pair==PAIR_NONE&&!g.finished));
 }
 cpu_pin_ready(&g,0,1);ticks(&g,CPU_PIN_SETUP_TICKS,0);assert(g.escape_required==0);
 escape(&g,30);assert(g.escape_progress==0&&g.pair==PAIR_PIN&&!g.finished);
 ticks(&g,200,0);assert(g.finished&&g.winner==1);
 game_reset(&g);g.cpu=true;
 while(g.pair!=PAIR_PIN&&g.ticks<600)game_tick(&g,0,0);
 assert(g.pair==PAIR_PIN&&g.hits[1]==3&&g.fighters[0].health==40&&!g.finished);
 /* Two escapes during a real CPU match, then a zero-energy three-count. */
 unsigned covers=0,progress=0;
 for(unsigned n=0;n<2000&&!g.finished;n++) {
  unsigned press=0;
  if(g.pair==PAIR_PIN&&g.pair_tick>=CPU_PIN_SETUP_TICKS&&g.escape_required) {
   press=(progress++%2)?INPUT_KICK:INPUT_PUNCH;
   if(g.escape_progress+1==g.escape_required)covers++;
  }
  game_tick(&g,0,press);
 }
 assert(covers==2&&g.finished&&g.winner==1&&g.hits[1]==5&&g.fighters[0].health==0);
 /* Recovery without CPU coverage, invalid depth, and edge clamps. */
 ready(&g,40,0);g.fighters[0].health=60;g.fighters[1].state=ST_PUNCH;g.fighters[1].tick=5;
 game_tick(&g,0,0);assert(g.fighters[0].state==ST_RECOVER&&g.fighters[0].health==40);
 assert(g.fighters[0].y==205*256&&g.fighters[0].rise_y==180*256);
 ticks(&g,RECOVER_TOTAL_TICKS+10,0);assert(g.fighters[0].state==ST_IDLE&&g.fighters[0].y==180*256);
 for(int dir=-1;dir<=1;dir+=2) {
  for(int x=42;x<=278;x+=236) {
   game_reset(&g);g.cpu=true;g.fighters[0].x=x*256;g.fighters[0].state=ST_RECOVER;g.fighters[0].tick=24;g.fighters[0].facing=-dir;
   g.fighters[0].rise_y=180*256;g.fighters[0].y=205*256;g.fighters[1].x=(x==42?90:230)*256;
   game_tick(&g,0,0);assert(g.pair==PAIR_PIN);
   int px=g.fighters[0].x/256;
   assert(px+(dir>0?CPU_PIN_MIN_X:-CPU_PIN_MAX_X-1)>=-122);
   assert(px+(dir>0?CPU_PIN_MAX_X:-CPU_PIN_MIN_X-1)<=373);
  }
 }
 game_reset(&g);g.cpu=true;g.fighters[0].state=ST_RECOVER;g.fighters[0].tick=24;g.fighters[0].rise_y=145*256;g.fighters[0].y=170*256;
 g.fighters[1].y=200*256;g.fighters[1].x=g.fighters[0].x+40*256;
 game_tick(&g,0,0);assert(g.pair==PAIR_NONE&&g.fighters[1].y<200*256);
 game_reset(&g);g.cpu=true;g.fighters[0].state=ST_RECOVER;g.fighters[0].tick=24;
 g.fighters[0].x=42*256;g.fighters[1].x=250*256;
 game_tick(&g,0,0);assert(g.pair==PAIR_NONE&&g.fighters[1].x<250*256);
 game_reset(&g);assert(!g.finished&&!g.cpu&&g.pair==PAIR_NONE&&g.escape_progress==0&&g.escape_required==0);
 puts("PASS: Test06 CPU knockdown/cover/victory, both orientations and edges, original rise/uncover schedules, alternating fresh inputs, energy tiers, exact count deadlines, pause, AI toggle, reset and full CPU match");
 /* Referee: each count and visual mat contact must share the same tick. */
 for(unsigned who=0;who<2;who++)for(int dir=-1;dir<=1;dir+=2) {
  if(who)cpu_pin_ready(&g,0,dir);
  else {pin_ready(&g,0);g.fighters[1].facing=-dir;game_tick(&g,0,INPUT_PIN);}
  assert(g.referee.covering&&g.referee.slaps==0);
  int rx=g.referee.target_x,ry=g.referee.target_y;
  unsigned setup=who?CPU_PIN_SETUP_TICKS:PIN_SETUP_TICKS;
  for(unsigned t=1;t<=setup+3*PIN_COUNT_TICKS;t++) {
   unsigned previous=g.pin_count;game_tick(&g,0,0);
   assert(g.referee.target_x==rx&&g.referee.target_y==ry);
   if(g.pin_count!=previous) {
    assert(g.referee.slaps==g.pin_count&&game_referee_pose(&g)==REF_POSE_SLAP);
    assert(g.referee.x==rx&&g.referee.y==ry);
   }
   if(t==setup+PIN_COUNT_TICKS-1)assert(g.referee.state==REF_COUNT&&game_referee_pose(&g)==REF_POSE_ARM_UP);
   if(t==setup+PIN_COUNT_TICKS+11)assert(game_referee_pose(&g)==REF_POSE_SLAP);
   if(t==setup+PIN_COUNT_TICKS+12)assert(game_referee_pose(&g)==REF_POSE_ARM_UP);
  }
  assert(g.finished&&g.referee.slaps==3&&g.referee.state==REF_FINISH);
  unsigned pt=g.pair_tick;referee_t frozen=g.referee;
  g.paused=true;ticks(&g,60,0);assert(memcmp(&frozen,&g.referee,sizeof(frozen))==0);g.paused=false;
  ticks(&g,12,0);assert(game_referee_pose(&g)==REF_POSE_KNEEL&&g.pair_tick==pt);
  ticks(&g,12,0);assert(game_referee_pose(&g)==REF_POSE_SIGNAL_START);
  ticks(&g,8,0);assert(game_referee_pose(&g)==REF_POSE_SIGNAL&&g.referee.slaps==3);
  ticks(&g,100,0);assert(game_referee_pose(&g)==REF_POSE_SIGNAL&&g.pair_tick==pt);
 }
 /* All reachable edges, depths and starting sides arrive before count one. */
 for(unsigned who=0;who<2;who++)for(int dir=-1;dir<=1;dir+=2)
 for(int side=0;side<2;side++)for(int depth=RING_TOP;depth<=RING_BOTTOM;depth+=RING_BOTTOM-RING_TOP)
 for(int refside=0;refside<2;refside++) {
  game_reset(&g);g.cpu=who;
  fighter_t *p=&g.fighters[who],*q=&g.fighters[1-who];
  q->x=(side?game_ring_right(depth):game_ring_left(depth))*256;q->health=0;q->state=ST_DOWN;q->tick=24;q->facing=-dir;
  q->rise_y=depth*256;q->y=(depth+(who?HULK_PRONE_Y:17))*256;
  p->x=q->x+(side?-48:48)*256;p->y=depth*256;
  g.referee.x=(refside?318:-66)*256;g.referee.y=RING_BOTTOM*256;
  game_tick(&g,0,who?0:INPUT_PIN);assert(g.pair==PAIR_PIN);
  unsigned setup=who?CPU_PIN_SETUP_TICKS:PIN_SETUP_TICKS;
  for(unsigned t=0;t<setup+PIN_COUNT_TICKS;t++) {
   game_tick(&g,0,0);
   assert(g.referee.x>=-66*256&&g.referee.x<=318*256);
   assert(g.referee.y>=(RING_TOP-10)*256&&g.referee.y<=RING_BOTTOM*256);
  }
  assert(g.pin_count==1&&g.referee.state==REF_COUNT&&g.referee.slaps==1);
  assert(game_referee_pose(&g)==REF_POSE_SLAP);
 }
 /* Cancelling while he approaches must not produce a kneel or phantom slap. */
 pin_ready(&g,30);game_tick(&g,0,INPUT_PIN);assert(g.referee.state==REF_WALK);
 game_tick(&g,0,INPUT_KICK);assert(!g.referee.covering&&g.referee.slaps==0);
 ticks(&g,100,0);assert(g.referee.state==REF_IDLE&&g.referee.x>=-66*256&&g.referee.x<=318*256&&g.referee.y>=(RING_TOP-10)*256&&g.referee.y<=RING_BOTTOM*256);
 /* Cancelling after kneeling stands him up and returns him to live tracking. */
 pin_ready(&g,30);game_tick(&g,0,INPUT_PIN);ticks(&g,PIN_SETUP_TICKS+PIN_COUNT_TICKS,0);
 assert(g.referee.slaps==1);game_tick(&g,0,INPUT_KICK);assert(g.referee.state==REF_RISE);
 ticks(&g,12,0);assert(g.referee.state==REF_WALK);ticks(&g,100,0);assert(g.referee.state==REF_IDLE&&g.referee.slaps==1);
 /* Escape can happen before the first count. No later strike is invented. */
 cpu_pin_ready(&g,40,1);ticks(&g,CPU_PIN_SETUP_TICKS,0);escape(&g,8);
 assert(g.pair==PAIR_NONE&&!g.referee.covering&&g.referee.slaps==0);
 g.cpu=false;ticks(&g,160,0);assert(g.referee.state==REF_IDLE&&g.referee.slaps==0);
 pin_ready(&g,65);game_tick(&g,0,INPUT_PIN);ticks(&g,PIN_SETUP_TICKS+PIN_COUNT_TICKS+18,0);
 assert(g.pin_message==PIN_MSG_KICKOUT&&g.referee.state==REF_RISE&&g.referee.slaps==1);
 /* Pause also freezes approaching and kneeling, not only the count. */
 for(unsigned advance=0;advance<=40;advance+=20) {
  pin_ready(&g,30);game_tick(&g,0,INPUT_PIN);ticks(&g,advance,0);
  referee_t frozen=g.referee;unsigned pt=g.pair_tick;
  g.paused=true;ticks(&g,50,0);assert(memcmp(&frozen,&g.referee,sizeof(frozen))==0&&g.pair_tick==pt);g.paused=false;
 }
 game_reset(&g);g.referee.state=REF_WALK;unsigned counts[4]={0};
 for(unsigned t=1;t<=32;t++){g.referee.walk_tick=t;unsigned pose=game_referee_pose(&g);assert(pose>=REF_POSE_WALK_1&&pose<=REF_POSE_WALK_4);counts[pose-REF_POSE_WALK_1]++;}
 for(unsigned i=0;i<4;i++)assert(counts[i]==8);
 game_reset(&g);assert(g.referee.state==REF_IDLE&&!g.referee.covering&&g.referee.slaps==0&&game_referee_pose(&g)==REF_POSE_IDLE);
 puts("PASS: Test07 exact count/hand contact, three-count signal, early cancellation, player/CPU escapes, all edges and orientations, fixed target, pause, full walk cycle and reset");
 /* R1: the actual A+B gesture must work from the start of a cover. */
 for(int dir=-1;dir<=1;dir+=2) {
  cpu_pin_ready(&g,40,dir);assert(game_escape_prompt_visible(&g));
  int x=game_escape_prompt_x(&g);assert(x==8||x==232);
  for(unsigned i=0;i<4;i++) {
   game_tick(&g,0,INPUT_PUNCH|INPUT_KICK);
   assert(g.escape_progress==2*(i+1)&&g.escape_pulse==8&&game_escape_prompt_pose(&g)==1);
   game_tick(&g,0,0);
  }
  assert(g.pair==PAIR_PIN&&g.escape_progress==8); /* Finish the entry before the get-up. */
  ticks(&g,CPU_PIN_SETUP_TICKS-8,0);assert(g.pair==PAIR_NONE&&g.fighters[0].state==ST_RISE);
  assert(!game_escape_prompt_visible(&g)&&game_pose(&g.fighters[0])==HULK_RISE_POSE_0);
  g.cpu=false;ticks(&g,14,0);assert(game_pose(&g.fighters[0])==HULK_RISE_POSE_1);
  ticks(&g,14,0);assert(game_pose(&g.fighters[0])==HULK_RISE_POSE_2);
  ticks(&g,20,0);assert(g.fighters[0].state==ST_IDLE);
 }
 cpu_pin_ready(&g,20,1);ticks(&g,CPU_PIN_SETUP_TICKS,0);
 for(unsigned i=0;i<5;i++){game_tick(&g,0,INPUT_PUNCH|INPUT_KICK);game_tick(&g,0,0);}
 assert(g.pair==PAIR_PIN&&g.escape_progress==10);
 game_tick(&g,0,INPUT_PUNCH|INPUT_KICK);assert(g.pair==PAIR_NONE);
 cpu_pin_ready(&g,40,1);ticks(&g,CPU_PIN_SETUP_TICKS,0);
 game_tick(&g,0,INPUT_PUNCH|INPUT_KICK);assert(g.escape_progress==2&&game_pair_pose(&g)==4);
 g.paused=true;unsigned pulse=g.escape_pulse;tick=g.pair_tick;ticks(&g,30,0);
 assert(g.escape_pulse==pulse&&g.pair_tick==tick);g.paused=false;
 ticks(&g,8,INPUT_PUNCH|INPUT_KICK);assert(g.escape_progress==2&&g.escape_pulse==0&&game_pair_pose(&g)==3);
 cpu_pin_ready(&g,0,1);assert(!game_escape_prompt_visible(&g));
 for(unsigned i=0;i<10;i++)game_tick(&g,0,INPUT_PUNCH|INPUT_KICK);
 assert(g.escape_progress==0&&g.escape_pulse==0);
 pin_ready(&g,40);game_tick(&g,0,INPUT_PIN);assert(!game_escape_prompt_visible(&g));
 game_reset(&g);assert(!game_escape_prompt_visible(&g)&&g.escape_pulse==0);
 puts("PASS: R1 simultaneous A+B, repeated single presses, held-input exclusion, entry input, animated prompt, effort pulse, complete Hogan get-up and energy limits");
 /* Test08: full ring, integer camera, four corners, dive/miss recovery. */
 for(int c=0;c<4;c++) {
  game_reset(&g);fighter_t *h=&g.fighters[0],*q=&g.fighters[1];
  int y=c<2?RING_TOP:RING_BOTTOM,x=(c&1)?game_ring_right(y):game_ring_left(y);
  h->x=x*256;h->y=y*256;h->rise_y=h->y;
  q->x=(x+((c&1)?-120:120))*256;q->y=(y+(c<2?40:-40))*256;q->rise_y=q->y;
  assert(game_corner_near(h)==c);game_tick(&g,0,INPUT_GRAB);
  assert(h->state==ST_CLIMB&&h->corner==(unsigned)c&&g.pair==PAIR_NONE);
  assert(h->facing==((c&1)?-1:1));
  unsigned poses=0;
  for(unsigned n=0;n<44;n++) {
   unsigned pose=game_pose(h);assert(pose>=HULK_CLIMB_0&&pose<=HULK_CLIMB_4);poses|=1u<<(pose-HULK_CLIMB_0);
   game_tick(&g,INPUT_LEFT|INPUT_DOWN,0);
   int t=n+1<16?(int)n+1:16;assert(h->x==(x*256+((c&1)?32:-32)*256*t/16)&&h->y==y*256);
  }
  assert(poses==31&&h->state==ST_CORNER&&game_pose(h)==HULK_CLIMB_5);
  g.paused=true;game_t frozen=g;ticks(&g,60,INPUT_RIGHT);assert(memcmp(&g,&frozen,sizeof(g))==0);g.paused=false;
  ticks(&g,60,INPUT_PUNCH|INPUT_KICK);assert(h->state==ST_CORNER); /* Fresh edge required. */
  game_tick(&g,0,INPUT_KICK);assert(h->state==ST_DESCEND);
  ticks(&g,44,0);assert(h->state==ST_IDLE&&game_on_floor(h->x/256,h->y/256));
  ticks(&g,20,0);game_tick(&g,0,INPUT_GRAB);ticks(&g,44,0);
  game_tick(&g,0,INPUT_PUNCH);assert(h->state==ST_DIVE&&game_fighter_lift(h)==62);
  int maxlift=0;
  for(unsigned n=0;n<40;n++) {
   int lift=game_fighter_lift(h);if(lift>maxlift)maxlift=lift;
   game_tick(&g,INPUT_LEFT|INPUT_UP,INPUT_PUNCH|INPUT_KICK);
   assert(h->y>=RING_TOP*256&&h->y<=RING_BOTTOM*256);
   assert(h->x>=(game_ring_left(h->y/256)-FIGHTER_SIDE_MARGIN)*256);
   assert(h->x<=(game_ring_right(h->y/256)+FIGHTER_SIDE_MARGIN)*256);
   assert(g.camera_x>=CAMERA_MIN_X&&g.camera_x<=CAMERA_MAX_X&&g.camera_y>=CAMERA_MIN_Y&&g.camera_y<=CAMERA_MAX_Y);
  }
  assert(maxlift>70&&h->state==ST_LAND&&game_fighter_lift(h)==0);
  assert(g.hits[0]==1&&q->health==65&&q->state==ST_RECOVER);
  ticks(&g,40,0);assert(h->state==ST_IDLE&&g.hits[0]==1);
  /* A fresh R after landing can cover the knocked-down target. */
  game_tick(&g,0,INPUT_PIN);assert(g.pair==PAIR_PIN);
 }
 game_reset(&g);g.fighters[0].x=-22*256;g.fighters[0].y=RING_TOP*256;
 game_tick(&g,0,INPUT_GRAB);ticks(&g,44,0);game_tick(&g,INPUT_DOWN,INPUT_PUNCH);
 assert(g.fighters[0].motion_y1==(RING_TOP+65)*256);
 ticks(&g,90,0);assert(g.hits[0]==0&&g.fighters[0].state==ST_IDLE&&g.fighters[1].health==100);
 /* Pause at every new stage freezes action, hit eligibility and camera. */
 for(unsigned stage=0;stage<5;stage++) {
  game_reset(&g);g.fighters[0].x=-22*256;g.fighters[0].y=RING_TOP*256;
  game_tick(&g,0,INPUT_GRAB);
  if(stage){ticks(&g,44,0);if(stage==2)game_tick(&g,0,INPUT_KICK);if(stage>=3){game_tick(&g,0,INPUT_PUNCH);ticks(&g,stage==3?20:40,0);}}
  g.paused=true;game_t frozen=g;
  for(unsigned n=0;n<60;n++)game_tick(&g,INPUT_RIGHT,INPUT_PUNCH|INPUT_GRAB);
  assert(memcmp(&g,&frozen,sizeof(g))==0);
 }
 /* Reach every extremity continuously; camera never changes world position. */
 game_reset(&g);unsigned dirs[4]={INPUT_LEFT|INPUT_UP,INPUT_RIGHT|INPUT_UP,INPUT_RIGHT|INPUT_DOWN,INPUT_LEFT|INPUT_DOWN};
 for(unsigned c=0;c<4;c++)for(unsigned n=0;n<1000;n++) {
  int cx=g.camera_x,cy=g.camera_y;game_tick(&g,dirs[c],0);
  assert(game_on_floor(g.fighters[0].x/256,g.fighters[0].y/256));
  assert(g.camera_x-cx>=-3&&g.camera_x-cx<=3&&g.camera_y-cy>=-3&&g.camera_y-cy<=3);
  assert(g.camera_x>=CAMERA_MIN_X&&g.camera_x<=CAMERA_MAX_X&&g.camera_y>=CAMERA_MIN_Y&&g.camera_y<=CAMERA_MAX_Y);
 }
 assert(g.fighters[0].x==-34*256&&g.fighters[0].y==RING_BOTTOM*256);
 assert(g.camera_x==-114&&g.camera_y==RING_BOTTOM-180);
 /* Whole-pair slams and exit feet remain in the arena near either sloping side. */
 for(int y=RING_TOP;y<=RING_BOTTOM;y+=29)for(int dir=-1;dir<=1;dir+=2) {
  game_reset(&g);fighter_t *h=&g.fighters[0],*q=&g.fighters[1];
  int edge=dir>0?game_ring_right(y):game_ring_left(y);
  q->x=edge*256;h->x=(edge-dir*60)*256;h->facing=dir;q->facing=-dir;h->y=q->y=y*256;
  game_tick(&g,0,INPUT_GRAB);assert(g.pair==PAIR_HOLD);
  game_tick(&g,0,INPUT_PUNCH);ticks(&g,88,0);assert(g.pair==PAIR_NONE&&g.hits[0]==1);
  assert(game_on_floor(h->x/256,h->y/256));
  assert(game_on_floor(q->x/256,q->rise_y/256));
 }
 puts("PASS: Test08 four-corner climb/descend/dive, aim, hit/miss, exact-once damage, cover after dive, paused stages, full trapezoid traversal, camera limits/speed and sloping-edge slams");
 /* R1: the exact painter plan consumed by main.c is checked on the host. */
 game_reset(&g);
 assert(draw_index(&g,DRAW_SIDE_ROPES)<draw_index(&g,DRAW_HULK));
 assert(draw_index(&g,DRAW_SIDE_ROPES)<draw_index(&g,DRAW_JAKE));
 assert(draw_index(&g,DRAW_FRONT_ROPES)>draw_index(&g,DRAW_REFEREE));
 assert(draw_index(&g,DRAW_PAIR)==-1&&draw_index(&g,DRAW_PROMPT)==-1);
 for(unsigned state=ST_CLIMB;state<=ST_DESCEND;state++) {
  g.fighters[0].state=(fighter_state_t)state;
  assert(draw_index(&g,DRAW_HULK)>draw_index(&g,DRAW_FRONT_ROPES));
  assert(draw_index(&g,DRAW_JAKE)>draw_index(&g,DRAW_SIDE_ROPES));
 }
 g.fighters[0].state=ST_DIVE;assert(draw_index(&g,DRAW_HULK)>draw_index(&g,DRAW_SIDE_ROPES));
 /* Both counting orientations and both attackers: referee above the cover,
  * front ropes still above him, then the escape prompt if applicable. */
 for(unsigned who=0;who<2;who++)for(int dir=-1;dir<=1;dir+=2) {
  if(who)cpu_pin_ready(&g,40,dir);
  else {pin_ready(&g,30);g.fighters[1].facing=-dir;game_tick(&g,0,INPUT_PIN);}
  g.referee.y=RING_TOP*256-30*256; /* Shall not override counting priority. */
  for(unsigned state=REF_KNEEL;state<=REF_FINISH;state++) {
   g.referee.state=(referee_state_t)state;
   assert(draw_index(&g,DRAW_PAIR)<draw_index(&g,DRAW_REFEREE));
   assert(draw_index(&g,DRAW_REFEREE)<draw_index(&g,DRAW_FRONT_ROPES));
   assert(draw_index(&g,DRAW_HULK)==-1&&draw_index(&g,DRAW_JAKE)==-1);
   if(who)assert(draw_index(&g,DRAW_PROMPT)>draw_index(&g,DRAW_FRONT_ROPES));
  }
 }
 game_reset(&g);g.referee.state=REF_RISE;
 assert(draw_index(&g,DRAW_REFEREE)>draw_index(&g,DRAW_HULK));
 assert(draw_index(&g,DRAW_REFEREE)>draw_index(&g,DRAW_JAKE));
 g.referee.state=REF_WALK;g.referee.y=150*256;
 assert(draw_index(&g,DRAW_REFEREE)<draw_index(&g,DRAW_HULK));
 g.referee.y=240*256;assert(draw_index(&g,DRAW_REFEREE)>draw_index(&g,DRAW_HULK));
 /* Covers fit as whole compositions at either sloping edge, including entry.
  * Previously only the defender anchor was clamped to the screen-sized map. */
 for(unsigned who=0;who<2;who++)for(int dir=-1;dir<=1;dir+=2)
 for(int y=RING_TOP;y<=RING_BOTTOM;y+=29)for(unsigned side=0;side<2;side++) {
  game_reset(&g);g.cpu=who;
  fighter_t *q=&g.fighters[1-who],*pinner=&g.fighters[who];
  int left=game_ring_left(y),right=game_ring_right(y);
  q->x=(side?right:left)*256;q->y=(y+(who?25:17))*256;q->rise_y=y*256;
  q->state=ST_DOWN;q->health=0;q->tick=24;q->facing=-dir;
  pinner->x=q->x+(side?-48:48)*256;pinner->y=y*256;
  game_tick(&g,0,who?0:INPUT_PIN);assert(g.pair==PAIR_PIN);
  int mn=who?CPU_PIN_MIN_X:PIN_MIN_X,mx=who?CPU_PIN_MAX_X:PIN_MAX_X;
  int a=dir>0?mn:-mx-1,b=dir>0?mx:-mn-1;
  assert(q->x+a*256>=left*256&&q->x+b*256<=right*256);
  ticks(&g,70,0);assert(g.referee.state==REF_COUNT);
  assert(draw_index(&g,DRAW_REFEREE)>draw_index(&g,DRAW_PAIR));
 }
 /* All depths retain a body margin; motion along the edge remains continuous. */
 for(int y=RING_TOP;y<=RING_BOTTOM;y++) {
  int left=-22-44*(y-RING_TOP)/(RING_BOTTOM-RING_TOP),right=252-left;
  assert(game_ring_left(y)==left+32&&game_ring_right(y)==right-32);
  game_reset(&g);g.fighters[0].x=left*256;g.fighters[0].y=y*256;
  game_tick(&g,INPUT_LEFT,0);assert(g.fighters[0].x==(left+32)*256);
  game_reset(&g);g.fighters[0].x=right*256;g.fighters[0].y=y*256;
  game_tick(&g,INPUT_RIGHT,0);assert(g.fighters[0].x==(right-32)*256);
 }
 puts("PASS: Test08-R1 exact painter order, side/front separation, referee above both covers, recovery layering, 40 edge covers and body margin at every floor depth");
 return 0;
}
