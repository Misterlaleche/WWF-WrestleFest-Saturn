#!/usr/bin/env python3
"""Software preview using the actual C block decoder and shipped palette.
Not an emulator/console capture. No generated or substituted artwork.
"""
from pathlib import Path
import ctypes as c
import hashlib,json,struct,subprocess,tempfile
import numpy as np
from PIL import Image,ImageDraw,ImageFont

class Pack(c.Structure):
    _fields_=[('data',c.POINTER(c.c_uint8)),('size',c.c_size_t)]+[(name,c.c_uint32) for name in ['magic','frames','records','tiles','texture_offset','blocks']]
class Entry(c.Structure):
    _fields_=[('owner',c.POINTER(c.c_uint8)),('block',c.c_uint),('bytes',c.c_uint8*2048)]
class Cache(c.Structure):
    _fields_=[('entries',Entry*4),('next',c.c_uint),('decodes',c.c_uint),('hits',c.c_uint)]

def main():
    root=Path(__file__).resolve().parents[1]
    poses=[150,151,152,153,154,155,180,181]
    palette=np.frombuffer((root/'assets/ROSTER.PAL').read_bytes(),dtype='>u2')
    colors=np.stack([(palette&31)*255//31,((palette>>5)&31)*255//31,((palette>>10)&31)*255//31],axis=1).astype(np.uint8)
    backgrounds=(22,26,34)
    sheet=Image.new('RGB',(960,710),backgrounds);draw=ImageDraw.Draw(sheet)
    try:
        titlefont=ImageFont.truetype('DejaVuSans.ttf',18)
        font=ImageFont.truetype('DejaVuSans.ttf',13)
    except OSError:titlefont=font=ImageFont.load_default()
    draw.text((16,12),'COMBAT DEV — recursos reales decodificados por el código C',font=titlefont,fill='white')
    draw.text((16,42),'Reconstrucción por software. No es una captura de Saturn/MiSTer.',font=font,fill=(165,185,205))
    cache=Cache();decoded={};packs={};owners={}
    with tempfile.TemporaryDirectory(prefix='wwf-combat-preview-') as tmp:
        shared=Path(tmp)/'pack.so'
        subprocess.run(['gcc','-shared','-fPIC','-std=c11','-O2','-I.', 'roster_pack.c','codec.c','-o',str(shared)],cwd=root,check=True)
        lib=c.CDLL(str(shared));lib.roster_pack_open.argtypes=[c.POINTER(Pack),c.POINTER(c.c_uint8),c.c_size_t,c.c_uint];lib.roster_pack_open.restype=c.c_bool
        lib.roster_pack_tile.argtypes=[c.POINTER(Pack),c.c_uint,c.POINTER(c.c_uint8),c.POINTER(Cache)];lib.roster_pack_tile.restype=c.c_bool
        def packed_tile(ch,tile):
            key=(ch,tile)
            if key not in decoded:
                out=(c.c_uint8*128)()
                assert lib.roster_pack_tile(c.byref(packs[ch]),tile,out,c.byref(cache))
                b=np.frombuffer(bytes(out),np.uint8).reshape(16,8)
                a=np.empty((16,16),np.uint8);a[:,::2]=b>>4;a[:,1::2]=b&15;decoded[key]=a
            return decoded[key]
        def frame(ch,pose):
            if ch not in packs:
                data=(root/f'cd/C{ch:02}.PAK').read_bytes();owners[ch]=c.create_string_buffer(data);packs[ch]=Pack()
                assert lib.roster_pack_open(c.byref(packs[ch]),c.cast(owners[ch],c.POINTER(c.c_uint8)),len(data),207)
            data=owners[ch].raw;index=199+poses.index(pose)
            first,count=struct.unpack_from('>HH',data,32+4*index)
            canvas=np.full((190,160,3),backgrounds,np.uint8)
            for i in range(count):
                tile,x,y,flip=struct.unpack_from('>HhhH',data,32+207*4+(first+i)*8)
                a=packed_tile(ch,tile)
                if flip&1:a=a[:,::-1]
                if flip&2:a=a[::-1,:]
                x+=72;y+=150
                x0=max(0,x);y0=max(0,y);x1=min(160,x+16);y1=min(190,y+16)
                if x0>=x1 or y0>=y1:continue
                cut=a[y0-y:y1-y,x0-x:x1-x];mask=cut!=0
                canvas[y0:y1,x0:x1][mask]=colors[ch*16+cut[mask]]
            return Image.fromarray(canvas)
        names={0:'Hogan',1:'Warrior',4:'Smash',5:'Crush',6:'Slaughter',7:'Perfect',8:'Earthquake'}
        draw.text((16,77),'Hogan · brazo en carrera · seis poses de la secuencia original',font=font,fill=(235,200,110))
        for i,pose in enumerate(poses[:6]):
            sheet.paste(frame(0,pose),(i*160,104));draw.text((i*160+10,285),str(pose),font=font,fill='white')
        draw.text((16,322),'Otros luchadores compatibles · muestra de la primera pose',font=font,fill=(235,200,110))
        for i,ch in enumerate([1,4,5,6,7,8]):
            sheet.paste(frame(ch,150),(i*160,350));draw.text((i*160+10,527),names[ch],font=font,fill='white')
        draw.text((16,566),'Patadón frontal: Hogan y Earthquake',font=font,fill=(235,200,110))
        # Scale down uniformly only for this contact sheet, never in-game.
        for i,(ch,pose) in enumerate([(0,180),(0,181),(8,180),(8,181)]):
            pic=frame(ch,pose).resize((96,114),Image.Resampling.NEAREST)
            sheet.paste(pic,(310+i*150,586));draw.text((310+i*150,688),f'{names[ch]} {pose}',font=font,fill='white')
        target=root/'docs/combat-moves-preview.png';sheet.save(target)
        record={'renderer':'software, native roster_pack.c/codec.c, shipped RGB555 palette',
                'new_pose_slots':[199,200,201,202,203,204,205,206],
                'preview_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
                'native_tiles_read':len(decoded),'cache_decodes':cache.decodes,'cache_hits':cache.hits,
                'console_capture':False}
        (root/'docs/combat-preview.json').write_text(json.dumps(record,indent=2)+'\n')
        print(json.dumps(record,indent=2))

if __name__=='__main__':main()
