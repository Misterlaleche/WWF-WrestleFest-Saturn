#include "arcade_stamina.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

static unsigned char *load(size_t *n){FILE*f=fopen("program.bin","rb");assert(f);fseek(f,0,SEEK_END);*n=(size_t)ftell(f);rewind(f);unsigned char*b=malloc(*n);assert(b&&fread(b,1,*n,f)==*n);fclose(f);return b;}
static void bytes(const unsigned char*b,size_t n,size_t off,const unsigned char*want,size_t wn){assert(off+wn<=n);for(size_t i=0;i<wn;i++)assert(b[off+i]==want[i]);}
int main(void){
 size_t n;unsigned char*b=load(&n);
 const unsigned char builder[]={
  0x30,0x39,0x00,0x14,0x00,0x20,0x02,0x40,0x30,0x00,0xe5,0x40,0x33,0xc0,0x00,0x1c,0x00,0x66,
  0x30,0x39,0x00,0x14,0x00,0x22,0x02,0x40,0x3f,0x00,0x81,0x79,0x00,0x1c,0x00,0x66,
  0x30,0x39,0x00,0x14,0x00,0x24,0x02,0x40,0x3f,0x00,0xe0,0x48,0x81,0x79,0x00,0x1c,0x00,0x66,
  0x30,0x39,0x00,0x14,0x00,0x26,0x02,0x40,0x03,0x00,0xe4,0x48,0x81,0x79,0x00,0x1c,0x00,0x66,
  0x46,0x79,0x00,0x1c,0x00,0x66,0x4e,0x75};
 bytes(b,n,0x1e1e,builder,sizeof(builder));
 /* Port $140022 bits 8-9 map unchanged into packed bits 8-9 before the final NOT. */
 for(unsigned raw=0;raw<4;raw++){
  uint16_t cfg=arcade_operator_pack_config(0xffff,(uint16_t)(raw<<8),0xffff,0xffff);
  assert(arcade_difficulty_from_config(cfg)==arcade_difficulty_from_raw_dip(raw));
 }
 assert(arcade_difficulty_from_config(arcade_operator_pack_config(0,0x0300,0,0))==ARCADE_DIFFICULTY_NORMAL);
 assert(arcade_difficulty_from_config(arcade_operator_pack_config(0,0x0200,0,0))==ARCADE_DIFFICULTY_EASY);
 assert(arcade_difficulty_from_config(arcade_operator_pack_config(0,0x0100,0,0))==ARCADE_DIFFICULTY_HARD);
 assert(arcade_difficulty_from_config(arcade_operator_pack_config(0,0x0000,0,0))==ARCADE_DIFFICULTY_HARDEST);
 free(b);puts("PASS: Test127 exact operator-port packing proves difficulty is $140022 bits8-9 -> $1C0066 bits8-9 after inversion");
}
