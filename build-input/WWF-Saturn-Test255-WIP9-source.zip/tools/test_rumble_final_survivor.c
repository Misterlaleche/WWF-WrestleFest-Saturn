#include "game.h"
#include <assert.h>
#include <stdio.h>
int main(void){unsigned r[6]={0,1,2,3,4,5};game_t g;game_match_start(&g,GAME_RUMBLE,r);g.cpu=false;g.rumble_total=6;g.rumble_next=6;g.rumble_pending_slot=6;for(unsigned i=1;i<6;i++){g.fighters[i].outside=true;game_tick(&g,0,0);if(g.finished)break;}assert(g.finished&&g.winner==0&&g.finish_reason==FINISH_ELIMINATION&&g.eliminated==5&&g.active_mask==1);puts("PASS Test118: Rumble resolves victory only after all remaining active CPU entrants are eliminated and the replacement queue is exhausted");}
