#!/usr/bin/env python3
"""Append verified original attack poses and build bounded 16-tile LZ4 banks.

Needs the user's assembled program/sprite regions and the V0.023 source folder.
Existing assets are sufficient for ordinary compilation; ROMs are not included.
"""
from pathlib import Path
import argparse,hashlib,itertools,json,re,struct
import numpy as np
import arcade_composition as composition
import lz4_codec

POSES=[150,151,152,153,154,155,180,181]
CLOTHESLINE={0,1,4,5,6,7,8}
BIG_BOOT={0,8}

def fnv(data):
    value=2166136261
    for byte in data:value=((value^byte)*16777619)&0xffffffff
    return value

def read_legacy(data):
    h=struct.unpack_from('>8I',data)
    assert h[0]==0x57464331 and h[1]==199,'Use the unmodified V0.023 baseline'
    textures=[data[h[4]+128*i:h[4]+128*(i+1)] for i in range(h[3])]
    frames=[]
    for frame in range(h[1]):
        first,count=struct.unpack_from('>HH',data,32+4*frame)
        frames.append([list(struct.unpack_from('>HhhH',data,32+h[1]*4+8*(first+j))) for j in range(count)])
    return frames,textures

def pack_blocks(frames,textures,block_tiles=32):
    indexes=[];records=[]
    for frame in frames:indexes.append((len(records),len(frame)));records.extend(frame)
    assert len(records)<=65535 and len(textures)<=65535
    body=b''.join(struct.pack('>HH',*r) for r in indexes)+b''.join(struct.pack('>HhhH',*r) for r in records)
    offset=(32+len(body)+31)&~31
    raw=b''.join(textures);blocks=[]
    for first in range(0,len(textures),block_tiles):
        chunk=b''.join(textures[first:first+block_tiles]);compressed=lz4_codec.compress(chunk)
        assert lz4_codec.decompress(compressed,len(chunk))==chunk
        blocks.append((chunk,compressed))
    position=offset+len(blocks)*12;directory=[];payload=[]
    for chunk,compressed in blocks:
        directory.append(struct.pack('>III',position,len(compressed),len(chunk)))
        payload.append(compressed);position+=len(compressed)
    header=struct.pack('>8I',0x57464332,len(frames),len(records),len(textures),offset,fnv(raw),block_tiles,len(blocks))
    return header+body+bytes(offset-32-len(body))+b''.join(directory)+b''.join(payload)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline',type=Path,required=True)
    parser.add_argument('--program',type=Path,required=True)
    parser.add_argument('--sprites',type=Path,required=True)
    args=parser.parse_args();root=Path(__file__).resolve().parents[1]
    assert root.resolve()!=args.baseline.resolve(),'Do not overwrite the baseline'
    composition.load_program(args.program)
    region=np.frombuffer(args.sprites.read_bytes(),np.uint8).reshape(4,65536,32)
    decoded={}
    def tile(code):
        if code not in decoded:
            bits=np.unpackbits(region[:,code,:],axis=1).reshape(4,2,16,8).transpose(0,2,1,3).reshape(4,16,16)
            pixels=np.sum(bits*np.array([8,4,2,1],np.uint8)[:,None,None],axis=0,dtype=np.uint8)
            decoded[code]=((pixels[:,::2]<<4)|pixels[:,1::2]).tobytes()
        return decoded[code]
    sizes=[];hashes=[];reports=[]
    for ch in range(10):
        old=(args.baseline/f'cd/C{ch:02}.PAK').read_bytes()
        frames,textures=read_legacy(old);old_frames=[[r[:] for r in frame] for frame in frames]
        lookup={data:i for i,data in enumerate(textures)};added=[]
        for pose in POSES:
            records=[]
            for piece in composition.commands(ch,pose,partner=2 if ch!=2 else 0):
                if piece['bank']!=ch:continue
                pixels=tile(piece['code'])
                if not any(pixels):continue
                if pixels not in lookup:lookup[pixels]=len(textures);textures.append(pixels)
                x=piece['x']-160;y=piece['y']-160
                # Same feet anchor and facing conversion as the integrated basic poses.
                records.append([lookup[pixels],-x-16+11,y+10,(int(piece['fx'])|(int(piece['fy'])<<1))^1])
            supported=ch in (CLOTHESLINE if pose<180 else BIG_BOOT)
            assert bool(records)==supported,(ch,pose,'composition coverage changed')
            frames.append(records)
            if records:added.append(pose)
        assert frames[:199]==old_frames
        # No legacy tile index is changed; its original 128 bytes must survive.
        h=struct.unpack_from('>8I',old)
        assert all(textures[i]==old[h[4]+128*i:h[4]+128*(i+1)] for i in range(h[3]))
        data=pack_blocks(frames,textures);(root/f'cd/C{ch:02}.PAK').write_bytes(data)
        sizes.append(len(data));hashes.append(fnv(data))
        reports.append(dict(character=ch,old_bytes=len(old),bytes=len(data),frames=len(frames),
                            new_nonempty_poses=added,tiles=len(textures),legacy_frames_verified=199,
                            texture_sha256=hashlib.sha256(b''.join(textures)).hexdigest()))
    header=(args.baseline/'roster_data.h').read_text()
    header=header.replace('#define ROSTER_FRAMES 199','#define ROSTER_FRAMES 207')
    header=re.sub(r'static const unsigned roster_bytes\[10\]=\{.*?\};',
                  'static const unsigned roster_bytes[10]={'+','.join(map(str,sizes))+'};',header)
    header=re.sub(r'static const unsigned roster_hash\[10\]=\{.*?\};',
                  'static const unsigned roster_hash[10]={'+','.join(str(v)+'U' for v in hashes)+'};',header)
    cases=''.join(f' case {pose}:return {199+i};\n' for i,pose in enumerate(POSES))
    header=header.replace(' default:return ROSTER_FRAMES;',cases+' default:return ROSTER_FRAMES;')
    (root/'roster_data.h').write_text(header)
    aligned=[(size+2047)&~2047 for size in sizes]
    worst_six=max(sum(aligned[i] for i in group) for group in itertools.combinations(range(10),6))
    assert worst_six<=1048576,'Six compressed banks must fit in standard low work RAM'
    report=dict(poses=POSES,characters=reports,legacy_frames_preserved=1990,
                new_nonempty_character_poses=sum(len(r['new_nonempty_poses']) for r in reports),
                frames_per_pack=207,format='WFC2 / 16 tiles per independent LZ4 block',
                worst_six_low_ram_bytes=worst_six,low_ram_capacity=1048576,
                high_ram_pack_overflow_required=False,cache_blocks=4,cache_payload_bytes=16384,
                hardware_performance_measured=False,
                program_sha256=hashlib.sha256(composition.P).hexdigest(),
                sprite_region_sha256=hashlib.sha256(region.tobytes()).hexdigest())
    (root/'docs/combat-assets.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
