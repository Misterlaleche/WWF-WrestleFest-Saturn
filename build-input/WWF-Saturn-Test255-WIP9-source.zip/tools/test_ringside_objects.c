#include <assert.h>
#include <stdio.h>
#include "arcade_ringside.h"
int main(void){
 const arcade_ringside_object_init_t *a=arcade_ringside_object_init(0),*b=arcade_ringside_object_init(1);
 assert(a&&b&&a->type==0&&a->raw_x==0x40d&&a->raw_y==0x140);
 assert(b->type==1&&b->raw_x==0x330&&b->raw_y==0x119);
 assert(!arcade_ringside_object_init(2));
 assert(arcade_ringside_pickup_contact(100,100,131,131,3,false));
 assert(!arcade_ringside_pickup_contact(100,100,132,131,3,false));
 assert(!arcade_ringside_pickup_contact(100,100,131,132,3,false));
 assert(!arcade_ringside_pickup_contact(100,100,101,101,2,false));
 assert(!arcade_ringside_pickup_contact(100,100,101,101,3,true));
 puts("PASS: ROM ringside objects and strict $20 pickup-contact window");
}
