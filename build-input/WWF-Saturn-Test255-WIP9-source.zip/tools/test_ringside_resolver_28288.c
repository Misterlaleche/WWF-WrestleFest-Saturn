#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include "arcade_ringside.h"

static uint16_t left_bound(uint16_t y){
 int32_t n=(int32_t)((uint32_t)y<<8)+0x28000;
 return (uint16_t)(int16_t)(n/0x2e0);
}
static uint16_t right_bound(uint16_t y){
 int32_t n=(int32_t)((uint32_t)y<<8)-0xba000;
 int16_t q=(int16_t)(n/0x2e0);
 return (uint16_t)(int16_t)(-q);
}
int main(void){
 arcade_ringside_state2_probe_t p;
 /* Central in-bounds point: no contact and no corrections. */
 assert(!arcade_ringside_resolver_28288(0x280,0x160,0x120,0,&p));
 assert(p.contact_code==0&&p.collision_flags==0&&p.raw_dx==0&&p.raw_dy==0&&p.raw_dz==0);

 /* Z floor is exact but, like ROM, does not itself set +$36 contact code. */
 assert(!arcade_ringside_resolver_28288(0x280,0x160,0x0f0,0x08,&p));
 assert(p.contact_code==0&&p.raw_dz==0x18&&(p.collision_flags&0x10));

 /* Left sloped wall: strict comparison against DIVS-derived boundary. */
 uint16_t lb=left_bound(0x160); assert(lb<0x1c7);
 assert(!arcade_ringside_resolver_28288(lb,0x160,0x100,0,&p));
 assert(arcade_ringside_resolver_28288((uint16_t)(lb-1),0x160,0x100,0,&p));
 assert(p.contact_code==3&&p.raw_dx==1&&(p.collision_flags&0x02));
 assert(arcade_ringside_resolver_28288(0,0x160,0x0f0,4,&p));
 assert(p.raw_dx==(int)lb&&p.raw_dz==0x14&&((p.collision_flags&0x12)==0x12));

 /* Right sloped wall: strict unsigned x>bound test after NEG.w quotient. */
 uint16_t rb=right_bound(0x160); assert(rb>0x360);
 assert(!arcade_ringside_resolver_28288(rb,0x160,0x100,0,&p));
 assert(arcade_ringside_resolver_28288((uint16_t)(rb+1),0x160,0x100,0,&p));
 assert(p.contact_code==3&&p.raw_dx==-1&&(p.collision_flags&0x01));

 /* The coarse outer gates remain strict at $01C7/$0360. */
 assert(!arcade_ringside_resolver_28288(0x1c7,0,0x100,0,&p));
 assert(!arcade_ringside_resolver_28288(0x360,0xffff,0x100,0,&p));
 puts("PASS ringside resolver $28288 exact sloped X bounds and Z floor");
 return 0;
}
