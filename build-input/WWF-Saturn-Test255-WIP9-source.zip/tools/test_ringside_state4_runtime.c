#include <assert.h>
#include <stdio.h>
#include "game.h"
#include "arcade_ringside.h"
int main(void){
 game_t g; unsigned c[6]={0,1,2,3,4,5};
 game_match_start_arcade(&g,0,c,0,1);
 g.ringside_object_count=1;
 ringside_object_t *o=&g.ringside_objects[0];
 o->state=ARCADE_OBJECT_POST_THROW_STATE;o->holder=0;o->z=0x44*256;o->state4_initialized=false;o->state4_timer=0;o->state4_phase=0;
 for(unsigned i=1;i<49;i++){
  game_ringside_objects_tick(&g);
  assert(o->state==ARCADE_OBJECT_POST_THROW_STATE);
 }
 game_ringside_objects_tick(&g);
 assert(o->state==ARCADE_OBJECT_AVAILABLE_STATE);
 assert(o->z==ARCADE_OBJECT_AVAILABLE_RAW_Z*256);
 assert(!o->state4_initialized&&o->state4_timer==0&&o->state4_phase==0);
 puts("PASS: native game object lifecycle consumes exact ROM $FF54 state-4 clock and restores availability/raw Z on handler call 49");
 return 0;
}
