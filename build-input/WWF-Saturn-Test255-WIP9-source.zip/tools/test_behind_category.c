#include "arcade_action_map.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
static void seq(const uint8_t *rom,unsigned at,const uint8_t *s,unsigned n){for(unsigned i=0;i<n;++i)assert(rom[at+i]==s[i]);}
int main(void){
 FILE *f=fopen("program.bin","rb");assert(f);uint8_t *rom=malloc(0x80000);assert(rom);assert(fread(rom,1,0x80000,f)==0x80000);fclose(f);
 const uint8_t start[]={0x22,0x68,0x00,0x7a,0x08,0x28,0x00,0x05,0x00,0x34};seq(rom,0xe382,start,sizeof start);
 const uint8_t target[]={0x4a,0xa9,0x00,0x26,0x66,0x00,0xfc,0x72,0x0c,0x29,0x00,0x04,0x00,0x21};seq(rom,0xe3aa,target,sizeof target);
 const uint8_t target65[]={0x0c,0x29,0x00,0x01,0x00,0x65};seq(rom,0xe3bc,target65,sizeof target65);
 assert(arcade_behind_category_raw(0,0,0,0,4,1,0x4f,0x0f,1,1)==0x10);
 assert(arcade_behind_category_raw(0,1,0,0,4,1,-1,-1,-1,-1)==0x10);
 assert(arcade_behind_category_raw(0x20,0,0,0,4,1,1,1,1,1)<0);
 assert(arcade_behind_category_raw(0,2,0,0,4,1,1,1,1,1)<0);
 assert(arcade_behind_category_raw(0,1,1,0,4,1,1,1,1,1)<0);
 assert(arcade_behind_category_raw(0,0,0,1,4,1,1,1,1,1)<0);
 assert(arcade_behind_category_raw(0,0,0,0,3,1,1,1,1,1)<0);
 assert(arcade_behind_category_raw(0,0,0,0,4,2,1,1,1,1)<0);
 assert(arcade_behind_category_raw(0,0,0,0,4,1,0x50,1,1,1)<0);
 assert(arcade_behind_category_raw(0,0,0,0,4,1,1,0x10,1,1)<0);
 assert(arcade_behind_category_raw(0,0,0,0,4,1,1,1,1,-1)<0);
 free(rom);puts("PASS Test78: ROM $E382 full behind-category $10 raw predicate recovered; geometry-only shortcut is not treated as complete");
}
