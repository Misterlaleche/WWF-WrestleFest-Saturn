#!/usr/bin/env python3
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from package_release import source_files
root=Path(__file__).resolve().parents[1]
paths={p.relative_to(root).as_posix() for p in source_files(root)}
required={
 'arcade_moves.c','arcade_moves.h','arcade_ringside.c','arcade_ringside.h',
 'arcade_stamina.c','arcade_stamina.h','arcade_input.c','arcade_input.h','arcade_action_map.c','arcade_action_map.h','arcade_behind_pair.c','arcade_behind_pair.h','campaign.c','campaign.h',
 'campaign_runtime.c','campaign_runtime.h','program.bin','game.c','game.h',
 'tools/package_checkpoint.py','tools/package_release.py'
}
missing=sorted(required-paths)
if missing: raise SystemExit('checkpoint source set missing: '+', '.join(missing))
print(f'PASS checkpoint source set contains all {len(required)} required recovery files')
