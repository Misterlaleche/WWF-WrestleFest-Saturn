#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void seq(const unsigned char*r,size_t n,size_t o,const unsigned char*s,size_t z){assert(o+z<=n);assert(!memcmp(r+o,s,z));}
int main(void){FILE*f=fopen("program.bin","rb");assert(f);fseek(f,0,SEEK_END);long ln=ftell(f);rewind(f);size_t n=(size_t)ln;unsigned char*r=malloc(n);assert(r&&fread(r,1,n,f)==n);fclose(f);
 const unsigned char base[]={0x41,0xf9,0x00,0x1c,0x05,0xb0,0x7c,0x08};seq(r,n,0x1c15c,base,sizeof base);const unsigned char stride[]={0xd1,0xfc,0x00,0x00,0x01,0x0c,0x51,0xce};seq(r,n,0x1c1e8,stride,sizeof stride);const unsigned char dispatch[]={0x30,0x28,0x00,0x20,0x02,0x40,0x00,0xff};seq(r,n,0x1c1d2,dispatch,sizeof dispatch);const unsigned char target[]={0x22,0x68,0x00,0x7a};seq(r,n,0x1c228,target,sizeof target);const unsigned char consume[]={0x08,0x2a,0x00,0x06,0x00,0x33};seq(r,n,0x1ca00,consume,sizeof consume);
 free(r);puts("PASS Test86: $1C150 CPU actor loop scans 9 records from $1C05B0 stride $10C, dispatches by raw +$20, derives target through +$7A, and state-1 AI directly consumes target +$33 bit6 at $1CA00");return 0;}
