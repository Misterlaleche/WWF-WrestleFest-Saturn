#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void seq(long o,const uint8_t*p,size_t n){FILE*f=fopen("program.bin","rb");assert(f);uint8_t*b=malloc(n);assert(b);assert(fseek(f,o,SEEK_SET)==0&&fread(b,1,n,f)==n);fclose(f);assert(!memcmp(b,p,n));free(b);}
int main(void){
 const uint8_t p[]={0x08,0x28,0x00,0x04,0x00,0x37,0x67,0x00,0x00,0xd4,0x08,0xe8,0x00,0x07,0x00,0x18,0x4e,0xb9,0x00,0x01,0x11,0x0e,0x42,0x28,0x00,0x01,0x4e,0xb9,0x00,0x01,0x11,0x52};seq(0x144f0,p,sizeof p);
 puts("PASS Test183: action-$47 contact resolution is gated by actor +$37 bit4, sets +$18 bit7, then calls $1110E and $11152");return 0;}
