#include "game.h"
#include "arcade_moves.h"
#include <assert.h>
#include <stdio.h>
static void setup(game_t *g,unsigned ch,unsigned enemy_health){unsigned r[6]={ch,2,1,3,4,5};game_match_start(g,GAME_TAG,r);g->cpu=false;fighter_t *p=&g->fighters[0],*q=&g->fighters[1];p->x=100*256;p->y=q->y=180*256;q->x=130*256;q->health=enemy_health;q->stamina_tier=enemy_health<=24?2:(enemy_health<=2*(q->max_health/3));}
int main(void){game_t g;
 setup(&g,0,100);game_tick(&g,0,INPUT_GRAB);game_tick(&g,0,INPUT_PUNCH);assert(g.pair==PAIR_THROW&&g.pair_move==AMOVE_BODY_SLAM);
 setup(&g,0,100);g.fighters[0].grapple_serial=1;game_tick(&g,0,INPUT_GRAB);game_tick(&g,0,INPUT_PUNCH);assert(g.pair_move==AMOVE_SNAP_MARE);
 setup(&g,0,20);game_tick(&g,0,INPUT_GRAB);game_tick(&g,0,INPUT_PUNCH);assert(g.pair_move==AMOVE_ATOMIC_DROP);
 setup(&g,0,20);g.fighters[0].grapple_serial=1;game_tick(&g,0,INPUT_GRAB);game_tick(&g,0,INPUT_PUNCH);assert(g.pair_move==AMOVE_SUPLEX);
 /* Damage now follows the selected move rather than the old hard-coded 35. */
 unsigned before=g.fighters[1].health;for(unsigned i=0;i<60;i++)game_tick(&g,0,0);assert(g.fighters[1].health<before);
 puts("PASS: stamina-tier four-move grapple rota is connected to live pair combat");}
