#include "game.h"
#include "layer_view.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static const unsigned cast[6]={0,2,7,1,4,5};
static unsigned plan[GAME_DRAW_CAPACITY],count;
static int index_of(unsigned object){
    int found=-1;for(unsigned i=0;i<count;i++)if(plan[i]==object){assert(found<0);found=(int)i;}
    return found;
}
static void read_plan(const game_t *g){
    struct {unsigned before,order[GAME_DRAW_CAPACITY],after;} guarded={.before=0xabcdef,.after=0x123456};
    game_t before=*g;count=game_render_plan(g,guarded.order);
    assert(guarded.before==0xabcdef&&guarded.after==0x123456&&count<=10);
    assert(!memcmp(&before,g,sizeof(before)));memcpy(plan,guarded.order,sizeof(plan));
    assert(index_of(DRAW_SIDE_ROPES)>=0&&index_of(DRAW_FRONT_ROPES)>index_of(DRAW_SIDE_ROPES));
    assert(index_of(DRAW_REFEREE)>=0);
    for(unsigned i=0;i<count;i++)assert(index_of(plan[i])==(int)i);
    unsigned projected[8],pn=game_draw_order(g,projected),j=0;
    for(unsigned i=0;i<count;i++)if(plan[i]<DRAW_FIGHTER_2){assert(j<pn&&projected[j]==plan[i]);++j;}
    assert(j==pn);
}
static void start(game_t *g,unsigned mode){game_match_start(g,mode,cast);g->cpu=false;}
static void plan_tests(void){
    game_t g;start(&g,GAME_TAG);read_plan(&g);
    assert(index_of(DRAW_FIGHTER_2)<index_of(DRAW_SIDE_ROPES));
    assert(index_of(DRAW_FIGHTER_3)<index_of(DRAW_SIDE_ROPES));
    assert(g.fighters[2].facing==1&&g.fighters[3].facing==-1);
    /* Regression: hardware used to paint every pair AFTER both supporters. */
    for(unsigned pair=PAIR_HOLD;pair<=PAIR_PIN;pair++)for(unsigned attacker=0;attacker<2;attacker++){
        start(&g,GAME_TAG);g.pair=(pair_state_t)pair;g.pair_attacker=g.pin_attacker=attacker;
        g.support_phase[0]=g.support_phase[1]=SUPPORT_RUN;
        for(unsigned i=0;i<2;i++){g.fighters[i].y=200*256;g.fighters[i].rise_y=200*256;}
        if(pair==PAIR_PIN){fighter_t *f=&g.fighters[1-attacker];f->state=ST_RECOVER;f->y+=25*256;}
        g.fighters[2].y=190*256;g.fighters[3].y=210*256;g.referee.y=230*256;
        read_plan(&g);assert(index_of(DRAW_HULK)<0&&index_of(DRAW_JAKE)<0);
        assert(index_of(DRAW_FIGHTER_2)<index_of(DRAW_PAIR));
        assert(index_of(DRAW_PAIR)<index_of(DRAW_FIGHTER_3));
        assert(index_of(DRAW_FIGHTER_3)<index_of(DRAW_REFEREE));
        g.referee.y=180*256;read_plan(&g);assert(index_of(DRAW_REFEREE)<index_of(DRAW_PAIR));
        for(unsigned state=REF_KNEEL;state<=REF_FINISH;state++){
            g.referee.state=(referee_state_t)state;read_plan(&g);
            assert(index_of(DRAW_REFEREE)>index_of(DRAW_PAIR));
            assert(index_of(DRAW_REFEREE)>index_of(DRAW_FIGHTER_3));
            assert(index_of(DRAW_REFEREE)<index_of(DRAW_FRONT_ROPES));
        }
    }
    /* ALL six actors, not just the controlled slot, stay whole over ropes. */
    const fighter_state_t above[]={ST_CLIMB,ST_CORNER,ST_DESCEND,ST_DIVE,ST_RING_EXIT,ST_RING_ENTER,ST_TOSSED};
    for(unsigned actor=0;actor<6;actor++)for(unsigned s=0;s<sizeof(above)/sizeof(above[0]);s++){
        start(&g,GAME_RUMBLE);g.fighters[actor].state=above[s];read_plan(&g);
        unsigned object=actor<2?DRAW_HULK+actor:DRAW_FIGHTER_2+actor-2;
        assert(index_of(object)>index_of(DRAW_FRONT_ROPES));
    }
    /* Stable floor depth while prone, then rising: no anchor-induced jump. */
    start(&g,GAME_RUMBLE);g.fighters[0].y=225*256;g.fighters[0].rise_y=200*256;
    g.fighters[0].state=ST_RECOVER;g.fighters[1].y=210*256;read_plan(&g);
    assert(index_of(DRAW_HULK)<index_of(DRAW_JAKE));
    g.fighters[0].state=ST_DOWN;read_plan(&g);assert(index_of(DRAW_HULK)<index_of(DRAW_JAKE));
    g.fighters[0].state=ST_RISE;g.fighters[0].y=200*256;read_plan(&g);assert(index_of(DRAW_HULK)<index_of(DRAW_JAKE));
    /* Far and lateral ringside belong behind ropes; front ringside does not. */
    for(unsigned actor=0;actor<6;actor++)for(int y=128;y<=312;y++){
        start(&g,GAME_RUMBLE);g.fighters[actor].outside=true;g.fighters[actor].y=y*256;
        unsigned object=actor<2?DRAW_HULK+actor:DRAW_FIGHTER_2+actor-2;read_plan(&g);
        if(y<=RING_BOTTOM)assert(index_of(object)<index_of(DRAW_SIDE_ROPES));
        else assert(index_of(object)>index_of(DRAW_FRONT_ROPES));
    }
    start(&g,GAME_RUMBLE);g.fighters[0].state=g.fighters[1].state=ST_TOSSED;
    g.fighters[0].y=220*256;g.fighters[1].y=210*256;read_plan(&g);
    assert(index_of(DRAW_JAKE)<index_of(DRAW_HULK));
    /* Rumble elimination: never reintroduce a hidden/inactive actor. */
    for(unsigned mask=1;mask<64;mask++){
        start(&g,GAME_RUMBLE);g.active_mask=mask;read_plan(&g);
        for(unsigned actor=0;actor<6;actor++){
            unsigned object=actor<2?DRAW_HULK+actor:DRAW_FIGHTER_2+actor-2;
            assert((index_of(object)>=0)==!!(mask&(1U<<actor)));
        }
    }
    for(unsigned v=0;v<VIEW_COUNT;v++){
        assert(layer_view_object(v,DRAW_SIDE_ROPES)==layer_view_ropes(v));
        assert(layer_view_object(v,DRAW_FRONT_ROPES)==layer_view_ropes(v));
        assert(layer_view_object(v,DRAW_PAIR)==layer_view_actor(v));
        assert(layer_view_object(v,DRAW_FIGHTER_5)==layer_view_actor(v));
        assert(layer_view_object(v,DRAW_PROMPT)==(v==VIEW_ALL));
    }
}
static void stress(void){
    game_t g;unsigned snapshots=0;uint32_t seed=37;
    for(unsigned mode=GAME_TAG;mode<=GAME_RUMBLE;mode++)for(unsigned run=0;run<12;run++){
        start(&g,mode);g.cpu=true;
        for(unsigned t=0;t<2500;t++){
            seed=seed*1664525U+1013904223U;
            unsigned held=(seed>>20)&15,pressed=(seed&7)?0:1U<<(4+(seed>>8)%10);
            game_tick(&g,held,pressed);read_plan(&g);++snapshots;
            if(g.finished)start(&g,mode);
        }
    }
    assert(snapshots==60000);printf("PASS: %u shared render plans over TAG/Rumble simulation ticks\n",snapshots);
}
int main(void){plan_tests();stress();puts("PASS: pair/support/referee depth, six corner actors, prone anchors, ringside, masks, elimination and immutable plan");}
