#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
int main(void){FILE*f=fopen("program.bin","rb");assert(f);uint8_t b[32];assert(fseek(f,0x2007A,SEEK_SET)==0&&fread(b,1,sizeof b,f)==sizeof b);fclose(f);
 const uint8_t p[]={0x08,0x28,0x00,0x00,0x00,0x25,0x66,0x20,0x52,0x39,0x00,0x1c,0x16,0x9a,0x70,0x00,0x30,0x28,0x00,0x24,0xe2,0x48,0x61,0x00,0x05,0xea};assert(!memcmp(b,p,sizeof p));
 puts("PASS Test168: on even raw phases the +$109 producer increments global $1C169A, then derives a helper argument from actor +$24>>1; $1C169A is the independently recovered ring-out/count counter storage");return 0;}
