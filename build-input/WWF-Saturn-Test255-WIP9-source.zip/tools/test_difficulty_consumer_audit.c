#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned char *load(size_t *n){FILE*f=fopen("program.bin","rb");assert(f);fseek(f,0,SEEK_END);*n=(size_t)ftell(f);rewind(f);unsigned char*b=malloc(*n);assert(b&&fread(b,1,*n,f)==*n);fclose(f);return b;}
static unsigned countpat(const unsigned char*b,size_t n,const unsigned char*p,size_t pn){unsigned c=0;for(size_t i=0;i+pn<=n;i++)if(!memcmp(b+i,p,pn))c++;return c;}
int main(void){size_t n;unsigned char*b=load(&n);
 /* Exact difficulty extraction at $107F8: MOVE.w $1C0066,D4; ANDI #$0300,D4. */
 const unsigned char diff[]={0x38,0x39,0x00,0x1c,0x00,0x66,0x02,0x44,0x03,0x00};
 assert(n>0x10802&&!memcmp(b+0x107f8,diff,sizeof(diff)));
 assert(countpat(b,n,diff,sizeof(diff))==1);
 /* No direct bit-test of the two difficulty bits exists anywhere in program ROM. */
 for(unsigned bit=8;bit<=9;bit++){unsigned char p[]={0x08,0x39,0x00,(unsigned char)bit,0x00,0x1c,0x00,0x66};assert(countpat(b,n,p,sizeof(p))==0);}
 /* The adjacent $0C00 consumers are DIP bits10-11, not difficulty bits8-9. */
 const unsigned char other[]={0x02,0x41,0x0c,0x00};assert(countpat(b,n,other,sizeof(other))>=1);
 free(b);puts("PASS: Test128 ROM audit finds the difficulty field $0300 extracted once for stamina setup and no direct AI bit8/9 tests");}
