#include "game.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
int main(void){FILE*f=fopen("program.bin","rb");assert(f);fseek(f,0,SEEK_END);long ln=ftell(f);rewind(f);size_t n=(size_t)ln;unsigned char*r=malloc(n);assert(r&&fread(r,1,n,f)==n);fclose(f);assert(n>0x10718);
 int16_t v[8];for(int i=0;i<8;i++)v[i]=(int16_t)((r[0x10708+i*2]<<8)|r[0x10709+i*2]);assert(v[2]-v[0]==-0x20&&v[3]-v[1]==0x10&&v[6]-v[4]==0x20&&v[7]-v[5]==0x10);free(r);
 unsigned ro[6]={0,2,1,3,4,5};game_t g;game_match_start(&g,GAME_TAG,ro);assert(g.fighters[2].x!=-0x20*256+g.fighters[0].x||g.fighters[2].y!=0x10*256+g.fighters[0].y);
 puts("PASS Test94: ROM reserve deltas are exact raw geometry, but native Saturn placement remains deliberately provisional until raw->world scale/origin is proven");return 0;}
