#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void seq(long o,const uint8_t*p,size_t n){FILE*f=fopen("program.bin","rb");assert(f);uint8_t*b=malloc(n);assert(b);assert(fseek(f,o,SEEK_SET)==0&&fread(b,1,n,f)==n);fclose(f);assert(!memcmp(b,p,n));free(b);}
int main(void){
 const uint8_t p[]={0x30,0x39,0x00,0x1c,0x00,0x66,0x02,0x40,0x60,0x00,0xee,0x48,0xea,0x48,0x43,0xf9,0x00,0x00,0x91,0x2a,0x30,0x31,0x00,0x00};seq(0x90ea,p,sizeof p); const uint8_t t[]={0x00,0x18,0x00,0x20,0x00,0x0c,0x00,0x00};seq(0x912a,t,sizeof t);
 puts("PASS Test197: $90D6 derives restore amount from global config $1C0066 bits $6000 through exact table {24,32,12,0}");return 0;}
