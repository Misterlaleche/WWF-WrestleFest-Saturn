#!/usr/bin/env python3
import argparse,gzip,json,struct,subprocess,tempfile,wave
from pathlib import Path

SECTOR=2352
PREGAP_SECTORS=150

def main():
 ap=argparse.ArgumentParser()
 ap.add_argument("--renderer",required=True,help="libvgm vgm2wav built with Nuked-OPM")
 ap.add_argument("--source",default="music-vgm")
 ap.add_argument("--output",default="audio-tracks")
 args=ap.parse_args()
 source=Path(args.source);out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
 manifest=json.loads((source/"MUSIC-MANIFEST.json").read_text())
 generated=[]
 for m in manifest:
  cmd=int(m["command"],16)
  gz=source/f"FM{cmd:02X}.vgm.gz"
  with tempfile.TemporaryDirectory() as td:
   td=Path(td);vgm=td/f"FM{cmd:02X}.vgm";wav=td/f"FM{cmd:02X}.wav"
   with gzip.open(gz,"rb") as fi,vgm.open("wb") as fo:
    while True:
     b=fi.read(1024*1024)
     if not b:break
     fo.write(b)
   subprocess.run([args.renderer,"--loops","0","--fade","0",str(vgm),str(wav)],check=True)
   with wave.open(str(wav),"rb") as w:
    if (w.getframerate(),w.getnchannels(),w.getsampwidth())!=(44100,2,2):
     raise SystemExit(f"unexpected WAV format for {cmd:02X}")
    frames=w.getnframes();raw=w.readframes(frames)
   # WAV is little-endian PCM. CDDA sector audio is 16-bit big-endian stereo.
   ba=bytearray(raw)
   for i in range(0,len(ba),2):ba[i],ba[i+1]=ba[i+1],ba[i]
   payload=bytearray(SECTOR*PREGAP_SECTORS);payload.extend(ba)
   if len(payload)%SECTOR:payload.extend(b"\0"*(SECTOR-len(payload)%SECTOR))
   path=out/f"{cmd:02d}_FM{cmd:02X}.BIN";path.write_bytes(payload)
   audio_sectors=(len(payload)//SECTOR)-PREGAP_SECTORS
   generated.append({"command":m["command"],"file":path.name,"frames":frames,
                     "audio_sectors":audio_sectors,"pregap_sectors":PREGAP_SECTORS})
   print(f"{m['command']} -> {path} ({audio_sectors} audio sectors)")
 (out/"CDDA-GENERATED.json").write_text(json.dumps(generated,indent=2))
if __name__=="__main__":main()
