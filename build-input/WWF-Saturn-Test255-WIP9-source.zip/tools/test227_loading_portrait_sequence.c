#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(void){FILE*f=fopen("main.c","rb");assert(f);fseek(f,0,SEEK_END);long n=ftell(f);rewind(f);char*s=malloc(n+1);assert(s);assert(fread(s,1,n,f)==(size_t)n);s[n]=0;fclose(f);assert(strstr(s,"loading_boot_portraits[5]={0,2,1,3,7}"));assert(strstr(s,"loading.portrait_ch=loading_boot_portraits[loading.stage]"));assert(strstr(s,"loading_portrait_build(loading.portrait_ch)"));free(s);puts("PASS Test227: each real boot preload stage advances an authentic recovered HUD portrait without inventing facial frames");}