#include "campaign.h"
#include "arcade_stamina.h"
#include <assert.h>
#include <stdio.h>
static int distinct_from_players(const campaign_t *c,unsigned x){return x!=c->player_character[0]&&x!=c->player_character[1];}
int main(void){
 campaign_t c;campaign_reset(&c,CAMPAIGN_TAG,5,0,ARCADE_DIFFICULTY_NORMAL);campaign_set_players(&c,0,1);
 unsigned o[2];
 /* Stage 0 has eight weighted candidates. Rolls at opposite extremes select
    opposite ends of the sorted internal-id pool. */
 campaign_select_opponents(&c,1,100,o);assert(o[0]!=o[1]);assert(distinct_from_players(&c,o[0])&&distinct_from_players(&c,o[1]));assert(o[0]<10&&o[1]<10);
 /* Equal random indices are corrected to an adjacent pool entry like $103F8. */
 campaign_select_opponents(&c,1,1,o);assert(o[0]!=o[1]);
 /* Stage 1/2/3 progressively restrict weighted choice to first 6/4/2 entries. */
 c.stage=1;campaign_select_opponents(&c,100,100,o);unsigned s1a=o[0],s1b=o[1];assert(s1a!=s1b);
 c.stage=2;campaign_select_opponents(&c,100,100,o);assert(o[0]!=o[1]);
 c.stage=3;campaign_select_opponents(&c,100,100,o);assert(o[0]!=o[1]);
 /* The ROM forces internal IDs 4/5 at stage modifiers 4 and 9. */
 c.stage=4;campaign_select_opponents(&c,37,88,o);assert(o[0]==10&&o[1]==11);
 c.stage=9;campaign_select_opponents(&c,1,1,o);assert(o[0]==10&&o[1]==11);
 /* Defenses 5..8 reuse groups 0..3. */
 c.stage=5;campaign_select_opponents(&c,1,100,o);assert(o[0]!=o[1]&&o[0]<10&&o[1]<10);
 assert(arcade_stamina_internal_id(10)==4&&arcade_stamina_internal_id(11)==5);
 puts("PASS: ROM $1034A opponent pool/weights, collision adjustment, defense repeat and forced Hawk/Animal stages");
}
