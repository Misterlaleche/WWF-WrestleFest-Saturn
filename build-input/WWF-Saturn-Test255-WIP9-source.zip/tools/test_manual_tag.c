#include "game.h"
#include <assert.h>
#include <stdio.h>
static void at_corner(game_t *g){g->cpu=false;g->fighters[0].x=30*256;g->fighters[0].y=170*256;g->fighters[0].state=ST_IDLE;g->fighters[0].cooldown=0;g->tag_cooldown=0;g->support_phase[0]=SUPPORT_WAIT;}
static void finish_tag(game_t *g){for(unsigned i=0;i<160&&g->tags==0;i++)game_tick(g,0,0);}
int main(void){unsigned r[6]={0,1,2,3,4,5};game_t g;
 game_match_start(&g,GAME_TAG,r);at_corner(&g);unsigned incoming=g.fighters[2].character;game_tick(&g,0,INPUT_KICK);assert(g.tags==0&&g.tag_phase[0]!=TAG_PHASE_NONE);finish_tag(&g);assert(g.tags==1&&g.fighters[0].character==incoming);
 game_match_start(&g,GAME_TAG,r);at_corner(&g);g.fighters[2].health=0;game_tick(&g,0,INPUT_KICK);assert(g.tags==0&&g.tag_phase[0]==TAG_PHASE_NONE);
 game_match_start(&g,GAME_TAG,r);at_corner(&g);incoming=g.fighters[2].character;game_tick(&g,0,INPUT_TAG);finish_tag(&g);assert(g.tags==1&&g.fighters[0].character==incoming);
 puts("PASS Test102/205: manual TAG keeps original K edge/C alias but now completes through staged approach, hand contact and rope entry; KO reserve blocked");return 0;}
