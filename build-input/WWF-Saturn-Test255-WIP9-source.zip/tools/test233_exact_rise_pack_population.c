#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include "../roster_data.h"
static unsigned be16(const unsigned char*p){return ((unsigned)p[0]<<8)|p[1];}
static unsigned count(const unsigned char*d,unsigned frame){return be16(d+34+frame*4);}
int main(void){
 for(unsigned ch=0;ch<10;ch++){char n[32];sprintf(n,"cd/C%02u.PAK",ch);FILE*f=fopen(n,"rb");assert(f);unsigned char*d=malloc(roster_bytes[ch]);assert(d&&fread(d,1,roster_bytes[ch],f)==roster_bytes[ch]);fclose(f);
  for(unsigned pose=104;pose<=113;pose++){if(pose!=104&&pose<110)continue;unsigned fr=roster_arcade_frame_character(ch,pose);if(fr<ROSTER_FRAMES)assert(count(d,fr)>0);}
  free(d);
 }
 puts("PASS Test233: every character-specific exact RISE alias resolves to a populated resident WFC2 frame");
}
