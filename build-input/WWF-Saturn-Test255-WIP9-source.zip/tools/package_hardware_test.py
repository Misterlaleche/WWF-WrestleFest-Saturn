#!/usr/bin/env python3
"""Bundle the verified Test15 raw disc, matching sources, reports and hashes."""
import argparse,hashlib,json,shutil,subprocess,sys,zipfile
from pathlib import Path
from package_release import program_name
from verify_iso import verify as verify_iso
from iso_to_bin import verify as verify_bin

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('disc',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
    root=Path(__file__).resolve().parents[1];disc=a.disc.resolve();output=a.output.resolve();output.mkdir(exist_ok=True,parents=True)
    stem=program_name(root);assert stem=='wrestlefest-saturn-test15'
    iso=root/(stem+'.iso');binary=disc/(stem+'.bin');cue=disc/(stem+'.cue')
    verify_iso(root);current=verify_bin(iso,binary,cue)
    independent=json.loads((disc/'disc-independent-validation.json').read_text())
    assert independent['bin_sha256']==current['bin_sha256'] and independent['cue_payload_matches_iso']
    assert independent['edc_bitwise_all_sectors'] and independent['ecc_mame_tables_all_sectors']
    assert json.loads((disc/'disc-validation.json').read_text())==current
    for name in ['disc-validation.json','disc-independent-validation.json']:shutil.copy2(disc/name,root/'docs'/name)
    sh2=json.loads((root/'docs/sh2-validation.json').read_text());assert sh2['elf_sha256']==sha(root/'build'/(stem+'.elf'))
    normal=(root/'docs/host-tests.log').read_text();sanitized=(root/'docs/sanitized-tests.log').read_text()
    suites=['render_assets','layers','combat_moves','roster_pack','next','test14','cpu_tag','run','hud','game','session','test11_regressions','intro','dma','animation','basic_motion']
    for name in suites:
        assert name+'\n' in normal and name+'\n' in sanitized
    visual=json.loads((root/'docs/layers-visual.json').read_text());assert visual['preview_sha256']==sha(root/'docs/layers-preview.png')
    record={'build':'Test15 V0.025','base':'COMBAT DEV V0.024','host_suites':suites,'host_passed':True,'asan_ubsan_passed':True,
            'render_plan_ticks':60000,'combat_regression_ticks':50000,'conservative_combat_commands':788,
            'dynamic_tile_bound':228,'texture_bytes':341344,'visual_frames':len(visual['frames']),
            'elf_sha256':sh2['elf_sha256'],'iso_sha256':current['iso_sha256'],'bin_sha256':current['bin_sha256'],
            'sectors':current['sectors'],'disc_reader':'libcdio','boot_saturn':False,'boot_mister':False,'boot_mednafen':False,
            'background_baked_layers_fully_separated':False,'audio':False}
    (root/'docs/test15-validation.json').write_text(json.dumps(record,indent=2)+'\n')
    sources=output/'WWF-Saturn-Test15-fuentes.zip'
    subprocess.run([sys.executable,str(root/'tools/package_checkpoint.py'),str(sources),'--root',str(root)],check=True)
    with zipfile.ZipFile(sources) as z:
        assert z.testzip() is None
        for line in z.read('SOURCE-SHA256.txt').decode().splitlines():
            digest,name=line.split('  ',1);assert hashlib.sha256(z.read(name)).hexdigest()==digest
        for path in root.iterdir():
            if path.suffix in ('.c','.h'):assert path.name in z.namelist(),f'Omitted source {path.name}'
    shutil.copy2(sources,disc/sources.name);shutil.copy2(root/'README.md',disc/'README.md')
    (disc/'docs').mkdir(exist_ok=True)
    for name in ['INFORME.md','COVERAGE.md','COMBATE-V0024.md','layers-preview.png','test15-validation.json']:
        shutil.copy2(root/'docs'/name,disc/'docs'/name)
    report=output/'WWF-Saturn-Test15-informe.md';shutil.copy2(root/'docs/INFORME.md',report)
    paths=sorted(path for path in disc.rglob('*') if path.is_file() and path.name!='SHA256.txt')
    (disc/'SHA256.txt').write_text(''.join(sha(path)+'  '+path.relative_to(disc).as_posix()+'\n' for path in paths))
    target=output/'WWF-Saturn-Test15-BIN-CUE.zip'
    with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED) as z:
        for path in sorted(disc.rglob('*')):
            if path.is_file():z.write(path,path.relative_to(disc))
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
        for line in z.read('SHA256.txt').decode().splitlines():
            digest,name=line.split('  ',1);assert hashlib.sha256(z.read(name)).hexdigest()==digest
        assert z.read(stem+'.bin')==binary.read_bytes() and z.read(stem+'.cue')==cue.read_bytes()
        assert z.read(sources.name)==sources.read_bytes() and z.read('docs/INFORME.md')==report.read_bytes()
    print(json.dumps({'package':str(target),'package_bytes':target.stat().st_size,'package_sha256':sha(target),
                      'sources':str(sources),'report':str(report),'crc_and_manifest':'passed'},indent=2))

if __name__=='__main__':main()
