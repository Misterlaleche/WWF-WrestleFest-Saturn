#include <assert.h>
#include <stdint.h>
int main(void){
 const unsigned resident_start=0x14000u,dynamic_start=0x3A800u,stride=0xA000u;
 const unsigned music_a=0x60000u,music_b=0x68000u,music_bytes=0x8000u;
 assert(resident_start<dynamic_start);
 assert(dynamic_start+3u*stride<=music_a);
 assert(music_a+music_bytes<=music_b);
 assert(music_b+music_bytes<=0x80000u);
 const unsigned char v[16]={255,251,247,243,239,236,231,228,223,0,0,0,0,0,0,0};
 assert(v[0]==255&&v[1]==251&&v[8]==223&&v[9]==0);
 /* sample18 exact duration: 32018 bytes at 8k under 221.068737...Hz */
 uint64_t num=32018ull*3579545ull,den=8000ull*64ull*253ull;
 unsigned ticks=(unsigned)((num+den-1)/den);
 assert(ticks==885u);
 return 0;
}
