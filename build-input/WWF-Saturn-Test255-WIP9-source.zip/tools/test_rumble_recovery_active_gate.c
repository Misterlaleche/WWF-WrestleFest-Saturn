#include "game.h"
#include "arcade_stamina.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 unsigned r[6]={0,1,2,3,4,5};game_t g;game_match_start_arcade(&g,GAME_RUMBLE,r,0,ARCADE_DIFFICULTY_NORMAL);g.cpu=false;
 g.fighters[2].health=90;g.fighters[2].stamina_recovery=127;g.active_mask&=~(1U<<2);
 game_tick(&g,0,0);assert(g.fighters[2].health==90&&g.fighters[2].stamina_recovery==0);
 g.active_mask|=1U<<2;g.fighters[2].stamina_recovery=127;game_tick(&g,0,0);
 assert(g.fighters[2].health==91&&g.fighters[2].stamina_recovery==0);
 puts("PASS Test101: live Rumble recovery obeys ROM $8EE0 active-actor bit gate");return 0;
}
