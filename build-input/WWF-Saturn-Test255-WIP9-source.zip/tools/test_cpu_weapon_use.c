#include <assert.h>
#include <stdio.h>
#include "game.h"
#include "arcade_ringside.h"

static void tickn(game_t *g,unsigned n){while(n--)game_tick(g,0,0);}
int main(void){
 game_t g;unsigned r[6]={0,2,1,3,0,0};game_match_start(&g,GAME_TAG,r);
 g.cpu=true; fighter_t *p=&g.fighters[0],*q=&g.fighters[1];
 p->outside=q->outside=true; p->state=q->state=ST_IDLE;
 q->x=100*256;q->y=220*256;p->x=(100+0x67)*256;p->y=(220+0x0b)*256;
 ringside_object_t *o=&g.ringside_objects[0];o->state=ARCADE_OBJECT_HELD_STATE;o->holder=2;q->held_object=1;
 assert(arcade_ringside_cpu_weapon_direct_contact(0x67,0x0b));
 assert(!arcade_ringside_cpu_weapon_direct_contact(0x68,0));
 assert(!arcade_ringside_cpu_weapon_direct_contact(0,0x0c));
 game_tick(&g,0,0);assert(q->state==ST_OBJECT_USE);assert(game_arcade_pose(q)==116);
 tickn(&g,ARCADE_OBJECT_USE_TICKS);assert(q->state==ST_IDLE&&!q->held_object&&o->state==ARCADE_OBJECT_THROWN_STATE);
 /* Outside direct-use branch must not trigger at the strict boundaries. */
 game_match_start(&g,GAME_TAG,r);g.cpu=true;p=&g.fighters[0];q=&g.fighters[1];p->outside=q->outside=true;p->state=q->state=ST_IDLE;
 q->x=100*256;q->y=220*256;p->x=(100+0x90)*256;p->y=220*256;o=&g.ringside_objects[0];o->state=ARCADE_OBJECT_HELD_STATE;o->holder=2;q->held_object=1;
 game_tick(&g,0,0);assert(q->state!=ST_OBJECT_USE);
 puts("PASS: CPU held-object direct-use reproduces strict $68/$0C ROM branch and original action 30/31 animation");
}
