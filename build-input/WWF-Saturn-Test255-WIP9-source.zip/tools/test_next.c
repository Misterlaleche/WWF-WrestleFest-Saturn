#include "game.h"
#include "match_result.h"
#include "match_flow.h"
#include "recovery_timing.h"
#include "arcade_animation.h"
#include "pair_rules.h"
#include <assert.h>
#include <string.h>
#include <stdio.h>
static const unsigned cast[6]={0,2,7,1,4,5};
static void recover(game_t *g){
 game_match_start(g,GAME_TAG,cast);g->cpu=false;
 g->fighters[0].state=ST_RECOVER;g->fighters[0].tick=0;g->fighters[0].rise_y=200*256;g->fighters[0].y=225*256;
 g->fighters[1].x=250*256;g->fighters[1].y=160*256;
}
static void recovery(void){
 game_t g;recover(&g);fighter_t *p=&g.fighters[0];
 for(unsigned t=0;t<RECOVER_PRONE_TICKS-1;t++)game_tick(&g,INPUT_PUNCH|INPUT_KICK,0);
 assert(p->state==ST_RECOVER&&p->recovery_bonus==0);game_tick(&g,0,0);assert(p->state==ST_RISE);
 recover(&g);g.paused=true;game_tick(&g,0,INPUT_PUNCH|INPUT_KICK);assert(!p->tick&&!p->recovery_bonus);g.paused=false;
 for(unsigned t=0;t<12;t++)game_tick(&g,INPUT_RIGHT|INPUT_RUN,INPUT_PUNCH|INPUT_KICK);
 assert(p->recovery_bonus==48&&p->tick==60&&p->state==ST_RECOVER);
 for(unsigned t=12;t<87;t++)game_tick(&g,0,INPUT_PUNCH|INPUT_KICK);
 assert(p->state==ST_RISE&&p->tick==0&&!p->queued_attack&&p->y==p->rise_y);
 for(unsigned t=0;t<ARCADE_RISE_TICKS-1;t++)game_tick(&g,0,INPUT_PUNCH|INPUT_KICK);
 assert(p->state==ST_RISE);game_tick(&g,0,0);assert(p->state==ST_IDLE&&!p->queued_attack);
 recover(&g);p->state=ST_DOWN;p->health=0;for(unsigned t=0;t<200;t++)game_tick(&g,0,INPUT_PUNCH|INPUT_KICK);
 assert(p->state==ST_DOWN&&!p->recovery_bonus);
 puts("PASS: fresh-input recovery, capped bonus, no held-button bonus, no zero-HP revival, full rise, pause and no queued punch");
 for(unsigned role=0;role<2;role++){
  recover(&g);p->state=ST_RISE;p->actor=role;p->tick=0;unsigned count[3]={0};
  for(unsigned t=0;t<ARCADE_RISE_TICKS;t++){
   p->tick=t;unsigned pose=game_pose(p);
   unsigned index=pose-(role?JAKE_RISE_POSE_0:HULK_RISE_POSE_0);assert(index<3);++count[index];
   int original=t<26?arcade_animation_sample(role?0x181ec:0x181fc,t):arcade_animation_sample(0x11e36,t-26);
   assert(original==(int)(index<2?(role?110:112)+index:104));
  }
  assert(count[0]==13&&count[1]==13&&count[2]==17);
 }
 game_reset(&g);g.cpu=false;p=&g.fighters[0];p->state=ST_RISE;p->tick=0;
 for(unsigned t=0;t<RISE_TICKS-1;t++)game_tick(&g,0,0);
 assert(p->state==ST_RISE);game_tick(&g,0,0);assert(p->state==ST_IDLE);
 puts("PASS: both get-up pose variants use ROM descriptor durations 13/13/17 without changing legacy training timing");
}
static void cpu_attacks(void){
 game_t g;
 for(unsigned ch=0;ch<10;ch++)for(unsigned gap=40;gap<=60;gap+=20){
  game_match_start(&g,GAME_TAG,cast);g.ticks=60;g.fighters[1].character=ch;
  g.fighters[0].x=100*256;g.fighters[1].x=(100+gap)*256;g.fighters[0].y=g.fighters[1].y=210*256;
  game_tick(&g,0,0);assert(g.fighters[1].state==(gap==60?ST_KICK:ST_PUNCH));
  assert(g.fighters[1].attack_serial==1);
 }
 game_match_start(&g,GAME_TAG,cast);g.ticks=60;g.fighters[1].attack_serial=2;
 g.fighters[0].x=100*256;g.fighters[1].x=140*256;g.fighters[0].y=g.fighters[1].y=210*256;
 game_tick(&g,0,0);assert(g.fighters[1].state==ST_KICK&&g.fighters[1].attack_serial==3);
 g.cpu=false;g.fighters[1].state=ST_IDLE;g.fighters[1].cooldown=0;game_tick(&g,0,0);assert(g.fighters[1].state==ST_IDLE);
 game_match_start(&g,GAME_TAG,cast);g.ticks=60;
 g.fighters[0].x=100*256;g.fighters[1].x=180*256;
 g.fighters[0].y=g.fighters[1].y=210*256;
 g.fighters[1].health=25;g.fighters[1].stamina_tier=2;g.fighters[1].state=ST_RUN;g.fighters[1].run_speed=15;g.fighters[1].facing=-1;
 game_tick(&g,0,0);
 assert(g.fighters[1].state!=ST_RUN_ATTACK&&!g.fighters[1].attack_serial);
 puts("PASS: CPU punch/kick by range, alternating short-range attacks, all ten characters, CPU-off and tag retreat cancels running attack");
}
static void results(void){
 game_t g;game_match_start(&g,GAME_TAG,cast);g.cpu=false;
 match_result_t r={0},sentinel;memset(&sentinel,0x55,sizeof(sentinel));r=sentinel;
 assert(!match_result_capture(&r,&g)&&!memcmp(&r,&sentinel,sizeof(r)));
 g.fighters[0].x=24*256;g.fighters[0].y=170*256;game_tick(&g,0,INPUT_TAG);
 assert(g.fighters[0].character==7&&g.fighters[2].character==0);
 g.fighters[0].health=70;g.hits[0]=9;g.finished=true;g.winner=0;g.finish_reason=FINISH_PIN;
 g.rescues=2;g.blocks=3;g.throws=4;
 assert(match_result_capture(&r,&g));assert(r.fighters[0].character==7&&r.fighters[0].health==70&&r.fighters[0].hits==9);
 assert(r.tags==1&&r.rescues==2&&r.blocks==3&&r.throws==4&&r.winner==0&&!strcmp(match_result_reason(&r),"PIN FALL"));
 unsigned retry[6];match_result_retry_roster(&r,retry);assert(!memcmp(retry,cast,sizeof(cast)));
 g.fighters[0].health=1;assert(r.fighters[0].health==70);
 match_history_t h={0};assert(!match_history_recent(&h,0));
 for(unsigned i=0;i<12;i++){g.ticks=i;assert(match_history_record(&h,&g));}
 assert(h.count==8&&match_history_recent(&h,0)->elapsed_ticks==11&&match_history_recent(&h,7)->elapsed_ticks==4&&!match_history_recent(&h,8));
 game_match_start(&g,GAME_TAG,cast);g.time_left=1;g.clock_phase=56445;game_tick(&g,0,0);
 assert(g.finished&&g.finish_reason==FINISH_TIME&&match_result_capture(&r,&g)&&!strcmp(match_result_reason(&r),"TIME UP"));
 game_reset(&g);g.fighters[0].health=g.fighters[1].health=0;game_tick(&g,0,0);assert(g.finish_reason==FINISH_DOUBLE_KO);
 assert(match_result_capture(&r,&g)&&!strcmp(match_result_reason(&r),"DOUBLE KO"));
 game_match_start(&g,GAME_RUMBLE,cast);g.fighters[1].outside=true;g.fighters[1].y=320*256;game_tick(&g,0,0);
 assert(!g.finished&&g.finish_reason==FINISH_NONE&&!match_result_capture(&r,&g));
 puts("PASS: immutable final result, character identity after tag, original retry roster, eight-entry history, finish causes and no intermediate Rumble results");
}
int main(void){recovery();cpu_attacks();results();}
