#include "game.h"
#include "arcade_stamina.h"
#include <assert.h>
#include <stdio.h>
static void ticks(game_t *g,unsigned n){while(n--)game_tick(g,0,0);}
int main(void){unsigned r[6]={0,2,1,3,4,5};game_t g;game_match_start(&g,GAME_TAG,r);g.cpu=false;
 /* Waiting partners are always painted before side/front ropes. */unsigned order[GAME_DRAW_CAPACITY],n=game_render_plan(&g,order),p2=99,side=99,front=99;for(unsigned i=0;i<n;i++){if(order[i]==DRAW_FIGHTER_2)p2=i;if(order[i]==DRAW_SIDE_ROPES)side=i;if(order[i]==DRAW_FRONT_ROPES)front=i;}assert(p2<side&&p2<front);
 fighter_t *mate=&g.fighters[2];mate->health=mate->max_health-2;ticks(&g,64);assert(mate->health==mate->max_health);
 mate->power_meter=478;ticks(&g,2);assert(mate->power_up&&mate->apron_state==APRON_ROPE_SHAKE);
 /* Apron strike: put enemy by the player's corner without moving the waiting partner through ropes. */g.fighters[1].x=10*256;g.fighters[1].y=157*256;unsigned hp=g.fighters[1].health;ticks(&g,60);assert(mate->apron_attacks>=1&&g.fighters[1].health<hp&&game_partner_waiting(&g,2));
 /* Power-up doubles a normal live strike. */g.fighters[0].power_up=true;g.fighters[0].x=100*256;g.fighters[1].x=140*256;g.fighters[0].y=g.fighters[1].y=200*256;g.fighters[0].state=ST_IDLE;g.fighters[1].state=ST_IDLE;hp=g.fighters[1].health;game_tick(&g,0,INPUT_PUNCH);ticks(&g,35);assert(hp-g.fighters[1].health==2*ARCADE_STATIONARY_PUNCH_DAMAGE);
 /* Leaving the ring cancels power-up as observed in the arcade. */g.fighters[0].power_up=true;g.fighters[0].x=game_ring_left(200)*256;g.fighters[0].y=200*256;g.fighters[0].state=ST_IDLE;g.fighters[0].cooldown=0;game_tick(&g,0,INPUT_RING);ticks(&g,60);assert(g.fighters[0].outside&&!g.fighters[0].power_up);
 puts("PASS: apron layer, fast partner recovery, Power Up, corner strike and ring-out cancellation");}
