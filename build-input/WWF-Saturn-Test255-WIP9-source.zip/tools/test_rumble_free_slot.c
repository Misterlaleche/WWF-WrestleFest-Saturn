#include "arcade_rumble.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
int main(void){
 FILE *f=fopen("program.bin","rb");assert(f);uint8_t a[8],b[8];assert(fseek(f,0x10af0,SEEK_SET)==0);assert(fread(a,1,8,f)==8);assert(fseek(f,0x10b26,SEEK_SET)==0);assert(fread(b,1,8,f)==8);fclose(f);
 const uint8_t pro[8]={0x48,0xe7,0x60,0x80,0x41,0xf9,0x00,0x1c};for(unsigned i=0;i<8;i++){assert(a[i]==pro[i]);assert(b[i]==pro[i]);}
 uint16_t v[6]={1,1,0,1,0,1};assert(arcade_rumble_reverse_free_slot(v)==4);v[4]=1;assert(arcade_rumble_reverse_free_slot(v)==2);v[2]=1;assert(arcade_rumble_reverse_free_slot(v)==-1);
 puts("PASS Test116: $10AF0/$10B26 use six-word reverse free-slot scans (5 -> 0)");
}
