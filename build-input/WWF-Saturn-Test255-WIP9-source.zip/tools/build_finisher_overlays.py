#!/usr/bin/env python3
"""Build on-demand WrestleFest finisher overlays from the user's original ROM regions.

Core Cxx.PAK banks remain at 207 always-resident combat frames.  Each mapped
trademark move gets one Fxx.PAK overlay containing only its original arcade
compositions, including per-opponent pair variants when the ROM composition is
partner-dependent.  Overlay frames keep the original piece interleave and a
generated role-run table tells Saturn which palette belongs to each run.
"""
from pathlib import Path
import argparse, hashlib, itertools, json, struct, sys
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
import arcade_composition as comp
from build_combat_assets import pack_blocks, fnv

ROOT=Path(__file__).resolve().parents[1]
# ch, name, descriptor, action, poses, durations, pair-dependent
FIN=[
 dict(ch=0,name='LEGDROP',desc=64,action=53,poses=[132,133,230,231,232],dur=[8,20,16,0xff00,16],pair=False),
 dict(ch=1,name='GORILLA_PRESS',desc=58,action=47,poses=[263,264,272,526,527,0],dur=[6,10,8,24,16,56],pair=True),
 dict(ch=2,name='DDT',desc=63,action=52,poses=[144,145,312,313,314,315,316,317,104],dur=[8,9,10,8,8,0xff00,16,16,40],pair=True),
 dict(ch=3,name='BOSS_MAN_SLAM',desc=60,action=49,poses=[194,195,196,197,198,199,200,201],dur=[32,4,4,4,4,0xff00,8,28],pair=True),
 dict(ch=4,name='SUPLEX',desc=51,action=40,poses=[334,335,336,337],dur=[16,16,0xff00,32],pair=True),
 dict(ch=5,name='BACK_BREAKER',desc=141,action=137,poses=[269,452,453,454,455],dur=[24,16,16,12,12],pair=True),
 dict(ch=6,name='COBRA_CLUTCH',desc=70,action=59,poses=[411,412,413,414,415],dur=[8,12,32,24,24],pair=True),
 dict(ch=7,name='PERFECT_PLEX',desc=38,action=26,poses=[324,325,326,327,328],dur=[12,8,10,10,12],pair=True),
 dict(ch=8,name='VERTICAL_SPLASH',desc=46,action=35,poses=[470,471],dur=[0xff00,16],pair=False),
 dict(ch=9,name='MILLION_DOLLAR_DREAM',desc=65,action=54,poses=[248,299,300,301],dur=[8,16,20,20],pair=True),
]

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--program',type=Path,required=True)
 ap.add_argument('--sprites',type=Path,required=True)
 a=ap.parse_args(); comp.load_program(a.program)
 region=np.frombuffer(a.sprites.read_bytes(),np.uint8).reshape(4,65536,32)
 decoded={}
 def tile(code):
  if code not in decoded:
   bits=np.unpackbits(region[:,code,:],axis=1).reshape(4,2,16,8).transpose(0,2,1,3).reshape(4,16,16)
   px=np.sum(bits*np.array([8,4,2,1],np.uint8)[:,None,None],axis=0,dtype=np.uint8)
   decoded[code]=((px[:,::2]<<4)|px[:,1::2]).tobytes()
  return decoded[code]

 reports=[]; all_maps={}; all_runs={}; sizes=[0]*10; hashes=[0]*10; frames_count=[0]*10
 for f in FIN:
  textures=[]; lookup={}; frames=[]; fmap={}; runs={}
  partners=[255] if not f['pair'] else [p for p in range(10) if p!=f['ch']]
  supported_partners=[];missing_partners=[]
  for partner in partners:
   actual_partner=(2 if f['ch']!=2 else 0) if partner==255 else partner
   pending=[];valid=True
   for phase,pose in enumerate(f['poses']):
    rec_raw=[];seq=[]
    try: pieces=comp.commands(f['ch'],pose,partner=actual_partner)
    except Exception: pieces=[]
    for piece in pieces:
     bank=piece['bank']
     if f['pair']:
      if bank not in (f['ch'],actual_partner): continue
      role=0 if bank==f['ch'] else 1
     else:
      if bank!=f['ch']: continue
      role=0
     px=tile(piece['code'])
     if not any(px): continue
     x=piece['x']-160; y=piece['y']-160
     rec_raw.append((px,[-x-16+11,y+10,(int(piece['fx'])|(int(piece['fy'])<<1))^1]))
     if seq and seq[-1][0]==role: seq[-1][1]+=1
     else: seq.append([role,1])
    if not rec_raw: valid=False;break
    pending.append((phase,pose,rec_raw,seq))
   if not valid:
    missing_partners.append(partner);continue
   supported_partners.append(partner)
   for phase,pose,rec_raw,seq in pending:
    frame=len(frames);fmap[(partner,phase)]=frame;rec=[]
    for px,fields in rec_raw:
     if px not in lookup:lookup[px]=len(textures);textures.append(px)
     rec.append([lookup[px],*fields])
    frames.append(rec);runs[frame]=seq
  data=pack_blocks(frames,textures,block_tiles=32)
  path=ROOT/f'cd/F{f["ch"]:02}.PAK';path.write_bytes(data)
  sizes[f['ch']]=len(data);hashes[f['ch']]=fnv(data);frames_count[f['ch']]=len(frames)
  all_maps[f['ch']]=fmap;all_runs[f['ch']]=runs
  reports.append(dict(character=f['ch'],name=f['name'],descriptor=f['desc'],action=f['action'],pair=f['pair'],
                      poses=f['poses'],durations=f['dur'],frames=len(frames),tiles=len(textures),bytes=len(data),hash=fnv(data),
                      opponents=0 if not f['pair'] else len(supported_partners),supported_partners=supported_partners,missing_partners=missing_partners))

 # Header: local frame lookup + exact role interleave per overlay.
 lines=['#ifndef WWF_FINISHER_ASSETS_H','#define WWF_FINISHER_ASSETS_H','#include <stdint.h>',
        'typedef struct {uint8_t role,count;} finisher_run_t;',
        'static const unsigned finisher_overlay_bytes[10]={'+','.join(map(str,sizes))+'};',
        'static const unsigned finisher_overlay_hash[10]={'+','.join(str(x)+'U' for x in hashes)+'};',
        'static const unsigned finisher_overlay_frames[10]={'+','.join(map(str,frames_count))+'};',
        f'#define FINISHER_OVERLAY_MAX_BYTES {max(sizes)}U',
        'static inline unsigned finisher_asset_phase_count(unsigned ch){switch(ch){']
 for f in FIN: lines.append(f' case {f["ch"]}:return {len(f["poses"])};')
 lines+=[' default:return 0;}}','static inline unsigned finisher_asset_frame(unsigned ch,unsigned partner,unsigned phase){switch(ch){']
 for f in FIN:
  fmap=all_maps[f['ch']]
  if not f['pair']:
   lines.append(f' case {f["ch"]}:return phase<{len(f["poses"])}?phase:0xffffU;')
  else:
   lines.append(f' case {f["ch"]}:if(phase>={len(f["poses"])}||partner=={f["ch"]})return 0xffffU;switch(partner){{')
   for partner in range(10):
    if partner==f['ch'] or (partner,0) not in fmap:continue
    lines.append(f'  case {partner}:return {fmap[(partner,0)]}+phase;')
   lines.append(' }return 0xffffU;')
 lines+=[' default:return 0xffffU;}}',
         'static inline const finisher_run_t *finisher_asset_runs(unsigned ch,unsigned frame,unsigned *count){']
 # one static pool per character; frame offsets are local to each Fxx.PAK
 for f in FIN:
  pool=[];offs={}
  for frame in range(frames_count[f['ch']]):
   seq=all_runs[f['ch']][frame];offs[frame]=(len(pool),len(seq));pool.extend(seq)
  lines.append(f' static const finisher_run_t p{f["ch"]}[]={{'+','.join('{%d,%d}'%(r,c) for r,c in pool)+'};')
 lines.append(' switch(ch){')
 for f in FIN:
  pool=[];offs={}
  for frame in range(frames_count[f['ch']]):
   seq=all_runs[f['ch']][frame];offs[frame]=(len(pool),len(seq));pool.extend(seq)
  lines.append(f' case {f["ch"]}:switch(frame){{')
  for frame,(off,cnt) in offs.items():lines.append(f'  case {frame}:*count={cnt};return &p{f["ch"]}[{off}];')
  lines.append(' }break;')
 lines+=[' }*count=0;return 0;','}',
         'static inline int finisher_asset_pair(unsigned ch){switch(ch){']
 for f in FIN:lines.append(f' case {f["ch"]}:return {1 if f["pair"] else 0};')
 lines+=[' default:return 0;}}','#endif']
 (ROOT/'finisher_assets.h').write_text('\n'.join(lines)+'\n')

 # Standard-low-RAM guarantee: worst six compact Cxx packs + largest overlay.
 core_sizes=[(ROOT/f'cd/C{ch:02}.PAK').stat().st_size for ch in range(10)]
 aligned=[(s+2047)&~2047 for s in core_sizes]
 worst_core=max(sum(aligned[i] for i in combo) for combo in itertools.combinations(range(10),6))
 max_overlay_aligned=(max(sizes)+2047)&~2047
 report=dict(version='V0.029',architecture='one on-demand Fxx.PAK per finisher character',core_frames=207,
             core_sizes=core_sizes,worst_six_core_bytes=worst_core,overlay_reports=reports,
             max_overlay_bytes=max(sizes),max_overlay_aligned_bytes=max_overlay_aligned,
             worst_six_plus_max_overlay=worst_core+max_overlay_aligned,low_ram_capacity=1048576,
             standard_low_ram_fits=worst_core+max_overlay_aligned<=1048576,
             program_sha256=hashlib.sha256(comp.P).hexdigest(),sprite_region_sha256=hashlib.sha256(region.tobytes()).hexdigest(),
             same_character_pair_policy='gated until original role ownership can be disambiguated')
 (ROOT/'docs/finisher-overlay-build.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report,indent=2))
 if not report['standard_low_ram_fits']:raise SystemExit('overlay does not fit standard LWRAM with worst six core banks')

if __name__=='__main__':main()
