#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(void){FILE*f=fopen("main.c","rb");assert(f);fseek(f,0,SEEK_END);long n=ftell(f);rewind(f);char*s=malloc(n+1);assert(s);assert(fread(s,1,n,f)==(size_t)n);s[n]=0;fclose(f);assert(strstr(s,"if(loading.kind==LOAD_BOOT)"));assert(strstr(s,"else if(session.mode)"));assert(strstr(s,"loading_tag_tips"));assert(strstr(s,"loading_rumble_tips"));assert(strstr(s,"NOW LOADING"));assert(!strstr(s,"HOLD ON, BROTHER!"));assert(!strstr(s,"GET READY FOR ACTION!"));free(s);puts("PASS Test228: invented loading slogans removed; long/short loads retain explicit NOW LOADING status plus mode-context ROM-exact arcade help wording");}