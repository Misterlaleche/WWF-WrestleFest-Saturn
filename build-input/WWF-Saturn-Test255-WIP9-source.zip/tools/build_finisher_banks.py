#!/usr/bin/env python3
"""LEGACY V0.028: expand resident WFC2 banks with original finisher compositions.

Consumes the user's assembled WrestleFest program and sprite regions.  Pair
moves allocate one shared logical frame per phase/opponent; the attacker and
victim records live at the same frame index in their respective character
banks, while a generated run table preserves the arcade piece interleave.
No ROM bytes are copied into the output package.
"""
from pathlib import Path
import argparse,hashlib,itertools,json,struct,sys
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
import arcade_composition as comp
import lz4_codec
from build_combat_assets import pack_blocks,fnv
ROOT=Path(__file__).resolve().parents[1]
FIN=[
 dict(ch=0,name='LEGDROP',poses=[132,133,230,231,232],pair=False),
 dict(ch=2,name='DDT',poses=[144,145,312,313,314,315,316,317,104],pair=True),
 dict(ch=3,name='BOSS_MAN_SLAM',poses=[194,195,196,197,198,199,200,201],pair=True),
 dict(ch=7,name='PERFECT_PLEX',poses=[324,325,326,327,328],pair=True),
]

def read_wfc2(data):
 h=struct.unpack_from('>8I',data)
 assert h[0]==0x57464332
 frames=[]
 for i in range(h[1]):
  first,count=struct.unpack_from('>HH',data,32+i*4)
  frames.append([list(struct.unpack_from('>HhhH',data,32+h[1]*4+(first+j)*8)) for j in range(count)])
 textures=[]
 blocks=h[7];off=h[4]
 for i in range(blocks):
  pos,cs,raw=struct.unpack_from('>III',data,off+i*12)
  chunk=lz4_codec.decompress(data[pos:pos+cs],raw)
  assert len(chunk)%128==0
  textures.extend(chunk[j:j+128] for j in range(0,len(chunk),128))
 assert len(textures)==h[3]
 return frames,textures

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--program',type=Path,required=True);ap.add_argument('--sprites',type=Path,required=True)
 a=ap.parse_args();comp.load_program(a.program)
 region=np.frombuffer(a.sprites.read_bytes(),np.uint8).reshape(4,65536,32);decoded={}
 def tile(code):
  if code not in decoded:
   bits=np.unpackbits(region[:,code,:],axis=1).reshape(4,2,16,8).transpose(0,2,1,3).reshape(4,16,16)
   px=np.sum(bits*np.array([8,4,2,1],np.uint8)[:,None,None],axis=0,dtype=np.uint8)
   decoded[code]=((px[:,::2]<<4)|px[:,1::2]).tobytes()
  return decoded[code]
 banks=[];lookups=[]
 old_sizes=[]
 for ch in range(10):
  data=(ROOT/f'cd/C{ch:02}.PAK').read_bytes();old_sizes.append(len(data));frames,textures=read_wfc2(data)
  assert len(frames)==207
  banks.append([frames,textures]);lookups.append({d:i for i,d in enumerate(textures)})
 base=207;slots=[];runs={};cursor=base
 for f in FIN:
  if not f['pair']:
   for phase,pose in enumerate(f['poses']):
    slots.append(dict(frame=cursor,finisher=f['ch'],partner=255,phase=phase,pose=pose,pair=False));cursor+=1
  else:
   for partner in range(10):
    if partner==f['ch']:continue
    for phase,pose in enumerate(f['poses']):
     slots.append(dict(frame=cursor,finisher=f['ch'],partner=partner,phase=phase,pose=pose,pair=True));cursor+=1
 final_frames=cursor
 for frames,_ in banks:frames.extend([[] for _ in range(final_frames-len(frames))])
 def add_record(bank,frame,piece):
  px=tile(piece['code'])
  if not any(px):return False
  lookup=lookups[bank];textures=banks[bank][1]
  if px not in lookup:lookup[px]=len(textures);textures.append(px)
  x=piece['x']-160;y=piece['y']-160
  banks[bank][0][frame].append([lookup[px],-x-16+11,y+10,(int(piece['fx'])|(int(piece['fy'])<<1))^1])
  return True
 for s in slots:
  attacker=s['finisher'];partner=s['partner'] if s['pair'] else (2 if attacker!=2 else 0)
  cmds=comp.commands(attacker,s['pose'],partner=partner)
  seq=[]
  for piece in cmds:
   bank=piece['bank']
   if s['pair']:
    assert bank in (attacker,partner),(s,bank)
    role=0 if bank==attacker else 1
   else:
    if bank!=attacker:continue
    role=0
   if not add_record(bank,s['frame'],piece):continue
   if seq and seq[-1][0]==role:seq[-1][1]+=1
   else:seq.append([role,1])
  assert seq,(s,'empty original composition')
  runs[s['frame']]=seq
 sizes=[];hashes=[];tile_counts=[]
 for ch,(frames,textures) in enumerate(banks):
  data=pack_blocks(frames,textures);(ROOT/f'cd/C{ch:02}.PAK').write_bytes(data)
  sizes.append(len(data));hashes.append(fnv(data));tile_counts.append(len(textures))
 # Update common pack dimensions/hashes.
 p=ROOT/'roster_data.h';text=p.read_text()
 import re
 text=re.sub(r'#define ROSTER_FRAMES\s+\d+',f'#define ROSTER_FRAMES {final_frames}',text)
 text=re.sub(r'static const unsigned roster_bytes\[10\]=\{.*?\};','static const unsigned roster_bytes[10]={'+','.join(map(str,sizes))+'};',text)
 text=re.sub(r'static const unsigned roster_hash\[10\]=\{.*?\};','static const unsigned roster_hash[10]={'+','.join(str(x)+'U' for x in hashes)+'};',text)
 p.write_text(text)
 # Generate compact frame/run lookup. Same logical frame index is used in both role banks.
 lines=['#ifndef WWF_FINISHER_ASSETS_H','#define WWF_FINISHER_ASSETS_H','#include <stdint.h>',
        f'#define FINISHER_FRAME_FIRST {base}',f'#define FINISHER_FRAME_COUNT {final_frames-base}',
        'typedef struct {uint8_t role,count;} finisher_run_t;',
        'typedef struct {uint16_t frame;uint8_t finisher,partner,phase,pose_count;uint16_t pose;} finisher_frame_record_t;',
        'static const finisher_frame_record_t finisher_frame_records[]={']
 for s in slots:lines.append(' {%d,%d,%d,%d,%d,%d},'%(s['frame'],s['finisher'],s['partner'],s['phase'],len(next(f['poses'] for f in FIN if f['ch']==s['finisher'])),s['pose']))
 lines+=['};','static inline unsigned finisher_asset_frame(unsigned ch,unsigned partner,unsigned phase){']
 for f in FIN:
  if not f['pair']:
   start=next(s['frame'] for s in slots if s['finisher']==f['ch']);lines.append(f' if(ch=={f["ch"]})return phase<{len(f["poses"])}?{start}+phase:0xffffU;')
  else:
   starts=[]
   for partner in range(10):
    if partner==f['ch']:continue
    starts.append((partner,next(s['frame'] for s in slots if s['finisher']==f['ch'] and s['partner']==partner)))
   lines.append(f' if(ch=={f["ch"]}){{if(phase>={len(f["poses"])}||partner=={f["ch"]})return 0xffffU;switch(partner){{')
   for partner,start in starts:lines.append(f'  case {partner}:return {start}+phase;')
   lines.append(' }return 0xffffU;}')
 lines+=[' return 0xffffU;','}',
         'static inline unsigned finisher_asset_phase_count(unsigned ch){switch(ch){case 0:return 5;case 2:return 9;case 3:return 8;case 7:return 5;default:return 0;}}',
         'static inline const finisher_run_t *finisher_asset_runs(unsigned frame,unsigned *count){']
 # Flat run pool plus offsets generated below by replace after collection.
 pool=[];offsets={}
 for frame in range(base,final_frames):
  seq=runs[frame];offsets[frame]=(len(pool),len(seq));pool.extend(seq)
 lines.append(' static const finisher_run_t pool[]={')
 lines.extend('  {%d,%d},'%(r,c) for r,c in pool);lines.append(' };')
 lines.append(' switch(frame){')
 for frame,(off,cnt) in offsets.items():lines.append(f'  case {frame}:*count={cnt};return &pool[{off}];')
 lines+=[' }*count=0;return 0;','}','#endif']
 (ROOT/'finisher_assets.h').write_text('\n'.join(lines)+'\n')
 aligned=[(x+2047)&~2047 for x in sizes];worst=max(sum(aligned[i] for i in c) for c in itertools.combinations(range(10),6))
 report=dict(version='V0.028',base_frames=base,frames_per_pack=final_frames,finisher_frames=final_frames-base,
             old_sizes=old_sizes,new_sizes=sizes,tile_counts=tile_counts,worst_six_low_ram_bytes=worst,
             low_ram_capacity=1048576,standard_low_ram_fits=worst<=1048576,
             program_sha256=hashlib.sha256(comp.P).hexdigest(),sprite_region_sha256=hashlib.sha256(region.tobytes()).hexdigest(),
             slots=slots)
 (ROOT/'docs/finisher-bank-build.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='slots'},indent=2))
if __name__=='__main__':main()
