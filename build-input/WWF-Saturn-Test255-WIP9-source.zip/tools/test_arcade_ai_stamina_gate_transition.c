#include "arcade_ai.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned char *load(size_t *n){FILE*f=fopen("program.bin","rb");assert(f);fseek(f,0,SEEK_END);*n=(size_t)ftell(f);rewind(f);unsigned char*b=malloc(*n);assert(b&&fread(b,1,*n,f)==*n);fclose(f);return b;}
int main(void){
 size_t n;unsigned char *rom=load(&n);assert(n==524288U);
 /* Exact branch body: equality gate, clear raw +$20 low byte, +$61 special cases,
    then raw +$60=$56 default or $4B for $4A/$64. */
 static const unsigned char gate[]={
  0x10,0x28,0x01,0x09,0xb0,0x28,0x00,0xbd,0x66,0x24,
  0x42,0x28,0x00,0x20,0x0c,0x28,0x00,0x4a,0x00,0x61,
  0x67,0x10,0x0c,0x28,0x00,0x64,0x00,0x61,0x67,0x08,
  0x31,0x7c,0x00,0x56,0x00,0x60,0x60,0x08,
  0x31,0x7c,0x00,0x4b,0x00,0x60
 };
 assert(!memcmp(rom+0x1e45c,gate,sizeof gate));free(rom);
 uint8_t state=0xa5;uint16_t raw60=0xbeef;
 assert(!arcade_ai_stamina_gate_transition(100,1,0x20,&state,&raw60));
 assert(state==0xa5&&raw60==0xbeef);
 state=0xa5;raw60=0xbeef;assert(arcade_ai_stamina_gate_transition(100,2,0x20,&state,&raw60));assert(state==0&&raw60==0x56);
 state=0xa5;raw60=0xbeef;assert(arcade_ai_stamina_gate_transition(100,2,0x4a,&state,&raw60));assert(state==0&&raw60==0x4b);
 state=0xa5;raw60=0xbeef;assert(arcade_ai_stamina_gate_transition(100,2,0x64,&state,&raw60));assert(state==0&&raw60==0x4b);
 puts("PASS Test144: ROM-exact stamina bucket/+109 match clears raw state +$20 low byte and selects raw +$60 $56/$4B by +$61");
}
