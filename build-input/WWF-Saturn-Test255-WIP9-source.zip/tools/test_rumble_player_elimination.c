#include "game.h"
#include <assert.h>
#include <stdio.h>
int main(void){unsigned r[10]={0,1,2,3,4,5,6,7,8,9};game_t g;game_match_start_rumble_queue(&g,r,10);g.cpu=false;g.fighters[0].outside=true;game_tick(&g,0,0);assert(g.finished&&g.finish_reason==FINISH_ELIMINATION&&g.winner==1&&!(g.active_mask&1U)&&g.eliminated==1);assert(g.rumble_next==6);puts("PASS Test117: human over-rope elimination ends Rumble immediately and never consumes a replacement entrant");}
