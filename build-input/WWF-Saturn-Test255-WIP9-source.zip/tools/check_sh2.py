#!/usr/bin/env python3
"""Compile/link the SH-2 ELF only. Does not generate a game BIN/ISO/CUE."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sdk', default=os.environ.get('YAUL_INSTALL_ROOT'))
    parser.add_argument('--host-libs', type=Path,
                        help='Optional directory for the host toolchain shared libraries')
    parser.add_argument('--force', action='store_true', help='Recompile all ELF dependencies')
    args = parser.parse_args()
    if not args.sdk:
        parser.error('Set YAUL_INSTALL_ROOT or pass --sdk')
    sdk = Path(args.sdk).resolve()
    if not (sdk / 'bin/sh2eb-elf-gcc').is_file():
        parser.error('The selected SDK does not contain bin/sh2eb-elf-gcc')
    root = Path(__file__).resolve().parents[1]
    program = re.search(r'^SH_PROGRAM\s*:=\s*(\S+)',
                        (root / 'Makefile').read_text(), re.M).group(1)
    elf = root / 'build' / (program + '.elf')
    env = dict(os.environ)
    env.update(YAUL_INSTALL_ROOT=str(sdk), YAUL_ARCH_SH_PREFIX='sh2eb-elf',
               YAUL_PROG_SH_PREFIX='', YAUL_ARCH_M68K_PREFIX='m68keb-elf',
               YAUL_OPTION_MALLOC_IMPL='tlsf', SILENT='1', NOCOLOR='1')
    env['PATH'] = str(sdk / 'bin') + os.pathsep + env.get('PATH', '')
    if args.host_libs:
        env['LD_LIBRARY_PATH'] = str(args.host_libs.resolve()) + (
            os.pathsep + env['LD_LIBRARY_PATH'] if env.get('LD_LIBRARY_PATH') else '')
    command = ['make', '-C', str(root)]
    if args.force:
        command.append('-B')
    # Yaul's make rules use absolute targets; the default target builds a disc.
    command.append(str(elf))
    result = subprocess.run(command, env=env, text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT)
    print(result.stdout, end='')
    docs = root / 'docs'
    docs.mkdir(exist_ok=True)
    (docs / 'sh2-compile.log').write_text(result.stdout)
    result.check_returncode()
    nm = subprocess.check_output(['sh2eb-elf-nm', '-n', str(elf)], env=env, text=True)
    end = re.search(r'^([0-9a-fA-F]+)\s+\w\s+___end$', nm, re.M)
    if not end:
        raise RuntimeError('SH-2 linker end symbol not found')
    static_end = int(end.group(1), 16)
    if static_end >= 0x06100000:
        raise RuntimeError('Static allocation exceeds Saturn high work RAM')
    size = subprocess.check_output(['sh2eb-elf-size', str(elf)], env=env, text=True)
    print(size, end='')
    validation = {
        'program': program,
        'target': 'SH-2 ELF only',
        'compile_link': 'passed',
        'static_end': f'0x{static_end:08x}',
        'elf_sha256': hashlib.sha256(elf.read_bytes()).hexdigest(),
        'size_output': size,
        'link_warnings': [line for line in result.stdout.splitlines() if 'warning:' in line],
        'disc_generation_requested': False,
        'hardware_test': False,
        'mister_test': False,
        'mednafen_test': False,
        'note': 'Static end is not a runtime heap/stack or performance certification.',
    }
    (docs / 'sh2-validation.json').write_text(json.dumps(validation, indent=2) + '\n')


if __name__ == '__main__':
    main()
