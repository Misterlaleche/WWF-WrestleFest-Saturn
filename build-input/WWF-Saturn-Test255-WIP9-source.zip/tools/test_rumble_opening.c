#include "game.h"
#include "presentation.h"
#include <assert.h>
#include <stdio.h>
int main(void){for(unsigned i=0;i<6;i++)for(unsigned j=i+1;j<6;j++)assert(rumble_intro_x(i)!=rumble_intro_x(j)||rumble_intro_y(i)!=rumble_intro_y(j));assert(rumble_intro_y(0)>rumble_intro_y(2)&&rumble_intro_y(2)>rumble_intro_y(4));unsigned r[6]={0,2,7,1,4,5};game_t g;game_match_start(&g,GAME_RUMBLE,r);assert(game_player_marker_visible(&g));g.active_mask&=~1U;assert(!game_player_marker_visible(&g));puts("PASS Test114: Royal opening uses six non-overlapping depth-ranked anchors and live player slot exposes a dedicated 1P marker condition");}
