#include "../render_pose.h"
#include "../roster_data.h"
#include <assert.h>
#include <stdio.h>
int main(void){fighter_t f={0};
 for(unsigned ch=0;ch<10;ch++){f.character=ch;for(unsigned raw=0;raw<600;raw++)assert(!render_pose_registered_fallback(&f,raw));}
 assert(roster_arcade_frame_character(2,267)<ROSTER_FRAMES);assert(roster_arcade_frame_character(3,267)<ROSTER_FRAMES);
 puts("PASS Test247 reduction regression: recovered resident art remains mapped and legacy fallback remains empty at Test252");
}
