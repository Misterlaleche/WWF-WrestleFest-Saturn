#include "finisher_runtime.h"
#include <assert.h>
#include <stdio.h>
#define FP 256
static void start(game_t *g,unsigned a,unsigned b){unsigned c[6]={a,b,4,5,6,8};game_match_start(g,GAME_TAG,c);g->cpu=false;}
static void grapple(game_t *g,unsigned ch,unsigned opp){start(g,ch,opp);g->fighters[0].x=120*FP;g->fighters[1].x=160*FP;g->fighters[0].facing=1;game_tick(g,0,INPUT_GRAB);assert(g->pair==PAIR_HOLD);}
int main(void){game_t g;
 for(unsigned ch_i=0;ch_i<5;ch_i++){unsigned ch=(unsigned[]){1,2,4,5,7}[ch_i];unsigned opp=ch==5?0:3;grapple(&g,ch,opp);assert(game_finisher_probe(&g,0)==FINISHER_PROBE_READY);}
 start(&g,3,0);g.fighters[0].x=120*FP;g.fighters[0].y=190*FP;g.fighters[1].x=180*FP;g.fighters[1].y=190*FP;g.fighters[1].state=ST_RUN;g.fighters[1].whipped=true;assert(game_finisher_probe(&g,0)==FINISHER_PROBE_READY);g.fighters[1].whipped=false;assert(game_finisher_probe(&g,0)==FINISHER_PROBE_WRONG_CONTEXT);
 start(&g,0,2);g.fighters[0].x=110*FP;g.fighters[0].y=180*FP;g.fighters[1].x=150*FP;g.fighters[1].y=200*FP;g.fighters[1].rise_y=200*FP;g.fighters[1].state=ST_DOWN;g.fighters[1].tick=12;assert(game_finisher_probe(&g,0)==FINISHER_PROBE_READY);
 start(&g,8,2);g.fighters[0].x=110*FP;g.fighters[0].y=180*FP;g.fighters[1].x=150*FP;g.fighters[1].y=200*FP;g.fighters[1].rise_y=200*FP;g.fighters[1].state=ST_DOWN;g.fighters[1].tick=12;assert(game_finisher_probe(&g,0)==FINISHER_PROBE_UNMAPPED);
 for(unsigned ch_i=0;ch_i<2;ch_i++){unsigned ch=(unsigned[]){6,9}[ch_i];start(&g,ch,0);g.fighters[0].x=120*FP;g.fighters[1].x=150*FP;g.fighters[0].y=g.fighters[1].y=200*FP;g.fighters[0].facing=g.fighters[1].facing=1;assert(game_finisher_probe(&g,0)==FINISHER_PROBE_READY);}
 grapple(&g,2,2);assert(game_finisher_probe(&g,0)==FINISHER_PROBE_MISSING_GRAPHICS);
 grapple(&g,5,4);assert(game_finisher_probe(&g,0)==FINISHER_PROBE_MISSING_GRAPHICS);
 puts("PASS: nine high-confidence finisher contexts are probed; Earthquake candidate plus same-bank/incomplete variants are safely gated");return 0;}
