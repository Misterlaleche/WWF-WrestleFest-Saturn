#include <assert.h>
#include <stdio.h>
#include "render_pose.h"
int main(void){fighter_t f={0};
 const unsigned raw[]={104,114,123,206,210,248,263,265,292,294,395,516,520};
 for(unsigned i=0;i<sizeof(raw)/sizeof(raw[0]);i++)assert(!render_pose_registered_fallback(&f,raw[i]));
 puts("PASS Test212 guard regression: Test252 keeps the legacy fallback hook fail-closed; exact resident/overlay renderers must intercept recovered families");
}
