#include <assert.h>
#include <stdio.h>
#include "arcade_ringside.h"
int main(void){
 int x=0x120,y=0x230,z=0x40;
 unsigned s=arcade_ringside_state2_integrate(&x,&y,&z,0x18,-0x0c,-0x08,0);
 assert(x==0x138&&y==0x224&&z==0x38&&s==ARCADE_OBJECT_THROWN_STATE);
 s=arcade_ringside_state2_integrate(&x,&y,&z,-0x04,0x03,-0x10,ARCADE_OBJECT_STATE2_COLLISION_BIT);
 assert(x==0x134&&y==0x227&&z==0x28&&s==ARCADE_OBJECT_POST_THROW_STATE);
 puts("PASS: ROM $FE82 state-2 tail integrates +$38/+$3A/+$3C into XYZ and collision bit 4 advances state 2 -> 4");
 return 0;
}
