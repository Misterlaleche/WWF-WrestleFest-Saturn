#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void seq(long o,const uint8_t*p,size_t n){FILE*f=fopen("program.bin","rb");assert(f);uint8_t*b=malloc(n);assert(b);assert(fseek(f,o,SEEK_SET)==0&&fread(b,1,n,f)==n);fclose(f);assert(!memcmp(b,p,n));free(b);}
int main(void){
 const uint8_t a[]={0x35,0x7c,0x00,0x16,0x00,0x68};seq(0x152b4,a,sizeof a);seq(0x152ee,a,sizeof a); const uint8_t b[]={0x35,0x7c,0x00,0x5e,0x00,0x60};seq(0x152e8,b,sizeof b);
 puts("PASS Test193: Perfect Plex has two exact +$68=$16 (22) victim writes; alternate branch also writes raw victim +$60=$5E");return 0;}
