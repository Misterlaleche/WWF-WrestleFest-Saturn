#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "object_assets.h"
#include "roster_pack.h"
#include "render_pose.h"
#include "ground_pair_assets.h"

static uint16_t be16(const uint8_t *p){return (uint16_t)(((uint16_t)p[0]<<8)|p[1]);}
static uint32_t fnv1a(const uint8_t *p,size_t n){uint32_t h=2166136261U;while(n--)h=(h^*p++)*16777619U;return h;}
static uint16_t rgb444_to_rgb555(uint16_t v){
 unsigned r=v&15U,g=(v>>4)&15U,b=(v>>8)&15U;
 r=(r<<1)|(r>>3);g=(g<<1)|(g>>3);b=(b<<1)|(b>>3);
 return (uint16_t)(0x8000U|(b<<10)|(g<<5)|r);
}
static uint8_t *read_all(const char *name,size_t *size){
 FILE *f=fopen(name,"rb");assert(f);assert(!fseek(f,0,SEEK_END));long n=ftell(f);assert(n>=0);rewind(f);
 uint8_t *p=malloc((size_t)n);assert(p);assert(fread(p,1,(size_t)n,f)==(size_t)n);fclose(f);*size=(size_t)n;return p;
}
int main(void){
 size_t ps=0,os=0,pals=0;uint8_t *program=read_all("program.bin",&ps);uint8_t *obj=read_all("cd/OBJ15.PAK",&os);uint8_t *pal=read_all("assets/OBJECT15.PAL",&pals);
 assert(ps>OBJECT_PALETTE_SOURCE_OFFSET+32U);assert(os==OBJECT_PACK_BYTES);assert(pals==32U);assert(fnv1a(obj,os)==OBJECT_PACK_HASH);
 assert(!memcmp(program+0x2B26,"\x47\xf9\x00\x00\x2f\x22",6));
 for(unsigned i=0;i<16;i++){uint16_t src=be16(program+OBJECT_PALETTE_SOURCE_OFFSET+i*2U);assert(be16(pal+i*2U)==rgb444_to_rgb555(src));}
 roster_pack_t pack={0};assert(roster_pack_open(&pack,obj,os,OBJECT_PACK_FRAMES));assert(pack.frames==100U);
 unsigned palette_mask=0,bank15_frames=0,records=0;
 for(unsigned ch=0;ch<10;ch++)for(unsigned pose=114;pose<=123;pose++){
  unsigned frame=object_asset_frame(ch,pose),nr=0,sum=0;assert(frame<OBJECT_PACK_FRAMES);
  const object_run_t *runs=object_asset_runs(frame,&nr);assert(runs&&nr);
  bool has15=false;for(unsigned r=0;r<nr;r++){assert(runs[r].count);assert(runs[r].palette<16U);sum+=runs[r].count;palette_mask|=1U<<runs[r].palette;if(runs[r].palette==15U)has15=true;}
  assert(has15);bank15_frames++;
  unsigned count=be16(obj+34U+frame*4U);assert(sum==count);records+=count;
 }
 assert(bank15_frames==100U);assert(palette_mask==OBJECT_REQUIRED_PALETTE_MASK);assert(records==pack.records);
 /* Test252 fallback audit: every family that was in Test251's explicit registry
    is now exact-resident or intercepted by Gxy/OBJ15 before render_pose. */
 fighter_t f={0};
 const unsigned gp[]={206,207,208,209,210};f.state=ST_GROUND_PICKUP;for(unsigned i=0;i<5;i++)assert(!render_pose_registered_fallback(&f,gp[i]));
 const unsigned ga[]={248,263,264,265,292,293,294,516,517,518,519,520};f.state=ST_GROUND_ATTACK;for(unsigned i=0;i<12;i++)assert(!render_pose_registered_fallback(&f,ga[i]));
 f.state=ST_OBJECT_USE;for(unsigned raw=114;raw<=123;raw++)assert(!render_pose_registered_fallback(&f,raw));
 unsigned pair_hits=0;for(unsigned a=0;a<10;a++)for(unsigned p=0;p<10;p++)if(a!=p){for(unsigned i=0;i<5;i++)pair_hits+=ground_pair_asset_available(a,p,gp[i]);for(unsigned i=0;i<12;i++)pair_hits+=ground_pair_asset_available(a,p,ga[i]);}
 assert(pair_hits==873U);
 free(program);free(obj);free(pal);
 puts("PASS Test252: bank15 palette and 100 object compositions are ROM-exact/separate; Test212 registry is empty after 873 Gxy + OBJ15 closure");
}
