#include <assert.h>
#include <stdio.h>
#include "game.h"
#include "arcade_ringside.h"
static const unsigned roster[6]={0,1,2,3,4,5};
static void prep(game_t *g,unsigned obj){game_match_start(g,GAME_TAG,roster);g->cpu=false;g->time_left=9999;fighter_t *p=&g->fighters[0];ringside_object_t *o=&g->ringside_objects[obj];p->outside=true;p->state=ST_IDLE;p->cooldown=0;p->held_object=0;p->x=o->x;p->y=o->y;p->rise_y=p->y;}
int main(void){game_t g;prep(&g,0);game_tick(&g,0,INPUT_PUNCH);assert(g.fighters[0].state==ST_OBJECT_PICKUP&&g.fighters[0].held_object==1);prep(&g,1);game_tick(&g,0,INPUT_KICK);assert(g.fighters[0].state==ST_OBJECT_PICKUP&&g.fighters[0].held_object==2);prep(&g,0);game_tick(&g,0,INPUT_PUNCH|INPUT_KICK);assert(g.fighters[0].state==ST_OBJECT_PICKUP&&g.fighters[0].held_object==1);prep(&g,0);game_tick(&g,0,INPUT_GRAB);assert(g.fighters[0].held_object==0&&g.ringside_objects[0].state==ARCADE_OBJECT_AVAILABLE_STATE);puts("PASS Test68: either fresh physical action button selects ringside pickup action $70; synthetic GRAB does not");}
