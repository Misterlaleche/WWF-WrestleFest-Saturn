#include "session.h"
#include <assert.h>
#include <stdio.h>
static void press(session_t*s,unsigned b){session_tick(s,0);session_tick(s,b);}
static void build(session_t*s,unsigned entropy,unsigned out[2]){session_reset(s,0);s->entropy=entropy;press(s,MENU_OK);s->cursor=0;press(s,MENU_OK);s->cursor=1;press(s,MENU_OK);assert(s->phase==SESSION_CPU);out[0]=s->characters[1];out[1]=s->characters[3];assert(out[0]!=out[1]&&out[0]!=s->selected[0]&&out[0]!=s->selected[1]&&out[1]!=s->selected[0]&&out[1]!=s->selected[1]);}
int main(void){session_t s;unsigned a[2],b[2],c[2];build(&s,1,a);build(&s,0x12345678,b);build(&s,0xf00dbabe,c);assert(a[0]!=b[0]||a[1]!=b[1]||a[0]!=c[0]||a[1]!=c[1]);assert(a[0]>=6||a[1]>=6||b[0]>=6||b[1]>=6||c[0]>=6||c[1]>=6);puts("PASS Test110: TAG CPU roster uses full ten-wrestler pool and menu entropy instead of fixed Jake/Bossman sequential fill");}
