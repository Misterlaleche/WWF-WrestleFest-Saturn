#include <assert.h>
#include <stdio.h>
#include "../game.h"
#include "../arcade_moves.h"
#include "../render_pose.h"
int main(void){
 fighter_t f={0};
 f.character=8;f.arcade_motion=true;f.state=ST_GROUND_ATTACK;f.current_move=AMOVE_STOMP;f.facing=1;
 f.tick=0;assert(game_arcade_pose(&f)==470);render_pose_t a=render_fighter_pose(&f);assert(a.frame==212);
 /* action $23 holds pose 470 on its callback-controlled first phase; the terminal
    finite frame 471 is still directly addressable and resident even though exact
    callback release timing remains unclaimed. */
 assert(roster_arcade_frame_character(8,471)==213);
 f.character=0;assert(roster_arcade_frame_character(f.character,470)==ROSTER_FRAMES);
 puts("PASS Test237: Earthquake STOMP bypasses Test212 fallback with exact resident art; unresolved characters still guard");
 return 0;
}
