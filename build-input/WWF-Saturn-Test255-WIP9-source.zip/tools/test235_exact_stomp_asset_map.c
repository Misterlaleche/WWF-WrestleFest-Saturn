#include <assert.h>
#include <stdio.h>
#include "../roster_data.h"
int main(void){
 assert(ROSTER_FRAMES>=214);
 assert(roster_arcade_frame_character(8,470)==212);
 assert(roster_arcade_frame_character(8,471)==213);
 assert(roster_arcade_frame_character(0,470)==ROSTER_FRAMES);
 puts("PASS Test235: Earthquake poses 470/471 now resolve to resident exact frames; other characters remain guarded");
 return 0;
}
