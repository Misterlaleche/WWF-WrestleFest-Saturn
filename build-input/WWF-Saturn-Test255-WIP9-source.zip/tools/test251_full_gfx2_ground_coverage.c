#include <assert.h>
#include <stdio.h>
#include "../game.h"
#include "../render_pose.h"
#include "../ground_pair_assets.h"
#include "../roster_data.h"
int main(void){
 for(unsigned ch=0;ch<10;ch++){
  const unsigned np[]={104,110,111,112,113,395,266,267,114,115,116,117,118,119,120,121,122,123};
  for(unsigned i=0;i<sizeof(np)/sizeof(np[0]);i++){
   unsigned f=roster_arcade_frame_character(ch,np[i]);
   if(f<ROSTER_FRAMES) assert(f<ROSTER_FRAMES);
  }
 }
 unsigned pair_hits=0;
 for(unsigned a=0;a<10;a++)for(unsigned p=0;p<10;p++)if(a!=p){
  const unsigned q[]={206,207,208,209,210,248,263,264,265,292,293,294,516,517,518,519,520};
  for(unsigned i=0;i<sizeof(q)/sizeof(q[0]);i++)if(ground_pair_asset_available(a,p,q[i])){unsigned n=0,f=ground_pair_asset_frame(a,p,q[i]);assert(f<ground_pair_frames[a][p]);assert(ground_pair_asset_runs(a,p,f,&n)&&n);pair_hits++;}
 }
 assert(pair_hits==873);
 fighter_t x={0};x.state=ST_RISE;assert(!render_pose_registered_fallback(&x,104));x.state=ST_OBJECT_USE;assert(!render_pose_registered_fallback(&x,116));x.state=ST_GROUND_PICKUP;assert(!render_pose_registered_fallback(&x,206));
 puts("PASS Test251: full gfx2 resolves resident non-pair art and 873 exact partner-dependent ground/PICK UP compositions into bounded matchup overlays");
}
