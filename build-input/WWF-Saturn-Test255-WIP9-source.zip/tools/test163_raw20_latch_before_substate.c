#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
int main(void){FILE*f=fopen("program.bin","rb");assert(f);uint8_t b[22];assert(fseek(f,0x1faf0,SEEK_SET)==0&&fread(b,1,sizeof b,f)==sizeof b);fclose(f);
 const uint8_t p[]={0x08,0x28,0x00,0x07,0x00,0x20,0x67,0x0c,0x08,0xa8,0x00,0x07,0x00,0x20,0x31,0x68,0x00,0x20,0x00,0x1c,0x70,0x00};
 assert(!memcmp(b,p,sizeof p));
 puts("PASS Test163: before +$1D substate dispatch, raw +$20 bit7 is tested; when set it is cleared and raw +$20 is copied to +$1C");return 0;}
