#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void seq(long o,const uint8_t*p,size_t n){FILE*f=fopen("program.bin","rb");assert(f);uint8_t*b=malloc(n);assert(b);assert(fseek(f,o,SEEK_SET)==0&&fread(b,1,n,f)==n);fclose(f);assert(!memcmp(b,p,n));free(b);}
int main(void){
 const uint8_t p[]={0x08,0x29,0x00,0x01,0x00,0x33,0x67,0x06,0x08,0xa9,0x00,0x06,0x00,0x56};seq(0x213c0,p,sizeof p);
 puts("PASS Test178: TAG cleanup tests linked +$33 bit1 and clears +$56 bit6 when that bit is set");return 0;}
