"""Local liblz4 ABI; paired decompression validates every compressed block."""
import ctypes as c,ctypes.util
lib=c.CDLL(ctypes.util.find_library('lz4'))
lib.LZ4_compressBound.argtypes=[c.c_int];lib.LZ4_compressBound.restype=c.c_int
lib.LZ4_compress_HC.argtypes=[c.c_void_p,c.c_void_p,c.c_int,c.c_int,c.c_int];lib.LZ4_compress_HC.restype=c.c_int
lib.LZ4_decompress_safe.argtypes=[c.c_void_p,c.c_void_p,c.c_int,c.c_int];lib.LZ4_decompress_safe.restype=c.c_int
def compress(data):
 out=c.create_string_buffer(lib.LZ4_compressBound(len(data)))
 n=lib.LZ4_compress_HC(data,out,len(data),len(out),12);assert n>0
 return out.raw[:n]
def decompress(data,size):
 out=c.create_string_buffer(size);n=lib.LZ4_decompress_safe(data,out,len(data),size);assert n==size
 return out.raw
