#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arcade_action_map.h"
static void seq(const unsigned char*r,size_t n,size_t o,const unsigned char*s,size_t z){assert(o+z<=n);assert(!memcmp(r+o,s,z));}
int main(void){FILE*f=fopen("program.bin","rb");assert(f);fseek(f,0,SEEK_END);long n=ftell(f);rewind(f);unsigned char*r=malloc((size_t)n);assert(r);assert(fread(r,1,(size_t)n,f)==(size_t)n);fclose(f);
 const unsigned char gate[]={0x22,0x68,0x00,0x26,0x0c,0x28,0x00,0x0c,0x00,0x21};seq(r,(size_t)n,0xe1b0,gate,sizeof gate);
 const unsigned char tail[]={0x0c,0x28,0x00,0x01,0x00,0x45,0x66,0x00,0xfe,0x5c,0x30,0x3c,0x00,0x09,0x42,0x68,0x00,0x44};seq(r,(size_t)n,0xe1be,tail,sizeof tail);
 unsigned after=0xffff;assert(arcade_pair_category9_raw(1,0x0c,1,0x1234,&after)==9&&after==0);assert(arcade_pair_category9_raw(0,0x0c,1,0,&after)<0);assert(arcade_pair_category9_raw(1,0x0b,1,0,&after)<0);assert(arcade_pair_category9_raw(1,0x0c,0,0,&after)<0);
 for(unsigned i=0;i<12;i++){assert(arcade_action_for_buttons_internal(i,9,1)==0x15);assert(arcade_action_for_buttons_internal(i,9,2)==0x17);assert(arcade_action_for_buttons_internal(i,9,3)==0x15);}
 free(r);puts("PASS Test80: ROM category $09 requires existing link + attacker state $0C + attacker +$45=1, clears attacker +$44, and universally maps P/K/P+K to $15/$17/$15");return 0;}
