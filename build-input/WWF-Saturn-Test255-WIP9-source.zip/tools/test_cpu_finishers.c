#include "finisher_runtime.h"
#include <assert.h>
#include <stdio.h>
#define FP 256
static void start(game_t *g,unsigned cpu_ch,unsigned player_ch){unsigned r[6]={player_ch,cpu_ch,4,5,6,8};game_match_start(g,GAME_TAG,r);g->cpu=true;g->ticks=0;fighter_t *p=&g->fighters[0],*q=&g->fighters[1];p->x=150*FP;p->y=190*FP;q->x=112*FP;q->y=190*FP;q->facing=1;}
int main(void){game_t g;start(&g,2,0);g.fighters[0].health=20;g.fighters[0].stamina_tier=2;g.fighters[1].grapple_serial=3;for(unsigned i=0;i<240&&g.pair==PAIR_NONE;i++)game_tick(&g,0,0);assert(g.pair==PAIR_HOLD&&g.pair_attacker==1);assert(game_finisher_probe(&g,1)==FINISHER_PROBE_READY);for(unsigned i=0;i<80&&g.pair==PAIR_HOLD;i++)game_tick(&g,0,0);assert(g.pair==PAIR_FINISHER&&g.pair_attacker==1);unsigned before=g.fighters[0].health;for(unsigned i=0;i<700&&g.pair==PAIR_FINISHER;i++)game_tick(&g,0,0);assert(g.pair!=PAIR_FINISHER&&g.finishers==1&&g.hits[1]>=1&&g.fighters[0].health<before);puts("PASS: CPU grapple rota completes mapped Jake DDT without human finisher input");}
