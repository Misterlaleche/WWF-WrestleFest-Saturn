#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void need(const uint8_t*r,size_t n,size_t o,const uint8_t*p,size_t m){assert(o+m<=n);assert(!memcmp(r+o,p,m));}
int main(void){
 FILE*f=fopen("program.bin","rb");assert(f);fseek(f,0,SEEK_END);long z=ftell(f);rewind(f);uint8_t*r=malloc((size_t)z);assert(r&&fread(r,1,(size_t)z,f)==(size_t)z);fclose(f);
 const uint8_t entry[]={0x43,0xf9,0x00,0x00,0x27,0x5c,0xe5,0x48,0x38,0x31,0x00,0x00};
 const uint8_t sign[]={0x08,0x2a,0x00,0x07,0x00,0x2e,0x67,0x02,0x44,0x84};
 need(r,(size_t)z,0x26b2,entry,sizeof entry);need(r,(size_t)z,0x26c6,sign,sizeof sign);
 free(r);puts("PASS Test151: ROM $26AE indexes the $275C 4-byte vector table by D0<<2 and negates horizontal offset D4 when target +$2E bit7 is set");return 0;
}
