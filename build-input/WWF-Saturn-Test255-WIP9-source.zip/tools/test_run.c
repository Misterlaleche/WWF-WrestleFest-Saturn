#include "game.h"
#include <assert.h>
#include <stdio.h>
static const unsigned roster[6]={0,2,7,1,4,5};
static void setup(game_t *g){game_match_start(g,GAME_TAG,roster);g->cpu=false;g->fighters[0].x=100*256;g->fighters[0].y=230*256;g->fighters[1].x=200*256;g->fighters[1].y=160*256;}
int main(void){
 static const unsigned speed[10]={47,53,49,45,56,48,44,56,40,47};game_t g;
 for(unsigned ch=0;ch<10;ch++){
  setup(&g);fighter_t *f=&g.fighters[0];f->character=ch;int old=f->x;
  game_tick(&g,INPUT_RIGHT|INPUT_RUN,INPUT_PUNCH|INPUT_KICK);
  assert(f->state==ST_RUN&&f->x-old==(int)speed[ch]*20&&game_arcade_pose(f)==9);
  assert(!f->queued_attack);
  for(unsigned t=1;t<7;t++){game_tick(&g,INPUT_RIGHT|INPUT_RUN,0);assert(game_arcade_pose(f)==9);}
  game_tick(&g,INPUT_RIGHT|INPUT_RUN,0);assert(game_arcade_pose(f)==10);
  unsigned tick=f->tick;old=f->x;g.paused=true;game_tick(&g,0,0);assert(f->tick==tick&&f->x==old);g.paused=false;
  game_tick(&g,0,0);assert(f->state==ST_RUN_STOP&&game_arcade_pose(f)==10);
  for(unsigned t=0;t<20;t++)game_tick(&g,0,0);
  assert(f->state==ST_IDLE&&f->run_speed==0);
 }
 for(int dir=-1;dir<=1;dir+=2){
  setup(&g);fighter_t *f=&g.fighters[0];f->x=(dir<0?game_ring_left(230):game_ring_right(230))*256;
  unsigned held=INPUT_RUN|(dir<0?INPUT_LEFT:INPUT_RIGHT);
  game_tick(&g,held,0);assert(f->state==ST_REBOUND&&f->facing==-dir&&game_arcade_pose(f)==105);
  int x=f->x;for(unsigned t=1;t<9;t++){game_tick(&g,held,0);assert(f->x==x);}
  game_tick(&g,held,0);assert(f->x-x==-dir*12*20);
  for(unsigned t=10;t<=22;t++)game_tick(&g,held,0);
  assert(f->state==ST_RUN&&game_arcade_pose(f)==9);
  assert(game_on_floor(f->x/256,f->y/256));
 }
 setup(&g);g.fighters[0].outside=true;g.fighters[0].y=320*256;
 game_tick(&g,INPUT_RUN|INPUT_RIGHT,0);assert(g.fighters[0].state!=ST_RUN);
 puts("PASS: 10 run speeds, complete cycle timing, braking, two rope rebounds, pause, no phantom attack and no exterior running");
}
