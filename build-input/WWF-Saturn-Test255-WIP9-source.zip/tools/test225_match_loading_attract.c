#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static char *slurp(const char *p){FILE*f=fopen(p,"rb");assert(f);fseek(f,0,SEEK_END);long n=ftell(f);rewind(f);char*s=malloc((size_t)n+1);assert(s);assert(fread(s,1,(size_t)n,f)==(size_t)n);fclose(f);s[n]=0;return s;}
int main(void){char*s=slurp("main.c");
 assert(strstr(s,"(session.phase==SESSION_HALL||session.phase==SESSION_ANNOUNCE)&&!loaded_roster"));
 assert(strstr(s,"loading_begin(LOAD_MATCH,session.phase)"));
 assert(strstr(s,"native_match_start(true);roster_load()"));
 assert(strstr(s,"hud_map(slots,cells);hud_pixels(cells,full)"));
 assert(strstr(s,"HOLD ON, BROTHER!"));assert(strstr(s,"GET READY FOR ACTION!"));assert(strstr(s,"NOW LOADING"));
 assert(strstr(s,"if(!check_error&&loading.kind!=LOAD_NONE)loading_scene"));
 free(s);puts("PASS Test225: short match preload is a real staged roster/ring transition rendered through an attract-style dialogue surface using authentic arcade HUD portrait pixels; exact attract portrait animation/text remain PROVISIONAL");}
