#include <assert.h>
#include <stdio.h>
#include "game.h"
static unsigned run(unsigned ch){unsigned r[6]={ch,1,2,3,4,5};game_t g;game_match_start(&g,GAME_TAG,r);g.cpu=false;fighter_t*p=&g.fighters[0],*q=&g.fighters[1];p->x=120*256;p->y=200*256;p->cooldown=0;q->x=150*256;q->rise_y=200*256;q->y=217*256;q->state=ST_RECOVER;q->tick=24;q->health=100;game_tick(&g,0,INPUT_PUNCH|INPUT_KICK);assert(p->state==ST_GROUND_ATTACK);unsigned n=0;while(p->state==ST_GROUND_ATTACK&&n<100){game_tick(&g,0,0);n++;}assert(n<100);return n;}
int main(void){unsigned elbow=run(2),knee=run(5);assert(elbow>=61&&elbow<=65);assert(knee>=68&&knee<=72);puts("PASS Test213: finite ELBOW DROP/KNEE DROP ground states preserve their recovered 61/68-tick arcade visual schedules instead of truncating both at 32 ticks");}
