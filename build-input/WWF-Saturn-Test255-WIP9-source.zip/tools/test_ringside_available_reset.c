#include <assert.h>
#include <stdio.h>
#include "game.h"
#include "arcade_ringside.h"
#define FP 256
int main(void){
 game_t g; unsigned r[6]={0,2,1,3,0,0};
 game_match_start_arcade(&g,GAME_TAG,r,0,0);
 assert(g.ringside_object_count==2);
 for(unsigned i=0;i<2;i++){
  assert(g.ringside_objects[i].state==ARCADE_OBJECT_AVAILABLE_STATE);
  assert(g.ringside_objects[i].holder==0);
  assert(g.ringside_objects[i].z==ARCADE_OBJECT_AVAILABLE_RAW_Z*FP);
 }
 assert(ARCADE_OBJECT_AVAILABLE_RAW_Z==0x100);
 puts("PASS: ROM $FA14 resets both ringside objects to available state 3 at exact raw +$0E=$0100");
 return 0;
}
