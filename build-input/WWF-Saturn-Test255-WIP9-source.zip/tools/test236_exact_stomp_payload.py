#!/usr/bin/env python3
from pathlib import Path
import struct,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import lz4_codec
ROOT=Path(__file__).resolve().parents[1]
def be16(b,o):return int.from_bytes(b[o:o+2],'big')
def be32(b,o):return int.from_bytes(b[o:o+4],'big')
def unpack(path):
 b=path.read_bytes();assert be32(b,0)==0x57464332
 frames,records,tiles,off,bt,blocks=[be32(b,o) for o in (4,8,12,16,24,28)]
 idx=[(be16(b,32+i*4),be16(b,34+i*4)) for i in range(frames)]
 ro=32+frames*4;rec=[list(struct.unpack_from('>HhhH',b,ro+i*8)) for i in range(records)]
 tex=[]
 for bi in range(blocks):
  eo=off+bi*12;pos,stored,raw=be32(b,eo),be32(b,eo+4),be32(b,eo+8)
  c=lz4_codec.decompress(b[pos:pos+stored],raw);tex.extend(c[i:i+128] for i in range(0,len(c),128))
 return [[r[:] for r in rec[f:f+n]] for f,n in idx],tex
cf,ct=unpack(ROOT/'cd/C08.PAK');ff,ft=unpack(ROOT/'cd/F08.PAK')
assert len(cf)>=214 and len(ff)==2
for phase in range(2):
 a=cf[212+phase];b=ff[phase]
 assert len(a)==len(b)
 for cr,fr in zip(a,b):
  assert cr[1:]==fr[1:]
  assert ct[cr[0]]==ft[fr[0]]
print('PASS Test236: C08 frames 212/213 are bit-identical texture/geometry copies of validated F08 frames 0/1')
