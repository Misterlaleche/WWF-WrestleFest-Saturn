#include "game.h"
#include "session.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 unsigned r[6]={0,2,1,3,4,5};game_t g;game_match_start(&g,GAME_TAG,r);g.cpu=true;
 g.pair=PAIR_SUBMISSION;g.pair_attacker=0;g.pair_tick=1;
 g.support_phase[0]=g.support_phase[1]=SUPPORT_RUN;
 g.fighters[2].x=130*256;g.fighters[2].y=200*256;g.fighters[3].x=150*256;g.fighters[3].y=200*256;
 g.fighters[2].state=ST_PUNCH;g.fighters[2].tick=22;g.fighters[2].connected=false;g.fighters[2].cooldown=0;
 g.fighters[3].state=ST_IDLE;g.fighters[3].cooldown=0;
 unsigned before=g.fighters[3].health;game_tick(&g,0,0);
 assert(g.fighters[3].health<before);assert(g.fighters[3].state==ST_HIT||g.fighters[3].state==ST_DOWN);assert(g.blocks==1);
 puts("PASS Test207: TAG intervention partners now inflict real strike damage on each other instead of pose-only robotic blocking");
}
