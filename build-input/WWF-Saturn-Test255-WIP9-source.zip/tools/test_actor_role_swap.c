#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void seq(const unsigned char*r,size_t n,size_t o,const unsigned char*s,size_t z){assert(o+z<=n);assert(!memcmp(r+o,s,z));}
int main(void){FILE*f=fopen("program.bin","rb");assert(f);fseek(f,0,SEEK_END);long ln=ftell(f);rewind(f);size_t n=(size_t)ln;unsigned char*r=malloc(n);assert(r&&fread(r,1,n,f)==n);fclose(f);
 const unsigned char pair[]={0x22,0x68,0x00,0x86};seq(r,n,0x21428,pair,sizeof pair);
 const unsigned char swap1[]={0x08,0xa8,0x00,0x06,0x00,0x56,0x08,0xea,0x00,0x02,0x00,0x32,0x08,0xea,0x00,0x06,0x00,0x56};seq(r,n,0x2149e,swap1,sizeof swap1);
 const unsigned char retarget[]={0x25,0x49,0x00,0x7a};seq(r,n,0x214b0,retarget,sizeof retarget);
 const unsigned char reverse[]={0x22,0x68,0x00,0x86,0x08,0xe8,0x00,0x06,0x00,0x56,0x08,0xa9,0x00,0x06,0x00,0x56};seq(r,n,0x214e6,reverse,sizeof reverse);
 free(r);puts("PASS Test88: $21424/$214CA use reciprocal +$86 pair links to exchange +$56 bit6 actor roles and retarget paired actors through +$7A");return 0;}
