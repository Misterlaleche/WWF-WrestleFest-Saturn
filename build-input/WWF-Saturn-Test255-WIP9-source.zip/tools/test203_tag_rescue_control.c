#include "game.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 unsigned r[6]={0,2,1,3,4,5};game_t g;game_match_start(&g,GAME_TAG,r);g.cpu=false;
 /* CPU is covering P1; human reserve has already completed its rope entry. */
 g.pair=PAIR_PIN;g.pin_attacker=1;g.pair_attacker=1;g.support_phase[0]=SUPPORT_RUN;g.support_phase[1]=SUPPORT_WAIT;
 fighter_t *p=&g.fighters[0],*partner=&g.fighters[2],*cpu=&g.fighters[1];
 p->state=ST_DOWN;p->health=40;partner->state=ST_IDLE;partner->x=80*256;partner->y=200*256;cpu->x=150*256;cpu->y=200*256;
 assert(game_player_controls_partner(&g));unsigned old=partner->x,escape=g.escape_progress;
 game_tick(&g,INPUT_RIGHT,INPUT_PUNCH);assert(partner->x>old);assert(g.escape_progress==escape);
 /* Move close and strike: partner, not prone legal wrestler, resolves rescue. */
 partner->x=cpu->x-30*256;partner->y=cpu->y;partner->cooldown=0;game_tick(&g,0,INPUT_PUNCH);
 for(unsigned i=0;i<30&&g.pair!=PAIR_NONE;i++)game_tick(&g,0,0);
 assert(g.pair==PAIR_NONE&&g.rescues>0);
 puts("PASS Test203: during a CPU pin P1 input transfers to the entering TAG partner; movement/strike can break the pin without also feeding escape mash");
}
