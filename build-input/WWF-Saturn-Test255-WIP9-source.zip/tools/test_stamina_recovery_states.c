#include "arcade_stamina.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 assert(!arcade_stamina_recovery_state_allows(false,0,0,0));
 assert(!arcade_stamina_recovery_state_allows(true,0x0b,0,0));
 assert(!arcade_stamina_recovery_state_allows(true,0x0c,0,0));
 assert(!arcade_stamina_recovery_state_allows(true,0xff,0x0c,0));
 assert( arcade_stamina_recovery_state_allows(true,0xff,0x05,0));
 assert(!arcade_stamina_recovery_state_allows(true,0x05,0,0x4a));
 assert( arcade_stamina_recovery_state_allows(true,0x05,0,0x49));
 assert( arcade_stamina_recovery_state_allows(true,0x04,0,0x4a));
 puts("PASS: exact $8ECC Rumble recovery exclusions 0B/0C/FF->0C and 05+pose4A");
}
