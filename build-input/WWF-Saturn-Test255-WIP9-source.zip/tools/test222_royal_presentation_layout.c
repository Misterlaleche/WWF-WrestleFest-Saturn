#include "../presentation.h"
#include <assert.h>
#include <stdio.h>
int main(void){for(unsigned i=0;i<6;i++){assert(rumble_announce_x(i)>=70&&rumble_announce_x(i)<=250);assert(rumble_announce_y(i)==(i<3?164:210));}assert(rumble_announce_x(0)==rumble_announce_x(3));assert(rumble_announce_y(0)!=rumble_announce_y(3));puts("PASS Test222: Royal announcement uses a bounded 3x2 presentation grid; exact arcade geometry remains provisional");}
