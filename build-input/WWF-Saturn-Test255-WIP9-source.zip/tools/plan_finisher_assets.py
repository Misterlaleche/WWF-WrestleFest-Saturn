#!/usr/bin/env python3
"""Audit current WFC2 coverage for the first authentic finisher conversion batch.

This script does not invent or duplicate art.  It reports which original arcade
pose IDs are already addressable in the current Saturn roster banks and which
must be regenerated from the user's assembled WrestleFest program/sprite data.
"""
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[1]
FINISHERS=[
 dict(character=0,name='LEGDROP',descriptor=64,action=53,rom='0x175A8',callback='0x175C4',condition='prone_diagonal',evidence='candidate',poses=[132,133,230,231,232],partner_dependent=[]),
 dict(character=2,name='DDT',descriptor=63,action=52,rom='0x1747E',callback='0x174AA',condition='grapple',evidence='high_confidence',poses=[144,145,312,313,314,315,316,317,104],partner_dependent=[144,145,312,313,314,315,316]),
 dict(character=3,name='BOSS MAN SLAM',descriptor=60,action=49,rom='0x16FD8',callback='0x17000',condition='opponent_running',evidence='high_confidence',poses=[194,195,196,197,198,199,200,201],partner_dependent=[196,197,198,199,200]),
 dict(character=7,name='PERFECT PLEX',descriptor=38,action=26,rom='0x1520C',callback='0x15228',condition='grapple',evidence='high_confidence',poses=[324,325,326,327,328],partner_dependent=[324,325,326,327,328]),
]

def mapped_poses():
 text=(ROOT/'roster_data.h').read_text()
 return {int(x) for x in re.findall(r'case\s+(\d+)\s*:\s*return\s+\d+',text)}

def build():
 mapped=mapped_poses();rows=[]
 for f in FINISHERS:
  present=[p for p in f['poses'] if p in mapped]
  missing=[p for p in f['poses'] if p not in mapped]
  row=dict(f)
  row.update(current_direct_mapped_poses=present,missing_original_poses=missing,
             current_pose_coverage=f'{len(present)}/{len(f["poses"])}',
             graphics_ready=not missing and not f['partner_dependent'])
  rows.append(row)
 return dict(version='V0.028',source='Recovered animation descriptor/pose audit',
             policy='No finisher is gameplay-ready until original role compositions are generated and audited.',
             current_roster_frames=int(re.search(r'#define ROSTER_FRAMES\s+(\d+)',(ROOT/'roster_data.h').read_text()).group(1)),
             finishers=rows,
             raw_inputs_required_for_expansion=['assembled main program region','assembled sprite region'],
             pair_note='Partner-dependent poses require attacker/victim role extraction; copying an attacker frame is not sufficient.')

if __name__=='__main__':
 out=build();path=ROOT/'docs/finisher-assets-plan.json';path.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
