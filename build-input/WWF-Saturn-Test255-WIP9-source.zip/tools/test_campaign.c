#include "campaign.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 campaign_t c;campaign_reset(&c,CAMPAIGN_TAG,5,0,2);
 assert(campaign_stage(&c)==0&&!campaign_is_title_match(&c)&&!c.championship);
 assert(!campaign_is_cage_match(&c));
 assert(campaign_finish_match(&c,true)&&c.stage==1);
 assert(campaign_finish_match(&c,true)&&c.stage==2&&campaign_is_cage_match(&c));
 assert(campaign_finish_match(&c,true)&&c.stage==3);
 assert(campaign_finish_match(&c,true)&&c.stage==4&&campaign_is_title_match(&c)&&campaign_is_lod_match(&c));
 /* First LOD win awards title but does not end the game. */
 assert(campaign_finish_match(&c,true)&&c.stage==5&&c.championship&&!c.complete);
 assert(campaign_finish_match(&c,true)&&c.stage==6);
 assert(campaign_finish_match(&c,true)&&c.stage==7&&campaign_is_cage_match(&c));
 assert(campaign_finish_match(&c,true)&&c.stage==8);
 assert(campaign_finish_match(&c,true)&&c.stage==9&&campaign_is_final_lod(&c)&&campaign_is_lod_match(&c));
 assert(!campaign_finish_match(&c,true)&&c.complete&&c.championship&&c.wins==10);
 campaign_reset(&c,CAMPAIGN_TAG,4,2,0);
 for(unsigned n=0;n<3;n++)assert(campaign_finish_match(&c,true));
 assert(c.stage==3&&campaign_is_title_match(&c));unsigned st=c.stage;
 assert(!campaign_finish_match(&c,false)&&c.stage==st&&c.losses==1&&!c.championship);
 assert(campaign_finish_match(&c,true)&&c.championship&&c.stage==4);
 campaign_reset(&c,CAMPAIGN_RUMBLE,5,3,0);assert(!campaign_finish_match(&c,true)&&c.complete);
 puts("PASS: ten-stage TAG route, initial/final LOD, two cage stages, 4th/5th title DIP and Rumble completion");
}
