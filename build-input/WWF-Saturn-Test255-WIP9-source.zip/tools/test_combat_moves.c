#include "game.h"
#include "combat_moves.h"
#include "arcade_animation.h"
#include "roster_data.h"
#include <assert.h>
#include <stdio.h>
static const unsigned cast[6]={0,2,7,1,4,5};
static void setup(game_t *g,unsigned ch,int dir){
    game_match_start(g,GAME_TAG,cast);g->cpu=false;g->ticks=60;
    fighter_t *a=&g->fighters[0],*b=&g->fighters[1];
    a->character=ch;a->x=(dir>0?80:190)*256;a->y=250*256;a->facing=dir;
    b->x=a->x+dir*72*256;b->y=a->y;b->rise_y=b->y;
}
static void tick(game_t *g,unsigned n){while(n--)game_tick(g,0,0);}
static void input_mapping(void){
    game_t g;
    for(unsigned ch=0;ch<10;ch++){
        setup(&g,ch,1);fighter_t *f=&g.fighters[0];f->state=ST_RUN;
        assert(combat_remap_input(f,INPUT_RUN|INPUT_RIGHT,INPUT_PUNCH|INPUT_KICK,0)==0);
        unsigned a=combat_remap_input(f,0,INPUT_PUNCH,INPUT_PUNCH);
        assert(a==(combat_has_clothesline(ch)?INPUT_CLOTHESLINE:INPUT_RUN_ATTACK));
        assert(combat_remap_input(f,0,INPUT_KICK,INPUT_KICK)==INPUT_RUN_ATTACK);
        f->state=ST_IDLE;
        unsigned b=combat_remap_input(f,0,INPUT_PUNCH|INPUT_KICK,INPUT_KICK);
        assert(b==0);
        assert(combat_remap_input(f,0,INPUT_PUNCH|INPUT_KICK,0)==0);
        assert(combat_remap_input(f,INPUT_RUN|INPUT_RIGHT,INPUT_PUNCH|INPUT_KICK,INPUT_KICK)==INPUT_KICK);
        f->state=ST_RECOVER;
        assert(combat_remap_input(f,0,INPUT_PUNCH|INPUT_KICK,INPUT_PUNCH|INPUT_KICK)==(INPUT_PUNCH|INPUT_KICK));
        f->state=ST_IDLE;f->outside=true;
        assert(combat_remap_input(f,0,INPUT_PUNCH|INPUT_KICK,INPUT_KICK)==INPUT_KICK);
    }
    puts("PASS: new Saturn action mapping, capability guards, fresh presses, run chord, recovery effort and outside exclusions");
}
static void clotheslines(void){
    game_t g;
    for(unsigned ch=0;ch<10;ch++)for(int dir=-1;dir<=1;dir+=2){
        setup(&g,ch,dir);fighter_t *a=&g.fighters[0],*b=&g.fighters[1];
        game_tick(&g,INPUT_RUN|(dir>0?INPUT_RIGHT:INPUT_LEFT),0);
        game_tick(&g,0,INPUT_CLOTHESLINE);
        if(!combat_has_clothesline(ch)){assert(a->state!=ST_CLOTHESLINE);continue;}
        assert(a->state==ST_CLOTHESLINE&&a->tick==0&&game_arcade_pose(a)==150);
        g.paused=true;int x=a->x;tick(&g,12);assert(a->tick==0&&a->x==x);g.paused=false;
        tick(&g,65);
        assert(g.hits[0]==1&&b->health==b->max_health-32&&b->state==ST_RECOVER);
        assert(game_on_floor(a->x/256,a->y/256)&&!a->queued_attack);
        /* An opponent at another depth is not hit, even while passing. */
        setup(&g,ch,dir);b=&g.fighters[1];b->y=170*256;
        game_tick(&g,INPUT_RUN|(dir>0?INPUT_RIGHT:INPUT_LEFT),0);game_tick(&g,0,INPUT_CLOTHESLINE);
        tick(&g,65);assert(g.hits[0]==0&&b->health==b->max_health);
    }
    for(int dir=-1;dir<=1;dir+=2){
        setup(&g,0,dir);fighter_t *a=&g.fighters[0];a->state=ST_CLOTHESLINE;a->run_speed=47;
        a->x=(dir>0?game_ring_right(250):game_ring_left(250))*256;
        game_tick(&g,0,0);assert(a->state==ST_REBOUND&&a->facing==-dir&&game_on_floor(a->x/256,a->y/256));
    }
    setup(&g,0,1);g.fighters[0].state=ST_RUN_STOP;g.fighters[0].run_speed=35;g.fighters[0].cooldown=25;
    game_tick(&g,0,INPUT_CLOTHESLINE);assert(g.fighters[0].state!=ST_CLOTHESLINE);
    /* Isolate the visual clock from movement, contact freeze and rope abort. */
    setup(&g,0,1);g.fighters[1].y=170*256;fighter_t *a=&g.fighters[0];a->state=ST_CLOTHESLINE;a->run_speed=0;
    unsigned counts[6]={0};
    for(unsigned t=0;t<CLOTHESLINE_TICKS;t++){
        assert(a->state==ST_CLOTHESLINE);
        int pose=game_arcade_pose(a);assert(pose>=150&&pose<=155);++counts[pose-150];
        assert(pose==arcade_animation_sample(0x12f08,t)&&roster_arcade_frame(pose)<ROSTER_FRAMES);
        game_tick(&g,0,0);
    }
    const unsigned expected[6]={7,7,7,7,5,13};
    for(unsigned i=0;i<6;i++)assert(counts[i]==expected[i]);
    assert(a->state==ST_RUN_STOP);
    puts("PASS: original six-pose clothesline clock, seven characters, both directions, single damage, misses, pause, knockdown and rope rebound");
}
static void boots(void){
    game_t g;
    for(unsigned ch=0;ch<10;ch++)for(int dir=-1;dir<=1;dir+=2){
        setup(&g,ch,dir);fighter_t *a=&g.fighters[0],*b=&g.fighters[1];b->x=a->x+dir*60*256;
        game_tick(&g,0,INPUT_BIG_BOOT);
        if(!combat_has_big_boot(ch)){assert(a->state!=ST_BIG_BOOT);continue;}
        assert(a->state==ST_BIG_BOOT&&game_arcade_pose(a)==180);
        tick(&g,14);assert(b->health==b->max_health&&g.hits[0]==0&&game_arcade_pose(a)==180);
        game_tick(&g,0,0);assert(b->health==b->max_health-30&&g.hits[0]==1&&game_arcade_pose(a)==181);
        tick(&g,40);assert(g.hits[0]==1&&a->state==ST_IDLE&&b->state==ST_RECOVER);
        a->x=b->x-dir*24*256;a->y=b->rise_y;
        game_tick(&g,0,INPUT_PIN);assert(g.pair==PAIR_PIN&&g.pin_attacker==0);
    }
    setup(&g,0,1);g.fighters[1].y=170*256;fighter_t *a=&g.fighters[0];
    game_tick(&g,0,INPUT_BIG_BOOT);g.paused=true;tick(&g,30);assert(a->tick==0);g.paused=false;
    unsigned counts[2]={0};
    for(unsigned t=0;t<BIG_BOOT_TICKS;t++){
        assert(a->state==ST_BIG_BOOT);int pose=game_arcade_pose(a);assert(pose==180||pose==181);
        ++counts[pose-180];assert(pose==arcade_animation_sample(0x15b24,t));game_tick(&g,0,0);
    }
    assert(counts[0]==15&&counts[1]==25&&a->state==ST_IDLE&&g.hits[0]==0);
    setup(&g,0,1);a=&g.fighters[0];g.fighters[1].x=a->x+40*256;
    game_tick(&g,0,INPUT_BIG_BOOT);g.fighters[1].state=ST_PUNCH;g.fighters[1].tick=22;
    game_tick(&g,0,0);assert(a->state==ST_HIT&&g.hits[0]==0&&g.hits[1]==1);
    puts("PASS: Hogan/Earthquake big boot, 15/25 pose clock, first contact, one hit, miss, pause, interruption and follow-up pin");
}
static void cpu_moves(void){
    game_t g;
    for(unsigned ch=0;ch<10;ch++){
        setup(&g,0,1);g.cpu=true;fighter_t *q=&g.fighters[1];q->character=ch;
        q->state=ST_RUN;q->run_speed=47;q->facing=-1;
        game_tick(&g,0,0);assert(q->state==(combat_has_clothesline(ch)?ST_CLOTHESLINE:ST_RUN_ATTACK));
        setup(&g,0,1);g.cpu=true;q=&g.fighters[1];q->character=ch;q->x=g.fighters[0].x+60*256;q->attack_serial=3;
        game_tick(&g,0,0);assert(q->state==(combat_has_big_boot(ch)?ST_BIG_BOOT:ST_KICK));
    }
    puts("PASS: CPU selects supported original attacks and retains existing alternatives for the other characters");
}
static void simulations(void){
    unsigned actions=0,contacts=0;
    for(unsigned ch=0;ch<10;ch++){
        unsigned roster[6];for(unsigned i=0;i<6;i++)roster[i]=(ch+i)%10;
        game_t g;game_match_start(&g,GAME_TAG,roster);unsigned previous=0;
        for(unsigned t=0;t<5000;t++){
            if(g.finished){contacts+=g.hits[0]+g.hits[1];game_match_start(&g,GAME_TAG,roster);previous=0;}
            unsigned direction=t%240<120?INPUT_RIGHT:INPUT_LEFT;
            unsigned movement=(t%97<12)?0:direction;
            unsigned down=t%53<8?(INPUT_PUNCH|INPUT_KICK):(t%41<5?INPUT_PUNCH:(t%29<4?INPUT_KICK:0));
            if(movement&&down==(INPUT_PUNCH|INPUT_KICK))movement|=INPUT_RUN;
            unsigned edges=down&~previous;previous=down;
            unsigned command=combat_remap_input(&g.fighters[0],movement,down,edges);
            game_tick(&g,movement,command);
            for(unsigned i=0;i<g.roster_count;i++){
                fighter_t *f=&g.fighters[i];assert(f->character<10&&f->health<=f->max_health&&f->state<=ST_GROUND_PICKUP);
                if(f->state==ST_CLOTHESLINE){assert(combat_has_clothesline(f->character));++actions;}
                if(f->state==ST_BIG_BOOT){assert(combat_has_big_boot(f->character));++actions;}
            }
        }
        contacts+=g.hits[0]+g.hits[1];
    }
    assert(actions>100&&contacts>0);
    printf("PASS: 50000 deterministic gameplay ticks across ten rosters, %u contact events and %u new-action state samples\n",contacts,actions);
}
int main(void){input_mapping();clotheslines();boots();cpu_moves();simulations();}
