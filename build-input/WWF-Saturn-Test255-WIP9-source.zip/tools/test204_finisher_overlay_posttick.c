#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(void){FILE *f=fopen("main.c","rb");assert(f);fseek(f,0,SEEK_END);long n=ftell(f);rewind(f);char *b=malloc((size_t)n+1);assert(b);assert(fread(b,1,(size_t)n,f)==(size_t)n);b[n]=0;fclose(f);
 const char *tick=strstr(b,"game_tick(&game,held,pending)");assert(tick);const char *guard=strstr(tick,"game.pair==PAIR_FINISHER||game.fighters[0].state==ST_FINISHER||game.fighters[1].state==ST_FINISHER");assert(guard);const char *load=strstr(guard,"finisher_overlay_load(game.fighters[live_attacker].character)");assert(load&&load-guard<700);free(b);puts("PASS Test204: live finisher overlay is re-checked immediately after game_tick so a newly-started CPU/ground finisher cannot render one frame before its overlay is loaded (CHECK 338 race)");}
