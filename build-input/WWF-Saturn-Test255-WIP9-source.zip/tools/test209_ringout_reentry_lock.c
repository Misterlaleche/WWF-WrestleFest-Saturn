#include "game.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 unsigned r[6]={0,2,1,3,4,5};game_t g;game_match_start(&g,GAME_TAG,r);g.cpu=true;
 g.fighters[0].x=100*256;g.fighters[1].x=150*256;g.fighters[0].y=g.fighters[1].y=215*256;g.pair=PAIR_HOLD;g.pair_attacker=0;
 game_tick(&g,INPUT_RIGHT,INPUT_RING);assert(g.fighters[1].state==ST_TOSSED);
 for(unsigned i=0;i<48;i++)game_tick(&g,0,0);
 assert(g.fighters[1].outside&&g.fighters[1].state==ST_RECOVER&&g.fighters[1].cooldown>=24);
 /* Test253 replaces the old short native lock with the recovered visual chain:
  * provisional 24-tick FF00 release + exact $68 finite tail (82) + exact $6A
  * return (91) = 197 ringside recovery ticks.  Do not let the CPU snap back
  * into ring-entry before that chain has completed. */
 for(unsigned i=0;i<196;i++){game_tick(&g,0,0);assert(g.fighters[1].outside&&g.fighters[1].state==ST_RECOVER);}
 game_tick(&g,0,0);assert(g.fighters[1].outside&&g.fighters[1].state==ST_IDLE);
 game_tick(&g,0,0);assert(g.fighters[1].outside&&g.fighters[1].state==ST_RING_ENTER);
 /* Front entry now follows raw $6C's recovered visual clock.  Geometry/release
  * is still native, but the outside flag must remain set until completion. */
 for(unsigned i=0;i<69;i++){game_tick(&g,0,0);assert(g.fighters[1].outside&&g.fighters[1].state==ST_RING_ENTER);}
 game_tick(&g,0,0);assert(!g.fighters[1].outside);
 puts("PASS Test209/253: tossed wrestler completes the recovered $68+$6A ringside recovery before the $6C front-entry clock; no snap-back occurs");
}
