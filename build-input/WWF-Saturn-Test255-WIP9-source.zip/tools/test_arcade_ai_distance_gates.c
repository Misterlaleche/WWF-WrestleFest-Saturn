#include "arcade_ai.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned char *load(size_t*n){FILE*f=fopen("program.bin","rb");assert(f);fseek(f,0,SEEK_END);*n=(size_t)ftell(f);rewind(f);unsigned char*b=malloc(*n);assert(b&&fread(b,1,*n,f)==*n);fclose(f);return b;}
int main(void){size_t n;unsigned char*b=load(&n);
 const unsigned char midpairs[24]={8,92,14,86,5,95,7,93,16,84,10,90,3,97,12,88,7,93,8,92,10,90,12,88};
 const unsigned char farpairs[24]={20,80,30,70,15,85,20,80,35,65,25,75,10,90,25,75,12,88,18,82,25,75,22,78};
 assert(!memcmp(b+0x1f3a6,midpairs,24));assert(!memcmp(b+0x1f3be,farpairs,24));
 const unsigned char branch[]={0x0c,0x68,0x00,0xe0,0x00,0xb0,0x65,0x48};assert(!memcmp(b+0x1f318,branch,sizeof(branch)));
 for(unsigned ch=0;ch<12;ch++){assert(arcade_ai_distance_gate_weight(ch,0)==midpairs[ch*2]);assert(arcade_ai_distance_gate_weight(ch,1)==farpairs[ch*2]);}
 assert(arcade_ai_distance_gate_weight(6,0)==3);assert(arcade_ai_distance_gate_weight(4,1)==35);
 free(b);puts("PASS: Test130 recovers both 12-wrestler weighted distance gates at $1F3A6/$1F3BE");}
