#include "../campaign_presentation.h"
#include <assert.h>
#include <stdio.h>
int main(void){campaign_presentation_t p;campaign_presentation_reset(&p);campaign_presentation_begin_records(&p);assert(p.screen==CAMPAIGN_PRESENT_RECORDS&&p.duration==480);assert(campaign_presentation_tick(&p,1,true));puts("PASS Test218: Records presentation state is explicit and skippable");}
