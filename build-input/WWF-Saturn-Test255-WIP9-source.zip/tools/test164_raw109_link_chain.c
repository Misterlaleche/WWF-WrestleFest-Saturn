#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
int main(void){FILE*f=fopen("program.bin","rb");assert(f);uint8_t b[16];assert(fseek(f,0x20058,SEEK_SET)==0&&fread(b,1,sizeof b,f)==sizeof b);fclose(f);
 const uint8_t p[]={0x22,0x68,0x00,0x56,0x24,0x69,0x00,0x26,0x53,0x28,0x00,0x23,0x66,0x00,0x00,0xc6};assert(!memcmp(b,p,sizeof p));
 puts("PASS Test164: +$109 producer resolves A1=A0+$56 then A2=A1+$26 before ticking; increment target is the second linked actor, not A0 or the immediate +$56 link");return 0;}
