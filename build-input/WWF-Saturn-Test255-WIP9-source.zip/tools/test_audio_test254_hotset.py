#!/usr/bin/env python3
from pathlib import Path
PACK=Path(__file__).resolve().parents[1]/'cd'/'AUDADP.PAK'
SECTOR=2048
SOURCE_CAP=0x5000
PCM_CAP=0x8000
SCSP_START=0x14000
SCSP_LIMIT=0x3A800
ASSETS={
    18:(61136,16009,32018),
    69:(245328,2293,4586),
    70:(247624,2303,4606),
    71:(249928,2602,5204),
    72:(252532,1563,3126),
}
p=PACK.read_bytes()
assert len(p)==438658
addr=SCSP_START
for sid,(off,adpcm,pcm) in ASSETS.items():
    sector=off//SECTOR
    skip=off%SECTOR
    need=skip+adpcm
    read_bytes=(need+SECTOR-1)&~(SECTOR-1)
    assert read_bytes<=SOURCE_CAP
    window=p[sector*SECTOR:sector*SECTOR+read_bytes]
    assert window[skip:skip+adpcm]==p[off:off+adpcm]
    assert pcm==adpcm*2 and pcm<=PCM_CAP
    addr=(addr+31)&~31
    assert addr+pcm<=SCSP_LIMIT
    addr+=pcm
# Exact source18 evidence shipped by the audio package.
assert p[61136:61136+16009]==(Path(__file__).resolve().parent/'sample18.adpcm').read_bytes()
print(f'PASS Test254 hotset: 5 RECOVERED_ROM SFX payloads; SCSP end=0x{addr:X}; persistent HWRAM payload=0')
