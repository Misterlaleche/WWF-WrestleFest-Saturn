#!/usr/bin/env python3
"""Exact packed-asset host reference; not a Saturn emulator or hardware capture."""
from pathlib import Path
import argparse,csv,json
import numpy as np
from PIL import Image,ImageDraw

def rgb(w):return np.stack([(w&31)*255//31,((w>>5)&31)*255//31,((w>>10)&31)*255//31],axis=-1).astype(np.uint8)
class Renderer:
 def __init__(self,root):
  self.root=Path(root);self.m=json.loads((self.root/'model.json').read_text())
  raw=np.fromfile(self.root/'assets/SPRITES.TEX',dtype=np.uint8).reshape(-1,16,8)
  self.tiles=np.empty((len(raw),16,16),np.uint8);self.tiles[:,:,::2]=raw>>4;self.tiles[:,:,1::2]=raw&15
  self.pal=rgb(np.fromfile(self.root/'assets/PALETTES.PAL',dtype='>u2').reshape(-1,16))
  self.world=rgb(np.fromfile(self.root/'assets/RING.PAL',dtype='>u2'))[np.fromfile(self.root/'assets/RING.BIN',dtype=np.uint8).reshape(512,512)]
 def draw(self,dst,records,anchor=(0,0),mirror=False):
  height,width=dst.shape[:2]
  for t,x,y,p,f in records:
   if mirror:x=-x-16;f^=1
   a=self.tiles[t];a=a[:,::-1] if f&1 else a;a=a[::-1,:] if f&2 else a
   x+=anchor[0];y+=anchor[1];x0=max(0,x);y0=max(0,y);x1=min(width,x+16);y1=min(height,y+16)
   if x0>=x1 or y0>=y1:continue
   cut=a[y0-y:y1-y,x0-x:x1-x];mask=cut!=0
   dst[y0:y1,x0:x1][mask]=self.pal[p,cut[mask]]
 def frame(self,r):
  cx,cy=r['camera_x'],r['camera_y'];assert -130<=cx<=62 and -95<=cy<=131
  dst=self.world[cy+141:cy+381,cx+130:cx+450].copy();assert dst.shape==(240,320,3)
  def actor(i):self.draw(dst,self.m['clips'][i]['frames'][r[f'pose{i}']],(r[f'x{i}']-cx,r[f'y{i}']-cy-r[f'lift{i}']),r[f'dir{i}']<0)
  def ref():self.draw(dst,self.m['clips'][5]['frames'][r['refpose']],(r['refx']-cx,r['refy']-cy),r['refdir']<0)
  packed=r['draw_order'];sides=self.m['arena']['static_side_commands']
  while packed:
   layer=packed&15;packed>>=4
   if layer==1:self.draw(dst,self.m['front'][:sides],(-cx,-cy))
   elif layer in [2,3]:actor(layer-2)
   elif layer==4:
    anchor=r['anchor'];self.draw(dst,self.m['clips'][r['shared_clip']]['frames'][r['shared_pose']],(r[f'x{anchor}']-cx,r[f'y{anchor}']-cy),r['pair_dir']<0)
   elif layer==5:ref()
   elif layer==6:self.draw(dst,self.m['front'][sides:],(-cx,-cy))
   elif layer==7:self.draw(dst,self.m['clips'][6]['frames'][r['prompt_pose']],(r['prompt_x'],106))
   else:raise AssertionError(layer)
  return Image.fromarray(dst)

def render(root,trace):
 rr=Renderer(root);docs=rr.root/'docs';docs.mkdir(exist_ok=True)
 with open(trace) as f:rows=[{k:int(v) for k,v in r.items()} for r in csv.DictReader(f)]
 selected={4:'escape',9:'corner_back_left',14:'climb_down',16:'left_ropes',17:'right_ropes',20:'referee_hulk_pin',22:'referee_jake_pin'};gifs={k:[] for k in selected};seen=set()
 for r in rows:
  im=rr.frame(r)
  if r['run']==0 and r['tick']==0:im.save(docs/'scene_reference.png')
  if 9<=r['run']<=12:
   key=(r['run'],r['pose0'],r['state0'])
   if key not in seen:im.save(docs/f"corner{r['run']-9}_state{r['state0']}_pose{r['pose0']}.png");seen.add(key)
  if r['run'] not in selected:continue
  # Sampling retains integer positions. The label explicitly identifies a host render.
  stride=12 if r['run']==13 else (4 if r['run']<9 else 2)
  if r['tick']%stride:continue
  d=ImageDraw.Draw(im);d.rectangle((8,8,311,34),fill='black')
  status='NATIVE HOST REFERENCE - TEST08-R1'
  if r['state0']==10:status='CORNER: A DIVE / B CLIMB DOWN'
  elif r['state0']==9:status='CLIMBING TURNBUCKLE'
  elif r['state0']==11:status='CLIMBING DOWN'
  elif r['state0']==12:status='DIVING ATTACK'
  elif r['pair']==3:status=f"PIN COUNT {r['pin_count']}/3"
  elif r['corner_near']>=0:status='L TO CLIMB TURNBUCKLE'
  d.text((12,10),status,fill='white');d.text((12,22),f"HULK {r['hp0']}  JAKE {r['hp1']}  CAMERA {r['camera_x']},{r['camera_y']}",fill='white')
  gifs[r['run']].append(im.resize((640,480),Image.Resampling.NEAREST))
 for run,frames in gifs.items():
  if frames:frames[0].save(docs/f'{selected[run]}_preview.gif',save_all=True,append_images=frames[1:],duration=210 if run==13 else (70 if run<9 else 35),loop=0)
 world=rr.world.copy();rr.draw(world,rr.m['front'],(130,141));Image.fromarray(world).save(docs/'arena_complete.png')
 sheet=Image.new('RGB',(5*144,2*192),(32,32,32));d=ImageDraw.Draw(sheet)
 for i,pose in enumerate(range(19,29)):
  a=np.full((192,144,3),32,np.uint8);rr.draw(a,rr.m['clips'][0]['frames'][pose],(72,174))
  x=i%5*144;y=i//5*192;sheet.paste(Image.fromarray(a),(x,y));d.text((x+3,y+178),rr.m['clips'][0]['poses'][pose],fill='white')
 sheet.save(docs/'corner_poses.png')
 (docs/'trace_summary.json').write_text(json.dumps({'samples':len(rows),'runs':len(set(r['run'] for r in rows)),'host_reference_only':True},indent=2)+'\n')
 print('Rendered',len(rows),'samples; new actions, full arena and camera references.')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('trace');p.add_argument('--root',default=Path(__file__).resolve().parents[1]);a=p.parse_args();render(a.root,a.trace)
