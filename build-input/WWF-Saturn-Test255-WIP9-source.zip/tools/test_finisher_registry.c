#include "finisher_data.h"
#include "arcade_animation.h"
#include <assert.h>
#include <stdio.h>
static void mapped(unsigned ch,unsigned descriptor,unsigned action,unsigned addr,unsigned first,unsigned count){
 const finisher_record_t *r=finisher_record(ch);
 assert(r->descriptor_index==descriptor&&r->action_index==action&&r->rom_address==addr);
 assert(r->pose_count==count&&finisher_descriptor_mapped(ch)&&finisher_graphics_ready(ch));
 assert(finisher_sequence_pose(ch,0)==first);assert(finisher_overlay_bytes[ch]>0&&finisher_overlay_frames[ch]>0);
}
int main(void){
 for(unsigned ch=0;ch<10;ch++)assert((unsigned)finisher_for_character(ch)==ch);
 mapped(0,64,53,0x175a8,132,5);mapped(1,58,47,0x16c5e,263,6);
 mapped(2,63,52,0x1747e,144,9);mapped(3,60,49,0x16fd8,194,8);
 mapped(4,51,40,0x1641e,334,4);mapped(5,141,137,0x1aba4,269,5);
 mapped(6,70,59,0x17cf6,411,5);mapped(7,38,26,0x1520c,324,5);
 const finisher_record_t *eq=finisher_record(8);assert(eq->descriptor_index==46&&eq->action_index==35&&eq->rom_address==0x15ce0&&eq->evidence==FINISHER_EVIDENCE_CANDIDATE&&!finisher_descriptor_mapped(8));mapped(9,65,54,0x17912,248,4);
 assert(finisher_record(3)->condition==FINISHER_COND_OPPONENT_RUNNING);
 assert(finisher_record(0)->condition==FINISHER_COND_PRONE_DIAGONAL);
 assert(finisher_record(8)->evidence==FINISHER_EVIDENCE_CANDIDATE);
 
 static const unsigned exact_damage[10]={18,22,28,22,18,0,0,22,0,0};
 for(unsigned ch=0;ch<10;ch++){
  if(exact_damage[ch]){assert(finisher_damage_exact(ch));assert(finisher_damage_value(ch)==exact_damage[ch]);}
  else assert(!finisher_damage_exact(ch));
 }
puts("PASS: all ten trademark moves bind recovered descriptor clocks and on-demand overlay metadata");return 0;
}
