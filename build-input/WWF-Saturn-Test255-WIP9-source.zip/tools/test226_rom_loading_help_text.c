#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned char *readf(const char *p,size_t *n){FILE*f=fopen(p,"rb");assert(f);fseek(f,0,SEEK_END);*n=ftell(f);rewind(f);unsigned char*b=malloc(*n);assert(b);assert(fread(b,1,*n,f)==*n);fclose(f);return b;}
static void exact(unsigned char*b,size_t n,size_t off,const char*s){size_t l=strlen(s);assert(off+l<=n);assert(!memcmp(b+off,s,l));}
int main(void){size_t n;unsigned char*b=readf("program.bin",&n);exact(b,n,0x259e9,"DCHOOSE 2 WRESTLERS AND");exact(b,n,0x25a01,"MAKE TEAM.");exact(b,n,0x25a0c,"USE COMBINATION PLAY");exact(b,n,0x25a8f,"DCHOOSE 1 WRESTLER AND");exact(b,n,0x25aa6,"BEAT WRESTLERS ONE");exact(b,n,0x25adb,"GET THEM OUT OF THE");exact(b,n,0x25aef,"RING OF GET FALL,AND");exact(b,n,0x25b04,"BE A CHAMPION.");free(b);puts("PASS Test226: loading help wording is byte-pinned to original ROM tutorial/attract strings; reuse as loading commentary is explicitly provisional");}