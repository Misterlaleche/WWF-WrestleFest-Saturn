#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static char *slurp(const char *p){FILE*f=fopen(p,"rb");assert(f);fseek(f,0,SEEK_END);long n=ftell(f);rewind(f);char*s=malloc((size_t)n+1);assert(s);assert(fread(s,1,(size_t)n,f)==(size_t)n);fclose(f);s[n]=0;return s;}
int main(void){char*s=slurp("main.c");
 assert(strstr(s,"old_intro==INTRO_TECHNOS&&intro.screen==INTRO_TITLE"));
 assert(strstr(s,"loading_begin(LOAD_BOOT,0)"));
 assert(strstr(s,"if(!loading.shown){loading.shown=1;return false;}"));
 assert(strstr(s,"cd_read(\"TITLE.ANM\",(void *)LWRAM(0),1048576)"));
 assert(strstr(s,"title_lwram_cached=true"));
 assert(strstr(s,"if(!title_lwram_cached)"));
 free(s);puts("PASS Test223: Technos -> title now enters a visible boot-loading state before any staged blocking CD preload; TITLE.ANM is loaded under that screen and reused by title presentation");}
