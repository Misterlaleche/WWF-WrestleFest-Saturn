#include <assert.h>
#include <stdio.h>
#include "../roster_data.h"
int main(void){
 assert(ROSTER_FRAMES>=212);
 assert(roster_arcade_frame_character(0,104)==207);
 assert(roster_arcade_frame_character(0,112)==210);
 assert(roster_arcade_frame_character(0,113)==211);
 assert(roster_arcade_frame_character(2,104)==207);
 assert(roster_arcade_frame_character(2,110)==208);
 assert(roster_arcade_frame_character(2,111)==209);
 assert(roster_arcade_frame_character(1,104)==ROSTER_FRAMES);
 puts("PASS Test232: six RISE character/pose compositions now resolve to exact resident frames; unmapped characters remain guarded");
 return 0;
}
