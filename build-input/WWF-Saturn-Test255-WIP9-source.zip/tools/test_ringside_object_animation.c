#include <assert.h>
#include <stdio.h>
#include "arcade_ringside.h"
#include "arcade_animation.h"
int main(void){
 unsigned p0=arcade_ringside_pickup_descriptor(0),p1=arcade_ringside_pickup_descriptor(1);
 unsigned u0=arcade_ringside_use_descriptor(0),u1=arcade_ringside_use_descriptor(1);
 assert(p0==0x19e80&&p1==0x19e90&&u0==0x159f8&&u1==0x15a0c);
 assert(arcade_animation_sample(p0,0)==114&&arcade_animation_sample(p0,8)==114&&arcade_animation_sample(p0,9)==115&&arcade_animation_sample(p0,17)==115);
 assert(arcade_animation_sample(p1,0)==119&&arcade_animation_sample(p1,9)==120&&arcade_animation_sample(p1,17)==120);
 assert(arcade_animation_sample(u0,0)==116&&arcade_animation_sample(u0,8)==116&&arcade_animation_sample(u0,9)==117&&arcade_animation_sample(u0,17)==117&&arcade_animation_sample(u0,18)==118&&arcade_animation_sample(u0,26)==118);
 assert(arcade_animation_sample(u1,0)==121&&arcade_animation_sample(u1,9)==122&&arcade_animation_sample(u1,18)==123&&arcade_animation_sample(u1,26)==123);
 puts("PASS: exact two-object pickup/use descriptors, poses and underflow-inclusive 9-tick clocks");
}
