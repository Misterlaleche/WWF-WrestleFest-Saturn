#include "../campaign_presentation.h"
#include <assert.h>
#include <stdio.h>
int main(void){campaign_t c;campaign_reset(&c,CAMPAIGN_TAG,5,0,0);campaign_presentation_t p;campaign_presentation_reset(&p);assert(campaign_matches_remaining(&c)==10);c.wins=3;c.stage=3;assert(campaign_matches_remaining(&c)==7);campaign_presentation_begin_progress(&p);assert(p.screen==CAMPAIGN_PRESENT_PROGRESS&&!campaign_presentation_tick(&p,8,false));p.tick=299;assert(campaign_presentation_tick(&p,1,false));puts("PASS Test217: TAG progress interstitial has deterministic lifetime and remaining-match model");}
