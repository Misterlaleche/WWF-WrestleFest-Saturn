#include "game.h"
#include <assert.h>
#include <stdio.h>
static void start_hold(game_t *g){unsigned r[10]={0,2,1,3,4,5,6,7,8,9};game_match_start_rumble_queue(g,r,10);g->cpu=false;g->active_mask=3U;g->fighters[0].x=100*256;g->fighters[0].y=200*256;g->fighters[0].facing=1;g->fighters[1].x=140*256;g->fighters[1].y=200*256;game_tick(g,INPUT_RIGHT,INPUT_GRAB);assert(g->pair==PAIR_STRUGGLE);for(unsigned round=0;round<2;round++){game_tick(g,0,INPUT_PUNCH);for(unsigned i=0;i<60;i++)game_tick(g,0,0);}assert(g->pair==PAIR_HOLD&&g->pair_attacker==0);}
int main(void){game_t g;start_hold(&g);int x0=g.fighters[0].x,x1=g.fighters[1].x,delta=g.fighters[1].x-g.fighters[0].x;for(unsigned i=0;i<12;i++)game_tick(&g,INPUT_RIGHT,0);assert(g.pair==PAIR_HOLD);assert(g.fighters[0].x>x0&&g.fighters[1].x>x1);assert(g.fighters[1].x-g.fighters[0].x==delta);puts("PASS Test125: human headlock composition can walk as one unit, enabling the documented Rumble rope setup and future headlock-to-corner TAG path");}
