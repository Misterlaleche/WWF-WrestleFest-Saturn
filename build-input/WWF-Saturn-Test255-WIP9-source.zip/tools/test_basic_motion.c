#include "game.h"
#include "game.h" /* Guard must cover the entire public API. */
#include "arcade_animation.h"
#include "arcade_animation_data.h"
#include "autoplay.h"
#include <assert.h>
#include <stdio.h>
static const unsigned chars[6]={0,2,7,1,4,5};
static void setup(game_t *g,unsigned ch){
 game_match_start(g,GAME_TAG,chars);g->cpu=false;
 g->fighters[0].character=ch;g->fighters[0].x=100*256;g->fighters[0].y=210*256;
 g->fighters[1].x=250*256;g->fighters[1].y=RING_TOP*256;
}
int main(void){
 /* Independent sequential clock and random-access game sampler agree. */
 for(unsigned i=0;i<ARCADE_ANIMATION_COUNT;i++){
  const arcade_animation_t *a=&arcade_animations[i];arcade_animation_clock_t c;
  arcade_animation_reset(&c,a);
  for(unsigned t=0;t<2000;t++){
   assert(arcade_animation_sample(a->rom_address,t)==arcade_animation_pose(&c,a));
   arcade_animation_tick(&c,a);
  }
 }
 assert(arcade_animation_sample(0xffffffff,0)==0xffff);
 static const int speed[12]={27,29,28,25,30,27,24,30,22,27,28,27};
 game_t g;
 for(unsigned ch=0;ch<12;ch++)for(int sign=-1;sign<=1;sign+=2){
  setup(&g,ch);fighter_t *f=&g.fighters[0];
  int x=f->x,y=f->y;unsigned direction=sign>0?INPUT_RIGHT:INPUT_LEFT;
  for(unsigned t=0;t<10;t++)game_tick(&g,direction,0);
  assert(f->x-x==sign*speed[ch]*20*10&&f->y==y);
  setup(&g,ch);x=f->x;y=f->y;
  for(unsigned t=0;t<10;t++)game_tick(&g,direction|INPUT_UP,0);
  assert((f->x-x)*256+f->move_fraction_x==sign*speed[ch]*0xe24*10);
  assert((f->y-y)*256+f->move_fraction_y==-speed[ch]*0xb50*10);
 }
 setup(&g,0);fighter_t *f=&g.fighters[0];f->state=ST_WALK;
 unsigned seen[4]={0};
 for(unsigned t=1;t<=44;t++){f->walk_tick=t;int p=game_arcade_pose(f);assert(p>=1&&p<=4);seen[p-1]++;}
 for(unsigned i=0;i<4;i++)assert(seen[i]==11);
 setup(&g,0);game_tick(&g,0,INPUT_PUNCH);assert(game_arcade_pose(f)==0);
 for(unsigned t=1;t<37;t++){
  game_tick(&g,0,0);assert(f->state==ST_PUNCH);
  int expected=t<11?0:t<18?146:t<23?147:t<34?148:147;
  assert(game_arcade_pose(f)==expected);
 }
 game_tick(&g,0,0);assert(f->state==ST_IDLE);
 setup(&g,0);game_tick(&g,0,INPUT_KICK);
 for(unsigned t=1;t<33;t++){
  game_tick(&g,0,0);assert(f->state==ST_KICK);
  assert(game_arcade_pose(f)==(t<11?0:t<22?461:462));
 }
 g.paused=true;unsigned before=f->tick;for(unsigned i=0;i<100;i++)game_tick(&g,0,0);
 assert(f->tick==before);g.paused=false;game_tick(&g,0,0);assert(f->state==ST_IDLE);
 /* Production hit eligibility coincides with the visible contact pose. */
 setup(&g,0);g.fighters[1].x=140*256;g.fighters[1].y=210*256;
 game_tick(&g,0,INPUT_PUNCH);for(unsigned i=0;i<22;i++)game_tick(&g,0,0);
 assert(!g.hits[0]);game_tick(&g,0,0);assert(g.hits[0]==1&&game_arcade_pose(f)==148);
 for(unsigned i=0;i<50;i++)game_tick(&g,0,0);
 assert(g.hits[0]==1);
 for(unsigned mode=GAME_TAG;mode<=GAME_RUMBLE;mode++)for(unsigned lead=0;lead<10;lead++){
  unsigned cast[6];for(unsigned i=0;i<6;i++)cast[i]=(lead+i)%10;
  game_match_start(&g,mode,cast);
  for(unsigned t=0;t<10000&&!g.finished;t++){
   unsigned b=autoplay_buttons(&g);game_tick(&g,b&15,b&~15U);
   for(unsigned i=0;i<g.roster_count;i++){
    assert(g.fighters[i].health<=g.fighters[i].max_health&&g.fighters[i].character<10);
    int pose=game_arcade_pose(&g.fighters[i]);assert(pose==-1||(pose>=0&&pose<564));
   }
  }
 }
 puts("PASS: 216 descriptor samplers, 12 character speeds, subpixel diagonal residual, full walk cycle, basic attack poses/timing/contact and pause");
}
