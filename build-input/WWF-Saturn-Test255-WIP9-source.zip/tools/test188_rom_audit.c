#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void seq(long o,const uint8_t*p,size_t n){FILE*f=fopen("program.bin","rb");assert(f);uint8_t*b=malloc(n);assert(b);assert(fseek(f,o,SEEK_SET)==0&&fread(b,1,n,f)==n);fclose(f);assert(!memcmp(b,p,n));free(b);}
int main(void){
 const uint8_t p[]={0x0c,0x28,0x00,0x46,0x00,0x61,0x66,0x0c,0x30,0x3c,0xff,0xd0,0x42,0x41,0x42,0x42,0x61,0x00,0xc5,0x7c};seq(0x14642,p,sizeof p);
 puts("PASS Test188: fallback applies the extra $FFD0 impulse only to neighbouring raw action $46, not action $47");return 0;}
