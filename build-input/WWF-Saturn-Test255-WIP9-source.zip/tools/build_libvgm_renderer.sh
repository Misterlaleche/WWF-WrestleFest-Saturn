#!/usr/bin/env bash
set -euo pipefail
root="${1:-/tmp/libvgm-audio-complete}"
rm -rf "$root"
git clone --depth 1 --recursive https://github.com/ValleyBell/libvgm.git "$root"
sed -i 's@// set_core(plrEngine,DEVID_YM2612,FCC_NUKE);@set_core(plrEngine,DEVID_YM2151,FCC_NUKE);@' "$root/vgm2wav.cpp"
grep 'set_core(plrEngine,DEVID_YM2151,FCC_NUKE);' "$root/vgm2wav.cpp"
cmake -S "$root" -B "$root/build" -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build "$root/build" --target vgm2wav
find "$root/build" -type f -name vgm2wav -perm -111 | head -1
