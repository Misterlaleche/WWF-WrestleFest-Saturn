#!/usr/bin/env python3
"""Build ROM-exact ring-transition compositions and bank-14 palette for Test253.

The arcade descriptors/actions recovered from program.bin use:
  raw $06 / descriptor $13020: poses 175,176,0 (linked ring-out aggressor)
  raw $69 / descriptor $199FC: poses 32..38, clears actor +$33 bit2 (ring exit)
  raw $6C / descriptor $19C28: poses 39..43, sets actor +$33 bit2 (front ring entry)
  raw $68 / descriptor $1981E: poses 22,19,104 (forced fall/outside chain)
  raw $6A / descriptor $19B3C: poses 19,104,0 (outside recovery chain)
  raw state 4 selector 14 / descriptor $1B460: poses 177,177,178,179 (tossed flight)

Poses 32..41 mix wrestler bank 0..9 with graphics bank 14.  This pack keeps
original piece order and palette-bank runs and emits bank 14 separately as
RING14.PAL.  No graphics or colors are invented.
"""
from pathlib import Path
import hashlib,json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import arcade_composition as comp
import build_exact_ground_assets as common

ROOT=Path(__file__).resolve().parents[1]
PROGRAM=ROOT/'program.bin'; GFX=ROOT/'gfx2.bin'
POSES=[19,22,27]+list(range(32,44))+[104,175,176,177,178,179]
PALETTE_TABLE=0x2F22; PALETTE_BANK=14; PALETTE_OFFSET=PALETTE_TABLE+PALETTE_BANK*32
PROGRAM_SHA256='265ac89deeb7e708ac6fda724356bfd6af1c9012928a4e551e6e2faa424c2306'
GFX_SHA256='a3b5e1fedd6c41cd398ba0cb437cddb2f50b3ae0a0dc178a10b70a7ed5d010ba'

def rgb444_to_rgb555(v):
 r=v&15;g=(v>>4)&15;b=(v>>8)&15
 r=(r<<1)|(r>>3);g=(g<<1)|(g>>3);b=(b<<1)|(b>>3)
 return 0x8000|(b<<10)|(g<<5)|r

def main():
 p=PROGRAM.read_bytes();g=GFX.read_bytes()
 assert hashlib.sha256(p).hexdigest()==PROGRAM_SHA256
 assert hashlib.sha256(g).hexdigest()==GFX_SHA256
 assert p[0x2B26:0x2B2C]==bytes.fromhex('47 f9 00 00 2f 22')
 src=[int.from_bytes(p[PALETTE_OFFSET+i*2:PALETTE_OFFSET+i*2+2],'big') for i in range(16)]
 assert src[0]==0
 pal555=[rgb444_to_rgb555(v) for v in src]
 pal_bytes=b''.join(v.to_bytes(2,'big') for v in pal555)
 (ROOT/'assets'/'RING14.PAL').write_bytes(pal_bytes)
 comp.load_program(PROGRAM);tile=common.make_tile_decoder()
 frames=[];textures=[];lookup={};runs={};mapping={};detail=[];mask=0
 for ch in range(10):
  for pose in POSES:
   pieces=comp.commands(ch,pose,partner=(ch+1)%10);assert pieces,(ch,pose)
   rec=[];rr=[];last=None;banks=[]
   for q in pieces:
    bank=q['bank'];assert bank<10 or bank==PALETTE_BANK,(ch,pose,bank)
    mask|=1<<bank;banks.append(bank);px=tile(q['code'])
    if px not in lookup:lookup[px]=len(textures);textures.append(px)
    rec.append([lookup[px],*common.geom(q)])
    if last==bank:rr[-1][1]+=1
    else:rr.append([bank,1]);last=bank
   fr=len(frames);frames.append(rec);runs[fr]=rr;mapping[(ch,pose)]=fr
   detail.append(dict(character=ch,pose=pose,frame=fr,pieces=len(rec),banks={str(b):banks.count(b) for b in sorted(set(banks))},runs=rr))
 # The rope-crossing poses must really prove bank14 usage for every wrestler.
 for ch in range(10):
  for pose in range(32,42):
   d=detail[ch*len(POSES)+POSES.index(pose)]
   assert str(PALETTE_BANK) in d['banks'],(ch,pose)
 data=common.pack(frames,textures,32);path=ROOT/'cd'/'RING14.PAK';path.write_bytes(data)
 hv=common.fnv(data);aligned=(len(data)+2047)&~2047
 out=['#ifndef WWF_RING_TRANSITION_ASSETS_H','#define WWF_RING_TRANSITION_ASSETS_H','#include <stdint.h>',
      'typedef struct {uint8_t palette,count;} ring_transition_run_t;',
      f'#define RING_TRANSITION_PALETTE_BANK {PALETTE_BANK}U',
      f'#define RING_TRANSITION_PALETTE_SOURCE_OFFSET 0x{PALETTE_OFFSET:08X}U',
      f'#define RING_TRANSITION_REQUIRED_PALETTE_MASK 0x{mask:04X}U',
      f'#define RING_TRANSITION_PACK_FRAMES {len(frames)}U',f'#define RING_TRANSITION_PACK_BYTES {len(data)}U',
      f'#define RING_TRANSITION_PACK_ALIGNED_BYTES {aligned}U',f'#define RING_TRANSITION_PACK_HASH {hv}U',
      'static inline unsigned ring_transition_asset_frame(unsigned ch,unsigned pose){',' if(ch>=10U)return 0xffffU;',' switch(pose){']
 for i,pose in enumerate(POSES):out.append(f' case {pose}U:return ch*{len(POSES)}U+{i}U;')
 out+=[' default:return 0xffffU;',' }','}']
 for fr in range(len(frames)):
  out.append(f'static const ring_transition_run_t ring_transition_runs_{fr}[]={{'+','.join('{%d,%d}'%tuple(x) for x in runs[fr])+'};')
 out+=['static inline const ring_transition_run_t *ring_transition_asset_runs(unsigned frame,unsigned *count){',' switch(frame){']
 for fr in range(len(frames)):out.append(f' case {fr}U:*count={len(runs[fr])}U;return ring_transition_runs_{fr};')
 out+=[' default:*count=0;return 0;',' }','}','#endif']
 (ROOT/'ring_transition_assets.h').write_text('\n'.join(out)+'\n')
 report=dict(test=253,version='V0.268',classification='ROM-EXACT',program_sha256=PROGRAM_SHA256,gfx2_sha256=GFX_SHA256,
  raw_actions={'0x06':{'descriptor':'0x13020','callback':'0x13034','poses':[175,176,0],'ticks':[33,25,33],'semantic':'linked ring-out aggressor; all four state4/selector14 producers write A2+$60=$C006'},'0x68':{'descriptor':'0x1981e','poses':[22,19,104]},'0x69':{'descriptor':'0x199fc','poses':list(range(32,39)),'semantic':'ring exit; callback clears +$33 bit2'},
               '0x6a':{'descriptor':'0x19b3c','poses':[19,104,0],'semantic':'outside recovery/return chain'},
               '0x6c':{'descriptor':'0x19c28','poses':[39,40,41,42,43,42],'semantic':'front ring entry; callback sets +$33 bit2'},
               'state4_selector14':{'descriptor':'0x1b460','poses':[177,177,178,179],'semantic':'linked thrown-flight state; produced at 0x1a8de/0x1a978/0x1aa1a/0x1aad6'}},
  palette_loader={'table':'0x2f22','bank':14,'source_offset':f'0x{PALETTE_OFFSET:x}'},palette_rgb444=[f'{v:03x}' for v in src],palette_rgb555=[f'{v:04x}' for v in pal555],
  ring_palette_sha256=hashlib.sha256(pal_bytes).hexdigest(),pack_bytes=len(data),pack_aligned_bytes=aligned,pack_fnv1a=hv,pack_sha256=hashlib.sha256(data).hexdigest(),
  frames=len(frames),textures=len(textures),records=sum(map(len,frames)),required_palette_mask=f'0x{mask:04x}',poses=POSES,frames_detail=detail,
  note='Original per-piece bank ordering preserved. Bank14 rope pieces never use wrestler palettes.')
 (ROOT/'docs'/'test253-ring-transition-build.json').write_text(json.dumps(report,indent=2)+'\n')
 print(f'PASS Test253 ring assets: {len(frames)} frames, {len(textures)} tiles, {len(data)} bytes, bank14 @ 0x{PALETTE_OFFSET:x}, mask 0x{mask:04x}')
if __name__=='__main__':main()
