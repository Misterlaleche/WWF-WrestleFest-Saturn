#include <assert.h>
#include <stdio.h>
#include "arcade_ringside.h"
int main(void){
 int x=0x200,y=0x150,z=0x170; unsigned state=99;
 arcade_ringside_state2_probe_t none={0,0x55,0x66,0x77,ARCADE_OBJECT_STATE2_COLLISION_BIT};
 assert(!arcade_ringside_state2_apply_probes(&x,&y,&z,&none,&none,&state));
 assert(x==0x200&&y==0x150&&z==0x170&&state==ARCADE_OBJECT_THROWN_STATE);

 arcade_ringside_state2_probe_t forward={1,-0x20,0x04,-0x10,0};
 arcade_ringside_state2_probe_t reverse={2,0x70,0x70,0x70,ARCADE_OBJECT_STATE2_COLLISION_BIT};
 assert(arcade_ringside_state2_apply_probes(&x,&y,&z,&forward,&reverse,&state));
 assert(x==0x1e0&&y==0x154&&z==0x160&&state==ARCADE_OBJECT_THROWN_STATE);

 x=0x200;y=0x150;z=0x170;
 arcade_ringside_state2_probe_t hit_floor={3,0,0,-0x30,ARCADE_OBJECT_STATE2_COLLISION_BIT};
 assert(arcade_ringside_state2_apply_probes(&x,&y,&z,&none,&hit_floor,&state));
 assert(x==0x200&&y==0x150&&z==0x140&&state==ARCADE_OBJECT_POST_THROW_STATE);
 puts("PASS: ROM $FE82 uses $280DC correction probes (+$20 then -$20); no-contact skips XYZ integration and bit-4 contact advances 2 -> 4");
 return 0;
}
