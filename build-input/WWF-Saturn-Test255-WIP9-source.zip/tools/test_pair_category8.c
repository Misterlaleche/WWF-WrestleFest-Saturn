#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arcade_action_map.h"
static void seq(const unsigned char *r,size_t n,size_t o,const unsigned char *s,size_t z){assert(o+z<=n);assert(!memcmp(r+o,s,z));}
int main(void){
 FILE*f=fopen("program.bin","rb");assert(f);fseek(f,0,SEEK_END);long n=ftell(f);rewind(f);unsigned char*r=malloc((size_t)n);assert(r);assert(fread(r,1,(size_t)n,f)==(size_t)n);fclose(f);
 const unsigned char gate[]={0x22,0x68,0x00,0x26,0x0c,0x28,0x00,0x0b,0x00,0x21,0x66,0x00};seq(r,(size_t)n,0xe180,gate,sizeof gate);
 const unsigned char flags[]={0x08,0x28,0x00,0x05,0x00,0x44,0x66,0x00,0xfe,0x8c,0x08,0x28,0x00,0x06,0x00,0x44};seq(r,(size_t)n,0xe18e,flags,sizeof flags);
 const unsigned char setcat[]={0x08,0xe9,0x00,0x06,0x00,0x44,0x30,0x3c,0x00,0x08};seq(r,(size_t)n,0xe1a2,setcat,sizeof setcat);
 unsigned after=0;assert(arcade_pair_category8_raw(1,0x0b,0,0x0003,&after)==8);assert(after==0x0043);
 after=0x55;assert(arcade_pair_category8_raw(0,0x0b,0,0,&after)<0&&after==0);
 assert(arcade_pair_category8_raw(1,0x0c,0,0,&after)<0);
 assert(arcade_pair_category8_raw(1,0x0b,0x20,0,&after)<0);
 assert(arcade_pair_category8_raw(1,0x0b,0x40,0,&after)<0);
 for(unsigned i=0;i<12;i++){assert(arcade_action_for_buttons_internal(i,8,1)==0x29);assert(arcade_action_for_buttons_internal(i,8,2)==0x29);assert(arcade_action_for_buttons_internal(i,8,3)==0x29);}
 free(r);puts("PASS Test79: ROM category $08 requires existing +$26 link, attacker state $0B and clear attacker +$44 bits5/6; target +$44 bit6 is set and all 12x3 action-map entries select $29");return 0;
}
