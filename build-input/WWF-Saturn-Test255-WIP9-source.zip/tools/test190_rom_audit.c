#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void seq(long o,const uint8_t*p,size_t n){FILE*f=fopen("program.bin","rb");assert(f);uint8_t*b=malloc(n);assert(b);assert(fseek(f,o,SEEK_SET)==0&&fread(b,1,n,f)==n);fclose(f);assert(!memcmp(b,p,n));free(b);}
int main(void){const uint8_t a[]={0x35,0x7c,0x00,0x23,0x00,0x64,0x08,0xea,0x00,0x05,0x00,0x64,0x08,0xea,0x00,0x03,0x00,0x32};seq(0x17542,a,sizeof a);const uint8_t b[]={0x35,0x7c,0x00,0x1c,0x00,0x68};seq(0x17554,b,sizeof b);puts("PASS Test190: Jake DDT impact writes victim +$64=$23 with bits5/3 set and exact +$68=$1C (28)");return 0;}
