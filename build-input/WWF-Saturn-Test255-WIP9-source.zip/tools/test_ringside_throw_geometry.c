#include <assert.h>
#include <stdio.h>
#include "game.h"
#include "arcade_ringside.h"
static void prep(game_t *g,int facing){
 unsigned r[6]={0,2,1,3,0,0};game_match_start_arcade(g,GAME_TAG,r,1,0);
 fighter_t *f=&g->fighters[0];ringside_object_t *o=&g->ringside_objects[0];
 f->outside=true;f->x=123*256;f->y=229*256;f->facing=facing;f->held_object=1;
 o->holder=1;o->state=ARCADE_OBJECT_HELD_STATE;o->x=f->x;o->y=f->y;o->z=0;
}
int main(void){
 game_t g;prep(&g,1);game_drop_ringside_object(&g,0);
 assert(g.ringside_objects[0].state==ARCADE_OBJECT_THROWN_STATE);
 assert(g.ringside_objects[0].x==(123+0x60)*256);
 assert(g.ringside_objects[0].y==229*256);
 assert(g.ringside_objects[0].z==0x40*256);
 prep(&g,-1);game_drop_ringside_object(&g,0);
 assert(g.ringside_objects[0].x==(123-0x60)*256);
 assert(g.ringside_objects[0].z==0x40*256);
 puts("PASS: ROM $15A20 throw release uses state 2, exact +/-$60 X and +$40 height");
 return 0;
}
