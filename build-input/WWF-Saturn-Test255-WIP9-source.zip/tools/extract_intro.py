#!/usr/bin/env python3
"""Reconstruct original boot plates from verified ROMs + captured video state.

No screenshot is used as texture input. The source PNG hashes are independent
references. Only CREDIT and INSERT COIN cells are removed from the text map.
PRESS START is rebuilt from the original 8x8 font as a native VDP1 texture.
"""
from pathlib import Path
import argparse, hashlib, json, struct, zipfile, zlib
import numpy as np
from PIL import Image, ImageDraw
from extract_assets import ROM_SPECS, fnv

SCENES = [('f0120', 'WINNERS DON\'T USE DRUGS'), ('f0240', 'LEGAL'),
          ('f0480', 'TECHNOS / TECMO'), ('f1260', 'WRESTLEFEST')]

def pack(data):
    """High bit: repeat 1..128 bytes. Otherwise literal 1..128 bytes."""
    out = bytearray(); i = 0
    while i < len(data):
        run = 1
        while run < 128 and i+run < len(data) and data[i+run] == data[i]: run += 1
        if run >= 3:
            out.extend((0x80 | (run-1), data[i])); i += run
        else:
            start = i; i += 1
            while i < len(data) and i-start < 128:
                if i+2 < len(data) and data[i] == data[i+1] == data[i+2]: break
                i += 1
            out.append(i-start-1); out.extend(data[start:i])
    return bytes(out)

def color555(v):
    r=v&15; g=(v>>4)&15; b=(v>>8)&15
    return 0x8000 | (((b<<1)|(b>>3))<<10) | (((g<<1)|(g>>3))<<5) | (r<<1)|(r>>3)

def rgb444(words):
    return np.stack([(words&15)*17,((words>>4)&15)*17,((words>>8)&15)*17],axis=2).astype(np.uint8)

def rgb555(words):
    v=words.astype(np.uint32)
    return np.stack([(v&31)*255//31,((v>>5)&31)*255//31,((v>>10)&31)*255//31],axis=2).astype(np.uint8)

def extract(rom, root):
    with zipfile.ZipFile(rom) as z:
        parts=[]
        for name,crc in ROM_SPECS:
            d=z.read(name); assert len(d)==0x100000 and f'{zlib.crc32(d):08x}'==crc
            parts.append(d)
        raw=np.frombuffer(b''.join(parts),np.uint8).reshape(4,65536,32)
        bg=z.read('31j1.ic2')+z.read('31j0.ic1'); font=z.read('31e12-0.ic33')
        assert zlib.crc32(bg[:0x40000])==0x82ed7155 and zlib.crc32(bg[0x40000:])==0x8a12b450
        assert zlib.crc32(font)==0x06f22615
    cache={}
    def tile(kind,code):
        key=(kind,code)
        if key in cache:return cache[key]
        if kind=='spr':
            bits=np.unpackbits(raw[:,code,:],axis=1).reshape(4,2,16,8).transpose(0,2,1,3).reshape(4,16,16)
            a=np.sum(bits*np.array([8,4,2,1],np.uint8)[:,None,None],axis=0,dtype=np.uint8)
        else:
            size=8 if kind=='text' else 16;a=np.zeros((size,size),np.uint8)
            for y in range(size):
                for x in range(size):
                    if kind=='text':
                        b=font[code*32+(x//2)*8+y]
                        for p in range(4):a[y,x]|=((b>>(7-(1-x%2)-p*2))&1)<<(3-p)
                    else:
                        off=(code&4095)*64+y*2+(32 if x>=8 else 0)
                        for p,plane in enumerate([1,0,0x40001,0x40000]):a[y,x]|=((bg[off+plane]>>(7-x%8))&1)<<(3-p)
        cache[key]=a;return a
    def tilemap(kind,data):
        size=8 if kind=='text' else 16;cols=64 if kind=='text' else 32
        out=np.zeros((size*32,size*cols),np.uint16)
        for i,w in enumerate(data):
            if kind=='bg':code=int(w)&4095;bank=int(w)>>12;base=3072;flags=0
            elif kind=='fg':flags,code=map(int,w);bank=flags&15;base=4096
            else:
                a,b=map(int,w);code=(a&255)|((b&15)<<8);bank=(b>>4)&15;base=0;flags=0
            a=tile('text' if kind=='text' else 'bg',code)
            if flags&64:a=a[:,::-1]
            if flags&128:a=a[::-1]
            out[(i//cols)*size:(i//cols+1)*size,(i%cols)*size:(i%cols+1)*size]=a.astype(np.uint16)+base+bank*16
        return out
    assets=root/'assets';docs=root/'docs';blob=bytearray();tables=[];report=[];previews=[]
    prompt=np.hstack([tile('text',ord(c)-16) for c in 'PRESS START'])
    prompt_data=((prompt[:,::2]<<4)|prompt[:,1::2]).tobytes()
    assert len(prompt_data)==352
    with zipfile.ZipFile(root/'intro_sources.zip') as source:
        reference=json.loads(source.read('references.json'))
        for scene,(name,label) in enumerate(SCENES):
            def read(suffix):return source.read(name+suffix)
            pal=np.frombuffer(read('.pal'),'>u2')
            sx0,sy0,sx1,sy1=map(int,np.frombuffer(read('.scroll'),'>u2'))
            pri,flip=map(int,read('.meta').split());assert pri==0x78 and flip==0
            bgmap=tilemap('bg',np.frombuffer(read('.bg1'),'>u2')[:1024])
            fgmap=tilemap('fg',np.frombuffer(read('.bg0'),'>u2').reshape(-1,2))
            text=np.frombuffer(read('.fg'),'>u2').reshape(-1,2).copy()
            dest=bgmap[(np.arange(240)+8+sy1)%512][:,(np.arange(320)+sx1)%512].copy()
            fgmap=fgmap[(np.arange(240)+8+sy0)%512][:,(np.arange(320)+sx0)%512]
            use=(fgmap&15)!=0;dest[use]=fgmap[use]
            for words in np.frombuffer(read('.spr'),'>u2').reshape(-1,8):
                w=list(map(int,words))
                if not w[1]&1:continue
                x=(w[5]&255)|((w[1]&4)<<6)
                if x>496:x-=512
                y=((256-((w[0]&255)|((w[1]&2)<<7)))&511)-16
                chain=(w[1]>>5)&7;code=(w[2]&255)|((w[3]&255)<<8)
                for c in range(chain+1):
                    yy=(y-chain*16+c*16 if w[1]&8 else y-c*16)-8
                    a=tile('spr',code+c)
                    if w[1]&16:a=a[:,::-1]
                    if w[1]&8:a=a[::-1]
                    x0=max(x,0);y0=max(yy,0);x1=min(x+16,320);y1=min(yy+16,240)
                    if x0>=x1 or y0>=y1:continue
                    cut=a[y0-yy:y1-yy,x0-x:x1-x];use=cut!=0
                    dest[y0:y1,x0:x1][use]=1024+(w[4]&15)*16+cut[use].astype(np.uint16)
            def composite(t):
                layer=tilemap('text',t)[8:248,:320]
                result=dest.copy();use=(layer&15)!=0;result[use]=layer[use];return pal[result]
            original=composite(text)
            assert hashlib.sha256(rgb444(original).tobytes()).hexdigest()==reference[name]['rgb_sha256'],name
            # Remove coin counters without painting over the underlying art.
            text[30*64+27:30*64+36]=0
            if scene==3:text[22*64+15:22*64+26]=0
            adapted=composite(text)
            v=np.array([color555(int(x)) for x in adapted.ravel()],np.uint16).reshape(240,320)
            unique,inv=np.unique(v,return_inverse=True);assert len(unique)<=256
            index=np.zeros((240,512),np.uint8);index[:,:320]=inv.reshape(240,320)
            palette=np.full(256,0x8000,np.uint16);palette[:len(unique)]=unique
            packed=pack(index.tobytes());offset=len(blob);blob.extend(packed)
            while len(blob)%4:blob.append(0)
            paloff=len(blob);palbytes=palette.astype('>u2').tobytes();blob.extend(palbytes)
            tables.append((offset,len(packed),paloff,fnv(index.tobytes()),fnv(palbytes)))
            image=rgb555(palette[index[:,:320]])
            y=168 if scene==3 else 224;x=116 if scene!=3 else 120
            prompt_rgb=rgb555(np.array([color555(int(c)) for c in pal[:16]],np.uint16)[prompt])
            image[y:y+8,x:x+88][prompt!=0]=prompt_rgb[prompt!=0]
            Image.fromarray(image).save(docs/f'intro_{scene+1:02d}.png');previews.append(Image.fromarray(image))
            report.append({'name':label,'source':name,'original_rgb_sha256':reference[name]['rgb_sha256'],
                'original_mismatched_pixels':0,'colors':len(unique),'compressed_bytes':len(packed),
                'bitmap_fnv1a':f'{tables[-1][3]:08x}','palette_fnv1a':f'{tables[-1][4]:08x}',
                'prompt_x':x,'prompt_y':y})
            if scene==3:prompt_pal=np.array([color555(int(c)) for c in pal[:16]],dtype='>u2').tobytes()
    if len(blob)&3:blob.extend(b'\0'*(4-len(blob)%4))
    (assets/'INTRO.RLE').write_bytes(blob);(assets/'PROMPT.TEX').write_bytes(prompt_data);(assets/'PROMPT.PAL').write_bytes(prompt_pal)
    h=['/* Generated from ROMs and original video state; see tools/extract_intro.py. */','#pragma once',
       '#include <stdint.h>','#define INTRO_BITMAP_BYTES (512U*240U)',f'#define INTRO_DATA_BYTES {len(blob)}U',
       f'#define INTRO_DATA_HASH 0x{fnv(blob):08x}UL',f'#define PROMPT_BYTES {len(prompt_data)}U',
       f'#define PROMPT_HASH 0x{fnv(prompt_data):08x}UL',f'#define PROMPT_PAL_HASH 0x{fnv(prompt_pal):08x}UL',
       'typedef struct { uint32_t offset, size, palette_offset, bitmap_hash, palette_hash; } intro_asset_t;',
       'static const intro_asset_t intro_assets[4] = {']
    h += [' {%dU,%dU,%dU,0x%08xUL,0x%08xUL},'%t for t in tables];h+=['};']
    (root/'intro_data.h').write_text('\n'.join(h)+'\n')
    sheet=Image.new('RGB',(640,516),(25,25,25));draw=ImageDraw.Draw(sheet)
    for i,im in enumerate(previews):
        x=(i%2)*320;y=(i//2)*258;sheet.paste(im,(x,y));draw.text((x+4,y+242),SCENES[i][1],fill='white')
    sheet.save(docs/'intro_sequence.png')
    manifest={'screens':report,'format':'VDP2 indexed 8bpp, 512 stride, 320x240 visible, 1:1',
        'animation':'Static original plates; native VDP1 PRESS START blink; no attract animation or audio.',
        'data_bytes':len(blob),'staging_bytes':512*240,'prompt_bytes':len(prompt_data),
        'source':'User ROM + MAME 0.264 video state; independent full-frame RGB hashes',
        'files':{n:hashlib.sha256((assets/n).read_bytes()).hexdigest() for n in ['INTRO.RLE','PROMPT.TEX','PROMPT.PAL']}}
    (docs/'intro_assets.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('rom');p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent.parent)
    a=p.parse_args();extract(a.rom,a.root)
