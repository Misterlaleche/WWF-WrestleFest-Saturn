#include "game.h"
#include "arcade_moves.h"
#include <assert.h>
#include <stdio.h>
static void prep(game_t*g){unsigned r[6]={0,2,1,3,4,5};game_match_start(g,GAME_TAG,r);g->cpu=false;fighter_t*p=&g->fighters[0],*q=&g->fighters[1];p->x=120*256;q->x=155*256;p->y=q->y=200*256;p->facing=q->facing=1;p->state=q->state=ST_IDLE;p->cooldown=q->cooldown=0;}
int main(void){game_t g;prep(&g);g.fighters[2].health=0;game_tick(&g,0,INPUT_KICK);for(int i=0;i<40;i++)game_tick(&g,0,0);assert(g.restrain_assists==0&&g.support_phase[0]==SUPPORT_WAIT);prep(&g);game_tick(&g,0,INPUT_PUNCH);assert(g.pair==PAIR_SUBMISSION);for(int i=0;i<10;i++)game_tick(&g,0,0);assert(g.restrain_assists==0);puts("PASS Test99: KO reserve cannot assist Restrain and Sleeper never uses the Restrain-assist strike path");}
