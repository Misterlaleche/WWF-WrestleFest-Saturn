#include "finisher_runtime.h"
#include "finisher_assets.h"
#include <assert.h>
#include <stdio.h>
#define FP 256
static void start(game_t *g,unsigned a,unsigned b){unsigned r[6]={a,b,7,3,4,8};game_match_start(g,GAME_TAG,r);g->cpu=false;g->ticks=60;}
static void until_end(game_t *g,unsigned limit){while(limit--&&(g->pair==PAIR_FINISHER||g->fighters[0].state==ST_FINISHER))game_tick(g,0,0);assert(g->pair!=PAIR_FINISHER&&g->fighters[0].state!=ST_FINISHER);}
static void run_one(unsigned ch,unsigned opp){game_t g;start(&g,ch,opp);fighter_t *a=&g.fighters[0],*b=&g.fighters[1];a->x=110*FP;a->y=190*FP;a->facing=1;b->x=150*FP;b->y=200*FP;b->rise_y=b->y;b->facing=1;unsigned before=b->health;
 const finisher_record_t *r=finisher_record(ch);
 if(r->condition==FINISHER_COND_GRAPPLE){b->y=a->y;game_tick(&g,0,INPUT_GRAB);assert(g.pair==PAIR_HOLD);}
 else if(r->condition==FINISHER_COND_PRONE_DIAGONAL){b->state=ST_DOWN;b->tick=12;}
 else if(r->condition==FINISHER_COND_OPPONENT_RUNNING){a->y=b->y;b->state=ST_RUN;b->whipped=true;b->run_speed=40;}
 else if(r->condition==FINISHER_COND_BEHIND){a->y=b->y;a->x=120*FP;b->x=150*FP;a->facing=b->facing=1;}
 assert(game_finisher_probe(&g,0)==FINISHER_PROBE_READY);game_tick(&g,0,INPUT_FINISHER);assert(g.pair==PAIR_FINISHER||a->state==ST_FINISHER);
 for(unsigned p=0;p<finisher_asset_phase_count(ch);p++)assert(finisher_asset_frame(ch,opp,p)<finisher_overlay_frames[ch]);
 g.paused=true;unsigned phase=g.finisher_phase;game_tick(&g,0,0);assert(g.finisher_phase==phase);g.paused=false;until_end(&g,700);
 assert(b->health<before&&g.finishers==1&&g.hits[0]==1&&(b->state==ST_RECOVER||b->state==ST_DOWN));}
int main(void){for(unsigned ch=0;ch<10;ch++){if(ch==8)continue;unsigned opp=ch==0?2:0;run_one(ch,opp);}game_t g;start(&g,8,2);g.fighters[1].state=ST_DOWN;g.fighters[1].tick=12;g.fighters[1].rise_y=g.fighters[1].y;assert(game_finisher_probe(&g,0)==FINISHER_PROBE_UNMAPPED);puts("PASS: nine high-confidence trademark moves execute; Earthquake candidate is gated instead of reusing exact STOMP action $23");}
