#include "arcade_ai.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned char *load(size_t*n){FILE*f=fopen("program.bin","rb");assert(f);fseek(f,0,SEEK_END);*n=(size_t)ftell(f);rewind(f);unsigned char*b=malloc(*n);assert(b&&fread(b,1,*n,f)==*n);fclose(f);return b;}
int main(void){size_t n;unsigned char*b=load(&n);
 const unsigned char lowgate[]={0x0c,0x68,0x00,0xc8,0x00,0xb0,0x64,0x32};
 const unsigned char state2[]={0x31,0x7c,0x00,0x02,0x00,0x20};
 assert(!memcmp(b+0x1f368,lowgate,sizeof(lowgate)));
 assert(!memcmp(b+0x1f38e,state2,sizeof(state2)));
 assert(!arcade_ai_state0_enter_approach(0,0xc7,1));
 assert(arcade_ai_state0_enter_approach(0,0xc8,8));
 assert(!arcade_ai_state0_enter_approach(0,0xc8,9));
 assert(arcade_ai_state0_enter_approach(4,0xe0,35));
 assert(!arcade_ai_state0_enter_approach(4,0xe0,36));
 free(b);puts("PASS: Test131 state-0 distance gate selects raw +$20=2 using the recovered wrestler table");}
