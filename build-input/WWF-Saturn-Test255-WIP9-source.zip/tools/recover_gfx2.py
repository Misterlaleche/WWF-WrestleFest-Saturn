#!/usr/bin/env python3
"""Assemble the exact 8 MiB WrestleFest sprite region from a user-supplied
wwfwfest.zip (or directory containing the eight gfx2 ROMs).

The output byte order is the plane-major order consumed by the existing Saturn
asset builders and is identical to tools/extract_assets.py::ROM_SPECS.
"""
from pathlib import Path
import argparse,hashlib,zlib,zipfile
ROM_SPECS=[
 ('31j3.ic9',0xe395cf1d),('31j2.ic8',0xb5a97465),
 ('31j5.ic11',0x2ce545e8),('31j4.ic10',0x00edb66a),
 ('31j6.ic12',0x79956cf8),('31j7.ic13',0x74d774c3),
 ('31j9.ic15',0xdd387289),('31j8.ic14',0x44abe127),
]
EXPECTED_BYTES=0x800000
EXPECTED_SHA256='a3b5e1fedd6c41cd398ba0cb437cddb2f50b3ae0a0dc178a10b70a7ed5d010ba'

def read_source(src,name):
 if src.is_dir():return (src/name).read_bytes()
 with zipfile.ZipFile(src) as z:return z.read(name)

def assemble(src):
 src=Path(src);chunks=[]
 for name,crc in ROM_SPECS:
  data=read_source(src,name)
  if len(data)!=0x100000:raise SystemExit(f'{name}: expected 1048576 bytes, got {len(data)}')
  actual=zlib.crc32(data)&0xffffffff
  if actual!=crc:raise SystemExit(f'{name}: CRC32 {actual:08x}, expected {crc:08x}')
  chunks.append(data)
 region=b''.join(chunks)
 if len(region)!=EXPECTED_BYTES:raise SystemExit('assembled sprite region has wrong size')
 sha=hashlib.sha256(region).hexdigest()
 if sha!=EXPECTED_SHA256:raise SystemExit(f'gfx2 SHA256 {sha}, expected {EXPECTED_SHA256}')
 return region

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('source',type=Path);ap.add_argument('-o','--output',type=Path,default=Path('gfx2.bin'));a=ap.parse_args()
 region=assemble(a.source);a.output.write_bytes(region)
 print(f'PASS gfx2: {len(region)} bytes SHA256 {hashlib.sha256(region).hexdigest()} -> {a.output}')
if __name__=='__main__':main()
