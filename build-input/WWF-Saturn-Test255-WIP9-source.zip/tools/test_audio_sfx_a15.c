#include <assert.h>
#include "../wf_audio_sfx.h"
static unsigned plays,stops,last_sample,last_bank,last_vol,last_voice;
static void play(unsigned v,unsigned b,unsigned s,unsigned vol,bool sup,void *u){
 (void)sup;(void)u;plays++;last_voice=v;last_bank=b;last_sample=s;last_vol=vol;
}
static void stop(unsigned v,void *u){(void)v;(void)u;stops++;}
int main(void){
 unsigned cmd;
 assert(WF_SFX_TIMER_A_HZ_NUM/WF_SFX_TIMER_A_HZ_DEN==221u);
 for(cmd=0x20;cmd<=0x81;cmd++){const wf_sfx_command_t *x=wf_sfx_command(cmd);assert(x&&x->event_count<=9u);}
 const wf_sfx_command_t *c=wf_sfx_command(0x32);
 assert(c->priority==6&&c->bank_policy==2&&c->event_count==4);
 for(unsigned i=0;i<4;i++){assert(c->events[i].sample_id==18);assert(c->events[i].delay_ticks==255);}
 wf_sfx_runtime_reset();plays=stops=0;
 assert(wf_sfx_start(0x32,play,stop,0));assert(plays==1&&last_sample==18);
 for(unsigned e=1;e<4;e++){for(unsigned i=0;i<255;i++)wf_sfx_timer_a_tick(play,stop,0);assert(plays==e+1);}
 for(unsigned i=0;i<255;i++)wf_sfx_timer_a_tick(play,stop,0);
 assert(!wf_sfx_voice(last_voice)->active);
 wf_sfx_runtime_reset();plays=0;
 assert(wf_sfx_start(0x65,play,stop,0));assert(last_bank==0&&last_sample==69&&last_vol==3);
 assert(wf_sfx_command(0x81)->priority==11);
 return 0;
}
