#include <assert.h>
#include <stdio.h>
#include "hud.h"
#include "arcade_stamina.h"
int main(void){
 const unsigned chars[]={2,3,6,7}; /* Jake, Boss Man, Slaughter, Perfect */
 for(unsigned k=0;k<4;k++){
  hud_slot_t s[4]={0};hud_cell_t c[160];s[0]=(hud_slot_t){.character=chars[k],.health=100,.player=0,.status=HUD_ACTIVE,.message=HUD_NEUTRAL};
  hud_map(s,c);unsigned internal=arcade_stamina_internal_id(chars[k]);
  assert(c[1*40+1].tile==0x1d0+internal*9);assert(c[1*40+1].palette==2+internal);
 }
 assert(arcade_stamina_internal_id(6)==1);assert(arcade_stamina_internal_id(7)==3);
 assert(arcade_stamina_internal_id(2)==2);assert(arcade_stamina_internal_id(3)==8);
 puts("PASS Test216: HUD portraits use ROM $64CC internal actor order for tile and palette identity");
}
