#include "arcade_animation.h"
#include "arcade_animation_data.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 unsigned loops=0,once=0,holds=0;
 for(unsigned i=0;i<ARCADE_ANIMATION_COUNT;i++){
  const arcade_animation_t *a=&arcade_animations[i];arcade_animation_clock_t c;arcade_animation_reset(&c,a);
  if(!a->count){assert(c.finished&&arcade_animation_pose(&c,a)==0xffff);continue;}
  for(unsigned f=0;f<a->count;f++){
   const arcade_animation_frame_t *p=&arcade_animation_frames[a->first+f];assert(c.frame==f&&arcade_animation_pose(&c,a)==p->pose);
   if(p->duration==0xff00){for(unsigned k=0;k<1000;k++)arcade_animation_tick(&c,a);assert(c.frame==f&&!c.finished);++holds;break;}
   for(unsigned k=0;k<p->duration;k++){arcade_animation_tick(&c,a);assert(c.frame==f&&!c.finished);}
   arcade_animation_tick(&c,a);
   if(f+1==a->count){if(a->kind==2){assert(c.frame==0&&!c.finished);++loops;}else{assert(c.finished&&c.frame==f);++once;}}
  }
 }
 assert(arcade_main_animations[1]<ARCADE_ANIMATION_COUNT&&arcade_action_animations[0]<ARCADE_ANIMATION_COUNT&&arcade_recovery_animations[0]<ARCADE_ANIMATION_COUNT);
 printf("PASS: %u original descriptors; %u loops, %u finite sequences, %u indefinite holds; ROM underflow timing and pose flips preserved\n",ARCADE_ANIMATION_COUNT,loops,once,holds);
}
