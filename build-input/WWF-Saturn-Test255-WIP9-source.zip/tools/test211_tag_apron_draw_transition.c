#include <assert.h>
#include <stdio.h>
#include "game.h"
int main(void){
 unsigned r[6]={0,1,2,3,4,5};game_t g;game_match_start(&g,GAME_TAG,r);
 int x,y;assert(game_partner_waiting(&g,2));game_fighter_draw_position(&g,2,&x,&y);assert(x==g.fighters[2].x/256-16);
 g.tag_phase[0]=TAG_PHASE_ENTRY;g.fighters[2].state=ST_RING_ENTER;game_fighter_draw_position(&g,2,&x,&y);
 assert(!game_partner_waiting(&g,2));assert(x==g.fighters[2].x/256);
 g.tag_phase[0]=TAG_PHASE_NONE;g.fighters[2].state=ST_IDLE;g.support_phase[0]=SUPPORT_RUN;game_fighter_draw_position(&g,2,&x,&y);
 assert(!game_partner_waiting(&g,2));assert(x==g.fighters[2].x/256);
 puts("PASS Test211: apron render correction is limited to stationary reserves and no longer side-jumps actors during TAG/support rope traversal");
}
