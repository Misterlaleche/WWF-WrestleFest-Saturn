#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void seq(long o,const uint8_t*p,size_t n){FILE*f=fopen("program.bin","rb");assert(f);uint8_t*b=malloc(n);assert(b);assert(fseek(f,o,SEEK_SET)==0&&fread(b,1,n,f)==n);fclose(f);assert(!memcmp(b,p,n));free(b);}
int main(void){
 const uint8_t p[]={0x22,0x69,0x00,0x86,0x08,0x29,0x00,0x01,0x00,0x33,0x66,0x0e,0x08,0xa9,0x00,0x07,0x00,0xb5,0x08,0xf9,0x00,0x00,0x00,0x1c,0x16,0x97};seq(0x213ce,p,sizeof p);
 puts("PASS Test179: TAG cleanup follows +$86; when +$33 bit1 is clear it clears +$B5 bit7 and sets global $1C1697 bit0");return 0;}
