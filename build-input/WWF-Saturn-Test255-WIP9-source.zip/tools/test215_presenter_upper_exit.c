#include <assert.h>
#include <stdio.h>
#include "session.h"
int main(void){
 session_t s={0};s.mode=1;s.phase=SESSION_ANNOUNCE;
 s.tick=4U*TAG_ANNOUNCE_WRESTLER_TICKS;int y0=session_tag_presenter_y(&s);
 s.tick+=TAG_ANNOUNCE_EXIT_TICKS/2;int y1=session_tag_presenter_y(&s);
 s.tick=4U*TAG_ANNOUNCE_WRESTLER_TICKS+TAG_ANNOUNCE_EXIT_TICKS;int y2=session_tag_presenter_y(&s);
 assert(y0==168);assert(y1<y0);assert(y2<y1);assert(y2==88);
 puts("PASS Test215: TAG presenter exits toward upper ring side (decreasing Saturn Y), not foreground/bottom");
}
