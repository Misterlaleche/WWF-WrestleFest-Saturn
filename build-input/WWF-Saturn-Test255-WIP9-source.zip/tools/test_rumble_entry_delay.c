#include "arcade_rumble.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
int main(void){
 FILE *f=fopen("program.bin","rb");assert(f);uint8_t sig[24];assert(fseek(f,0xbb30,SEEK_SET)==0);assert(fread(sig,1,sizeof(sig),f)==sizeof(sig));fclose(f);
 /* TST.B $1C16A7 ; BEQ ; ADDQ.W #1,$1C1694 ; CMPI.W #$0126,$1C1694 */
 const uint8_t want[]={0x4a,0x39,0x00,0x1c,0x16,0xa7,0x67,0xf6,0x52,0x79,0x00,0x1c,0x16,0x94,0x0c,0x79,0x01,0x26,0x00,0x1c,0x16,0x94};
 for(unsigned i=0;i<sizeof(want);i++)assert(sig[i]==want[i]);
 unsigned pending=1,timer=0;for(unsigned i=1;i<ARCADE_RUMBLE_ENTRY_DELAY;i++)assert(!arcade_rumble_entry_delay_step(&pending,&timer,5));assert(timer==ARCADE_RUMBLE_ENTRY_DELAY-1&&pending==1);
 assert(arcade_rumble_entry_delay_step(&pending,&timer,5));assert(timer==0&&pending==0);
 pending=1;timer=ARCADE_RUMBLE_ENTRY_DELAY-1;assert(!arcade_rumble_entry_delay_step(&pending,&timer,6));assert(timer==0&&pending==1);
 puts("PASS Test117: ROM $BB30 waits exactly $0126 ticks and services one pending entrant only below six active actors");
}
