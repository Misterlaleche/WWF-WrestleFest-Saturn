#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static char *slurp(const char *p){FILE*f=fopen(p,"rb");assert(f);fseek(f,0,SEEK_END);long n=ftell(f);rewind(f);char*s=malloc((size_t)n+1);assert(s);assert(fread(s,1,(size_t)n,f)==(size_t)n);fclose(f);s[n]=0;return s;}
int main(void){char*s=slurp("main.c");
 assert(strstr(s,"selection_pal[2][2048]"));
 assert(strstr(s,"selection_cache_load_page(0)"));assert(strstr(s,"selection_cache_load_page(1)"));
 assert(strstr(s,"mode_cache_ensure()"));assert(strstr(s,"entry_cache_ensure()"));
 char*m=strstr(s,"if(session.phase==SESSION_MODE)");assert(m);char*sel=strstr(m,"else if(session.phase==SESSION_SELECT");assert(sel);*sel=0;assert(!strstr(m,"selection_cache_free()"));
 free(s);puts("PASS Test224: boot loading persistently caches both select pages, MODE and ENTRY resources; 512-byte palettes use sector-sized 2048-byte read capacity and MODE no longer discards the cache");}
