#include "arcade_action_map.h"
#include "arcade_animation.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 /* selection 8 = Earthquake. ROM-exact prone category $07, fresh button 1. */
 int raw=arcade_action_for_buttons(8,7,1);assert(raw==0x47);
 assert(arcade_action_descriptor_address((unsigned)raw)==0x14440U);
 assert(arcade_action_callback_address((unsigned)raw)==0x14458U);
 assert(arcade_animation_sample(0x14440U,0)==132U);
 puts("PASS Test147: Earthquake prone category $07/button1 selects raw action $47 -> descriptor $14440; move semantic remains candidate until callback/composition closure");
 return 0;
}
