#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
int main(void){FILE*f=fopen("program.bin","rb");assert(f);uint8_t b[16];assert(fseek(f,0x14498,SEEK_SET)==0&&fread(b,1,sizeof b,f)==sizeof b);fclose(f);
 const uint8_t p[]={0x30,0x28,0x00,0x58,0x02,0x40,0x80,0x00,0x08,0x40,0x00,0x0f,0x31,0x40,0x00,0x2e};assert(!memcmp(b,p,sizeof p));
 puts("PASS Test155: action-$47 callback derives actor +$2E from the inverted sign bit of computed +$58 immediately after $26AE");return 0;}
