#include "game.h"
#include <assert.h>
#include <stdio.h>
int main(void){unsigned r[6]={0,2,7,1,4,5};game_t g;game_match_start(&g,GAME_TAG,r);g.cpu=false;fighter_t*f=&g.fighters[0];f->health=50;f->state=ST_RECOVER;f->tick=0;assert(game_recovery_prompt_visible(&g)&&game_escape_prompt_visible(&g));unsigned a=game_escape_prompt_pose(&g);f->tick=7;assert(game_escape_prompt_pose(&g)!=a);unsigned before=f->tick;game_tick(&g,0,INPUT_PUNCH);assert(f->tick>before+1&&f->recovery_bonus>0);f->state=ST_IDLE;assert(!game_recovery_prompt_visible(&g));puts("PASS Test112: prone human recovery exposes animated rapid-button prompt and fresh P/K edges accelerate the complete get-up path");}
