#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void seq(const unsigned char*r,size_t n,size_t o,const unsigned char*s,size_t z){assert(o+z<=n);assert(!memcmp(r+o,s,z));}
int main(void){FILE*f=fopen("program.bin","rb");assert(f);fseek(f,0,SEEK_END);long ln=ftell(f);rewind(f);size_t n=(size_t)ln;unsigned char*r=malloc(n);assert(r&&fread(r,1,n,f)==n);fclose(f);
 const unsigned char setup_active[]={0x08,0xe8,0x00,0x01,0x00,0x33,0x02,0x28,0x00,0xbf,0x00,0x56};seq(r,n,0x1067e,setup_active,sizeof setup_active);
 const unsigned char setup_reserve[]={0x22,0x48,0xd3,0xfc,0x00,0x00,0x01,0x0c,0x00,0x29,0x00,0x40,0x00,0x56};seq(r,n,0x1068a,setup_reserve,sizeof setup_reserve);
 const unsigned char promote[]={0x08,0xa9,0x00,0x06,0x00,0x56,0x08,0xa8,0x00,0x01,0x00,0x33,0x08,0xe9,0x00,0x01,0x00,0x33};seq(r,n,0x20f74,promote,sizeof promote);
 free(r);puts("PASS Test92: ROM pair setup/transfer proves +$33 bit1 is the transferable active role and +$56 bit6 marks the paired reserve until promotion");return 0;}
