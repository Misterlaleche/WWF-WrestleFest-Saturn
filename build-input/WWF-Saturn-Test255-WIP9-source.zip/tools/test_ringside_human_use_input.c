#include <assert.h>
#include <stdio.h>
#include "arcade_ringside.h"
#include "game.h"
static const unsigned roster[6]={0,1,2,3,4,5};
static void prep(game_t *g){game_match_start(g,GAME_TAG,roster);g->cpu=false;g->time_left=9999;fighter_t *p=&g->fighters[0];ringside_object_t *o=&g->ringside_objects[0];p->outside=true;p->state=ST_IDLE;p->cooldown=0;p->held_object=1;o->holder=1;o->state=ARCADE_OBJECT_HELD_STATE;o->x=p->x;o->y=p->y;}
int main(void){assert(arcade_ringside_human_weapon_action(0)==0);assert(arcade_ringside_human_weapon_action(1)==0x1e);assert(arcade_ringside_human_weapon_action(2)==0x1e);assert(arcade_ringside_human_weapon_action(3)==0x1e);game_t g;prep(&g);game_tick(&g,0,INPUT_PUNCH);assert(g.fighters[0].state==ST_OBJECT_USE);prep(&g);game_tick(&g,0,INPUT_KICK);assert(g.fighters[0].state==ST_OBJECT_USE);prep(&g);game_tick(&g,0,INPUT_PUNCH|INPUT_KICK);assert(g.fighters[0].state==ST_OBJECT_USE);puts("PASS Test69: held-object category $11 maps physical button1/button2/both to human action $1E");}
