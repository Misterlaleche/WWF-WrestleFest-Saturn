#include "game.h"
#include <assert.h>
#include <stdio.h>
static const unsigned roster[6]={0,1,2,3,4,5};
int main(void){
 game_t g;game_match_start(&g,GAME_TAG,roster);g.cpu=false;
 fighter_t *f=&g.fighters[0];
 /* Ten damage points: exact accumulator consumes two display points/update. */
 f->health=100;f->display_health=110;f->stamina_pending=-10;f->stamina_display_delta=0;
 game_tick(&g,0,0);assert(f->display_health==108&&f->stamina_display_delta==-8&&!f->stamina_pending);
 /* A six-point restore arrives before the old damage animation finishes; ROM\n  * folds it into the existing -8 accumulator, leaving only -2 to draw. */
 f->health=106;f->stamina_pending=6;game_tick(&g,0,0);
 assert(f->display_health==106&&f->stamina_display_delta==0&&!f->stamina_pending);
 /* Single-point deltas consume exactly one display point. */
 f->health=107;f->stamina_pending=1;game_tick(&g,0,0);assert(f->display_health==107&&!f->stamina_display_delta);
 f->health=106;f->stamina_pending=-1;game_tick(&g,0,0);assert(f->display_health==106&&!f->stamina_display_delta);
 puts("PASS: exact $7548 pending-delta/accumulator/display stamina pipeline");
}
