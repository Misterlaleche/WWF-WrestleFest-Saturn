#include "../game.h"
#include <assert.h>
#include <stdio.h>
int main(void){unsigned r[6]={0,2,7,1,4,5};game_t g;game_match_start(&g,GAME_TAG,r);fighter_t *f=&g.fighters[0];int y=210;
 f->state=ST_REBOUND;f->x=game_ring_left(y)*256;f->y=y*256;f->rope_contact_side=1;
 assert(game_rope_deflection(&g,game_ring_left(y),y)>0);assert(game_rope_deflection(&g,game_ring_right(y),y)==0);
 f->x=game_ring_right(y)*256;f->rope_contact_side=2;
 assert(game_rope_deflection(&g,game_ring_right(y),y)>0);assert(game_rope_deflection(&g,game_ring_left(y),y)==0);
 puts("PASS Test243: run rebound deflection is bound to the rope actually contacted, not an inferred unrelated foreground/south segment");}
