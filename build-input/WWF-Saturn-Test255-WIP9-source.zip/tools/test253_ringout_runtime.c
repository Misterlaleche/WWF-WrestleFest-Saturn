#include "game.h"
#include <assert.h>
#include <stdio.h>
int main(void){
 unsigned r[6]={0,2,1,3,4,5};game_t g;game_match_start(&g,GAME_TAG,r);g.cpu=false;
 g.fighters[0].x=100*256;g.fighters[1].x=150*256;g.fighters[0].y=g.fighters[1].y=215*256;
 g.fighters[0].facing=1;g.pair=PAIR_HOLD;g.pair_attacker=0;
 game_tick(&g,INPUT_RIGHT,INPUT_RING);
 assert(g.pair==PAIR_NONE);assert(g.fighters[0].state==ST_RING_THROW);assert(g.fighters[1].state==ST_TOSSED);
 assert(game_arcade_pose(&g.fighters[0])==175);assert(game_arcade_pose(&g.fighters[1])==177);
 for(unsigned i=0;i<33;i++)game_tick(&g,0,0);assert(game_arcade_pose(&g.fighters[0])==176);
 for(unsigned i=0;i<25;i++)game_tick(&g,0,0);assert(game_arcade_pose(&g.fighters[0])==0);
 for(unsigned i=0;i<33;i++)game_tick(&g,0,0);assert(g.fighters[0].state==ST_IDLE);
 puts("PASS Test253 runtime: ring-out throw now keeps aggressor in exact raw-$06 91-tick animation while victim follows the recovered thrown/outside chain");
}
