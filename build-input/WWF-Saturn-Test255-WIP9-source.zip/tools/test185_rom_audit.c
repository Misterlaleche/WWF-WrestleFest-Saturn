#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void seq(long o,const uint8_t*p,size_t n){FILE*f=fopen("program.bin","rb");assert(f);uint8_t*b=malloc(n);assert(b);assert(fseek(f,o,SEEK_SET)==0&&fread(b,1,n,f)==n);fclose(f);assert(!memcmp(b,p,n));free(b);}
int main(void){
 const uint8_t p[]={0x0c,0x28,0x00,0x46,0x00,0x61,0x66,0x06,0x52,0x6a,0x00,0xe0,0x60,0x04,0x52,0x6a,0x00,0xe2};seq(0x14562,p,sizeof p);
 puts("PASS Test185: contact branch A increments victim +$E0 only for raw actor +$61==$46, otherwise +$E2");return 0;}
