#include "game.h"
#include <assert.h>
#include <stdio.h>
int main(void){unsigned r[6]={0,2,1,3,4,5};game_t g;game_match_start(&g,GAME_TAG,r);g.cpu=true;fighter_t*p=&g.fighters[0],*q=&g.fighters[1];p->x=120*256;p->rise_y=200*256;p->y=217*256;p->state=ST_RECOVER;p->tick=24;p->health=40;p->stamina_tier=1;q->x=150*256;q->y=200*256;q->state=ST_IDLE;q->attack_serial=0;/* (0+Jake2)%3=2 */game_tick(&g,0,0);assert(q->state==ST_GROUND_PICKUP);for(unsigned i=0;i<18;i++)game_tick(&g,0,0);assert(p->state==ST_RISE);puts("PASS Test137: CPU can choose exact action-$22 PICK UP against a prone live opponent and return the victim to the rise path");}
