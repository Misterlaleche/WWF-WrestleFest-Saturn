#include "roster_pack.h"
#include "roster_data.h"
#include "combat_moves.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned u32(const unsigned char *p){return ((unsigned)p[0]<<24)|((unsigned)p[1]<<16)|((unsigned)p[2]<<8)|p[3];}
static unsigned u16(const unsigned char *p){return ((unsigned)p[0]<<8)|p[1];}
static void put32(unsigned char *p,unsigned n){p[0]=n>>24;p[1]=n>>16;p[2]=n>>8;p[3]=n;}
static unsigned fnv(const unsigned char *p,size_t size){unsigned h=2166136261U;while(size--)h=(h^*p++)*16777619U;return h;}
int main(void){
    static roster_block_cache_t cache;unsigned all_tiles=0,new_poses=0;
    for(unsigned ch=0;ch<10;ch++){
        char name[40];sprintf(name,"cd/C%02u.PAK",ch);FILE *file=fopen(name,"rb");assert(file);
        size_t size=roster_bytes[ch];unsigned char *data=malloc(size),*raw;assert(data);
        assert(fread(data,1,size,file)==size&&fgetc(file)==EOF);fclose(file);
        assert(fnv(data,size)==roster_hash[ch]);roster_pack_t p={0};
        assert(roster_pack_open(&p,data,size,ROSTER_FRAMES)&&p.magic==ROSTER_MAGIC_BLOCKS);
        raw=malloc(p.tiles*128);assert(raw);roster_pack_cache_reset(&cache);
        for(unsigned t=0;t<p.tiles;t++)assert(roster_pack_tile(&p,t,raw+128*t,&cache));
        assert(fnv(raw,p.tiles*128)==u32(data+20)&&cache.decodes==p.blocks);
        assert(cache.hits==p.tiles-p.blocks);all_tiles+=p.tiles;
        /* Cache survives unrelated banks, supports random lookup and the last short block. */
        unsigned char copy[128];
        for(unsigned i=0;i<500;i++){unsigned t=(i*113+7)%p.tiles;assert(roster_pack_tile(&p,t,copy,&cache)&&!memcmp(copy,raw+128*t,128));}
        assert(!roster_pack_tile(&p,p.tiles,copy,&cache));
        for(unsigned pose=150;pose<=155;pose++){
            unsigned frame=roster_arcade_frame(pose),n=u16(data+34+frame*4);
            assert((n!=0)==combat_has_clothesline(ch));if(n)++new_poses;
        }
        for(unsigned pose=180;pose<=181;pose++){
            unsigned frame=roster_arcade_frame(pose),n=u16(data+34+frame*4);
            assert((n!=0)==combat_has_big_boot(ch));if(n)++new_poses;
        }
        assert(!roster_pack_open(&p,data,size,199));
        for(unsigned n=0;n<32;n++)assert(!roster_pack_open(&p,data,n,ROSTER_FRAMES));
        assert(!roster_pack_open(&p,data,size-1,ROSTER_FRAMES));
        unsigned offset=u32(data+16),saved=u32(data+offset);
        put32(data+offset,0xffffffffU);assert(!roster_pack_open(&p,data,size,ROSTER_FRAMES));put32(data+offset,saved);
        unsigned raw_size=u32(data+offset+8);put32(data+offset+8,raw_size+128);
        assert(!roster_pack_open(&p,data,size,ROSTER_FRAMES));put32(data+offset+8,raw_size);
        unsigned char byte=data[saved];data[saved]=0;data[saved+1]=0;data[saved+2]=0;
        assert(roster_pack_open(&p,data,size,ROSTER_FRAMES));roster_pack_cache_reset(&cache);
        assert(!roster_pack_tile(&p,0,copy,&cache)&&!cache.decodes&&cache.entries[0].owner==NULL);
        data[saved]=byte;free(raw);free(data);
    }
    assert(new_poses==46);
    /* Legacy format remains readable and no unaligned native casts are used. */
    unsigned char rawpack[193]={0},tile[128];unsigned char *data=rawpack+1;
    put32(data,ROSTER_MAGIC_RAW);put32(data+4,1);put32(data+8,1);put32(data+12,1);put32(data+16,64);
    data[35]=1;for(unsigned i=0;i<128;i++)data[64+i]=(unsigned char)i;
    roster_pack_t p;assert(roster_pack_open(&p,data,192,1));
    assert(roster_pack_tile(&p,0,tile,&cache)&&!memcmp(tile,data+64,128));
    data[35]=2;assert(!roster_pack_open(&p,data,192,1));data[35]=1;
    data[43]=4;assert(!roster_pack_open(&p,data,192,1));
    assert(!roster_pack_open(NULL,data,192,1)&&!roster_pack_open(&p,NULL,192,1));
    printf("PASS: %u tiles decoded through native C, all ten bank hashes, 46 new populated poses, cache reuse/random reads, malformed input and legacy compatibility\n",all_tiles);
}
