#include "game.h"
#include "arcade_stamina.h"
#include <assert.h>
#include <stdio.h>
static void prone(game_t *g){
 fighter_t *p=&g->fighters[0],*q=&g->fighters[1];
 p->x=120*256;p->rise_y=200*256;p->y=217*256;p->state=ST_RECOVER;p->tick=24;p->health=80;p->stamina_tier=1;
 q->x=150*256;q->y=200*256;q->state=ST_IDLE;q->cooldown=0;
}
int main(void){
 unsigned r[6]={0,2,1,3,4,5};game_t g;game_match_start_arcade(&g,GAME_TAG,r,0,ARCADE_DIFFICULTY_NORMAL);g.cpu=true;
 prone(&g);g.ground_pressure[1]=1;game_tick(&g,0,0);assert(g.fighters[1].state==ST_GROUND_PICKUP);
 for(unsigned i=0;i<18;i++)game_tick(&g,0,0);assert(g.fighters[0].state==ST_RISE&&g.ground_pressure[1]==0);
 game_match_start_arcade(&g,GAME_TAG,r,0,ARCADE_DIFFICULTY_NORMAL);g.cpu=false;
 unsigned hp=g.fighters[0].health;g.fighters[1].x=g.fighters[0].x+30*256;g.fighters[1].y=g.fighters[0].y;g.fighters[1].state=ST_PUNCH;g.fighters[1].tick=22;
 game_tick(&g,0,0);assert(g.fighters[0].health<hp); /* native hit remains live */
 puts("PASS Test202: CPU prone-pressure anti-loop forces PICK UP after one ground follow-up while leaving ROM stamina tables untouched");
}
