#!/usr/bin/env python3
from pathlib import Path
import importlib.util,json
root=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('recover_gfx2',root/'tools/recover_gfx2.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
assert len(m.ROM_SPECS)==8 and sum(0x100000 for _ in m.ROM_SPECS)==m.EXPECTED_BYTES==0x800000
assert [n for n,_ in m.ROM_SPECS]==['31j3.ic9','31j2.ic8','31j5.ic11','31j4.ic10','31j6.ic12','31j7.ic13','31j9.ic15','31j8.ic14']
meta=json.loads((root/'docs/combat-assets.json').read_text())
assert meta['sprite_region_sha256']==m.EXPECTED_SHA256
assert json.loads((root/'docs/finisher-overlay-build.json').read_text())['sprite_region_sha256']==m.EXPECTED_SHA256
print('PASS Test248: gfx2 importer pins all eight ROM CRCs, exact plane-major order, 8 MiB size and the previously validated sprite-region SHA256')
