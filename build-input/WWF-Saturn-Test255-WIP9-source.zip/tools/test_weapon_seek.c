#include <assert.h>
#include <stdio.h>
#include "arcade_ringside.h"
int main(void){
 unsigned p=999;bool known=false;
 assert(arcade_ringside_weapon_seek_percent(0,1,&p)&&p==15); /* Hogan internal 0 */
 assert(arcade_ringside_weapon_seek_percent(6,5,&p)&&p==30); /* Slaughter -> internal 1 */
 assert(arcade_ringside_weapon_seek_percent(8,5,&p)&&p==55); /* Earthquake -> internal 10 */
 assert(arcade_ringside_weapon_seek_percent(9,5,&p)&&p==50); /* DiBiase -> internal 11 */
 assert(!arcade_ringside_weapon_seek_percent(9,6,&p));       /* table boundary not proven */
 assert(arcade_ringside_weapon_seek_roll(0,1,14,&known)&&known);
 assert(!arcade_ringside_weapon_seek_roll(0,1,15,&known)&&known);
 assert(!arcade_ringside_weapon_seek_roll(9,9,0,&known)&&!known);
 puts("PASS: ROM $23ED0 character/stage CPU weapon-seek probabilities");
}
