#include "game.h"
#include "arcade_moves.h"
#include "session.h"
#include "presentation.h"
#include "presentation_assets.h"
#include "match_flow.h"
#include "pair_rules.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static const unsigned cast[6]={0,2,7,1,4,5};
static void ticks(game_t *g,unsigned n){while(n--)game_tick(g,0,0);}
static void selection(void){
 session_t s;session_reset(&s,0);session_tick(&s,MENU_OK);session_tick(&s,0);session_tick(&s,MENU_OK);
 assert(s.count==1&&session_highlight(&s,0)==1);
 for(unsigned i=0;i<59;i++)session_tick(&s,0);
 assert(session_highlight(&s,0)==1);session_tick(&s,0);assert(session_highlight(&s,0)==2);
 session_tick(&s,MENU_RIGHT);assert(session_highlight(&s,0)==2&&!session_highlight(&s,1));
 session_tick(&s,0);session_tick(&s,MENU_BACK);assert(!s.confirmed&&s.count==0);
 static uint8_t bitmap[240*512];
 for(unsigned page=0;page<2;page++){
  unsigned colors[6]={1,2,0,2,1,0};memset(bitmap,17,sizeof(bitmap));selection_paint(bitmap,page,colors,selection_masks);
  unsigned changed=0;
  for(unsigned y=0;y<240;y++)for(unsigned x=0;x<512;x++){
   if(bitmap[y*512+x]==17)continue;
   ++changed;assert(y>=40&&y<216&&x>=16&&x<320);
  }
  assert(changed>8000);
  selection_paint(bitmap,page,(unsigned[6]){0},selection_masks);
  for(unsigned i=0;i<sizeof(bitmap);i++)assert(bitmap[i]==17||bitmap[i]==253);
 }
 puts("PASS: confirmed portrait white->green, persistent highlight, cancel, second-page geometry and masked repaint");
}
static void grapple(void){
 game_t g;
 for(unsigned ch=0;ch<10;ch++)for(int dir=-1;dir<=1;dir+=2){
  game_match_start(&g,GAME_TAG,cast);g.fighters[1].character=ch;
  g.fighters[1].x=150*256;g.fighters[0].x=(150+dir*44)*256;
  g.fighters[0].y=g.fighters[1].y=210*256;
  game_tick(&g,0,0);assert(g.pair==PAIR_HOLD&&g.pair_attacker==1&&g.cpu_grabs==1);
  assert(game_pair_anchor(&g)==1&&game_pair_facing(&g)==dir&&game_pair_fighter(&g,0)==1&&game_pair_fighter(&g,1)==0);
  assert(game_escape_prompt_visible(&g));
  unsigned old=g.pair_tick;g.paused=true;ticks(&g,8);assert(g.pair_tick==old);g.paused=false;
  for(unsigned i=0;i<3;i++)game_tick(&g,0,INPUT_PUNCH|INPUT_KICK);
  assert(g.pair==PAIR_NONE&&g.fighters[0].health==g.fighters[0].max_health&&g.fighters[1].cooldown==90);
 }
 game_match_start(&g,GAME_TAG,cast);g.fighters[0].x=100*256;g.fighters[1].x=144*256;
 game_tick(&g,0,0);assert(g.pair==PAIR_HOLD);g.cpu=false;
 ticks(&g,42);assert(g.pair==PAIR_THROW);
 ticks(&g,PAIR_THROW_FRAMES*PAIR_FRAME_TICKS);
 unsigned expected=arcade_move_native_damage(arcade_grapple_select(g.fighters[1].character,0,0,true));
 assert(g.pair==PAIR_NONE&&g.hits[1]==1&&g.hits[0]==0&&g.fighters[0].health==g.fighters[0].max_health-expected);
 assert(g.fighters[0].state==ST_RECOVER&&game_animation_role(&g.fighters[0])==1);
 ticks(&g,RECOVER_PRONE_TICKS);assert(g.fighters[0].state==ST_RISE&&game_animation_role(&g.fighters[0])==1);
 ticks(&g,RISE_TICKS);assert(g.fighters[0].state==ST_IDLE&&game_animation_role(&g.fighters[0])==0);
 puts("PASS: CPU grapple all ten identities/both orientations, roles, escape, pause, exact-once slam and defender recovery");
}
static void run_attack(void){
 game_t g;
 for(unsigned ch=0;ch<10;ch++){
  game_match_start(&g,GAME_TAG,cast);g.cpu=false;g.fighters[0].character=ch;
  g.fighters[0].x=100*256;g.fighters[1].x=180*256;g.fighters[0].y=g.fighters[1].y=220*256;
  game_tick(&g,INPUT_RUN|INPUT_RIGHT,0);assert(g.fighters[0].state==ST_RUN);
  game_tick(&g,0,INPUT_RUN_ATTACK);assert(g.fighters[0].state==ST_RUN_ATTACK);
  ticks(&g,55);assert(g.hits[0]==1&&g.fighters[1].health==g.fighters[1].max_health-32&&g.fighters[0].state==ST_IDLE);
  assert(g.fighters[1].y-g.fighters[1].rise_y==PAIR_LAND_Y*256);
  assert(game_on_floor(g.fighters[0].x/256,g.fighters[0].y/256));
 }
 puts("PASS: running kick ten characters, active window, exact-once damage, knockdown and floor bounds");
}
static void flow(void){
 match_flow_t f;match_flow_reset(&f,0);
 for(int winner=-1;winner<=1;winner++){
  match_flow_reset(&f,0);assert(!match_flow_tick(&f,true,winner,winner<0,MENU_OK,1));assert(f.phase==FLOW_RESULT);
  unsigned action=FLOW_NONE;for(unsigned i=0;i<180;i++)action=match_flow_tick(&f,true,winner,false,MENU_OK,1);
  if(winner==0){assert(action==FLOW_ADVANCE&&f.phase==FLOW_PLAY);}
  else {
   assert(f.phase==FLOW_CONTINUE&&action==FLOW_NONE);
   assert(match_flow_seconds(&f)==10);assert(!match_flow_tick(&f,true,winner,false,MENU_OK,1));
   match_flow_tick(&f,true,winner,false,0,1);
   assert(match_flow_tick(&f,true,winner,false,MENU_OK,1)==FLOW_RETRY&&f.phase==FLOW_PLAY);
  }
 }
 match_flow_reset(&f,0);match_flow_tick(&f,true,1,false,0,1);
 for(unsigned i=0;i<780;i++)match_flow_tick(&f,true,1,false,0,1);
 assert(f.phase==FLOW_GAMEOVER);
 for(unsigned i=0;i<179;i++)assert(!match_flow_tick(&f,true,1,false,0,1));
 assert(match_flow_tick(&f,true,1,false,0,1)==FLOW_TITLE);
 puts("PASS: result, victory/defeat/draw, ten-second continue, fresh-edge retry, timeout and title return");
}
int main(void){selection();grapple();run_attack();flow();}
