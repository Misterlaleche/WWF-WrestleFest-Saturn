#include <assert.h>
#include <stdio.h>
#include "game.h"
#include "arcade_animation.h"
int main(void){
 assert(arcade_animation_finite_ticks(0x15b6cU)==98U);
 const unsigned poses[]={395,206,207,208,209,210};
 const unsigned starts[]={0,17,34,45,56,65};
 fighter_t f={0};f.arcade_motion=true;f.state=ST_GROUND_PICKUP;
 for(unsigned i=0;i<6;i++){f.tick=starts[i];assert(game_arcade_pose(&f)==(int)poses[i]);}
 puts("PASS Test229: PICK UP keeps the complete six-pose ROM $15B6C visual schedule (98 ticks)");
}
