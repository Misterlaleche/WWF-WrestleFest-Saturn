#include "game.h"
#include <assert.h>
#include <stdio.h>
static void ticks(game_t *g,unsigned n){while(n--)game_tick(g,0,0);}
int main(void){
 unsigned r[6]={0,2,7,1,4,5};game_t g;game_match_start(&g,GAME_TAG,r);g.cpu=false;
 g.finished=true;g.winner=0;g.finish_reason=FINISH_PIN;
 int x0=g.fighters[0].x,x2=g.fighters[2].x,x1=g.fighters[1].x;
 game_tick(&g,0,0);assert(game_postmatch_active(&g));assert(g.fighters[0].x!=x0||g.fighters[0].y!=180*256);assert(g.fighters[2].x!=x2||g.fighters[2].y!=g.fighters[0].y);assert(g.fighters[1].x!=x1||g.fighters[1].y!=180*256);
 ticks(&g,120);assert(g.fighters[0].x==110*256&&g.fighters[2].x==142*256);assert(g.fighters[1].x==52*256&&g.fighters[3].x==200*256);
 game_match_start(&g,GAME_RUMBLE,r);g.cpu=false;g.finished=true;g.winner=0;game_tick(&g,0,0);ticks(&g,120);assert(g.fighters[0].x==110*256&&g.fighters[0].y==205*256);
 puts("PASS Test142: TAG/Rumble post-match staging moves resolved winners/losers without inventing victory poses");
}
