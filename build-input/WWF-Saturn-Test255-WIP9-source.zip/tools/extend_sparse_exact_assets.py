#!/usr/bin/env python3
"""Test246: recover additional ROM-exact raw pose 267 frames using only pixel
payloads already present in validated Cxx/Fxx banks plus program.bin composition
commands. No sprite ROM bytes or fabricated pixels are introduced.

Target coverage: raw pose 267 for Jake Roberts (ch2), Big Boss Man (ch3), and
Earthquake (ch8). For these characters the pose is a non-pair kind-1 record and
all referenced sprite codes can be resolved from existing exact bank payloads.
"""
from pathlib import Path
import struct,re,itertools,json,sys,collections,hashlib
sys.path.insert(0,str(Path(__file__).resolve().parent))
import lz4_codec, arcade_composition as comp
ROOT=Path(__file__).resolve().parents[1]
TARGET={2:267,3:267,8:267}
FIN_POSES={
 0:[132,133,230,231,232],1:[263,264,272,526,527,0],2:[144,145,312,313,314,315,316,317,104],
 3:[194,195,196,197,198,199,200,201],4:[334,335,336,337],5:[269,452,453,454,455],
 6:[411,412,413,414,415],7:[324,325,326,327,328],8:[470,471],9:[248,299,300,301]
}
FIN_PARTNERS={
 0:[255],1:[0,2,3,4,5,6,7,8,9],2:[0,1,3,4,5,6,7,8,9],3:[0,1,2,4,5,6,7,8,9],
 4:[0,1,2,3,5,6,7,8,9],5:[0,1,2,3,6,7,8,9],6:[0,1,2,3,4,5,7,8,9],
 7:[0,1,2,3,4,5,6,8,9],8:[255],9:[0,1,2,3,4,5,6,7,8]
}
KNOWN={0:177,1:178,2:179,3:180,4:181,146:182,147:183,148:184,461:185,462:186,
       89:187,90:188,91:189,92:190,93:191,9:192,10:193,11:194,12:195,13:196,14:197,
       105:198,150:199,151:200,152:201,153:202,154:203,155:204,180:205,181:206}
EXACT_EXISTING={2:{104:207,110:208,111:209},8:{470:212,471:213}}

def be16(b,o):return int.from_bytes(b[o:o+2],'big')
def be32(b,o):return int.from_bytes(b[o:o+4],'big')
def fnv(data):
 h=2166136261
 for x in data:h=((h^x)*16777619)&0xffffffff
 return h

def unpack(path):
 b=path.read_bytes();assert be32(b,0)==0x57464332
 frames,records,tiles,off,block_tiles,blocks=[be32(b,o) for o in (4,8,12,16,24,28)]
 idx=[(be16(b,32+i*4),be16(b,34+i*4)) for i in range(frames)]
 ro=32+frames*4;rec=[list(struct.unpack_from('>HhhH',b,ro+i*8)) for i in range(records)]
 tex=[]
 for bi in range(blocks):
  eo=off+bi*12;pos,stored,raw=be32(b,eo),be32(b,eo+4),be32(b,eo+8)
  chunk=lz4_codec.decompress(b[pos:pos+stored],raw);tex.extend(chunk[i:i+128] for i in range(0,len(chunk),128))
 assert len(tex)==tiles
 return [[r[:] for r in rec[first:first+count]] for first,count in idx],tex,block_tiles

def pack(frames,textures,block_tiles):
 indexes=[];records=[]
 for f in frames:indexes.append((len(records),len(f)));records.extend(f)
 body=b''.join(struct.pack('>HH',*x) for x in indexes)+b''.join(struct.pack('>HhhH',*r) for r in records)
 off=(32+len(body)+31)&~31;raw=b''.join(textures);chunks=[]
 for first in range(0,len(textures),block_tiles):
  chunk=b''.join(textures[first:first+block_tiles]);z=lz4_codec.compress(chunk);assert lz4_codec.decompress(z,len(chunk))==chunk;chunks.append((chunk,z))
 pos=off+len(chunks)*12;directory=[];payload=[]
 for chunk,z in chunks:directory.append(struct.pack('>III',pos,len(z),len(chunk)));payload.append(z);pos+=len(z)
 hdr=struct.pack('>8I',0x57464332,len(frames),len(records),len(textures),off,fnv(raw),block_tiles,len(chunks))
 return hdr+body+bytes(off-32-len(body))+b''.join(directory)+b''.join(payload)

def geom(p):return (155-p['x'],p['y']-150,(int(p['fx'])|(int(p['fy'])<<1))^1)

def learn(frame,textures,pieces,banks,maps):
 if isinstance(banks,int):banks={banks}
 q=collections.defaultdict(list)
 for r in frame:q[tuple(r[1:])].append(r[0])
 for p in pieces:
  bank=p['bank']
  if bank not in banks:continue
  g=geom(p)
  if not q[g]:continue
  ti=q[g].pop(0);px=textures[ti];code=p['code'];mapping=maps[bank] if isinstance(maps,list) else maps
  if code in mapping and mapping[code]!=px:raise RuntimeError(('pixel mapping conflict',bank,code))
  mapping[code]=px

def build_global_pixel_maps(cdata,fdata):
 maps=[{} for _ in range(10)]
 for ch,(cframes,ctex) in cdata.items():
  for pose,fr in KNOWN.items():
   pcs=comp.commands(ch,pose,partner=2 if ch!=2 else 0);learn(cframes[fr],ctex,pcs,ch,maps[ch])
  for pose,fr in EXACT_EXISTING.get(ch,{}).items():
   pcs=comp.commands(ch,pose,partner=2 if ch!=2 else 0);learn(cframes[fr],ctex,pcs,ch,maps[ch])
 # Conservative Fxx recovery: accept a frame only when its complete geometry
 # multiset identifies exactly one (partner, phase) candidate. This avoids
 # assigning a texture to a sprite code from ambiguous repeated geometry.
 identified=0
 for ach,(fframes,ftex) in fdata.items():
  poses=FIN_POSES[ach]
  pair=FIN_PARTNERS[ach]!=[255]
  candidates_partners=[p for p in range(10) if p!=ach] if pair else [255]
  for frame in fframes:
   rg=collections.Counter(tuple(r[1:]) for r in frame);cand=[]
   for phase,pose in enumerate(poses):
    for partner in candidates_partners:
     actual=(2 if ach!=2 else 0) if partner==255 else partner
     pcs=comp.commands(ach,pose,partner=actual)
     banks={ach} if partner==255 else {ach,partner}
     relevant=[p for p in pcs if p['bank'] in banks]
     cg=collections.Counter(geom(p) for p in relevant)
     if rg==cg:cand.append((actual,pcs,banks))
   if len(cand)!=1:continue
   actual,pcs,banks=cand[0]
   learn(frame,ftex,pcs,banks,maps)
   identified+=1
 return maps,identified

def main():
 comp.load_program(ROOT/'program.bin')
 cdata={};fdata={}
 for ch in range(10):
  cf,ct,cb=unpack(ROOT/'cd'/f'C{ch:02}.PAK');assert len(cf)==214;cdata[ch]=(cf,ct,cb)
  ff,ft,_=unpack(ROOT/'cd'/f'F{ch:02}.PAK');fdata[ch]=(ff,ft)
 maps,identified=build_global_pixel_maps({ch:(cdata[ch][0],cdata[ch][1]) for ch in range(10)},fdata)
 sizes=[];hashes=[];report=[]
 for ch in range(10):
  cpath=ROOT/'cd'/f'C{ch:02}.PAK';frames,tex,bt=cdata[ch]
  added=[]
  if ch in TARGET:
   mapping=maps[ch]
   pose=TARGET[ch];meta=comp.pair_metadata(ch,pose);assert meta and meta['kind']!=2,meta
   pcs=[p for p in comp.commands(ch,pose,partner=0 if ch!=0 else 1) if p['bank']==ch]
   missing=sorted({p['code'] for p in pcs if p['code'] not in mapping});assert not missing,(ch,missing)
   lookup={px:i for i,px in enumerate(tex)};rec=[]
   for p in pcs:
    px=mapping[p['code']]
    if not any(px):continue
    if px not in lookup:lookup[px]=len(tex);tex.append(px)
    x,y,flip=geom(p);rec.append([lookup[px],x,y,flip])
   assert rec, ch;frames.append(rec)
   added=[dict(pose=pose,frame=214,records=len(rec),mapped_sprite_codes=len(mapping),composition_kind=meta['kind'])]
  else:frames.append([])
  data=pack(frames,tex,bt);cpath.write_bytes(data);sizes.append(len(data));hashes.append(fnv(data));report.append(dict(character=ch,bytes=len(data),added=added))
 h=(ROOT/'roster_data.h').read_text().replace('#define ROSTER_FRAMES 214','#define ROSTER_FRAMES 215')
 h=re.sub(r'static const unsigned roster_bytes\[10\]=\{.*?\};','static const unsigned roster_bytes[10]={'+','.join(map(str,sizes))+'};',h)
 h=re.sub(r'static const unsigned roster_hash\[10\]=\{.*?\};','static const unsigned roster_hash[10]={'+','.join(str(x)+'U' for x in hashes)+'};',h)
 marker=' case 8: switch(pose){case 470:return 212;case 471:return 213;default:break;} break;'
 repl=' case 2: switch(pose){case 104:return 207;case 110:return 208;case 111:return 209;case 267:return 214;default:break;} break;'
 # replace existing case2 first, then add case3 and extend case8
 h=h.replace(' case 2: switch(pose){case 104:return 207;case 110:return 208;case 111:return 209;default:break;} break;',repl)
 h=h.replace(marker,' case 3: switch(pose){case 267:return 214;default:break;} break;\n case 8: switch(pose){case 470:return 212;case 471:return 213;case 267:return 214;default:break;} break;')
 (ROOT/'roster_data.h').write_text(h)
 aligned=[(x+2047)&~2047 for x in sizes];worst=max(sum(aligned[i] for i in c) for c in itertools.combinations(range(10),6));assert worst<=1048576
 doc=dict(test=246,frames_per_pack=215,recovered=report,worst_six_low_ram_bytes=worst,capacity=1048576,
  evidence='program.bin exact composition commands + exact pixels inferred only from uniquely identified validated Cxx/Fxx frames; no guessed pixels',
  uniquely_identified_overlay_frames=identified,
  recovered_pairs=['Jake Roberts raw267','Big Boss Man raw267','Earthquake raw267'],
  still_blocked=['PICK UP 395/206-210','ELBOW 265-266 and unsupported character variants','KNEE 292-294','FIST 516-520','objects 114-123'])
 (ROOT/'docs/test246-sparse-exact-recovery.json').write_text(json.dumps(doc,indent=2)+'\n')
 print(json.dumps(doc,indent=2))
if __name__=='__main__':main()
