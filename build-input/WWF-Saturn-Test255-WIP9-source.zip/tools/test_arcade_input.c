#include <assert.h>
#include <stdio.h>
#include "arcade_input.h"
static uint16_t raw_for(uint8_t active){return (uint16_t)(0xff00u | ((~active)&0xffu));}
int main(void){
 arcade_input_sample_t s=arcade_input_decode(0xffff,0);
 assert(s.activated_low==0&&s.direction==0&&s.buttons==0&&s.pressed==0);
 s=arcade_input_decode(raw_for(ARCADE_PORT_RIGHT|ARCADE_PORT_UP|ARCADE_PORT_BUTTON1),0);
 assert(s.direction==(ARCADE_PORT_RIGHT|ARCADE_PORT_UP));assert(s.buttons==1&&s.pressed==1);
 s=arcade_input_decode(raw_for(ARCADE_PORT_BUTTON1),1);assert(s.buttons==1&&s.pressed==0);
 s=arcade_input_decode(raw_for(ARCADE_PORT_BUTTON1|ARCADE_PORT_BUTTON2),1);assert(s.buttons==3&&s.pressed==2);
 s=arcade_input_decode(raw_for(ARCADE_PORT_BUTTON1|ARCADE_PORT_BUTTON2),0);assert(s.buttons==3&&s.pressed==3);
 s=arcade_input_decode(raw_for(0x40|0x80|ARCADE_PORT_LEFT),0);
 assert(s.activated_low==(0x40|0x80|ARCADE_PORT_LEFT));assert(s.direction==ARCADE_PORT_LEFT&&s.buttons==0);
 puts("PASS Test67: ROM $64EA active-low input normalization, four directions, two physical buttons and fresh-edge current&~previous");
}
