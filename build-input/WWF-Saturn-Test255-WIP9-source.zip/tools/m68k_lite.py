#!/usr/bin/env python3
"""Small MC68000 linear disassembler for WrestleFest ROM auditing.
Not a general replacement for Musashi: decodes base 68000 instruction groups,
with accurate enough lengths/EA rendering for control/data-flow research.
"""
from dataclasses import dataclass
from pathlib import Path
import argparse

CC=['T','F','HI','LS','CC','CS','NE','EQ','VC','VS','PL','MI','GE','LT','GT','LE']

def sx8(x): return x-256 if x&0x80 else x
def sx16(x): return x-65536 if x&0x8000 else x

def u16(b,p):
    if p+2>len(b): raise IndexError
    return (b[p]<<8)|b[p+1]
def u32(b,p): return (u16(b,p)<<16)|u16(b,p+2)

def ealen(mode,reg,size):
    if mode<=4:return 0
    if mode in (5,6):return 2
    if mode==7:
        if reg in (0,2,3):return 2
        if reg==1:return 4
        if reg==4:return 2 if size in ('b','w') else 4
    raise ValueError((mode,reg,size))

def ea(b,p,mode,reg,size,pcbase=0):
    if mode==0:return f'D{reg}',0
    if mode==1:return f'A{reg}',0
    if mode==2:return f'(A{reg})',0
    if mode==3:return f'(A{reg})+',0
    if mode==4:return f'-(A{reg})',0
    if mode==5:
        d=sx16(u16(b,p)); return f'{d:+#x}(A{reg})',2
    if mode==6:
        x=u16(b,p); d=sx8(x&255); xr=('A' if x&0x8000 else 'D')+str((x>>12)&7); sz='.l' if x&0x0800 else '.w'
        return f'{d:+#x}(A{reg},{xr}{sz})',2
    if mode==7 and reg==0:return f'${u16(b,p):04X}.w',2
    if mode==7 and reg==1:return f'${u32(b,p):08X}',4
    if mode==7 and reg==2:
        d=sx16(u16(b,p)); return f'${(pcbase+p+2+d)&0xffffffff:08X}(PC)',2
    if mode==7 and reg==3:
        x=u16(b,p); d=sx8(x&255); xr=('A' if x&0x8000 else 'D')+str((x>>12)&7); sz='.l' if x&0x0800 else '.w'
        return f'{d:+#x}(PC,{xr}{sz})',2
    if mode==7 and reg==4:
        if size=='l': return f'#${u32(b,p):08X}',4
        v=u16(b,p); return (f'#${v&255:02X}' if size=='b' else f'#${v:04X}'),2
    return f'<EA{mode},{reg}>',0

@dataclass
class Ins:
    addr:int; length:int; text:str; raw:bytes; branch:int|None=None; stop:bool=False

def decode(b,p,base=0):
    a=base+p; op=u16(b,p); q=p+2
    def I(txt,n=None,branch=None,stop=False):
        L=(q-p if n is None else n); return Ins(a,L,txt,b[p:p+L],branch,stop)
    # exact/simple
    exact={0x4e71:'NOP',0x4e75:'RTS',0x4e73:'RTE',0x4e70:'RESET',0x4e76:'TRAPV',0x4e77:'RTR'}
    if op in exact:return I(exact[op],2,stop=op in (0x4e75,0x4e73,0x4e77))
    if op==0x4e72: return I(f'STOP #${u16(b,q):04X}',4,stop=True)
    if (op&0xfff0)==0x4e40:return I(f'TRAP #{op&15}',2)
    if (op&0xfff8)==0x4e50:return I(f'LINK A{op&7},#{sx16(u16(b,q))}',4)
    if (op&0xfff8)==0x4e58:return I(f'UNLK A{op&7}',2)
    if (op&0xfff0)==0x4e60:return I(('MOVE A%d,USP' if op&8 else 'MOVE USP,A%d')%(op&7),2)
    # branches
    if (op&0xf000)==0x6000:
        cc=(op>>8)&15; d8=op&255
        if d8==0: d=sx16(u16(b,q)); L=4; target=a+2+d
        else: d=sx8(d8); L=2; target=a+2+d
        name='BRA' if cc==0 else ('BSR' if cc==1 else 'B'+CC[cc])
        return Ins(a,L,f'{name} ${target:06X}',b[p:p+L],target,cc==0)
    # MOVEQ
    if (op&0xf100)==0x7000:return I(f'MOVEQ #{sx8(op&255)},D{(op>>9)&7}',2)
    # MOVE / MOVEA
    top=op>>12
    if top in (1,2,3):
        sz={1:'b',2:'l',3:'w'}[top]; sm=(op>>3)&7; sr=op&7; dm=(op>>6)&7; dr=(op>>9)&7
        s,se=ea(b,q,sm,sr,sz,base); q+=se
        d,de=ea(b,q,dm,dr,sz,base); q+=de
        if dm==1 and sz!='b': return I(f'MOVEA.{sz} {s},A{dr}')
        return I(f'MOVE.{sz} {s},{d}')
    # immediate arithmetic/logical
    immmap={0x0000:'ORI',0x0200:'ANDI',0x0400:'SUBI',0x0600:'ADDI',0x0a00:'EORI',0x0c00:'CMPI'}
    key=op&0xff00
    if key in immmap and (op&0x003f)!=0x003c:
        ss=(op>>6)&3; sz={0:'b',1:'w',2:'l'}.get(ss,'w'); imm,ie=ea(b,q,7,4,sz,base); q+=ie
        m=(op>>3)&7;r=op&7; d,de=ea(b,q,m,r,sz,base);q+=de
        return I(f'{immmap[key]}.{sz} {imm},{d}')
    # ORI/ANDI/EORI to CCR/SR
    special={0x003c:('ORI','CCR','b'),0x007c:('ORI','SR','w'),0x023c:('ANDI','CCR','b'),0x027c:('ANDI','SR','w'),0x0a3c:('EORI','CCR','b'),0x0a7c:('EORI','SR','w')}
    if op in special:
        n,dst,sz=special[op]; val=u16(b,q); return I(f'{n} #${val:04X},{dst}',4)
    # immediate bit ops
    if (op&0xff00)==0x0800:
        typ=['BTST','BCHG','BCLR','BSET'][(op>>6)&3]; bit=u16(b,q)&255;q+=2;m=(op>>3)&7;r=op&7; d,de=ea(b,q,m,r,'b',base);q+=de
        return I(f'{typ} #{bit},{d}')
    # dynamic bit ops (exclude MOVEP rough)
    if (op&0xf100)==0x0100 and ((op>>3)&7)!=1:
        typ=['BTST','BCHG','BCLR','BSET'][(op>>6)&3];m=(op>>3)&7;r=op&7;d,de=ea(b,q,m,r,'b',base);q+=de
        return I(f'{typ} D{(op>>9)&7},{d}')
    # group 4 system/misc
    if (op&0xffc0)==0x4e80 or (op&0xffc0)==0x4ec0:
        m=(op>>3)&7;r=op&7;d,de=ea(b,q,m,r,'l',base);q+=de; name='JSR' if (op&0xffc0)==0x4e80 else 'JMP'
        target=None
        if m==7 and r==1: target=int(d[1:],16)
        return I(f'{name} {d}',branch=target,stop=name=='JMP')
    if (op&0xf1c0)==0x41c0:
        m=(op>>3)&7;r=op&7;s,se=ea(b,q,m,r,'l',base);q+=se;return I(f'LEA {s},A{(op>>9)&7}')
    if (op&0xffc0)==0x4840 and (op&0x38)!=0: # PEA except SWAP Dn
        m=(op>>3)&7;r=op&7;s,se=ea(b,q,m,r,'l',base);q+=se;return I(f'PEA {s}')
    if (op&0xfff8)==0x4840:return I(f'SWAP D{op&7}',2)
    if (op&0xfb80)==0x4880: # MOVEM, mask precedes EA extension
        sz='l' if op&0x40 else 'w'; mask=u16(b,q);q+=2;m=(op>>3)&7;r=op&7;d,de=ea(b,q,m,r,sz,base);q+=de
        direction='mem->regs' if op&0x400 else 'regs->mem'
        return I(f'MOVEM.{sz} ${mask:04X},{d} [{direction}]')
    for mask,val,name in [(0xff00,0x4200,'CLR'),(0xff00,0x4400,'NEG'),(0xff00,0x4600,'NOT'),(0xff00,0x4a00,'TST')]:
        if (op&mask)==val and ((op>>6)&3)!=3:
            sz={0:'b',1:'w',2:'l'}[(op>>6)&3];m=(op>>3)&7;r=op&7;d,de=ea(b,q,m,r,sz,base);q+=de;return I(f'{name}.{sz} {d}')
    if (op&0xffc0)==0x4ac0:
        m=(op>>3)&7;r=op&7;d,de=ea(b,q,m,r,'b',base);q+=de;return I(f'TAS {d}')
    if (op&0xffc0)==0x4800:
        m=(op>>3)&7;r=op&7;d,de=ea(b,q,m,r,'b',base);q+=de;return I(f'NBCD {d}')
    if (op&0xffc0)==0x40c0:
        m=(op>>3)&7;r=op&7;d,de=ea(b,q,m,r,'w',base);q+=de;return I(f'MOVE SR,{d}')
    if (op&0xffc0)==0x44c0:
        m=(op>>3)&7;r=op&7;s,se=ea(b,q,m,r,'w',base);q+=se;return I(f'MOVE {s},CCR')
    if (op&0xffc0)==0x46c0:
        m=(op>>3)&7;r=op&7;s,se=ea(b,q,m,r,'w',base);q+=se;return I(f'MOVE {s},SR')
    # group 5 DBcc/Scc/addq/subq
    if (op&0xf000)==0x5000:
        if (op&0x00f8)==0x00c8:
            d=sx16(u16(b,q));t=a+2+d;return I(f'DB{CC[(op>>8)&15]} D{op&7},${t:06X}',4,branch=t)
        if (op&0x00c0)==0x00c0:
            m=(op>>3)&7;r=op&7;d,de=ea(b,q,m,r,'b',base);q+=de;return I(f'S{CC[(op>>8)&15]} {d}')
        sz={0:'b',1:'w',2:'l'}.get((op>>6)&3,'w');n=(op>>9)&7;n=8 if n==0 else n;m=(op>>3)&7;r=op&7;d,de=ea(b,q,m,r,sz,base);q+=de
        return I(f'{"SUBQ" if op&0x0100 else "ADDQ"}.{sz} #{n},{d}')
    # group 8/9/B/C/D arithmetic families
    high=op>>12
    if high in (8,9,11,12,13):
        dn=(op>>9)&7; opmode=(op>>6)&7;m=(op>>3)&7;r=op&7
        # special div/mul
        if high==8 and opmode in (3,7):
            s,se=ea(b,q,m,r,'w',base);q+=se;return I(f'{"DIVS" if opmode==7 else "DIVU"}.w {s},D{dn}')
        if high==12 and opmode in (3,7):
            s,se=ea(b,q,m,r,'w',base);q+=se;return I(f'{"MULS" if opmode==7 else "MULU"}.w {s},D{dn}')
        names={8:'OR',9:'SUB',11:'CMP/EOR',12:'AND',13:'ADD'};nm=names[high]
        if opmode in (0,1,2):
            sz=['b','w','l'][opmode];s,se=ea(b,q,m,r,sz,base);q+=se;return I(f'{nm}.{sz} {s},D{dn}')
        if opmode in (4,5,6):
            sz=['b','w','l'][opmode-4];d,de=ea(b,q,m,r,sz,base);q+=de;return I(f'{nm}.{sz} D{dn},{d}')
        if high in (9,13) and opmode in (3,7):
            sz='w' if opmode==3 else 'l';s,se=ea(b,q,m,r,sz,base);q+=se;return I(f'{"SUBA" if high==9 else "ADDA"}.{sz} {s},A{dn}')
        if high==11 and opmode in (3,7):
            sz='w' if opmode==3 else 'l';s,se=ea(b,q,m,r,sz,base);q+=se;return I(f'CMPA.{sz} {s},A{dn}')
    # shifts/rotates: memory forms consume EA, register forms no ext
    if (op&0xf000)==0xe000:
        if (op&0x00c0)==0x00c0:
            m=(op>>3)&7;r=op&7;d,de=ea(b,q,m,r,'w',base);q+=de;return I(f'SHIFT.w {d}')
        return I('SHIFT/ROT reg',2)
    return I(f'DC.W ${op:04X}',2)

def disasm(path,start,end=None,base=0):
    b=Path(path).read_bytes();p=start-base;endp=len(b) if end is None else end-base
    while p<endp:
        try:i=decode(b,p,base)
        except Exception as e:
            i=Ins(base+p,2,f'DC.W ${u16(b,p):04X} ; {e}',b[p:p+2])
        print(f'{i.addr:06X}: {i.raw.hex(" ").upper():<24} {i.text}')
        p+=max(i.length,2)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('file');ap.add_argument('start',type=lambda x:int(x,0));ap.add_argument('end',nargs='?',type=lambda x:int(x,0));ap.add_argument('--base',type=lambda x:int(x,0),default=0);a=ap.parse_args();disasm(a.file,a.start,a.end,a.base)
if __name__=='__main__':main()
