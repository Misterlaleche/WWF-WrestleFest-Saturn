#include <yaul.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include "model_data.h"
#include "game.h"
#include "intro.h"
#include "intro_data.h"
#include "title_data.h"
#include "roster_data.h"
#include "pair_order.h"
#include "session.h"
#include "codec.h"
#include "graphics_dma.h"
#include "timing.h"
#include "presentation.h"
#include "autoplay.h"
#include "ui_assets.h"
#include "hud.h"
#include "presentation_assets.h"
#include "match_flow.h"
#include "match_result.h"
#include "campaign.h"
#include "campaign_runtime.h"
#include "campaign_presentation.h"
#include "arcade_stamina.h"
#include "combat_moves.h"
#include "roster_pack.h"
#include "layer_view.h"
#include "render_pose.h"
#include "ground_pair_assets.h"
#include "struggle_pair_assets.h"
#include "object_assets.h"
#include "ring_transition_assets.h"
#include "finisher_runtime.h"
#include "wf_audio_event.h"
#include "wf_audio_saturn.h"
static match_flow_t match_flow;
static match_history_t match_history;
static campaign_t campaign;
static campaign_presentation_t campaign_present;
static bool campaign_ready;
static uint32_t campaign_rng=0x57574631U; /* selection distribution exact; RNG source provisional */
static wf_audio_observer_t audio_observer;
#define WIDTH 320
#define HEIGHT 240
#define BITMAP_CAPACITY 262144U
#define RING_ADDR VDP2_VRAM_ADDR(0,0)
#define RINGPAL_ADDR VDP2_CRAM_MODE_1_OFFSET(4,0,0)
#define PAL_ADDR VDP2_CRAM_MODE_1_OFFSET(2,0,0)
#define ROSTER_ADDR VDP2_CRAM_MODE_1_OFFSET(1,0,0)
#define ENTRY_PAL_ADDR VDP2_CRAM_MODE_1_OFFSET(6,0,0)
#define PROMPT_PAL_ADDR (PAL_ADDR+PALETTE_BYTES)
extern uint8_t asset_pal[],asset_rosterpal[],asset_objectpal[],asset_ring14pal[],asset_entrypal[];
extern uint8_t asset_intro[],asset_prompt[],asset_promptpal[];
extern uint8_t asset_announcepal[],asset_logospal[];
extern uint8_t asset_ui[],asset_uipal[];
extern uint8_t asset_entryui[],asset_entryuipal[];
#define UI_TEXTURE_OFFSET (TEXTURE_BYTES+PROMPT_BYTES)
#define HUD_TEXTURE_OFFSET (UI_TEXTURE_OFFSET+UI_TEXTURE_BYTES)
#define ENTRY_TEXTURE_OFFSET (HUD_TEXTURE_OFFSET+HUD_BYTES)
#define DYNAMIC_TEXTURE_OFFSET (ENTRY_TEXTURE_OFFSET+ENTRY_OVERLAY_BYTES)
_Static_assert(DYNAMIC_TEXTURE_OFFSET%32==0,"VDP1 dynamic texture alignment");
_Static_assert(DYNAMIC_TEXTURE_OFFSET+DYNAMIC_TEXTURE_BYTES+CMD_CAPACITY*32U+32U<=524288U,"VDP1 VRAM partitions exceed capacity");
static unsigned selection_signature=~0U;
static uint8_t *selection_rle[2];static unsigned selection_rle_size[2];static uint8_t selection_pal[2][2048];
/* Test223+: persistent front-end caches. Palette buffers are sector-sized because
 * cd_read() validates the rounded MODE1/2048 transfer capacity (Test164 rule). */
static uint8_t *mode_rle_cache,*entry_rle_cache;static unsigned mode_rle_size,entry_rle_size;
static uint8_t mode_pal_cache[2048];static bool title_lwram_cached;
enum { LOAD_NONE, LOAD_BOOT, LOAD_MATCH };
typedef struct { unsigned kind,stage,shown,target_phase,tick; } loading_state_t;
static loading_state_t loading;
/* Test240: loading presentation deliberately minimal. No portrait, help text,
 * progress bar or animated decoration is retained. */

static uint8_t hud_buffer[HUD_BYTES] __aligned(32);
static uint16_t hud_palette[256] __aligned(32);

static bool hud_initialized;
static vdp1_vram_partitions_t partitions;
static vdp1_cmdt_list_t *cmds;
static smpc_peripheral_digital_t pad;
static game_t game;static intro_t intro;static session_t session;
static uint8_t *bitmap,*title_delta;
static unsigned title_frame,title_phase,title_page;
static unsigned demo_ticks;
static unsigned presentation_phase;
static bool hud=false,loaded_roster;
static unsigned layer_view;
static volatile unsigned video_clock;
static unsigned last_video,frame_intervals,render_frames,render_window,render_fps;
static uint32_t check_error;static unsigned phase,pending;
static uint32_t check_expected,check_actual,check_source,check_target;
enum { CDFS_FILE_CAPACITY=256 };
static cdfs_filelist_t files;static cdfs_filelist_entry_t file_entries[CDFS_FILE_CAPACITY];
static uint8_t *character_data[10],*overflow_character;
static roster_pack_t character_packs[10];
static roster_pack_t finisher_overlay_pack;
/* Test252: object compositions are persistent high-RAM data. They must never
 * share the low-RAM Fxx/Gxy overlay slot that was involved in CHECK338. */
static roster_pack_t object_pack;
static uint8_t *object_pack_data;
static uint8_t *finisher_overlay_data;
static unsigned finisher_overlay_character=255,finisher_overlay_partner=255,finisher_overlay_kind=0,roster_low_used;
static roster_block_cache_t roster_texture_cache;
static uint8_t dynamic_data[DYNAMIC_TEXTURE_BYTES] __aligned(32);
static uint16_t cache_char[512],cache_tile[512];static unsigned cache_count;
static uint16_t cache_hash[1024];
static char text_page[768],text_previous[768];static unsigned text_length;
static void text_printf(const char *format,...){
 if(text_length>=sizeof(text_page)-1)return;
 va_list ap;va_start(ap,format);int n=vsnprintf(text_page+text_length,sizeof(text_page)-text_length,format,ap);va_end(ap);
 if(n>0){unsigned left=sizeof(text_page)-text_length-1;text_length+=(unsigned)n>left?left:(unsigned)n;}
}
static bool in_intro(void){return intro.screen<INTRO_GAME;}
static bool in_ring(void){return !in_intro()&&session.phase>=SESSION_RING;}
static bool playing(void){return !in_intro()&&session.phase==SESSION_PLAY;}
static bool show_hud(void){return playing();}
static void intback(void *work __unused){++video_clock;smpc_peripheral_intback_issue();}
static uint32_t hash_ram(const uint8_t *p,size_t n){uint32_t h=2166136261UL;while(n--)h=(h^*p++)*16777619UL;return h;}
static uint32_t hash_video(const volatile uint16_t *p,size_t n){uint32_t h=2166136261UL;for(size_t i=0;i<n/2;i++){uint16_t w=p[i];h=(h^(w>>8))*16777619UL;h=(h^(w&255))*16777619UL;}return h;}
static void transfer(void *dst,const void *src,unsigned size){
 if(check_error)return;
 if(!graphics_dma_source_valid((uintptr_t)src,size)){
  check_source=(uintptr_t)src;check_target=(uintptr_t)dst;check_error=332;return;
 }
 scu_dma_transfer(0,dst,src,size);scu_dma_transfer_wait(0);
}
static unsigned cd_read(const char *name,void *dst,unsigned capacity){
 for(unsigned i=0;i<files.entries_count;i++)if(!strcmp(name,files.entries[i].name)){
  unsigned size=files.entries[i].size;
  if(((size+2047U)&~2047U)>capacity){check_error=301;return 0;}
  if(cd_block_sectors_read(files.entries[i].starting_fad,dst,size)){check_error=302;return 0;}return size;
 }
 check_error=303;return 0;
}
static uint32_t cd_fad(const char *name){
 for(unsigned i=0;i<files.entries_count;i++)if(!strcmp(name,files.entries[i].name))return files.entries[i].starting_fad;
 return 0;
}
static bool selection_cache_load_page(unsigned page){
 page&=1U;if(selection_rle[page])return true;
 char rn[16],pn[16];sprintf(rn,"SELECT%u.RLE",page);sprintf(pn,"SELECT%u.PAL",page);
 unsigned cap=page?45056U:47104U; /* sector-rounded exact capacity: 42920 / 45294 bytes */
 selection_rle[page]=malloc(cap);if(!selection_rle[page]){check_error=304;return false;}
 selection_rle_size[page]=cd_read(rn,selection_rle[page],cap);
 if(check_error||cd_read(pn,selection_pal[page],sizeof(selection_pal[page]))!=512){free(selection_rle[page]);selection_rle[page]=NULL;selection_rle_size[page]=0;return false;}
 return true;
}
static bool mode_cache_ensure(void){
 if(mode_rle_cache)return true;const unsigned cap=45056U; /* 42860 bytes rounded to CD sectors */
 mode_rle_cache=malloc(cap);if(!mode_rle_cache){check_error=304;return false;}
 mode_rle_size=cd_read("MODE.RLE",mode_rle_cache,cap);
 if(check_error||cd_read("MODE.PAL",mode_pal_cache,sizeof(mode_pal_cache))!=512){free(mode_rle_cache);mode_rle_cache=NULL;mode_rle_size=0;return false;}return true;
}
static bool entry_cache_ensure(void){
 if(entry_rle_cache)return true;const unsigned cap=55296U; /* 53627 bytes rounded to CD sectors */
 entry_rle_cache=malloc(cap);if(!entry_rle_cache){check_error=314;return false;}
 entry_rle_size=cd_read("ENTRY.RLE",entry_rle_cache,cap);return !check_error;
}
static bool plate_load(const char *name,const char *palname){
 uint8_t *src=malloc(131072);if(!src){check_error=304;return false;}
 unsigned size=cd_read(name,src,131072);
 if(!check_error&&!intro_unpack(src,size,bitmap,INTRO_BITMAP_BYTES))check_error=305;
 if(!check_error){transfer((void *)RING_ADDR,bitmap,INTRO_BITMAP_BYTES);if(cd_read(palname,src,131072)!=512)check_error=306;else transfer((void *)RINGPAL_ADDR,src,512);}
 free(src);return !check_error;
}
static void selection_cache_free(void){for(unsigned i=0;i<2;i++){free(selection_rle[i]);selection_rle[i]=NULL;selection_rle_size[i]=0;}}
static bool selection_cache_ensure(void){
 if(selection_rle[0]&&selection_rle[1])return true;
 if(!selection_cache_load_page(0)||!selection_cache_load_page(1)){selection_cache_free();return false;}return true;
}
static bool selection_cache_show(unsigned page){
 page&=1U;if(!selection_cache_ensure())return false;if(!intro_unpack(selection_rle[page],selection_rle_size[page],bitmap,INTRO_BITMAP_BYTES)){check_error=305;return false;}
 transfer((void *)RING_ADDR,bitmap,INTRO_BITMAP_BYTES);transfer((void *)RINGPAL_ADDR,selection_pal[page],512);return !check_error;
}
static void selection_update(void){
 if(in_intro()||(session.phase!=SESSION_SELECT&&session.phase!=SESSION_CPU))return;
 unsigned page=session_page(&session),signature=page;
 unsigned colors[6];
 for(unsigned row=0;row<2;row++)for(unsigned col=0;col<3;col++){
  unsigned cursor=row*5+col+page*2;
  unsigned h=session_highlight(&session,cursor);
  if(page&&row&&col==1){unsigned other=session_highlight(&session,9);h=(h==1||other==1)?1:(h>other?h:other);}
  colors[row*3+col]=h;signature=signature*3+h;
 }
 if(signature==selection_signature)return;selection_signature=signature;
 /* Dedicated colors, applied only to original palette-index masks. */
 MEMORY_WRITE(16,RINGPAL_ADDR+253*2,0xFFA0); /* arcade $fe0 -> RGB555 */
 MEMORY_WRITE(16,RINGPAL_ADDR+254*2,0xFFFF);
 MEMORY_WRITE(16,RINGPAL_ADDR+255*2,0x83E0);
 selection_paint(bitmap,page,colors,selection_masks);
 transfer((void *)RING_ADDR,bitmap,INTRO_BITMAP_BYTES);
}
static roster_pack_t ring_transition_pack;
static uint8_t *ring_transition_pack_data;
static bool ring_transition_pack_load(void){
 if(ring_transition_pack_data)return true;
 uint8_t *dst=malloc(RING_TRANSITION_PACK_ALIGNED_BYTES);if(!dst){check_error=342;return false;}
 unsigned bytes=cd_read("RING14.PAK",dst,RING_TRANSITION_PACK_ALIGNED_BYTES);
 if(bytes!=RING_TRANSITION_PACK_BYTES||hash_ram(dst,RING_TRANSITION_PACK_BYTES)!=RING_TRANSITION_PACK_HASH){free(dst);check_error=343;return false;}
 roster_pack_t pack;if(!roster_pack_open(&pack,dst,RING_TRANSITION_PACK_BYTES,RING_TRANSITION_PACK_FRAMES)){free(dst);check_error=344;return false;}
 ring_transition_pack=pack;ring_transition_pack_data=dst;return true;
}
static bool object_pack_load(void){
 if(object_pack_data)return true;
 uint8_t *dst=malloc(OBJECT_PACK_ALIGNED_BYTES);if(!dst){check_error=339;return false;}
 unsigned bytes=cd_read("OBJ15.PAK",dst,OBJECT_PACK_ALIGNED_BYTES);
 if(bytes!=OBJECT_PACK_BYTES||hash_ram(dst,OBJECT_PACK_BYTES)!=OBJECT_PACK_HASH){free(dst);check_error=340;return false;}
 roster_pack_t pack;if(!roster_pack_open(&pack,dst,OBJECT_PACK_BYTES,OBJECT_PACK_FRAMES)){free(dst);check_error=341;return false;}
 object_pack=pack;object_pack_data=dst;return true;
}
static void roster_load_ids(const unsigned *ids,unsigned count){
 memset(character_data,0,sizeof(character_data));free(overflow_character);overflow_character=NULL;unsigned used=0;
 memset(character_packs,0,sizeof(character_packs));memset(&finisher_overlay_pack,0,sizeof(finisher_overlay_pack));
 finisher_overlay_data=NULL;finisher_overlay_character=255;finisher_overlay_partner=255;finisher_overlay_kind=0;roster_low_used=0;roster_pack_cache_reset(&roster_texture_cache);
 unsigned order[6];if(count>6)count=6;for(unsigned i=0;i<count;i++)order[i]=ids[i];
 /* Put the five smallest packs in low RAM; at most the last uses high RAM. */
 for(unsigned i=1;i<count;i++)for(unsigned j=i;j&&roster_bytes[order[j]]<roster_bytes[order[j-1]];j--){unsigned c=order[j];order[j]=order[j-1];order[j-1]=c;}
 for(unsigned i=0;i<count;i++){
  unsigned ch=order[i];if(ch>=10){check_error=338;return;}unsigned size=(roster_bytes[ch]+2047)&~2047U;char name[16];sprintf(name,"C%02u.PAK",ch);
  if(character_data[ch])continue;
  uint8_t *dst;
  if(used+size<=1048576){dst=(uint8_t *)LWRAM(used);used+=size;}
  else {if(overflow_character){check_error=307;return;}dst=malloc(size);overflow_character=dst;if(!dst){check_error=307;return;}}
  if(cd_read(name,dst,size)!=roster_bytes[ch]||hash_ram(dst,roster_bytes[ch])!=roster_hash[ch]){check_error=308;return;}
  if(!roster_pack_open(&character_packs[ch],dst,roster_bytes[ch],ROSTER_FRAMES)){check_error=309;return;}
  character_data[ch]=dst;
 }
 roster_low_used=used;if(!object_pack_load()||!ring_transition_pack_load())return;loaded_roster=true;
}
static void roster_load(void){unsigned ids[6];for(unsigned i=0;i<game.roster_count;i++)ids[i]=session.characters[i];roster_load_ids(ids,game.roster_count);}
static void campaign_progress_roster_load(void){const unsigned ids[2]={0,4};roster_load_ids(ids,2);}
static bool finisher_overlay_load(unsigned ch){
 if(ch>=10||!finisher_overlay_bytes[ch]||!loaded_roster)return false;
 if(finisher_overlay_kind==1&&finisher_overlay_character==ch&&finisher_overlay_data)return true;
 unsigned bytes=finisher_overlay_bytes[ch],capacity=(bytes+2047U)&~2047U;
 if(roster_low_used+capacity>1048576U){check_error=335;return false;}
 char name[16];sprintf(name,"F%02u.PAK",ch);uint8_t *dst=(uint8_t *)LWRAM(roster_low_used);
 if(cd_read(name,dst,capacity)!=bytes||hash_ram(dst,bytes)!=finisher_overlay_hash[ch]){check_error=336;return false;}
 roster_pack_t pack;
 if(!roster_pack_open(&pack,dst,bytes,finisher_overlay_frames[ch])){check_error=337;return false;}
 finisher_overlay_pack=pack;finisher_overlay_data=dst;finisher_overlay_character=ch;finisher_overlay_partner=255;finisher_overlay_kind=1;
 /* Same LWRAM address is reused by every overlay: invalidate decoded blocks. */
 roster_pack_cache_reset(&roster_texture_cache);return true;
}
static bool ground_pair_overlay_load(unsigned ch,unsigned partner){
 if(ch>=10||partner>=10||ch==partner||!loaded_roster)return false;
 unsigned bytes=ground_pair_bytes[ch][partner];if(!bytes)return false;
 if(finisher_overlay_kind==2&&finisher_overlay_character==ch&&finisher_overlay_partner==partner&&finisher_overlay_data)return true;
 unsigned capacity=(bytes+2047U)&~2047U;if(roster_low_used+capacity>1048576U){check_error=335;return false;}
 char name[16];sprintf(name,"G%u%u.PAK",ch,partner);uint8_t *dst=(uint8_t *)LWRAM(roster_low_used);
 if(cd_read(name,dst,capacity)!=bytes||hash_ram(dst,bytes)!=ground_pair_hash[ch][partner]){check_error=336;return false;}
 roster_pack_t pack;if(!roster_pack_open(&pack,dst,bytes,ground_pair_frames[ch][partner])){check_error=337;return false;}
 finisher_overlay_pack=pack;finisher_overlay_data=dst;finisher_overlay_character=ch;finisher_overlay_partner=partner;finisher_overlay_kind=2;
 roster_pack_cache_reset(&roster_texture_cache);return true;
}
static bool struggle_pair_overlay_load(unsigned ch,unsigned partner){
 if(ch>=10||partner>=10||ch==partner||!loaded_roster)return false;
 unsigned bytes=struggle_pair_bytes[ch][partner];if(!bytes)return false;
 if(finisher_overlay_kind==3&&finisher_overlay_character==ch&&finisher_overlay_partner==partner&&finisher_overlay_data)return true;
 unsigned capacity=(bytes+2047U)&~2047U;if(roster_low_used+capacity>1048576U){check_error=335;return false;}
 char name[16];sprintf(name,"S%u%u.PAK",ch,partner);uint8_t *dst=(uint8_t *)LWRAM(roster_low_used);
 if(cd_read(name,dst,capacity)!=bytes||hash_ram(dst,bytes)!=struggle_pair_hash[ch][partner]){check_error=336;return false;}
 roster_pack_t pack;if(!roster_pack_open(&pack,dst,bytes,struggle_pair_frames[ch][partner])){check_error=337;return false;}
 finisher_overlay_pack=pack;finisher_overlay_data=dst;finisher_overlay_character=ch;finisher_overlay_partner=partner;finisher_overlay_kind=3;
 roster_pack_cache_reset(&roster_texture_cache);return true;
}
static void bitmap_palette(unsigned bank){
 const vdp2_scrn_bitmap_format_t f={.scroll_screen=VDP2_SCRN_NBG0,.ccc=VDP2_SCRN_CCC_PALETTE_256,.bitmap_size=VDP2_SCRN_BITMAP_SIZE_512X512,.palette_base=RINGPAL_ADDR+bank*512,.bitmap_base=RING_ADDR};
 vdp2_scrn_bitmap_format_set(&f);
}
static void title_draw_frame(void){
 if(check_error)return;
 if(title_frame==0)memset(bitmap,0,262144);
 const intro_asset_t *a=&title_frames[title_frame];
 if(a->offset>TITLE_BYTES||a->size>TITLE_BYTES-a->offset||!lz4_unpack((uint8_t *)LWRAM(a->offset),a->size,title_delta,77312)){check_error=310;return;}
 for(unsigned y=0;y<240;y++){
  uint32_t *dst=(uint32_t *)(bitmap+y*512);const uint32_t *src=(const uint32_t *)(title_delta+y*320);
  for(unsigned x=0;x<80;x++)dst[x]^=src[x];
 }
 title_page^=1;transfer((void *)(RING_ADDR+title_page*131072),bitmap,INTRO_BITMAP_BYTES);transfer((void *)(RINGPAL_ADDR+title_page*512),title_delta+76800,512);bitmap_palette(title_page);
 if(++title_frame==TITLE_COUNT)title_frame=0;
}
static void presentation_load(void);
static unsigned campaign_roll(void){
 /* The original weighted selector is exact in campaign_select_opponents(); the
  * arcade RNG core itself is not yet ported. Keep this source isolated so a
  * later ROM-exact $21B4 replacement cannot change campaign semantics. */
 campaign_rng^=campaign_rng<<13;campaign_rng^=campaign_rng>>17;campaign_rng^=campaign_rng<<5;
 return campaign_rng%100U+1U;
}
static void campaign_begin(void){
 if(campaign_ready||intro.demo)return;campaign_presentation_reset(&campaign_present);
 campaign_reset(&campaign,session.mode?CAMPAIGN_TAG:CAMPAIGN_RUMBLE,5,0,ARCADE_DIFFICULTY_NORMAL);
 if(session.mode)campaign_set_players(&campaign,session.selected[0],session.selected[1]);
 campaign_rng^=(uint32_t)video_clock+(session.selected[0]<<8)+(session.selected[1]<<16);
 campaign_ready=true;
}
static void native_match_start(bool reroll){
 if(intro.demo||!campaign_ready){
  if(session.mode)game_match_start(&game,GAME_TAG,session.characters);else game_match_start_rumble_queue(&game,session.characters,10);
  wf_audio_observer_reset(&audio_observer,game.stage_index);return;
 }
 if(reroll)campaign_start_game(&campaign,&game,session.characters,campaign_roll(),campaign_roll());
 else campaign_restart_game(&campaign,&game,session.characters);
 /* RECOVERED_ROM bindings are keyed by the current arcade stage index. */
 wf_audio_observer_reset(&audio_observer,game.stage_index);
}
static void loading_begin(unsigned kind,unsigned target_phase){
 loading=(loading_state_t){.kind=kind,.target_phase=target_phase};
 /* Render one complete static LOADING frame before any blocking CD access. */
}
static bool loading_step(void){
 if(loading.kind==LOAD_NONE)return false;if(!loading.shown){loading.shown=1;return false;}
 if(loading.kind==LOAD_BOOT){
  /* Test240: do not retain SELECT/MODE/ENTRY caches during the title.
   * They are loaded on demand after title_delta is released. This removes the
   * heap pressure that produced CHECK 312 on real Saturn. */
  if(loading.stage++==0){
   unsigned n=cd_read("TITLE.ANM",(void *)LWRAM(0),1048576);
   if(n!=TITLE_BYTES||hash_ram((uint8_t *)LWRAM(0),TITLE_BYTES)!=TITLE_HASH){check_error=311;return false;}
   title_lwram_cached=true;return false;
  }
  loading.kind=LOAD_NONE;presentation_load();last_video=video_clock;return true;
 }
 /* Short per-match load remains functional: actual match selection and roster
  * reads happen while the static LOADING frame is already visible. */
 if(loading.stage++==0){campaign_begin();native_match_start(true);roster_load();return false;}
 loading.kind=LOAD_NONE;presentation_load();last_video=video_clock;return true;
}
static void presentation_transition(void){
 if((session.phase==SESSION_HALL||session.phase==SESSION_ANNOUNCE)&&!loaded_roster&&!intro.demo){loading_begin(LOAD_MATCH,session.phase);return;}
 presentation_load();
}
static void presentation_load(void){
 if(check_error)return;
 layer_view=VIEW_ALL;
 presentation_phase=0;
 vdp2_tvmd_display_clear();vdp2_sync();vdp2_sync_wait();bitmap_palette(0);
 if(campaign_present.screen!=CAMPAIGN_PRESENT_NONE){
  memset(bitmap,0,INTRO_BITMAP_BYTES);transfer((void *)RING_ADDR,bitmap,INTRO_BITMAP_BYTES);
  if(campaign_present.screen==CAMPAIGN_PRESENT_PROGRESS)campaign_progress_roster_load();
  else {free(overflow_character);overflow_character=NULL;loaded_roster=false;memset(character_data,0,sizeof(character_data));}
  last_video=video_clock;return;
 }
 if(in_intro()){
  if(intro.screen==INTRO_TITLE){
   if(!title_lwram_cached){if(TITLE_BYTES>1048576||cd_read("TITLE.ANM",(void *)LWRAM(0),1048576)!=TITLE_BYTES||hash_ram((uint8_t *)LWRAM(0),TITLE_BYTES)!=TITLE_HASH){check_error=311;return;}}
   title_lwram_cached=false;title_delta=malloc(77312);if(!title_delta){check_error=312;return;}title_frame=0;title_phase=0;title_page=0;title_draw_frame();
  }else{
   const intro_asset_t *a=&intro_assets[intro.screen];
   if(!intro_unpack(asset_intro+a->offset,a->size,bitmap,INTRO_BITMAP_BYTES)||hash_ram(bitmap,INTRO_BITMAP_BYTES)!=a->bitmap_hash){check_error=313;return;}
   transfer((void *)RING_ADDR,bitmap,INTRO_BITMAP_BYTES);transfer((void *)RINGPAL_ADDR,asset_intro+a->palette_offset,512);
  }
  return;
 }
 free(title_delta);title_delta=NULL;
 if(session.phase==SESSION_MODE){
  /* Test224: keep boot-preloaded selection pages resident through MODE. */
  free(overflow_character);overflow_character=NULL;loaded_roster=false;memset(character_data,0,sizeof(character_data));
  if(mode_cache_ensure()){
   if(!intro_unpack(mode_rle_cache,mode_rle_size,bitmap,INTRO_BITMAP_BYTES))check_error=305;
   if(!check_error){transfer((void *)RING_ADDR,bitmap,INTRO_BITMAP_BYTES);transfer((void *)RINGPAL_ADDR,mode_pal_cache,512);}
  }
 }
 else if(session.phase==SESSION_SELECT||session.phase==SESSION_CPU){selection_cache_show(session_page(&session));selection_signature=~0U;}
 else if(session.phase==SESSION_HALL){
  campaign_begin();if(!loaded_roster){native_match_start(true);roster_load();}
  if(!entry_cache_ensure()||!intro_unpack(entry_rle_cache,entry_rle_size,bitmap,INTRO_BITMAP_BYTES))check_error=315;
  transfer((void *)RING_ADDR,bitmap,INTRO_BITMAP_BYTES);transfer((void *)RINGPAL_ADDR,asset_entrypal,512);
  transfer((void *)(VDP2_CRAM_MODE_1_OFFSET(0,0,0)+1792*2),asset_entryuipal,64);
 }else if(session.phase==SESSION_RING||session.phase==SESSION_ANNOUNCE){
  transfer((void *)(VDP2_CRAM_MODE_1_OFFSET(0,0,0)+1792*2),asset_logospal,480);
  if(!loaded_roster){native_match_start(true);roster_load();}
  if(cd_read("RING.BIN",bitmap,262144)!=RING_BYTES){check_error=316;return;}transfer((void *)RING_ADDR,bitmap,RING_BYTES);
  uint8_t *p=malloc(2048);if(!p){check_error=317;return;}if(cd_read("RING.PAL",p,2048)==512)transfer((void *)RINGPAL_ADDR,p,512);free(p);game.camera_x=-34;game.camera_y=20;
 }else {phase=0;pending=0;match_flow_reset(&match_flow,session.previous);}
 last_video=video_clock;
}
static void rectangle(vdp1_cmdt_t *cmd,int x0,int x1,int y0,int y1,uint16_t color){
 const vdp1_cmdt_draw_mode_t mode={.pre_clipping_disable=true,.trans_pixel_disable=true,.end_code_disable=true};
 const int16_vec2_t pts[4]={INT16_VEC2_INITIALIZER(x0,y0),INT16_VEC2_INITIALIZER(x1,y0),INT16_VEC2_INITIALIZER(x1,y1),INT16_VEC2_INITIALIZER(x0,y1)};
 vdp1_cmdt_polygon_set(cmd);vdp1_cmdt_draw_mode_set(cmd,mode);cmd->cmd_colr=color;vdp1_cmdt_vtx_set(cmd,pts);
}
static void border(vdp1_cmdt_t *list,unsigned *n,int x,int y,int w,int h,uint16_t color){rectangle(&list[(*n)++],x,x+w,y,y+1,color);rectangle(&list[(*n)++],x,x+w,y+h-1,y+h,color);rectangle(&list[(*n)++],x,x+1,y,y+h,color);rectangle(&list[(*n)++],x+w-1,x+w,y,y+h,color);}
static void sprite(vdp1_cmdt_t *cmd,unsigned offset,unsigned palette,int x,int y,unsigned flip,bool eight,bool opaque){
 const vdp1_cmdt_draw_mode_t mode={.color_mode=eight?4:0,.trans_pixel_disable=opaque,.pre_clipping_disable=true,.end_code_disable=true};
 const vdp1_cmdt_color_bank_t bank={.type_0.dc=palette};
 vdp1_cmdt_normal_sprite_set(cmd);vdp1_cmdt_draw_mode_set(cmd,mode);
 if(eight)vdp1_cmdt_color_mode4_set(cmd,bank);else vdp1_cmdt_color_mode0_set(cmd,bank);
 vdp1_cmdt_char_size_set(cmd,16,16);vdp1_cmdt_char_base_set(cmd,(vdp1_vram_t)partitions.texture_base+offset);vdp1_cmdt_char_flip_set(cmd,(vdp1_cmdt_char_flip_t)(flip<<4));cmd->cmd_xa=x;cmd->cmd_ya=y;
}
static void put_piece(vdp1_cmdt_t *cmd,const piece_t *p,int x,int y,bool mirror){sprite(cmd,p->tile*128,512+p->pal*16,x+(mirror?-p->x-16:p->x),y+p->y,p->flip^(mirror?1:0),false,false);}
static unsigned dynamic_tile_pack(unsigned key,const roster_pack_t *pack,unsigned tile){
 unsigned bucket=(tile*33U+key*101U)&1023;
 while(cache_hash[bucket]){unsigned i=cache_hash[bucket]-1;if(cache_char[i]==key&&cache_tile[i]==tile)return i*128;bucket=(bucket+1)&1023;}
 if(cache_count>=512){check_error=320;return 0;}
 if(!pack||tile>=pack->tiles){check_error=321;return 0;}
 unsigned slot=cache_count;
 if(!roster_pack_tile(pack,tile,dynamic_data+slot*128,&roster_texture_cache)){check_error=334;return 0;}
 ++cache_count;cache_char[slot]=key;cache_tile[slot]=tile;cache_hash[bucket]=slot+1;return slot*128;
}
static unsigned actor_count(unsigned ch,unsigned frame){if(!character_data[ch]||frame>=ROSTER_FRAMES)return 0;const uint16_t *ix=(const uint16_t *)(character_data[ch]+32);return ix[frame*2+1];}
static void pack_actor_part(vdp1_cmdt_t *list,unsigned *n,const roster_pack_t *pack,unsigned source_key,unsigned palette_ch,unsigned frame,int x,int y,bool mirror,unsigned first,unsigned end){
 if(!pack||!pack->data||frame>=pack->frames){check_error=322;return;}
 const uint16_t *ix=(const uint16_t *)(pack->data+32);unsigned count=ix[frame*2+1];if(end>count)end=count;
 const uint16_t *rec=(const uint16_t *)(pack->data+32+pack->frames*4+ix[frame*2]*8);
 for(unsigned i=first;i<end;i++){
  unsigned tile=rec[i*4],flip=rec[i*4+3];int px=(int16_t)rec[i*4+1],py=(int16_t)rec[i*4+2];px=x+(mirror?-px-16:px);py+=y;
  if(px>=320||px+16<=0||py>=240||py+16<=0)continue;
  if(*n>=CMD_CAPACITY-160){check_error=323;return;}
  sprite(&list[(*n)++],DYNAMIC_TEXTURE_OFFSET+dynamic_tile_pack(source_key,pack,tile),256+palette_ch*16,px,py,flip^(mirror?1:0),false,false);
 }
}
static void actor_part(vdp1_cmdt_t *list,unsigned *n,unsigned ch,unsigned frame,int x,int y,bool mirror,unsigned first,unsigned end){
 if(!loaded_roster||!character_data[ch]){check_error=322;return;}
 pack_actor_part(list,n,&character_packs[ch],ch,ch,frame,x,y,mirror,first,end);
}
static void actor(vdp1_cmdt_t *list,unsigned *n,unsigned ch,unsigned frame,int x,int y,bool mirror){actor_part(list,n,ch,frame,x,y,mirror,0,65535);}
static bool object_composition_draw(vdp1_cmdt_t *list,unsigned *n,unsigned which){
 const fighter_t *f=&game.fighters[which];int raw=game_arcade_pose(f);if(raw<0)return false;
 unsigned frame=object_asset_frame(f->character,(unsigned)raw&0x7fffU);if(frame==0xffffU)return false;
 if(!object_pack_data||!object_pack.data){check_error=339;return true;}
 unsigned run_count=0;const object_run_t *runs=object_asset_runs(frame,&run_count);if(!runs||!run_count){check_error=341;return true;}
 int draw_x=f->x/256,draw_y=f->y/256;game_fighter_draw_position(&game,which,&draw_x,&draw_y);
 bool mirror=(f->facing<0)^(((unsigned)raw&0x8000U)!=0);unsigned pos=0;
 for(unsigned i=0;i<run_count;i++){unsigned first=pos,end=first+runs[i].count;pos=end;
  pack_actor_part(list,n,&object_pack,31U,runs[i].palette,frame,draw_x-game.camera_x,draw_y-game.camera_y-game_fighter_lift(f),mirror,first,end);
  if(check_error)return true;
 }
 return true;
}
static bool ring_transition_composition_draw(vdp1_cmdt_t *list,unsigned *n,unsigned which){
 const fighter_t *f=&game.fighters[which];int raw=game_arcade_pose(f);if(raw<0)return false;
 unsigned frame=ring_transition_asset_frame(f->character,(unsigned)raw&0x7fffU);if(frame==0xffffU)return false;
 if(!ring_transition_pack_data||!ring_transition_pack.data){check_error=342;return true;}
 unsigned run_count=0;const ring_transition_run_t *runs=ring_transition_asset_runs(frame,&run_count);if(!runs||!run_count){check_error=344;return true;}
 int draw_x=f->x/256,draw_y=f->y/256;game_fighter_draw_position(&game,which,&draw_x,&draw_y);
 bool mirror=(f->facing<0)^(((unsigned)raw&0x8000U)!=0);unsigned pos=0;
 for(unsigned i=0;i<run_count;i++){unsigned first=pos,end=first+runs[i].count;pos=end;
  pack_actor_part(list,n,&ring_transition_pack,30U,runs[i].palette,frame,draw_x-game.camera_x,draw_y-game.camera_y-game_fighter_lift(f),mirror,first,end);
  if(check_error)return true;
 }
 return true;
}
static void finisher_overlay_part(vdp1_cmdt_t *list,unsigned *n,unsigned palette_ch,unsigned frame,int x,int y,bool mirror,unsigned first,unsigned end){
 if(finisher_overlay_character>=10||!finisher_overlay_data){check_error=338;return;}
 pack_actor_part(list,n,&finisher_overlay_pack,10+finisher_overlay_character,palette_ch,frame,x,y,mirror,first,end);
}
static void arcade_text(vdp1_cmdt_t *list,unsigned *n,const char *s,int x,int y){
 for(;*s&&x<320;s++,x+=8){unsigned c=(uint8_t)*s;if(c<32||c>=128)c='?';if(c==' '||x+8<=0)continue;
  if(*n>=CMD_CAPACITY-1){check_error=325;return;}
  sprite(&list[*n],UI_TEXTURE_OFFSET+UI_FONT_OFFSET+(c-32)*64,896,x,y,0,false,false);
  vdp1_cmdt_char_size_set(&list[(*n)++],8,16);
 }
}
static void timer_draw(vdp1_cmdt_t *list,unsigned *n){
 unsigned minutes=game.time_left/60,seconds=game.time_left%60;
 unsigned glyphs[11]={0,1,2,3,4,5,6+(minutes/10)%10,6+minutes%10,16,6+seconds/10,6+seconds%10};
 for(unsigned i=0;i<11;i++){
  sprite(&list[*n],UI_TEXTURE_OFFSET+UI_TIMER_OFFSET+glyphs[i]*64,912,8+i*8,224,0,false,false);
  vdp1_cmdt_char_size_set(&list[(*n)++],8,16);
 }
}
static void match_flow_draw(vdp1_cmdt_t *list,unsigned *n){
 if(!playing()||intro.demo||match_flow.phase==FLOW_PLAY)return;
 if(match_flow.phase==FLOW_RESULT){
  /* Test143: keep the post-match ring/staging visible.  Test100 used a large
   * opaque centre plate that hid the wrestlers exactly when the arcade keeps
   * celebrating/defeated actors on screen.  Layout remains provisional. */
  rectangle(&list[(*n)++],48,271,8,55,0x8000);
  const match_result_t *r=match_history_recent(&match_history,0);
  const char *reason=r?match_result_reason(r):"RESULT";
  arcade_text(list,n,match_flow.draw?reason:match_flow.winner==0?"YOU WIN":"YOU LOSE",112,12);
  if(r&&!match_flow.draw&&r->winner>=0&&r->winner<2){
   unsigned ch=r->fighters[r->winner].character;
   if(ch<10){const char *name=roster_names[ch];arcade_text(list,n,name,(320-(int)strlen(name)*8)/2,32);}
  }
 }else if(match_flow.phase==FLOW_CONTINUE){
  rectangle(&list[(*n)++],32,287,88,187,0x8000);
  char seconds[4];sprintf(seconds,"%u",match_flow_seconds(&match_flow));
  arcade_text(list,n,"CONTINUE?",120,100);arcade_text(list,n,seconds,152,120);
  arcade_text(list,n,"START: YES  B: NO",96,144);
 }else arcade_text(list,n,"GAME OVER",120,120);
}
static void hud_draw(vdp1_cmdt_t *list,unsigned *n){
 hud_initialized=true;
 hud_slot_t slots[4]={0};hud_cell_t cells[160];
 /* Test100 hardware comparison: TAG needs all four wrestler panels, including
  * reserve stamina. Rumble/single-player keeps P1 plus cabinet BUY-IN slots. */
 if(game.mode==GAME_TAG&&game.roster_count>=4){
  unsigned ch[4],hp[4];for(unsigned i=0;i<4;i++){ch[i]=game.fighters[i].character;hp[i]=game.fighters[i].display_health;}
  hud_tag_slots(ch,hp,slots);
 }else{
  const fighter_t *f=&game.fighters[0];
  slots[0]=(hud_slot_t){.character=f->character,.health=f->display_health,.player=0,.status=HUD_ACTIVE,.message=HUD_BUTTON};
  for(unsigned slot=1;slot<4;slot++)slots[slot]=(hud_slot_t){.player=slot,.status=HUD_JOIN};
 }
 hud_map(slots,cells);hud_pixels(cells,hud_buffer);
 transfer((void *)((uintptr_t)partitions.texture_base+HUD_TEXTURE_OFFSET),hud_buffer,HUD_BYTES);
 sprite(&list[*n],HUD_TEXTURE_OFFSET,0,0,0,0,true,false);vdp1_cmdt_char_size_set(&list[(*n)++],HUD_WIDTH,HUD_HEIGHT);
 timer_draw(list,n);if(intro.demo)arcade_text(list,n,"DEMO",256,224);
}
static void draw_fighter(vdp1_cmdt_t *list,unsigned *n,unsigned which){
 const fighter_t *f=&game.fighters[which];
 /* Test238: partner-dependent ground compositions are drawn once, anchored on
  * the attacker.  Suppress the separately scheduled victim while the exact
  * Fxx overlay already contains that role, avoiding a duplicate wrestler. */
 if(which<2){
  unsigned other=1U-which;const fighter_t *a=&game.fighters[other];
  if(a->state==ST_GROUND_ATTACK||a->state==ST_GROUND_PICKUP){int raw=game_arcade_pose(a);
   if(raw>=0&&ground_pair_asset_available(a->character,f->character,(unsigned)raw&0x7fffU))return;
  }
 }
 /* Test221: once a resolved TAG winner has reached the centre staging point,
  * animate it with existing recovered presentation gestures.  This is a
  * PROVISIONAL visual bridge, not a claim that raw 89-93 are the arcade clap. */
 if(game.mode==GAME_TAG&&game_postmatch_active(&game)&&game_postmatch_role(&game,which)>0&&f->state==ST_IDLE){
  unsigned raw=postmatch_winner_pose(f->character,game.postmatch_tick);
  unsigned frame=roster_arcade_frame(raw);
  if(frame<ROSTER_FRAMES){int dx=f->x/256,dy=f->y/256;game_fighter_draw_position(&game,which,&dx,&dy);actor(list,n,f->character,frame,dx-game.camera_x,dy-game.camera_y,f->facing<0);return;}
 }
 if((f->state==ST_RING_THROW||f->state==ST_RING_EXIT||f->state==ST_RING_ENTER||f->state==ST_TOSSED||(f->outside&&f->state==ST_RECOVER&&f->throw_recovery))&&ring_transition_composition_draw(list,n,which))return;
 if((f->state==ST_OBJECT_PICKUP||f->state==ST_OBJECT_USE)&&object_composition_draw(list,n,which))return;
 if((f->state==ST_GROUND_ATTACK||f->state==ST_GROUND_PICKUP)&&which<2){
  int raw=game_arcade_pose(f);unsigned partner=game.fighters[1U-which].character;
  unsigned frame=raw<0?0xffffU:ground_pair_asset_frame(f->character,partner,(unsigned)raw&0x7fffU);
  if(frame!=0xffffU){
   unsigned run_count=0,pos[2]={0,0};const finisher_run_t *runs=ground_pair_asset_runs(f->character,partner,frame,&run_count);
   if(finisher_overlay_kind!=2||finisher_overlay_character!=f->character||finisher_overlay_partner!=partner||!run_count){check_error=338;return;}
   for(unsigned i=0;i<run_count;i++){unsigned role=runs[i].role,ch=role?partner:f->character,first=pos[role],end=first+runs[i].count;pos[role]=end;
    finisher_overlay_part(list,n,ch,frame,f->x/256-game.camera_x,f->y/256-game.camera_y,f->facing<0,first,end);
   }
   return;
  }
 }
 if(f->state==ST_FINISHER){
  unsigned frame=finisher_asset_frame(f->character,game.fighters[1-which].character,f->finisher_phase);
  if(finisher_overlay_kind!=1||finisher_overlay_character!=f->character||frame==0xffffU){check_error=338;return;}
  finisher_overlay_part(list,n,f->character,frame,f->x/256-game.camera_x,f->y/256-game.camera_y,f->facing<0,0,65535);return;
 }
 render_pose_t p=render_fighter_pose(f);if(p.frame>=ROSTER_FRAMES){check_error=324;return;}
 int draw_x=f->x/256,draw_y=f->y/256;game_fighter_draw_position(&game,which,&draw_x,&draw_y);
 actor(list,n,f->character,p.frame,draw_x-game.camera_x,draw_y-game.camera_y-p.lift,p.mirror);
}
static void draw_ref(vdp1_cmdt_t *list,unsigned *n){const referee_t *r=&game.referee;const frame_t *f=&frames[clips[5].first+game_referee_pose(&game)];for(unsigned i=0;i<f->count;i++)put_piece(&list[(*n)++],&pieces[f->first+i],r->x/256-game.camera_x,r->y/256-game.camera_y,r->facing<0);}
static void draw_pair(vdp1_cmdt_t *list,unsigned *n){
 if(game.pair==PAIR_FINISHER){
  unsigned attacker=game.pair_attacker,victim=1-attacker,finisher_phase=game_finisher_phase(&game);
  unsigned ach=game.fighters[attacker].character,vch=game.fighters[victim].character;
  unsigned frame=finisher_asset_frame(ach,vch,finisher_phase),run_count=0,pos[2]={0,0};
  if(finisher_overlay_kind!=1||finisher_overlay_character!=ach||frame==0xffffU){check_error=338;return;}
  const finisher_run_t *runs=finisher_asset_runs(ach,frame,&run_count);
  const fighter_t *a=&game.fighters[attacker];bool victim_drawn=false;
  for(unsigned i=0;i<run_count;i++){
   unsigned role=runs[i].role,ch=role?vch:ach,first=pos[role],end=first+runs[i].count;pos[role]=end;
   finisher_overlay_part(list,n,ch,frame,a->x/256-game.camera_x,a->y/256-game.camera_y,game_pair_facing(&game)<0,first,end);
   if(role)victim_drawn=true;
  }
  /* Boss Man's anticipation and the post-impact DDT/Boss recovery frames are
   * attacker-only in the arcade descriptor. Keep the victim's current native
   * run/prone pose visible until a paired composition takes over. */
  if(!victim_drawn)draw_fighter(list,n,victim);
  return;
 }
 if(game.pair==PAIR_STRUGGLE){
  int raw=game_pair_struggle_raw_pose(&game);
  if(raw>=0){
   unsigned attacker=game_pair_struggle_action_side(&game),partner=1U-attacker;
   unsigned ach=game.fighters[attacker].character,pch=game.fighters[partner].character;
   unsigned frame=struggle_pair_asset_frame(ach,pch,(unsigned)raw&0x7fffU),run_count=0,pos[2]={0,0};
   const finisher_run_t *runs=struggle_pair_asset_runs(ach,pch,frame,&run_count);
   if(finisher_overlay_kind!=3||finisher_overlay_character!=ach||finisher_overlay_partner!=pch||frame==0xffffU||!runs){check_error=338;return;}
   const fighter_t *a=&game.fighters[attacker];
   for(unsigned i=0;i<run_count;i++){unsigned role=runs[i].role,ch=role?pch:ach,first=pos[role],end=first+runs[i].count;pos[role]=end;
    finisher_overlay_part(list,n,ch,frame,a->x/256-game.camera_x,a->y/256-game.camera_y,a->facing<0,first,end);
   }
   return;
  }
 }
 unsigned clip=game_pair_clip(&game),pose=game_pair_pose(&game),pos[2]={0,0},total[2]={0,0};
 const fighter_t *a=&game.fighters[game_pair_anchor(&game)];const pair_run_t *runs=pair_runs[clip-2][pose];
 int struggle_dx=game_pair_struggle_offset(&game);
 for(unsigned i=0;i<8&&runs[i].count;i++)total[runs[i].role]+=runs[i].count;
 for(unsigned i=0;i<8&&runs[i].count;i++){
  unsigned role=runs[i].role,ch=game.fighters[game_pair_fighter(&game,role)].character,frame=roster_parts[clip][pose][role],count=actor_count(ch,frame);
  unsigned start=pos[role]*count/total[role];pos[role]+=runs[i].count;
  actor_part(list,n,ch,frame,a->x/256-game.camera_x+struggle_dx,a->y/256-game.camera_y,game_pair_facing(&game)<0,start,pos[role]*count/total[role]);
 }
}
static void ropes(vdp1_cmdt_t *list,unsigned *n,unsigned first,unsigned end){for(unsigned i=first;i<end;i++){int deflect=game_rope_deflection(&game,foreground[i].x,foreground[i].y);int x=foreground[i].x-game.camera_x,y=foreground[i].y+deflect-game.camera_y;if(x<320&&x+16>0&&y<240&&y+16>0)put_piece(&list[(*n)++],&foreground[i],-game.camera_x,-game.camera_y+deflect,false);}}
static void crowd_draw(vdp1_cmdt_t *list,unsigned *n,bool entry){
 unsigned tick=entry?session.tick:game.ticks,crowd_phase=(tick/8)%3,count=entry?ENTRY_CROWD_COUNT:CROWD_COUNT;const piece_t *p=entry?entry_crowds[crowd_phase]:crowds[crowd_phase];
 for(unsigned i=0;i<count;i++){int x=p[i].x-(entry?0:game.camera_x),y=p[i].y-(entry?0:game.camera_y);if(x<320&&x+16>0&&y<240&&y+16>0)sprite(&list[(*n)++],p[i].tile*128,entry?1536:512+p[i].pal*16,x,y,p[i].flip,entry,true);}
}
static void logo_draw(vdp1_cmdt_t *list,unsigned *n,unsigned ch,int x,int y){
 for(unsigned i=0;i<logo_sizes[ch];i++){const piece_t *p=&logos[ch][i];sprite(&list[(*n)++],p->tile*128,1792,x+p->x,y+p->y,0,true,false);}
}
static void announce_scene(vdp1_cmdt_t *list,unsigned *n){
 game.ticks=session.tick;
 unsigned pose=session_tag_presenter_pose(&session);
 crowd_draw(list,n,false);ropes(list,n,0,SIDE_ROPE_COUNT);
 if(game.mode==GAME_TAG){
  unsigned current=session_tag_announce_wrestler(&session),local=session_tag_announce_local_tick(&session);
  for(unsigned draw=0;draw<4;draw++){unsigned i=tag_announce_fighter(draw),ch=game.fighters[i].character;
   unsigned gesture=(current<4&&i==hud_fighter(current))?presentation_pose(ch,local):0;
   actor(list,n,ch,roster_arcade_frame(gesture),tag_announce_x(i),tag_announce_y(i),i%2);
  }
 }else for(unsigned i=0;i<game.roster_count;i++){unsigned ch=game.fighters[i].character;unsigned gesture=presentation_pose(ch,session.tick);actor(list,n,ch,roster_arcade_frame(gesture),rumble_announce_x(i),rumble_announce_y(i),i%2);}
 int presenter_y=session_tag_presenter_y(&session);
 for(unsigned i=0;i<presenter_sizes[pose];i++){const piece_t *p=&presenters[pose][i];sprite(&list[(*n)++],p->tile*128,864,160+p->x,presenter_y+p->y,p->flip,false,false);}
 ropes(list,n,SIDE_ROPE_COUNT,FRONT_COUNT);
 /* Test222: character-logo plates belong to the TAG presentation path.  The
  * previous Royal branch drew two unrelated logos over a six-wrestler scene. */
 if(game.mode==GAME_TAG)for(unsigned slot=0;slot<4;slot++){unsigned who=hud_fighter(slot);logo_draw(list,n,game.fighters[who].character,(slot%2)*160,slot/2*144-8);}
}
static void ring_scene(vdp1_cmdt_t *list,unsigned *n){
 if(layer_view_crowd(layer_view))crowd_draw(list,n,false);
 if(session.phase==SESSION_RING){
  ropes(list,n,0,SIDE_ROPE_COUNT);
  ropes(list,n,SIDE_ROPE_COUNT,FRONT_COUNT);game.ticks=session.tick;
  unsigned t=session.tick;for(unsigned i=0;i<game.roster_count;i++){
   fighter_t *f=&game.fighters[i];int dest=game.mode==GAME_RUMBLE?rumble_intro_x(i):35+(int)(i%4)*60;int final_y=game.mode==GAME_RUMBLE?rumble_intro_y(i):203;
   f->x=dest*256;f->y=(int)(t<120?312-(312-final_y)*t/240:312-(312-final_y)*t/240)*256;f->facing=i%2?-1:1;
   if(t<120)actor(list,n,f->character,EXTRA_FIRST+4+((119-t)/18)%7,dest-game.camera_x,f->y/256-game.camera_y,i%2);
   else actor(list,n,f->character,roster_parts[0][1+(t/10)%4][0],dest-game.camera_x,f->y/256-game.camera_y,i%2);
  }return;
 }
 unsigned order[GAME_DRAW_CAPACITY],count=game_render_plan(&game,order);
 for(unsigned i=0;i<count;i++){
  unsigned object=order[i];if(!layer_view_object(layer_view,object))continue;
  int fighter=game_draw_fighter(object);
  if(fighter>=0)draw_fighter(list,n,(unsigned)fighter);
  else if(object==DRAW_SIDE_ROPES)ropes(list,n,0,SIDE_ROPE_COUNT);
  else if(object==DRAW_FRONT_ROPES)ropes(list,n,SIDE_ROPE_COUNT,FRONT_COUNT);
  else if(object==DRAW_PAIR)draw_pair(list,n);
  else if(object==DRAW_REFEREE)draw_ref(list,n);
  else if(object==DRAW_PROMPT){const frame_t *f=&frames[clips[6].first+game_escape_prompt_pose(&game)];int py=game_recovery_prompt_visible(&game)?game.fighters[0].rise_y/256-game.camera_y-54:106;for(unsigned p=0;p<f->count;p++)put_piece(&list[(*n)++],&pieces[f->first+p],game_escape_prompt_x(&game),py,false);}
 }
 unsigned pin=game_pin_indicator(&game);
 if(pin){char count[2]={(char)('0'+pin),0};arcade_text(list,n,count,game.referee.x/256-game.camera_x-4,game.referee.y/256-game.camera_y-42);}
 if(game_player_marker_visible(&game)){int mx=game.fighters[0].x/256-game.camera_x-10,my=game.fighters[0].y/256-game.camera_y-58;rectangle(&list[(*n)++],mx,mx+22,my,my+15,0x83e0);arcade_text(list,n,"1P",mx+3,my);}
 if(game_rumble_announcement_visible(&game)){
  unsigned ch=game_rumble_announced_character(&game);
  if(ch<10){
   const char *name=roster_names[ch];
   rectangle(&list[(*n)++],72,247,20,72,0x8000);
   border(list,n,72,20,175,52,0x83e0);
   arcade_text(list,n,"NEW CHALLENGER",rumble_announce_label_x(),rumble_announce_label_y());
   arcade_text(list,n,name,rumble_announce_name_x((unsigned)strlen(name)),rumble_announce_name_y());
  }
 }
}
static void campaign_progress_scene(vdp1_cmdt_t *list,unsigned *n){
 /* PROVISIONAL presentation geometry/art choreography.  The campaign stage,
    match count and character identities are native runtime facts; exact arcade
    interstitial composition/timing still awaits direct capture/ROM recovery. */
 unsigned t=campaign_present.tick,remaining=campaign_matches_remaining(&campaign);
 arcade_text(list,n,"TAG TOURNAMENT",104,18);
 char line[32];snprintf(line,sizeof(line),"MATCHES REMAINING %u",remaining);arcade_text(list,n,line,80,42);
 arcade_text(list,n,"HULK HOGAN",24,72);arcade_text(list,n,"DEMOLITION",208,72);
 unsigned hp=roster_arcade_frame(presentation_pose(0,t%120));
 unsigned dp=roster_arcade_frame(((t/12)&1)?89:90);
 if(hp<ROSTER_FRAMES)actor(list,n,0,hp,76,188,false);
 if(dp<ROSTER_FRAMES)actor(list,n,4,dp,242,188,true);
 /* Functional ten-match ladder. Completed boxes are filled; the next match
    pulses, making progression readable even before exact arcade artwork lands. */
 for(unsigned i=0;i<10;i++){
  int x=25+(int)i*27,y=116;uint16_t c=i<campaign.wins?0x83e0:0x8421;
  if(i==campaign.wins&&!campaign.complete&&((t/15)&1))c=0xffff;
  border(list,n,x,y,19,22,c);char d[3];snprintf(d,sizeof(d),"%u",i+1);arcade_text(list,n,d,x+(i==9?1:5),y+3);
 }
 arcade_text(list,n,"NEXT MATCH",120,154);
}
static void records_scene(vdp1_cmdt_t *list,unsigned *n){
 /* Test219 first functional Records surface.  Data are real RAM match-history
    records; typography/ranking/persistence remain PROVISIONAL until the arcade
    record table and Saturn save format are recovered. */
 arcade_text(list,n,"RECORDS",132,16);
 arcade_text(list,n,"REC  WRESTLER       RESULT",36,42);
 unsigned rows=match_history.count<8?match_history.count:8;
 for(unsigned i=0;i<rows;i++){
  const match_result_t *r=match_history_recent(&match_history,i);if(!r)continue;
  unsigned ch=0;if(r->winner>=0&&(unsigned)r->winner<r->roster_count)ch=r->fighters[r->winner].character;
  const char *name=ch<10?roster_names[ch]:"TEAM";char line[48];
  snprintf(line,sizeof(line),"%u   %-14.14s %-10.10s",i+1,name,match_result_reason(r));arcade_text(list,n,line,28,62+(int)i*19);
 }
 if(!rows)arcade_text(list,n,"NO RECORDS YET",104,90);
 arcade_text(list,n,"START: CONTINUE",96,220);
}
static void loading_scene(vdp1_cmdt_t *list,unsigned *n){
 /* Test240: intentionally static and minimal, per hardware feedback. */
 rectangle(&list[(*n)++],0,319,0,239,0x8000);
 arcade_text(list,n,"LOADING",132,116);
}
static void scene(void){
 vdp1_cmdt_t *list=cmds->cmdts;memset(list,0,sizeof(*list)*CMD_CAPACITY);cache_count=0;memset(cache_hash,0,sizeof(cache_hash));
 vdp1_cmdt_system_clip_coord_set(&list[0]);vdp1_cmdt_vtx_system_clip_coord_set(&list[0],INT16_VEC2(319,239));vdp1_cmdt_local_coord_set(&list[1]);vdp1_cmdt_vtx_local_coord_set(&list[1],INT16_VEC2(0,0));unsigned n=2;
 rectangle(&list[n++],0,319,0,239,0);
 if(!check_error&&loading.kind!=LOAD_NONE)loading_scene(list,&n);
 else if(!check_error&&campaign_present.screen==CAMPAIGN_PRESENT_PROGRESS)campaign_progress_scene(list,&n);
 else if(!check_error&&campaign_present.screen==CAMPAIGN_PRESENT_RECORDS)records_scene(list,&n);
 else if(!check_error&&in_intro()){
  if(intro_prompt_visible(&intro)){sprite(&list[n],TEXTURE_BYTES,848,116,intro.screen==INTRO_TITLE&&title_frame>310?168:224,0,false,false);vdp1_cmdt_char_size_set(&list[n++],88,8);}
 }else if(!check_error&&session.phase<=SESSION_CPU){
  unsigned glow=cursor_luminance(session.tick);
  MEMORY_WRITE(16,VDP2_CRAM_MODE_1_OFFSET(0,0,0)+(UI_PAL_INDEX+6)*2,0x8000|(glow<<5)|(glow/3));
  if(session.phase==SESSION_MODE){
   border(list,&n,session.mode?17:177,58,126,154,UI_PAL_INDEX+5);
   int x=session.mode?177:17;border(list,&n,x-1,57,128,156,UI_PAL_INDEX+1);border(list,&n,x+1,59,124,152,UI_PAL_INDEX+6);border(list,&n,x+2,60,122,150,UI_PAL_INDEX+6);
  }else{ui_rect_t r=roster_cursor_rect(session.phase==SESSION_CPU?session_cpu_cursor(&session):session.cursor);border(list,&n,r.x,r.y,r.w-1,r.h-1,UI_PAL_INDEX+6);border(list,&n,r.x+1,r.y+1,r.w-3,r.h-3,UI_PAL_INDEX+6);int spark=r.x+3+(session.tick*2)%(r.w-10);rectangle(&list[n++],spark,spark+5,r.y,r.y+1,UI_PAL_INDEX+1);}
 }else if(!check_error&&session.phase==SESSION_HALL){
  crowd_draw(list,&n,true);unsigned count=session.mode?2:1;
  /* Exact unscaled composition anchors found in arcade sprite RAM: 128/176,
     y213 at frame1000, +12 pixels after24 ticks. No per-pose recentering. */
  unsigned entry_tick=session.tick>24?session.tick-24:0;
  sprite(&list[n],ENTRY_TEXTURE_OFFSET+ENTRY_LIGHT_OFFSET,1792,100,167+(int)session.tick/2,0,true,false);vdp1_cmdt_char_size_set(&list[n++],120,48);
  for(unsigned i=0;i<count;i++){unsigned ch=session.selected[i];actor(list,&n,ch,ENTRY_FIRST+(entry_tick/12)%8,count==1?152:(i?128:176),201+(int)session.tick/2,false);}
  sprite(&list[n],ENTRY_TEXTURE_OFFSET,1792,0,176,0,true,false);vdp1_cmdt_char_size_set(&list[n++],320,56);
  arcade_text(list,&n,roster_names[session.selected[count-1]],16,184);
  if(session.mode)arcade_text(list,&n,roster_names[session.selected[0]],16,208);
 }else if(!check_error&&session.phase==SESSION_ANNOUNCE)announce_scene(list,&n);
 else if(!check_error)ring_scene(list,&n);
 if(loading.kind==LOAD_NONE&&campaign_present.screen==CAMPAIGN_PRESENT_NONE&&show_hud()&&!check_error&&layer_view==VIEW_ALL)hud_draw(list,&n);
 if(loading.kind==LOAD_NONE&&campaign_present.screen==CAMPAIGN_PRESENT_NONE&&!check_error)match_flow_draw(list,&n);
 assert(n<CMD_CAPACITY);vdp1_cmdt_end_set(&list[n++]);cmds->count=n;
}
static unsigned menu_buttons(void){unsigned b=0;if(pad.pressed.button.left)b|=MENU_LEFT;if(pad.pressed.button.right)b|=MENU_RIGHT;if(pad.pressed.button.up)b|=MENU_UP;if(pad.pressed.button.down)b|=MENU_DOWN;if(pad.pressed.button.a||pad.pressed.button.start)b|=MENU_OK;if(pad.pressed.button.b)b|=MENU_BACK;return b;}
static void input(void){
 if(intro.demo){unsigned steps=timing_steps(&phase,frame_intervals);while(steps--){unsigned b=autoplay_buttons(&game);game_tick(&game,b&15,b&~15U);wf_audio_observe_game(&audio_observer,&game,wf_audio_saturn_emit,NULL);if(game.pair==PAIR_STRUGGLE&&game_pair_struggle_raw_pose(&game)>=0){unsigned a=game_pair_struggle_action_side(&game),p=1U-a;struggle_pair_overlay_load(game.fighters[a].character,game.fighters[p].character);}}return;}
 if(campaign_present.screen!=CAMPAIGN_PRESENT_NONE){
  bool done=campaign_presentation_tick(&campaign_present,frame_intervals,pad.held.button.start||pad.held.button.a);
  if(!done)return;
  unsigned was=campaign_present.screen;campaign_presentation_reset(&campaign_present);
  free(overflow_character);overflow_character=NULL;loaded_roster=false;
  if(was==CAMPAIGN_PRESENT_PROGRESS){session.phase=SESSION_ANNOUNCE;session.tick=0;presentation_transition();return;}
  campaign_ready=false;intro_reset(&intro);intro.screen=INTRO_TITLE;presentation_load();return;
 }
 if(match_flow.phase==FLOW_PLAY&&game.finished)match_history_record(&match_history,&game);
 unsigned action=match_flow_tick(&match_flow,game.finished,game.winner,game.winner<0,menu_buttons(),frame_intervals);
 if(action==FLOW_RETRY){
  const match_result_t *r=match_history_recent(&match_history,0);if(r)match_result_retry_roster(r,session.characters);
  if(campaign_ready)campaign_restart_game(&campaign,&game,session.characters);else if(session.mode)game_match_start(&game,GAME_TAG,session.characters);else game_match_start_rumble_queue(&game,session.characters,10);
  wf_audio_observer_reset(&audio_observer,game.stage_index);
  session.phase=SESSION_ANNOUNCE;session.tick=0;presentation_transition();return;
 }
 if(action==FLOW_ADVANCE){
  bool more=campaign_ready?campaign_commit_win(&campaign,&game):false;
  if(campaign_ready&&session.mode){
   free(overflow_character);overflow_character=NULL;loaded_roster=false;
   if(more)campaign_presentation_begin_progress(&campaign_present);else campaign_presentation_begin_records(&campaign_present);
   presentation_load();return;
  }
  if(campaign_ready&&!more){free(overflow_character);overflow_character=NULL;loaded_roster=false;campaign_presentation_begin_records(&campaign_present);presentation_load();return;}
  free(overflow_character);overflow_character=NULL;loaded_roster=false;session.phase=SESSION_ANNOUNCE;session.tick=0;presentation_transition();return;
 }
 if(action==FLOW_TITLE){
  free(overflow_character);overflow_character=NULL;loaded_roster=false;
  if(campaign_ready){campaign_presentation_begin_records(&campaign_present);presentation_load();return;}
  intro_reset(&intro);intro.screen=INTRO_TITLE;presentation_load();return;
 }
 if(match_flow.phase!=FLOW_PLAY){referee_t *r=&game.referee;if(r->state==REF_FINISH&&r->tick<48)r->tick++;return;}
 if(pad.pressed.button.start&&pad.held.button.x){session_reset(&session,menu_buttons());session_entropy_mix(&session,video_clock);campaign_ready=false;loaded_roster=false;presentation_load();return;}
 if(pad.held.button.x){native_match_start(false);phase=0;pending=0;layer_view=VIEW_ALL;}
 if(pad.held.button.start){game.paused=!game.paused;pending=0;layer_view=VIEW_ALL;game.fighters[0].queued_attack=game.fighters[0].buffer_ticks=0;}
 if(pad.held.button.y)hud=!hud;if(game.paused){if(pad.held.button.c)layer_view=(layer_view+1)%VIEW_COUNT;pending=0;return;}
 /* Yaul names: pressed = current down state; held = new down edge.
    Keep edges pending until one logical tick consumes them, never repeat
    them on a second catch-up tick (including recovery effort). */
 if(pad.held.button.a)pending|=INPUT_PUNCH;if(pad.held.button.b)pending|=INPUT_KICK;if(pad.held.button.l)pending|=INPUT_GRAB;if(pad.held.button.z)pending|=INPUT_RING;if(pad.held.button.c)pending|=INPUT_TAG;
 unsigned held=menu_buttons()&15;
 if(!game.fighters[0].outside&&pad.pressed.button.a&&pad.pressed.button.b&&(held&(INPUT_LEFT|INPUT_RIGHT)))held|=INPUT_RUN;
 unsigned attack_down=(pad.pressed.button.a?INPUT_PUNCH:0)|(pad.pressed.button.b?INPUT_KICK:0);
 pending=combat_remap_input(&game.fighters[0],held,attack_down,pending);
 /* Finisher overlays share one temporary LWRAM slot.  Preload the actual
    attacker, including CPU trademark paths that need no human finisher edge. */
 unsigned overlay_attacker=0;bool overlay_needed=false;
 if(game.pair==PAIR_HOLD){
  overlay_attacker=game.pair_attacker;
  overlay_needed=game_finisher_probe(&game,overlay_attacker)==FINISHER_PROBE_READY;
 }else if((pending&INPUT_FINISHER)&&game_finisher_probe(&game,0)==FINISHER_PROBE_READY){
  overlay_attacker=0;overlay_needed=true;
 }else if(game.cpu&&game_finisher_probe(&game,1)==FINISHER_PROBE_READY){
  overlay_attacker=1;overlay_needed=true;
 }
 if(overlay_needed&&!finisher_overlay_load(game.fighters[overlay_attacker].character)){
  if(!overlay_attacker)pending&=~INPUT_FINISHER;
 }
 unsigned steps=timing_steps(&phase,frame_intervals);while(steps--){
  game_tick(&game,held,pending);pending=0;
  wf_audio_observe_game(&audio_observer,&game,wf_audio_saturn_emit,NULL);
  /* Test204: a CPU/ground-context finisher can become live inside game_tick,
   * after the pre-tick probe above.  Load that attacker's overlay before the
   * very same video frame is rendered, preventing the CHECK 338 race. */
  if(game.pair==PAIR_FINISHER||game.fighters[0].state==ST_FINISHER||game.fighters[1].state==ST_FINISHER){
   unsigned live_attacker=game.pair==PAIR_FINISHER?game.pair_attacker:(game.fighters[1].state==ST_FINISHER?1U:0U);
   finisher_overlay_load(game.fighters[live_attacker].character);
  }
  /* Test244: finisher owns the one temporary overlay slot for the complete
   * frame. Test238 used to reload a ground overlay after loading a finisher,
   * which could overwrite the slot and trigger CHECK338 in attract/demo. */
  bool finisher_live=game.pair==PAIR_FINISHER||game.fighters[0].state==ST_FINISHER||game.fighters[1].state==ST_FINISHER;
  if(!finisher_live&&game.pair==PAIR_STRUGGLE&&game_pair_struggle_raw_pose(&game)>=0){unsigned a=game_pair_struggle_action_side(&game),p=1U-a;struggle_pair_overlay_load(game.fighters[a].character,game.fighters[p].character);}
  if(!finisher_live&&game.pair!=PAIR_STRUGGLE)for(unsigned gi=0;gi<2;gi++)if(game.fighters[gi].state==ST_GROUND_ATTACK||game.fighters[gi].state==ST_GROUND_PICKUP){
   int raw=game_arcade_pose(&game.fighters[gi]);unsigned partner=game.fighters[1U-gi].character;
   if(raw>=0&&ground_pair_asset_available(game.fighters[gi].character,partner,(unsigned)raw&0x7fffU))
    ground_pair_overlay_load(game.fighters[gi].character,partner);
  }
 }
}
static void text_draw(void){
 text_printf("\x1b[H\x1b[2J");
 if(check_error){
  text_printf("\x1b[3;3HWWF SATURN TEST254: DATA ERROR\x1b[4;3HCHECK %lu - SEND THIS SCREEN",(unsigned long)check_error);
  if(check_error==330||check_error==331)
   text_printf("\x1b[6;3HEXPECT %08lX\x1b[7;3HACTUAL %08lX",(unsigned long)check_expected,(unsigned long)check_actual);
  if(check_error>=330&&check_error<=332)
   text_printf("\x1b[9;3HSOURCE %08lX\x1b[10;3HTARGET %08lX",(unsigned long)check_source,(unsigned long)check_target);
  return;
 }
 if(loading.kind!=LOAD_NONE)return;
 if(in_intro())return;
 if(session.phase==SESSION_MODE){text_printf("\x1b[28;8H%s\x1b[30;2HLEFT/RIGHT  A OR START TO SELECT",session.mode?"TAG TOURNAMENT":"ROYAL RUMBLE");return;}
 if(session.phase==SESSION_SELECT){text_printf("\x1b[29;2H%s: %s",session.count?"PARTNER":"PLAYER",roster_names[session_character(&session)]);text_printf("\x1b[30;2HDPAD SELECT  A/START OK  B BACK");return;}
 if(session.phase==SESSION_CPU){text_printf("\x1b[28;2HCPU 1: %.20s",roster_names[session.characters[1]]);if(session.tick>=120)text_printf("\x1b[30;2HCPU 2: %.20s",roster_names[session.characters[3]]);return;}
 if(session.phase==SESSION_HALL)return;
 if(session.phase==SESSION_ANNOUNCE){text_printf("\x1b[15;19HVS");return;}
 if(!show_hud())return;
 if(match_flow.phase!=FLOW_PLAY&&!intro.demo)return;
 if(game.paused){text_printf("\x1b[28;2HPAUSED - C: %s\x1b[30;2HTEST254 V0.269 - START: RESUME",layer_view_name(layer_view));return;}
 const char *status=game.mode==GAME_TAG?"TAG MATCH - C AT YOUR CORNER":"RUMBLE - SIX FIGHTERS";
 if(game.fighters[0].outside)status="RINGSIDE - Z NEAR ROPES TO ENTER";
 else if(game.fighters[0].state==ST_CORNER)status="CORNER: A DIVE / B CLIMB DOWN";
 else if(game.pair==PAIR_STRUGGLE)status="GRAPPLE - MASH A/B TO WIN";
 else if(game.pair==PAIR_HOLD)status=game.pair_attacker?"CPU GRAB - A/B ESCAPE, L COUNTER":"A SLAM B WHIP A+B RELEASE Z OUT";
 else if(game.pair==PAIR_THROW)status="SLAM";
 else if(game.pair==PAIR_FINISHER||game.fighters[0].state==ST_FINISHER)status="FINISHER";
 if(game.paused)status="PAUSED";
 if(game.finished)status=game.winner==0?"YOU WIN - X RESTART":"MATCH OVER - X RESTART";
 if(game.timed_out)status="TIME UP - DRAW - X RESTART";
 if(game.pair==PAIR_PIN&&!game.finished)text_printf("\x1b[28;3HCOUNT %u / 3  %s",game.pin_count,game.pin_attacker?"TAP A+B TO ESCAPE":"B RELEASE");
 else if(game.finished||game.paused||game.pair==PAIR_STRUGGLE||game.pair==PAIR_HOLD||game.pair==PAIR_FINISHER||game.fighters[0].state==ST_FINISHER||game.fighters[0].outside)text_printf("\x1b[28;3H%s",status);
 if(hud)text_printf("\x1b[29;2HFPS %u  Z OUT C TAG L GRAB R PIN",render_fps);
}

void user_init(void)
{
    cd_block_init();smpc_peripheral_init();vdp_sync_vblank_out_set(intback,NULL);
    vdp2_tvmd_display_clear();
    vdp2_tvmd_display_res_set(VDP2_TVMD_INTERLACE_NONE,VDP2_TVMD_HORZ_NORMAL_A,VDP2_TVMD_VERT_240);
    vdp2_cram_mode_set(1);
    const vdp1_env_t env={
        .bpp=VDP1_ENV_BPP_16,.rotation=VDP1_ENV_ROTATION_0,
        .color_mode=VDP1_ENV_COLOR_MODE_PALETTE,.sprite_type=0,
        .erase_color=RGB1555_INITIALIZER(0,0,0,0),
        .erase_points={INT16_VEC2_INITIALIZER(0,0),INT16_VEC2_INITIALIZER(WIDTH,HEIGHT)}
    };
    vdp1_env_set(&env);
    vdp1_vram_partitions_set(CMD_CAPACITY,DYNAMIC_TEXTURE_OFFSET+DYNAMIC_TEXTURE_BYTES,0,0);
    vdp1_vram_partitions_get(&partitions);
    /* One-shot plotting: the automatic mode can fetch this same VRAM command
     * table while the next frame replaces it. Manual mode starts only after
     * the new list is complete and waits for drawing before the buffer swap. */
    vdp1_sync_interval_set(-1);
    /* VBlank erase cannot clear 320x240 in NTSC. The first polygon does it;
     * change-only avoids any partial hardware erase after drawing. */
    vdp1_sync_mode_set(VDP1_SYNC_MODE_CHANGE_ONLY);
    vdp2_sprite_priority_set(0,6);
    vdp2_scrn_back_color_set(VDP2_VRAM_ADDR(3,0x1fffe),RGB1555(1,0,0,0));
    const vdp2_scrn_bitmap_format_t format={
        .scroll_screen=VDP2_SCRN_NBG0,.ccc=VDP2_SCRN_CCC_PALETTE_256,
        .bitmap_size=VDP2_SCRN_BITMAP_SIZE_512X512,.palette_base=RINGPAL_ADDR,.bitmap_base=RING_ADDR
    };
    vdp2_scrn_bitmap_format_set(&format);
    vdp2_scrn_scroll_x_set(VDP2_SCRN_NBG0,0);
    vdp2_scrn_scroll_y_set(VDP2_SCRN_NBG0,0);
    vdp2_scrn_priority_set(VDP2_SCRN_NBG0,3);
    dbgio_init();dbgio_dev_default_init(DBGIO_DEV_VDP2_ASYNC);dbgio_dev_font_load();
    /* Preserve the NBG3 debug-font cycles in bank 3. NBG0 bitmap uses banks 0/1. */
    vdp2_vram_cycp_t cycles=*vdp2_vram_cycp_get();
    for(unsigned bank=0;bank<2;bank++) {
        cycles.pt[bank].t0=VDP2_VRAM_CYCP_CHPNDR_NBG0;
        cycles.pt[bank].t1=VDP2_VRAM_CYCP_CHPNDR_NBG0;
        cycles.pt[bank].t2=VDP2_VRAM_CYCP_CHPNDR_NBG0;
        cycles.pt[bank].t3=VDP2_VRAM_CYCP_CHPNDR_NBG0;
        cycles.pt[bank].t4=VDP2_VRAM_CYCP_NO_ACCESS;
        cycles.pt[bank].t5=VDP2_VRAM_CYCP_NO_ACCESS;
        cycles.pt[bank].t6=VDP2_VRAM_CYCP_CPU_RW;
        cycles.pt[bank].t7=VDP2_VRAM_CYCP_CPU_RW;
    }
    vdp2_vram_cycp_set(&cycles);
    vdp2_sync();vdp2_sync_wait();
}

int main(void){
 cmds=vdp1_cmdt_list_alloc(CMD_CAPACITY);assert(cmds);bitmap=malloc(BITMAP_CAPACITY);assert(bitmap);
 cdfs_config_default_set();cdfs_filelist_init(&files,file_entries,CDFS_FILE_CAPACITY);cdfs_filelist_root_read(&files);
 /* Test254: canonical recovered audio event/command layer.  The Saturn
  * transport preloads only the ROM-proven gameplay SFX payloads from the
  * canonical AUDADP.PAK into SCSP, leaving no persistent pack copy in HWRAM. */
 if(!wf_audio_saturn_init(cd_fad("AUDADP.PAK")))check_error=345;
 else vdp_sync_vblank_in_set(wf_audio_saturn_vblank,NULL);
 /* Reuse the existing high-RAM bitmap staging allocation for the boot upload.
  * CD -> low RAM is valid; low RAM -> VDP1 via SCU-DMA is not. */
 _Static_assert(((TEXTURE_BYTES+2047U)&~2047U)<=BITMAP_CAPACITY,"ENV.TEX staging capacity");
 unsigned size=cd_read("ENV.TEX",bitmap,BITMAP_CAPACITY);
 if(!check_error){
  check_source=(uintptr_t)bitmap;check_target=(uintptr_t)partitions.texture_base;
  check_expected=TEX_HASH;check_actual=hash_ram(bitmap,size);
  if(size!=TEXTURE_BYTES||check_actual!=check_expected)check_error=330;
 }
 if(!check_error){
  transfer(partitions.texture_base,bitmap,TEXTURE_BYTES);
  if(!check_error){check_actual=hash_video(partitions.texture_base,TEXTURE_BYTES);if(check_actual!=check_expected)check_error=331;}
 }
 transfer((void *)PAL_ADDR,asset_pal,PALETTE_BYTES);transfer((void *)ROSTER_ADDR,asset_rosterpal,320);transfer((void *)(ROSTER_ADDR+RING_TRANSITION_PALETTE_BANK*32U),asset_ring14pal,32);transfer((void *)(ROSTER_ADDR+OBJECT_PALETTE_BANK*32U),asset_objectpal,32);transfer((void *)ENTRY_PAL_ADDR,asset_entrypal,512);
 transfer((void *)((uintptr_t)partitions.texture_base+TEXTURE_BYTES),asset_prompt,PROMPT_BYTES);transfer((void *)PROMPT_PAL_ADDR,asset_promptpal,32);
 transfer((void *)(VDP2_CRAM_MODE_1_OFFSET(0,0,0)+864*2),asset_announcepal,32);
 transfer((void *)(VDP2_CRAM_MODE_1_OFFSET(0,0,0)+1792*2),asset_logospal,480);
 transfer((void *)((uintptr_t)partitions.texture_base+UI_TEXTURE_OFFSET),asset_ui,UI_TEXTURE_BYTES);
 transfer((void *)((uintptr_t)partitions.texture_base+ENTRY_TEXTURE_OFFSET),asset_entryui,ENTRY_OVERLAY_BYTES);
 transfer((void *)(VDP2_CRAM_MODE_1_OFFSET(0,0,0)+880*2),asset_uipal,96);
 hud_palettes(hud_palette);transfer((void *)VDP2_CRAM_MODE_1_OFFSET(0,0,0),hud_palette,sizeof(hud_palette));
 game_reset(&game);intro_reset(&intro);session_reset(&session,MENU_OK);session_entropy_mix(&session,video_clock);presentation_load();bool queued=false;last_video=video_clock;render_window=last_video;
 while(true){
  vdp1_sync_wait();vdp2_sync_wait();if(queued)vdp2_tvmd_display_set();
  unsigned now=video_clock;frame_intervals=now-last_video;last_video=now;
  if(frame_intervals>8)frame_intervals=8;
  ++render_frames;if(now-render_window>=60){render_fps=render_frames*60/(now-render_window);render_frames=0;render_window=now;}
  smpc_peripheral_process();smpc_peripheral_digital_port(1,&pad);
  if(!check_error){
   if(loading.kind!=LOAD_NONE){loading.tick+=frame_intervals;loading_step();}
   else if(intro.demo&&!in_intro()&&(pad.held.button.start||(demo_ticks+=frame_intervals)>=1800||game.finished)){
    bool start=pad.held.button.start;intro.demo=false;loaded_roster=false;
    if(start){session_reset(&session,menu_buttons());session_entropy_mix(&session,video_clock);campaign_ready=false;}
    else{free(overflow_character);overflow_character=NULL;intro_reset(&intro);intro.screen=INTRO_TITLE;intro.start_down=pad.pressed.button.start;}
    presentation_load();last_video=video_clock;
   }else if(in_intro()){
    bool changed=false;unsigned old_intro=intro.screen,steps=frame_intervals;
    while(steps--)if(intro_tick(&intro,pad.pressed.button.start)){changed=true;break;}
    if(changed){
     if(old_intro==INTRO_TECHNOS&&intro.screen==INTRO_TITLE){loading_begin(LOAD_BOOT,0);last_video=video_clock;}
     else if(!in_intro()){
      session_reset(&session,menu_buttons());session_entropy_mix(&session,video_clock);campaign_ready=false;
      if(intro.demo){
       const unsigned cast[6]={0,2,7,1,4,5};memcpy(session.characters,cast,sizeof(cast));
       session.selected[0]=0;session.selected[1]=7;session.phase=SESSION_ANNOUNCE;
       loaded_roster=false;demo_ticks=0;
      }
     }
     if(loading.kind==LOAD_NONE)presentation_load();last_video=video_clock;
    }else if(intro.screen==INTRO_TITLE){title_phase+=frame_intervals*57445;while(title_phase>=120000){title_phase-=120000;title_draw_frame();}}
   }else if(session.phase!=SESSION_PLAY){unsigned steps=session.phase==SESSION_HALL?timing_steps(&presentation_phase,frame_intervals):frame_intervals;while(steps--)if(session_tick(&session,menu_buttons())){presentation_transition();last_video=video_clock;break;}}
   else input();
  }
  unsigned display=(!in_intro()||check_error)?VDP2_SCRN_DISPTP_NBG3:0;if(!check_error)display|=VDP2_SCRN_DISP_NBG0;vdp2_scrn_display_set((vdp2_scrn_disp_t)display);
  selection_update();scene();if(cache_count)transfer((void *)((uintptr_t)partitions.texture_base+DYNAMIC_TEXTURE_OFFSET),dynamic_data,cache_count*128);
  vdp2_scrn_scroll_x_set(VDP2_SCRN_NBG0,in_ring()?FIX16(game.camera_x+130):0);vdp2_scrn_scroll_y_set(VDP2_SCRN_NBG0,in_ring()?FIX16(game.camera_y+141):(in_intro()&&intro.screen==INTRO_TITLE?FIX16(title_page*256):0));
  vdp1_sync_cmdt_list_put(cmds,0);vdp1_sync_put_wait();vdp1_sync_render();vdp1_sync();queued=true;
  text_length=0;text_page[0]=0;text_draw();if(strcmp(text_page,text_previous)){dbgio_printf("%s",text_page);dbgio_flush();strcpy(text_previous,text_page);}vdp2_sync();
 }
 return 0;
}
