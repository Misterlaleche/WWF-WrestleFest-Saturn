#include "wf_audio_saturn.h"
#include "wf_audio_sfx.h"
#include "wf_audio_adpcm_index.h"
#include "wf_oki_decode.h"
#include "wf_music_cdda.h"
#include "ponesound_min.h"
#include <yaul.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

extern uint8_t asset_sound_driver[],asset_sound_driver_end[];

enum {
 WF_PCM_RATE=8000,
 WF_CD_SECTOR_BYTES=2048,
 WF_HOT_SOURCE_CAP=0x5000,
 WF_HOT_PCM_CAP=0x8000,
 WF_SCSP_RESIDENT_START=0x14000,
 WF_SCSP_RESIDENT_LIMIT=0x3A800,
 WF_SCSP_MUSIC_A=0x60000,
 WF_SCSP_MUSIC_B=0x68000,
 WF_SCSP_MUSIC_BYTES=0x8000
};

/*
 * Test254 Saturn transport adaptation.
 *
 * RECOVERED_ROM command identities/sequences remain in wf_audio_event.c and
 * wf_audio_sfx.c unchanged.  The package reference backend kept all 438658
 * bytes of AUDADP.PAK plus a 40 KiB decode staging buffer in HWRAM.  Test253
 * already has large gameplay/graphics HWRAM allocations, so doing that here
 * would materially endanger the canonical gameplay baseline.
 *
 * The currently proven gameplay -> SFX bindings emit only command 0x32 and
 * 0x65..0x68.  Their exact OKI payloads are samples 18 and 69..72 in bank 0.
 * We read those payloads from the canonical AUDADP.PAK at initialization,
 * decode them with the recovered OKI decoder, copy PCM8 into SCSP RAM, and
 * immediately free the temporary HWRAM scratch buffer.  No audio payload is
 * invented or recolored/reinterpreted; only the Saturn storage policy differs.
 *
 * The complete 0x20..0x81 command table and AUDADP.PAK remain in the source
 * checkpoint for future ROM-proven gameplay producers.  Until a producer is
 * recovered, this backend intentionally does not guess a binding.
 */

static wf_audio_backend_state_t state=WF_AUDIO_BACKEND_DISABLED;
static uint32_t resident0[74];
static uint16_t sample_ticks_left[3];
static bool suppress_next[3];
static unsigned last_command,cache_misses;
static uint32_t timer_a_accum;
static const uint8_t oki_to_ponesound_volume[16]={255,251,247,243,239,236,231,228,223,0,0,0,0,0,0,0};
static const uint8_t hot_bank0_samples[]={18u,69u,70u,71u,72u};

static unsigned align32(unsigned n){return (n+31u)&~31u;}
static uint8_t *align_ptr32(uint8_t *p){return (uint8_t *)(((uintptr_t)p+31u)&~(uintptr_t)31u);}

static bool read_adpcm_asset(uint32_t pack_fad,const wf_adpcm_asset_t *a,
                             uint8_t *src,unsigned src_cap,
                             const uint8_t **payload)
{
 if(!a||!a->adpcm_bytes||!src||!payload)return false;
 unsigned sector=a->offset/WF_CD_SECTOR_BYTES;
 unsigned skip=a->offset%WF_CD_SECTOR_BYTES;
 unsigned need=skip+(unsigned)a->adpcm_bytes;
 unsigned read_bytes=(need+WF_CD_SECTOR_BYTES-1u)&~(WF_CD_SECTOR_BYTES-1u);
 if(read_bytes>src_cap)return false;
 if(cd_block_sectors_read(pack_fad+sector,src,read_bytes)!=0)return false;
 *payload=src+skip;
 return true;
}

static bool preload_hot_samples(uint32_t pack_fad){
 const unsigned scratch_bytes=WF_HOT_SOURCE_CAP+WF_HOT_PCM_CAP+31u;
 uint8_t *raw=(uint8_t *)malloc(scratch_bytes);
 if(!raw)return false;
 uint8_t *src=align_ptr32(raw);
 int8_t *pcm=(int8_t *)(src+WF_HOT_SOURCE_CAP);
 unsigned addr=WF_SCSP_RESIDENT_START;
 memset(resident0,0,sizeof(resident0));
 bool ok=true;
 for(unsigned i=0;i<sizeof(hot_bank0_samples);i++){
  unsigned sample=hot_bank0_samples[i];
  const wf_adpcm_asset_t *a=wf_adpcm_asset(0u,sample);
  const uint8_t *payload=0;
  if(!a||a->pcm8_bytes>WF_HOT_PCM_CAP||
     !read_adpcm_asset(pack_fad,a,src,WF_HOT_SOURCE_CAP,&payload)||
     wf_oki_decode_pcm8(payload,a->adpcm_bytes,pcm,WF_HOT_PCM_CAP)!=a->pcm8_bytes){ok=false;break;}
  addr=align32(addr);
  if(addr+(unsigned)a->pcm8_bytes>WF_SCSP_RESIDENT_LIMIT){ok=false;break;}
  resident0[sample]=addr;
  wf_ponesound_copy_to_scsp(pcm,a->pcm8_bytes,(int)addr);
  addr+=(unsigned)a->pcm8_bytes;
 }
 free(raw);
 return ok;
}

static uint32_t resident_address(unsigned bank,unsigned sample){
 if(bank!=0u||sample>=74u)return 0;
 return resident0[sample];
}
static uint16_t sample_duration_ticks(unsigned bank,unsigned s){
 const wf_adpcm_asset_t *a=wf_adpcm_asset(bank,s);if(!a)return 0;
 uint64_t num=(uint64_t)a->pcm8_bytes*WF_SFX_TIMER_A_HZ_NUM;
 uint64_t den=(uint64_t)8000u*WF_SFX_TIMER_A_HZ_DEN;
 return (uint16_t)((num+den-1u)/den);
}
static void stop_cb(unsigned l,void *u){(void)u;if(l<3u){wf_ponesound_pcm_cease((short)l);sample_ticks_left[l]=0;suppress_next[l]=false;}}
static void play_cb(unsigned l,unsigned bank,unsigned sample,unsigned vol,bool suppress,void *u){
 (void)u;if(l>=3u)return;
 if(sample_ticks_left[l]&&suppress_next[l]){suppress_next[l]=suppress;return;}
 if(sample_ticks_left[l])wf_ponesound_pcm_cease((short)l);
 const wf_adpcm_asset_t *a=wf_adpcm_asset(bank,sample);if(!a)return;
 uint32_t addr=resident_address(bank,sample);
 /* Fail closed: a gameplay producer without a recovered/preloaded transport
    binding is registered in the canonical command table but not guessed here. */
 if(!addr){state=WF_AUDIO_BACKEND_ERROR;return;}
 wf_ponesound_configure_8bit_pcm(a->pcm8_bytes,(int)l,(int)addr,WF_PCM_RATE);
 wf_ponesound_pcm_play((short)l,PCM_PROTECTED,(char)oki_to_ponesound_volume[vol&15u]);
 sample_ticks_left[l]=sample_duration_ticks(bank,sample);suppress_next[l]=suppress;
}
static void timer_a_tick(void){for(unsigned i=0;i<3u;i++)if(sample_ticks_left[i])--sample_ticks_left[i];wf_sfx_timer_a_tick(play_cb,stop_cb,0);}
static void frt_1ms(void){
 uint32_t count=cpu_frt_count_get();int32_t diff=(int32_t)count-(int32_t)CPU_FRT_NTSC_320_8_COUNT_1MS;
 if(diff>=0)cpu_frt_count_set((uint32_t)diff);
 timer_a_accum+=WF_SFX_TIMER_A_HZ_NUM;
 while(timer_a_accum>=WF_SFX_TIMER_A_HZ_DEN*1000u){timer_a_accum-=WF_SFX_TIMER_A_HZ_DEN*1000u;timer_a_tick();}
}
static bool runtime_recovered_sfx(unsigned command){
 return command==0x32u||(command>=0x65u&&command<=0x68u);
}

bool wf_audio_saturn_init(uint32_t fad){
 int ds=(int)(asset_sound_driver_end-asset_sound_driver);
 if(ds<=0||fad==0u){state=WF_AUDIO_BACKEND_ERROR;return false;}
 wf_ponesound_load_driver(asset_sound_driver,ds);
 memset(sample_ticks_left,0,sizeof(sample_ticks_left));memset(suppress_next,0,sizeof(suppress_next));
 wf_sfx_runtime_reset();timer_a_accum=0;cache_misses=0;last_command=0;
 if(!preload_hot_samples(fad)){state=WF_AUDIO_BACKEND_ERROR;return false;}
 cpu_frt_init(CPU_FRT_CLOCK_DIV_8);cpu_frt_oca_set(CPU_FRT_NTSC_320_8_COUNT_1MS,frt_1ms);
 cpu_frt_count_set(0);cpu_frt_interrupt_priority_set(8);state=WF_AUDIO_BACKEND_READY;return true;
}
void wf_audio_saturn_vblank(void *work){if(state==WF_AUDIO_BACKEND_READY)wf_ponesound_vblank(work);}
void wf_audio_saturn_emit(wf_audio_event_t e,void *user){
 (void)user;last_command=e.command;if(state!=WF_AUDIO_BACKEND_READY)return;
 if(e.command>=1u&&e.command<=0x12u){
  if(!wf_music_cdda_play(e.command))state=WF_AUDIO_BACKEND_ERROR;
  return;
 }
 if(e.command==0u){wf_music_cdda_stop();return;}
 if(e.command>=WF_SFX_FIRST_COMMAND&&e.command<=WF_SFX_LAST_COMMAND){
  if(!runtime_recovered_sfx(e.command))return;
  uint8_t oldmask=cpu_intc_mask_get();cpu_intc_mask_set(15);
  (void)wf_sfx_start_voice(e.command,play_cb,stop_cb,0);cpu_intc_mask_set(oldmask);
 }
}
wf_audio_backend_state_t wf_audio_saturn_state(void){return state;}
unsigned wf_audio_saturn_last_command(void){return last_command;}
unsigned wf_audio_saturn_cache_misses(void){return cache_misses;}
