#ifndef WWF_ARCADE_PAIR_STATE_H
#define WWF_ARCADE_PAIR_STATE_H
#include <stdbool.h>
typedef struct {
 unsigned attacker_state,target_state;
 unsigned attacker_44,target_44;
 unsigned target_68,target_c7,target_54,target_52;
} arcade_pair29_state_t;
/* Test82: exact state-changing tail of action $29 callback $16582. */
bool arcade_pair29_apply_terminal(arcade_pair29_state_t *s,unsigned attacker_1c,unsigned attacker_25);
#endif
