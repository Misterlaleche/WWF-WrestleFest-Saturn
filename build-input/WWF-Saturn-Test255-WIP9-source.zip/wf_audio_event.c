#include "wf_audio_event.h"

static const uint8_t stage_music[10] = {
    0x04,0x0A,0x0C,0x0F,0x06,0x04,0x0A,0x0C,0x0F,0x06
};

uint8_t wf_audio_stage_music_command(unsigned stage_index)
{
    return stage_music[stage_index % 10u];
}

void wf_audio_observer_reset(wf_audio_observer_t *o, unsigned stage_index)
{
    if (!o) return;
    *o=(wf_audio_observer_t){0};
    o->stage_index=stage_index % 10u;
}

static void send(wf_audio_emit_fn emit, void *user, uint8_t cmd,
                 uint8_t priority, wf_audio_class_t klass)
{
    if (emit) emit((wf_audio_event_t){cmd,priority,klass},user);
}

void wf_audio_observe_game(wf_audio_observer_t *o, const game_t *g,
                           wf_audio_emit_fn emit, void *user)
{
    if (!o || !g) return;

    if (!o->stage_music_started) {
        send(emit,user,wf_audio_stage_music_command(o->stage_index),0,
             WF_AUDIO_CLASS_MUSIC);
        o->stage_music_started=true;
    }

    /* ROM-EXACT command identity: active-actor stamina < 0x18 -> command 0x0B.
       Native Saturn role binding remains the active human slot (fighter 0). */
    if (g->fighters[0].health < 0x18u) {
        if (!o->low_stamina_latched) {
            send(emit,user,0x0B,0x08,WF_AUDIO_CLASS_MUSIC);
            o->low_stamina_latched=true;
        }
    } else if (o->low_stamina_latched) {
        /* ROM-backed restore path reindexes the current stage table after the warning. */
        send(emit,user,wf_audio_stage_music_command(o->stage_index),0,WF_AUDIO_CLASS_MUSIC);
        o->low_stamina_latched=false;
    }

    /* ROM-EXACT final count commands only exist for displayed counts 17..20. */
    if (g->ringout_count != o->last_ringout_count) {
        if (g->ringout_count >= 17u && g->ringout_count <= 20u)
            send(emit,user,(uint8_t)(0x65u + g->ringout_count - 17u),
                 0x0Bu,WF_AUDIO_CLASS_SFX);
        o->last_ringout_count=g->ringout_count;
    }

    /* Command 0x32 is the recovered long heavy/finisher reaction layer.
       Trigger only on the rising edge of the existing native impact latch. */
    if (g->finisher_impact && !o->last_finisher_impact)
        send(emit,user,0x32,0x06,WF_AUDIO_CLASS_SFX);
    o->last_finisher_impact=g->finisher_impact;
}
