#ifndef WWF_GAME_H
#define WWF_GAME_H
#include <stdbool.h>
#include <stdint.h>

enum { INPUT_LEFT=1, INPUT_RIGHT=2, INPUT_UP=4, INPUT_DOWN=8, INPUT_PUNCH=16, INPUT_KICK=32, INPUT_GRAB=64, INPUT_PIN=128, INPUT_RING=256, INPUT_TAG=512, INPUT_RUN=1024, INPUT_RUN_ATTACK=2048, INPUT_CLOTHESLINE=4096, INPUT_BIG_BOOT=8192, INPUT_FINISHER=16384 };
typedef enum { ST_IDLE, ST_WALK, ST_PUNCH, ST_HIT, ST_DOWN, ST_KICK, ST_RECOVER, ST_RISE, ST_UNCOVER, ST_CLIMB, ST_CORNER, ST_DESCEND, ST_DIVE, ST_LAND, ST_RING_EXIT, ST_RING_ENTER, ST_TOSSED, ST_RUN, ST_RUN_STOP, ST_REBOUND, ST_RUN_ATTACK, ST_CLOTHESLINE, ST_BIG_BOOT, ST_FINISHER, ST_GROUND_ATTACK, ST_OBJECT_PICKUP, ST_OBJECT_USE, ST_GROUND_PICKUP, ST_RING_THROW } fighter_state_t;
typedef enum { PAIR_NONE, PAIR_STRUGGLE, PAIR_HOLD, PAIR_THROW, PAIR_PIN, PAIR_FINISHER, PAIR_SUBMISSION } pair_state_t;
typedef enum { REF_IDLE, REF_WALK, REF_KNEEL, REF_COUNT, REF_RISE, REF_FINISH } referee_state_t;
enum { PIN_MSG_NONE, PIN_MSG_KICKOUT, PIN_MSG_RELEASED, PIN_MSG_GET_CLOSER, PIN_MSG_HULK_ESCAPED };
enum { RECOVER_PRONE_TICKS=135, RISE_TICKS=48, UNCOVER_TICKS=12, RECOVER_TOTAL_TICKS=183, PIN_SETUP_TICKS=12, CPU_PIN_SETUP_TICKS=22, PIN_COUNT_TICKS=58 };
enum { RECOVERY_MAX_BONUS=48, RECOVERY_BONUS_PER_BUTTON=2 };
enum { FINISH_NONE,FINISH_PIN,FINISH_DOUBLE_KO,FINISH_TIME,FINISH_ELIMINATION,FINISH_SUBMISSION,FINISH_COUNTOUT };
typedef struct {
    int32_t x,y; /* 8.8 fixed point, centre of feet */
    int32_t rise_y; /* Standing depth before prone artwork extends down. */
    int32_t motion_x0,motion_x1;
    int32_t motion_y0,motion_y1;
    unsigned corner;
    unsigned character; bool outside;
    unsigned held_object; /* 0 none, 1/2 ringside object; ROM fighter +$76 linkage. */
    bool arcade_motion; /* ROM-sourced basic motion; other rules still native. */
    int32_t move_fraction_x,move_fraction_y; /* Low eight bits of ROM 16.16. */
    unsigned run_speed;
    unsigned recovery_bonus,attack_serial;
    bool throw_recovery,whipped;
    unsigned whip_rebounds;
    unsigned actor; /* 0 Hogan, 1 Jake: separate animation schedules. */
    int facing; /* +1 right, -1 left */
    fighter_state_t state;
    unsigned tick,health,max_health,display_health,stamina_tier,stamina_recovery,walk_tick,cooldown;
    int stamina_pending,stamina_display_delta; /* ROM +$6A/+6C HUD delta pipeline. */
    unsigned queued_attack,buffer_ticks,finisher_phase,current_move,grapple_serial;
    bool connected,power_up;
    unsigned apron_state,apron_tick,apron_anim_tick,power_meter,apron_attacks,rope_shakes;
    unsigned rope_contact_side; /* 0 none, 1 west, 2 east: latched when a run actually hits a side rope. */
    unsigned ringside_target; /* 0 none, otherwise object index + 1. */
} fighter_t;
typedef struct {
    int32_t x,y,target_x,target_y;
    int facing,count_facing;
    referee_state_t state;
    unsigned tick,walk_tick,slaps;
    bool covering;
} referee_t;
typedef struct {
    int32_t x,y,z;
    unsigned type,state,holder,tick; /* holder 0 none, otherwise fighter index + 1. */
    bool state4_initialized; unsigned state4_timer,state4_phase;
    bool native_position_provisional;
} ringside_object_t;
typedef struct {
    fighter_t fighters[6];
    referee_t referee;
    ringside_object_t ringside_objects[2];
    unsigned ringside_object_count;
    unsigned ticks,hits[6],freeze;
    unsigned mode,roster_count,active_mask,tag_cooldown,tags,eliminated,stage_index,difficulty;
    unsigned time_left,clock_phase;
    unsigned ringout_count,ringout_tick; /* ROM $1C169A/B, one count per 0x50 ticks. */
    unsigned finish_reason,starting_roster[6];
    unsigned rumble_queue[10],rumble_total,rumble_next,rumble_pending_slot,rumble_announce_ticks,rumble_entry_ticks;
    unsigned rumble_pending_eliminations,rumble_entry_delay;
    unsigned support_phase[2],support_cooldown[2],rescues,blocks,throws,irish_whips,restrain_assists;
    unsigned tag_phase[2],tag_tick[2]; /* Native staged TAG handshake/entry; exact arcade timing still pending. */
    unsigned ground_pressure[2]; /* Native anti-loop policy: consecutive prone pressure per attacker. */
    bool timed_out;
    bool cpu,paused,finished;
    bool postmatch_active; unsigned postmatch_tick;
    int winner;
    pair_state_t pair;
    unsigned pair_tick;
    unsigned pair_attacker,grapple_escape,cpu_grabs,grapple_reversals,cpu_reversals,pair_move,pair_damage,submission_pulses;
    unsigned grapple_score[2]; /* Test253: completed exact raw-$29 cycles per side; two-cycle terminal is ROM-backed. */
    unsigned grapple_action_tick,grapple_action_side; /* $29 visual clock; CPU trigger/tie arbitration still provisional. */
    unsigned finisher_phase,finisher_phase_tick,finisher_partner,finisher_attempts,finishers;
    bool pair_impact,pair_reversed,finisher_impact;
    unsigned pin_count,pin_message,pin_message_ticks;
    unsigned pin_attacker,escape_progress,escape_required,escape_last;
    unsigned escape_pulse;
    int camera_x,camera_y; /* Pixel viewport origin in native ring coordinates. */
} game_t;
enum { FIGHTER_SIDE_MARGIN=32, RING_TOP=157, RING_BOTTOM=273, CAMERA_MIN_X=-130, CAMERA_MAX_X=62, CAMERA_MIN_Y=-95, CAMERA_MAX_Y=131 };
int game_ring_left(int y);
int game_ring_right(int y);
bool game_on_floor(int x,int y);
int game_corner_near(const fighter_t *f);
int game_fighter_lift(const fighter_t *f);
bool game_over_ropes(const fighter_t *f);
enum { DRAW_SIDE_ROPES=1, DRAW_HULK, DRAW_JAKE, DRAW_PAIR, DRAW_REFEREE, DRAW_FRONT_ROPES, DRAW_PROMPT };
enum { DRAW_FIGHTER_2=8, DRAW_FIGHTER_3, DRAW_FIGHTER_4, DRAW_FIGHTER_5, GAME_DRAW_CAPACITY=12 };
/* Complete plan used by Saturn and host tests, including TAG/Rumble actors. */
unsigned game_render_plan(const game_t *g,unsigned order[GAME_DRAW_CAPACITY]);
int game_draw_fighter(unsigned object);
int32_t game_fighter_depth(const fighter_t *f);
/* Two-fighter projection for legacy trace files; delegates to the same plan. */
unsigned game_draw_order(const game_t *g,unsigned order[8]);
void game_reset(game_t *g);
void game_tick(game_t *g,unsigned held,unsigned pressed);
/* Host-visible exact ringside autonomous-object tick; Saturn game_tick uses the same path. */
void game_ringside_objects_tick(game_t *g);

/* Exact $90d6 clear-stage restore primitive. It is not the coin REGAIN POWER path. */
void game_clear_stage_restore(game_t *g,unsigned setting);
unsigned game_pose(const fighter_t *f);
/* Original pose word for integrated basic actions; -1 uses legacy pair/rise. */
int game_arcade_pose(const fighter_t *f);
/* -1 means independent fighters; pair clip and anchor identify shared poses. */
int game_pair_pose(const game_t *g);
unsigned game_pair_clip(const game_t *g);
unsigned game_pair_anchor(const game_t *g);
int game_pair_facing(const game_t *g);
unsigned game_pair_fighter(const game_t *g,unsigned role);
unsigned game_finisher_phase(const game_t *g);
unsigned game_animation_role(const fighter_t *f);
unsigned game_referee_pose(const game_t *g);
bool game_escape_prompt_visible(const game_t *g);
unsigned game_escape_prompt_pose(const game_t *g);
unsigned game_pin_indicator(const game_t *g);
bool game_recovery_prompt_visible(const game_t *g);
bool game_player_marker_visible(const game_t *g);
bool game_postmatch_active(const game_t *g);
/* Test220: resolved post-match side role: +1 winner, -1 defeated, 0 unrelated. */
int game_postmatch_role(const game_t *g,unsigned fighter);
int game_rope_deflection(const game_t *g,int rope_x,int rope_y);
int game_pair_struggle_offset(const game_t *g);
int game_pair_struggle_raw_pose(const game_t *g);
unsigned game_pair_struggle_action_side(const game_t *g);
int game_escape_prompt_x(const game_t *g);
enum {GAME_TRAINING,GAME_TAG,GAME_RUMBLE};
void game_match_start(game_t *g,unsigned mode,const unsigned characters[6]);
void game_match_start_rumble_queue(game_t *g,const unsigned characters[10],unsigned count);
unsigned game_rumble_active_count(const game_t *g);
bool game_rumble_announcement_visible(const game_t *g);
unsigned game_rumble_announced_character(const game_t *g);
unsigned game_rumble_pending_slot(const game_t *g);
void game_match_start_arcade(game_t *g,unsigned mode,const unsigned characters[6],unsigned stage_index,unsigned difficulty);
bool game_ringside_valid(int x,int y);
bool game_try_ringside_pickup(game_t *g,unsigned fighter);
bool game_try_ringside_object_use(game_t *g,unsigned fighter);
void game_drop_ringside_object(game_t *g,unsigned fighter);
int game_cpu_choose_ringside_object(game_t *g,unsigned fighter,unsigned roll_0_99,bool *probability_known);
bool game_ring_exit_near(const fighter_t *f);
enum {SUPPORT_WAIT,SUPPORT_ENTER,SUPPORT_RUN,SUPPORT_RETURN,SUPPORT_EXIT};
enum {TAG_PHASE_NONE,TAG_PHASE_APPROACH,TAG_PHASE_SLAP,TAG_PHASE_ENTRY};
enum {APRON_NEUTRAL,APRON_CHEER,APRON_WORRY,APRON_POWER,APRON_STRIKE,APRON_ROPE_SHAKE};
bool game_partner_waiting(const game_t *g,unsigned fighter);
/* True while P1 has temporary control of his illegal TAG partner during a rescue. */
bool game_player_controls_partner(const game_t *g);
/* Render-only hardware correction for waiting TAG reserves; gameplay coordinates stay untouched. */
void game_fighter_draw_position(const game_t *g,unsigned fighter,int *x,int *y);
#endif
