#ifndef WWF_ARCADE_MOVES_H
#define WWF_ARCADE_MOVES_H
#include <stdbool.h>

typedef enum {
 AMOVE_NONE,
 AMOVE_BODY_SLAM,AMOVE_SNAP_MARE,AMOVE_ATOMIC_DROP,AMOVE_SUPLEX,
 AMOVE_STANDING_DROPKICK,AMOVE_BACK_SUPLEX,AMOVE_PERFECT_PLEX,
 AMOVE_GUT_WRENCH_SUPLEX,AMOVE_DDT,AMOVE_HEADBUTT,AMOVE_POWERSLAM,AMOVE_BEAR_HUG,
 AMOVE_NOOGIE,AMOVE_CHESTBREAKER,AMOVE_COBRA_CLUTCH,AMOVE_BACKBREAKER,
 AMOVE_PILEDRIVER,AMOVE_MILLION_DOLLAR_DREAM,AMOVE_GORILLA_PRESS,AMOVE_NECKBREAKER,
 AMOVE_SHOULDER_BREAKER,
 AMOVE_SHOULDER_TACKLE,AMOVE_CLOTHESLINE,AMOVE_DROPKICK,AMOVE_SPINNING_ELBOW,
 AMOVE_HIGH_KNEE,AMOVE_GUT_SMASH,AMOVE_KNEE_SMASH,AMOVE_DOUBLE_CLOTHESLINE,
 AMOVE_BACK_BODY_DROP,AMOVE_BIG_BOOT,AMOVE_REVERSE_KNIFE_EDGE,AMOVE_BOSS_MAN_SLAM,
 AMOVE_PICK_UP,AMOVE_STOMP,AMOVE_ELBOW_DROP,AMOVE_KNEE_DROP,AMOVE_FIST_DROP,
 AMOVE_RUNNING_SPLASH,AMOVE_VERTICAL_SPLASH,AMOVE_WARRIOR_SPLASH,
 AMOVE_BOSTON_CRAB,AMOVE_FIGURE_FOUR,AMOVE_SLEEPER,AMOVE_RESTRAIN,
 AMOVE_BIONIC_ELBOW,AMOVE_AXEHANDLE,AMOVE_BIG_SPLASH,
 AMOVE_COUNT
} arcade_move_id_t;

typedef struct {
 arcade_move_id_t grapple[4];
 arcade_move_id_t running[2];      /* normal, weakened */
 arcade_move_id_t anti_running[2]; /* normal, weakened */
 arcade_move_id_t ground_drop;     /* P+K at body */
 arcade_move_id_t ground_submission;
 arcade_move_id_t diagonal;
 arcade_move_id_t turnbuckle_stand;
 arcade_move_id_t turnbuckle_prone;
} arcade_move_set_t;

const arcade_move_set_t *arcade_move_set(unsigned character);
const char *arcade_move_name(arcade_move_id_t move);
bool arcade_move_submission(arcade_move_id_t move);
bool arcade_move_signature(arcade_move_id_t move,unsigned character);
/* Guide-observed two-at-a-time grapple rotation: healthy opponent gets 0/1,
 * weakened/critical opponent gets 2/3. CPU can override the pair. */
arcade_move_id_t arcade_grapple_select(unsigned character,unsigned opponent_tier,unsigned serial,bool cpu_variation);
arcade_move_id_t arcade_running_select(unsigned character,unsigned self_tier);
arcade_move_id_t arcade_anti_running_select(unsigned character,unsigned self_tier);
/* Test72: category $10 physical-button selection for the recovered behind context. */
arcade_move_id_t arcade_behind_button_select(unsigned fresh_buttons);
/* Native mechanics defaults until individual callback damage is recovered. */
unsigned arcade_move_native_damage(arcade_move_id_t move);
#endif
