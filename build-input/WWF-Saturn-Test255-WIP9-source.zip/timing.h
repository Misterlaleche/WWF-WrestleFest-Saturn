#ifndef WWF_TIMING_H
#define WWF_TIMING_H
/* Accumulate original 57.445-Hz logic from observed NTSC video intervals,
 * independently of how many complete frames the renderer produces. */
static inline unsigned timing_steps(unsigned *phase,unsigned video_intervals)
{
    if(video_intervals>8)video_intervals=8;
    *phase+=video_intervals*57445U;
    unsigned steps=*phase/60000U;
    *phase%=60000U;
    return steps;
}
#endif
