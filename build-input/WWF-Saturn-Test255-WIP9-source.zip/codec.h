#pragma once
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
bool lz4_unpack(const uint8_t *src,size_t size,uint8_t *dst,size_t capacity);
