#pragma once
#include <stdbool.h>
#include "game.h"

/* Coverage checked against original per-character composition tables.
   Missing actions never borrow another wrestler's graphics. */
static inline bool combat_has_clothesline(unsigned ch){
    return ch<10&&((0x1f3U>>ch)&1U);
}
static inline bool combat_has_big_boot(unsigned ch){return ch==0||ch==8;}
enum { CLOTHESLINE_TICKS=46,CLOTHESLINE_FIRST=1,CLOTHESLINE_LAST=27,
       BIG_BOOT_TICKS=40,BIG_BOOT_FIRST=15,BIG_BOOT_LAST=39 };

/* Native Saturn controls, not a claim of the original arcade button rules.
   'down' is the current button level; 'edges' contains new presses only. */
static inline unsigned combat_remap_input(const fighter_t *f,unsigned movement,
                                          unsigned down,unsigned edges){
    unsigned attack=edges&(INPUT_PUNCH|INPUT_KICK);
    if(!f->arcade_motion||f->outside||!attack)return edges;
    if((f->state==ST_RUN||f->state==ST_RUN_STOP)&&!(movement&INPUT_RUN)){
        edges&=~(INPUT_PUNCH|INPUT_KICK);
        return edges|((attack==INPUT_PUNCH&&combat_has_clothesline(f->character))?
                       INPUT_CLOTHESLINE:INPUT_RUN_ATTACK);
    }
    /* Test73: stationary P+K maps to ROM sentinel $FF, not Big Boot. */
    if((f->state==ST_IDLE||f->state==ST_WALK)&&!(movement&15)&&
       (down&(INPUT_PUNCH|INPUT_KICK))==(INPUT_PUNCH|INPUT_KICK))
        edges&=~(INPUT_PUNCH|INPUT_KICK);
    return edges;
}
