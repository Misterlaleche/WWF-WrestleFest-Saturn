#include "arcade_rumble.h"

const arcade_rumble_raw_pos_t arcade_rumble_raw_positions[ARCADE_RUMBLE_ACTIVE_MAX]={
    {0x0240,0x0120},{0x02d0,0x0120},{0x0230,0x0150},
    {0x02c0,0x0150},{0x0240,0x0180},{0x02b0,0x0180}
};

int arcade_rumble_reverse_free_slot(const uint16_t words[ARCADE_RUMBLE_ACTIVE_MAX]){
    if(!words)return -1;
    for(int i=ARCADE_RUMBLE_ACTIVE_MAX-1;i>=0;i--)if(words[i]==0)return i;
    return -1;
}

bool arcade_rumble_entry_delay_step(unsigned *pending,unsigned *timer,unsigned active_count){
    if(!pending||!timer||!*pending)return false;
    ++*timer;
    if(*timer<ARCADE_RUMBLE_ENTRY_DELAY)return false;
    *timer=0;
    if(active_count>=ARCADE_RUMBLE_ACTIVE_MAX)return false;
    --*pending;
    return true;
}

unsigned arcade_rumble_preferred_pool(unsigned lower_active,unsigned upper_active){
    return upper_active<lower_active?1U:0U;
}

static bool pool_has_free(uint16_t used,unsigned pool){
    unsigned base=pool?6U:0U;
    for(unsigned i=0;i<6;i++)if(!(used&(1U<<(base+i))))return true;
    return false;
}
static int pool_pick(uint16_t used,unsigned pool,const unsigned rolls[4]){
    unsigned base=pool?6U:0U;
    for(unsigned k=0;k<4;k++){
        unsigned i=rolls[k]%6U;
        if(!(used&(1U<<(base+i))))return (int)(base+i);
    }
    uint16_t words[6];
    for(unsigned i=0;i<6;i++)words[i]=(used&(1U<<(base+i)))?1U:0U;
    int i=arcade_rumble_reverse_free_slot(words);
    return i<0?-1:(int)(base+(unsigned)i);
}
int arcade_rumble_select_entrant(uint16_t used_mask,unsigned lower_active,unsigned upper_active,const unsigned rolls[4]){
    if(!rolls)return -1;
    unsigned preferred=arcade_rumble_preferred_pool(lower_active,upper_active);
    if(pool_has_free(used_mask,preferred))return pool_pick(used_mask,preferred,rolls);
    preferred^=1U;
    if(pool_has_free(used_mask,preferred))return pool_pick(used_mask,preferred,rolls);
    return -1;
}
