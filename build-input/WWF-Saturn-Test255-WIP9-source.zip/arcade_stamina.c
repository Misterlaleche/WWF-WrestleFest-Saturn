#include "arcade_stamina.h"
#include <stdbool.h>

static const uint8_t selection_to_internal[12]={0,7,2,8,6,9,1,3,10,11,4,5};
static const uint16_t human_by_internal[12]={110,106,98,102,500,500,106,104,100,96,104,96};
static const uint16_t cpu_by_stage[10]={115,145,150,155,185,160,165,165,170,200};
/* Index is the post-inversion game value: 0 Normal, 1 Easy, 2 Hard, 3 Hardest.
 * Program ROM $1085C. */
static const int8_t difficulty_adjust[4]={0,-15,15,30};
static const uint8_t clear_stage_restore[4]={24,32,12,0};

unsigned arcade_stamina_internal_id(unsigned character){return character<12?selection_to_internal[character]:0;}
unsigned arcade_stamina_human_max(unsigned character){
 unsigned id=arcade_stamina_internal_id(character);
 return human_by_internal[id];
}
unsigned arcade_stamina_tier(unsigned stamina,unsigned maximum){
 if(stamina<=ARCADE_STAMINA_LOW)return 2;
 if(stamina<=2*(maximum/3))return 1;
 return 0;
}
unsigned arcade_difficulty_from_raw_dip(unsigned raw_bits){
 return (~raw_bits)&3U;
}
uint16_t arcade_operator_pack_config(uint16_t port20,uint16_t port22,uint16_t port24,uint16_t port26){
 uint16_t packed=(uint16_t)(((port20&0x3000U)<<2)|(port22&0x3f00U)|
                            ((port24&0x3f00U)>>8)|((port26&0x0300U)>>2));
 return (uint16_t)~packed;
}
unsigned arcade_difficulty_from_config(uint16_t config_word){return (config_word>>8)&3U;}
unsigned arcade_stamina_cpu_max(unsigned stage_index,bool secondary_slot,unsigned difficulty_index){
 if(stage_index>9)stage_index=9;
 if(difficulty_index>3)difficulty_index=3;
 int value=(int)cpu_by_stage[stage_index]+difficulty_adjust[difficulty_index]-(secondary_slot?15:0);
 return value>0?(unsigned)value:0;
}

unsigned arcade_clear_stage_restore(unsigned setting){return clear_stage_restore[setting<4?setting:3];}
bool arcade_stamina_low_warning(unsigned stamina){return stamina<ARCADE_STAMINA_LOW;}
bool arcade_stamina_recovery_state_allows(bool actor_active,unsigned state_code,unsigned linked_state_code,unsigned pose_code){
 if(!actor_active)return false;
 state_code&=0xffU;linked_state_code&=0xffU;pose_code&=0xffU;
 if(state_code==0x0bU||state_code==0x0cU)return false;
 if(state_code==0xffU&&linked_state_code==0x0cU)return false;
 if(state_code==0x05U&&pose_code==0x4aU)return false;
 return true;
}
