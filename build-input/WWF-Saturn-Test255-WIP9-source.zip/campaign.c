#include "campaign.h"
#include "arcade_stamina.h"
#include <string.h>
void campaign_reset(campaign_t *c,unsigned mode,unsigned championship_match,
                    unsigned clear_stage_setting,unsigned difficulty){
 memset(c,0,sizeof(*c));c->mode=mode;
 c->championship_match=championship_match==4?4:5;
 c->clear_stage_setting=clear_stage_setting<4?clear_stage_setting:0;
 c->difficulty=difficulty<4?difficulty:0;
}
bool campaign_is_title_match(const campaign_t *c){
 return c->mode==CAMPAIGN_TAG&&c->stage+1==c->championship_match;
}
bool campaign_is_final_lod(const campaign_t *c){return c->mode==CAMPAIGN_TAG&&c->stage==9;}
bool campaign_is_lod_match(const campaign_t *c){return campaign_is_title_match(c)||campaign_is_final_lod(c);}
bool campaign_is_cage_match(const campaign_t *c){
 /* Stage modifier audit: $02 is first cage, $07 is title-defense cage. */
 return c->mode==CAMPAIGN_TAG&&(c->stage==2||c->stage==7);
}
bool campaign_finish_match(campaign_t *c,bool player_won){
 if(c->complete)return false;
 if(!player_won){++c->losses;return false;}
 ++c->wins;
 if(c->mode==CAMPAIGN_RUMBLE){c->complete=true;return false;}
 /* The first LOD championship match awards the belts but the arcade continues
  * through title defenses. Stage $09 is the final LOD defense and game clear. */
 if(campaign_is_title_match(c))c->championship=true;
 if(c->stage>=9){c->complete=true;return false;}
 ++c->stage;
 return true;
}
unsigned campaign_stage(const campaign_t *c){return c->stage>9?9:c->stage;}
unsigned campaign_clear_stage_setting(const campaign_t *c){return c->clear_stage_setting;}

void campaign_set_players(campaign_t *c,unsigned first,unsigned second){
 c->player_character[0]=first;c->player_character[1]=second;
 for(unsigned i=0;i<2;i++){
  c->player_max[i]=arcade_stamina_human_max(c->player_character[i]);
  c->player_health[i]=c->player_max[i];
 }
 c->player_stamina_valid=true;
}
void campaign_capture_player_stamina(campaign_t *c,unsigned character,unsigned health){
 if(!c->player_stamina_valid)return;
 for(unsigned i=0;i<2;i++)if(c->player_character[i]==character){
  c->player_health[i]=health<c->player_max[i]?health:c->player_max[i];return;
 }
}
void campaign_clear_stage_power_up(campaign_t *c){
 if(!c->player_stamina_valid||c->mode!=CAMPAIGN_TAG)return;
 unsigned add=arcade_clear_stage_restore(c->clear_stage_setting);
 for(unsigned i=0;i<2;i++){unsigned h=c->player_health[i]+add;c->player_health[i]=h<c->player_max[i]?h:c->player_max[i];}
}
unsigned campaign_player_stamina(const campaign_t *c,unsigned character){
 if(c->player_stamina_valid)for(unsigned i=0;i<2;i++)if(c->player_character[i]==character)return c->player_health[i];
 return arcade_stamina_human_max(character);
}

static unsigned logical_from_internal(unsigned id){
 static const uint8_t reverse[12]={0,6,2,7,10,11,4,1,3,5,8,9};
 return id<12?reverse[id]:0;
}
static unsigned opponent_weight_index(unsigned group,unsigned roll){
 static const uint8_t weights[4][8]={
  {13,13,13,13,12,12,12,12},
  {17,17,17,17,16,16,0,0},
  {25,25,25,25,0,0,0,0},
  {50,50,0,0,0,0,0,0}
 };
 if(group>3)group=0;if(roll<1)roll=1;if(roll>100)roll=100;
 unsigned sum=0;
 for(unsigned i=0;i<8;i++){sum+=weights[group][i];if(roll<=sum)return i;}
 return 0;
}
void campaign_select_opponents(const campaign_t *c,unsigned roll_first,unsigned roll_second,unsigned out[2]){
 unsigned stage=campaign_stage(c);
 if(c->mode==CAMPAIGN_TAG&&(stage==4||stage==9)){out[0]=10;out[1]=11;return;}
 unsigned pool[8],count=0,a=arcade_stamina_internal_id(c->player_character[0]);
 unsigned b=arcade_stamina_internal_id(c->player_character[1]);
 for(unsigned id=0;id<12&&count<8;id++)if(id!=4&&id!=5&&id!=a&&id!=b)pool[count++]=id;
 while(count<8)pool[count]=pool[count?count-1:0],count++;
 unsigned group=stage>=5?stage-5:stage;if(group>=4)group=0;
 unsigned i1=opponent_weight_index(group,roll_first),i0=opponent_weight_index(group,roll_second);
 if(i1==i0)i1=i1?i1-1:i1+1; /* ROM $103F8-$10404 */
 out[0]=logical_from_internal(pool[i0]);out[1]=logical_from_internal(pool[i1]);
}
