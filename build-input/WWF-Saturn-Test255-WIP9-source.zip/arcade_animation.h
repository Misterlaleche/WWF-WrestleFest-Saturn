#ifndef WWF_ARCADE_ANIMATION_H
#define WWF_ARCADE_ANIMATION_H
#include <stdbool.h>
#include <stdint.h>
typedef struct {uint16_t duration,pose;} arcade_animation_frame_t;
typedef struct {uint32_t rom_address,callback_address;uint16_t first,count,kind;} arcade_animation_t;
typedef struct {uint16_t frame,remaining;bool finished;} arcade_animation_clock_t;
/* Descriptors recovered from ROM; callbacks require native gameplay handlers.
 * This clock does not execute 68000 code and does not emulate the board. */
void arcade_animation_reset(arcade_animation_clock_t *clock,const arcade_animation_t *animation);
void arcade_animation_tick(arcade_animation_clock_t *clock,const arcade_animation_t *animation);
uint16_t arcade_animation_pose(const arcade_animation_clock_t *clock,const arcade_animation_t *animation);
/* Unknown/callback-only descriptors return 0xffff, never a fake idle pose. */
uint16_t arcade_animation_sample(uint32_t address,uint32_t elapsed);
/* Exact finite visual length in Saturn ticks for a recovered descriptor.
 * Returns 0 for callback-held/unknown descriptors. */
uint32_t arcade_animation_finite_ticks(uint32_t address);
uint32_t arcade_action_descriptor_address(unsigned raw_action);
uint32_t arcade_action_callback_address(unsigned raw_action);
#endif
