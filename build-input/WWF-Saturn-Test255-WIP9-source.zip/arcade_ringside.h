#ifndef WWF_ARCADE_RINGSIDE_H
#define WWF_ARCADE_RINGSIDE_H
#include <stdbool.h>
#include <stdint.h>

enum { ARCADE_RINGSIDE_OBJECTS=2, ARCADE_OBJECT_HELD_STATE=1, ARCADE_OBJECT_THROWN_STATE=2, ARCADE_OBJECT_AVAILABLE_STATE=3, ARCADE_OBJECT_CONTACT=0x20 };
enum { ARCADE_OBJECT_PICKUP_TICKS=18, ARCADE_OBJECT_USE_TICKS=27, ARCADE_OBJECT_USE_RAW_X=0x60, ARCADE_OBJECT_USE_RAW_Z=0x40, ARCADE_OBJECT_AVAILABLE_RAW_Z=0x100 };
enum { ARCADE_CPU_WEAPON_DIRECT_X=0x68, ARCADE_CPU_WEAPON_MID_X=0x90, ARCADE_CPU_WEAPON_Y=0x0c };
enum { ARCADE_OBJECT_STATE2_PROBE=0x20, ARCADE_OBJECT_STATE2_COLLISION_BIT=0x10, ARCADE_OBJECT_POST_THROW_STATE=4, ARCADE_OBJECT_STATE4_TIMER=0x10, ARCADE_OBJECT_STATE4_PHASES=4 };
/* ROM $FA14 resets both autonomous objects to state 3 and +$0E=$0100. */
typedef struct {
    unsigned type;
    unsigned raw_x, raw_y;
} arcade_ringside_object_init_t;

/* ROM $FFD2: the two autonomous ringside objects. Coordinates are original
 * 68000 world coordinates and intentionally not pre-converted to Saturn pixels. */
const arcade_ringside_object_init_t *arcade_ringside_object_init(unsigned index);

/* ROM $F12E: available/unheld object and strict |dx|<0x20, |dy|<0x20 contact. */
bool arcade_ringside_pickup_contact(int fighter_x,int fighter_y,int object_x,int object_y,
                                    unsigned object_state,bool object_held);

/* ROM $1C79C->$23ED0: chance that CPU AI elects to seek an available ringside
 * object. Returns false when the ROM table for that internal character/stage
 * is not safely bounded by the next pointer; callers must then preserve the
 * current non-weapon AI rather than inventing a probability. */
bool arcade_ringside_weapon_seek_percent(unsigned logical_character,unsigned stage,unsigned *percent);
bool arcade_ringside_weapon_seek_roll(unsigned logical_character,unsigned stage,unsigned roll_0_99,bool *known);

/* ROM descriptors: type 0 uses $19E80 pickup / $159F8 use; type 1 uses
 * $19E90 pickup / $15A0C use. All four raw entries use duration byte 8; the original underflow clock makes each pose 9 effective ticks. */
unsigned arcade_ringside_pickup_descriptor(unsigned type);
unsigned arcade_ringside_use_descriptor(unsigned type);

/* CPU weapon branch $1CD5C->$1D032: only when |dy|<$0C.  |dx|<$68
 * selects action $1E directly; $68..$8F reaches a weighted action $1F path.
 * Actions 30/31 share the weapon-use descriptor. */
bool arcade_ringside_cpu_weapon_direct_contact(int dx,int dy);
/* ROM $1D032: for $68 <= |dx| < $90 and |dy| < $0C, $24CC is called
 * with table $1D066 = {0x32,0x32}. Result index zero selects action $1F;
 * therefore the demonstrated weighted decision is exactly 50/50. The caller
 * supplies the random roll because the native Saturn RNG source remains
 * provisional. */
bool arcade_ringside_cpu_weapon_mid_use(int dx,int dy,unsigned roll_0_99);
/* Test69: held-object human category $11 maps physical button1/2/both to action $1E. */
unsigned arcade_ringside_human_weapon_action(unsigned fresh_buttons);

/* ROM state dispatcher $FDEA selects state 2 handler $FE82.  $FE82 does
 * not consume persistent launch velocities: it sets +$3E=$20 and calls the
 * shared collision/boundary resolver $280DC. That routine clears +$38/$3A/$3C
 * on entry and writes correction deltas only on contact. If +$36 remains zero,
 * $FE82 retries with +$3E=-$20. If both probes report no contact, integration is
 * skipped entirely. Otherwise $FEE6/$FEEE/$FEF6 add the selected resolver
 * corrections to XYZ, and collision flag bit 4 advances state 2 to state 4. */
typedef struct {
    unsigned contact_code; /* resolver +$36; zero means no contact */
    int raw_dx, raw_dy, raw_dz; /* resolver +$38/+3A/+3C */
    unsigned collision_flags; /* resolver +$37 */
} arcade_ringside_state2_probe_t;
unsigned arcade_ringside_state2_integrate(int *raw_x,int *raw_y,int *raw_z,
                                           int raw_vx,int raw_vy,int raw_vz,
                                           unsigned collision_flags);
bool arcade_ringside_state2_apply_probes(int *raw_x,int *raw_y,int *raw_z,
                                          const arcade_ringside_state2_probe_t *forward,
                                          const arcade_ringside_state2_probe_t *reverse,
                                          unsigned *state_out);

/* Test61: shared resolver $280DC dispatches through the table at $28154.
 * The low three bits of global $1C007E are multiplied by eight; object +$32
 * bit 2 adds four, selecting the second pointer of each demonstrated pair.
 * $FFD2 initializes both ringside objects with +$32=$0004.  The table is
 * safely bounded for global modes 0..6 only; mode 7 is deliberately unknown. */
typedef enum {
 ARCADE_RESOLVER_ROUTE_UNKNOWN=0,
 ARCADE_RESOLVER_ROUTE_RTS,
 ARCADE_RESOLVER_ROUTE_28288,
 ARCADE_RESOLVER_ROUTE_2851E
} arcade_ringside_resolver_route_t;
bool arcade_ringside_object_resolver_route(unsigned global_mode,
                                            arcade_ringside_resolver_route_t *route,
                                            unsigned *raw_handler);

/* Test62: exact second-column resolver handler $2851E used by both ringside
 * objects when global mode 2 or 6 is active. Inputs are the raw D0/D1/D2
 * probe coordinates supplied by $280DC; raw_z_bias is object +$42. The
 * helper reproduces +$36 contact code, +$37 flags, and +$38/$3A/$3C
 * correction outputs. It intentionally does not assign a semantic meaning to
 * global modes 2/6 yet. */
bool arcade_ringside_resolver_2851e(int probe_x,int raw_y,int raw_z,int raw_z_bias,
                                     arcade_ringside_state2_probe_t *out);

/* Test64: exact first-column resolver handler $28288 used by both ringside
 * objects when global mode 0 or 5 is active. The X limits are sloped functions
 * of raw Y, computed with the original LSL.l #8 / signed DIVS.w #$02E0
 * sequence. raw_z_bias is object +$42, added only when Z is below $0100. */
bool arcade_ringside_resolver_28288(int probe_x,int raw_y,int raw_z,int raw_z_bias,
                                     arcade_ringside_state2_probe_t *out);

/* ROM state-4 handler $FF54. On first entry it starts phase 1 with timer
 * $10. Each later expiry reloads $10 and increments the phase; phase 4
 * writes state 3 at $FFC0, making the object available again. */
unsigned arcade_ringside_state4_step(bool *initialized,unsigned *timer,unsigned *phase);

/* Test65: exact $FEBC..$FEE0 two-probe orchestration around $280DC for the
 * bounded resolver routes recovered through Test64.  The caller supplies raw
 * object coordinates and +$40/+$42 biases exactly as $280F6..$28116 does.
 * `facing_flip` models object +$2E bit 7, which negates +$3E before each probe.
 * Returns true only when +$36 becomes non-zero.  `route_known` is false for
 * global mode 7, whose table entry is still intentionally unbounded. */
bool arcade_ringside_state2_resolve(unsigned global_mode,bool facing_flip,
                                     int raw_x,int raw_y,int raw_z,
                                     int raw_y_bias,int raw_z_bias,
                                     arcade_ringside_state2_probe_t *out,
                                     bool *route_known);

#endif
