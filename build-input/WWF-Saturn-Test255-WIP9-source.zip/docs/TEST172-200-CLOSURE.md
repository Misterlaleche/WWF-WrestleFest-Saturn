# Test172-Test200 / V0.187-V0.215 — ROM audit closure and Test200 runtime reconciliation

This sequence contains 29 concrete checkpoints. Tests172-199 are ROM-exact audits against `program.bin`; Test200 reconciles newly pinned clear-stage stamina semantics with the native Saturn runtime. No BIN/CUE is generated.

## Tests172-180 — linked actor / TAG / Royal cleanup

- Test172: `$21358` sets actor `+$B6 bit7`.
- Test173: non-null `+$7E` link has `+$B5 bit7` cleared and `+$B6 bit7` set.
- Test174: raw `+$61==$53` follows `+$26` and applies the `+$B6 bit7` mark to that actor.
- Test175: `$206FE` starts a four-entry cleanup at `$0C0744`, zeroing four longwords per `$100`-spaced entry.
- Test176: `$20156` selects raw effect `$3109` only for global `$1C0162==4/9`, otherwise `$3105`.
- Test177: `$213A6` splits on the TAG/Royal mode bit; TAG follows `+$26` and clears linked `+$34 bit0`.
- Test178: TAG cleanup tests linked `+$33 bit1` and clears `+$56 bit6` when set.
- Test179: TAG cleanup follows `+$86`; with `+$33 bit1` clear it clears `+$B5 bit7` and sets global `$1C1697 bit0`.
- Test180: Royal cleanup follows non-null `+$7E` and clears its `+$B5 bit7`.

These facts tighten actor-role cleanup around the `+$109` producer, but do not assign a gameplay name to `+$109` itself.

## Tests181-188 — Earthquake raw action `$47`

- Test181: phase 0 with zero `+$22` writes actor `+$01=2`.
- Test182: action `$47` has dedicated phase-1 offsets `$F8/$F0` instead of neighbouring `$F0/$28`.
- Test183: contact resolution requires `+$37 bit4`, sets `+$18 bit7`, then calls `$1110E/$11152`.
- Test184: contact branch A writes victim state 4, decrements `+$64` by 2, increments `+$C7`, sets `+$68=10`, emits `$2B/$32`.
- Test185: branch A increments victim `+$E0` only for neighbouring raw action `$46`; action `$47` takes `+$E2`.
- Test186: contact branch B writes victim state 5, `+$60=$77`, `+$68=10`, increments `+$C7`.
- Test187: phase `$FE` completes into actor state 7, sets `+$26 bit7`, calls `$10BD0` with `D0=$18,D1=-1,D2=0`.
- Test188: fallback extra `$FFD0` impulse is exclusive to neighbouring raw action `$46`, not `$47`.

The route is now substantially bounded mechanically. The human-readable identity of Earthquake action `$47` remains CANDIDATE until independently demonstrated; it is not promoted to Vertical Splash by inference.

## Tests189-195 — Signature / Super Throw callback operands

- Test189: Warrior's two Gorilla Press impact paths each write victim `+$68=$16` (22).
- Test190: Jake DDT writes `+$64=$23`, sets bits5/3, and exact `+$68=$1C` (28).
- Test191: Boss Man Slam writes `+$64=$2A`, increments `+$C7` by 5, writes exact `+$68=$16` (22), then sets bits3/5.
- Test192: Smash Suplex writes `+$64=5`, exact `+$68=$12` (18), then sets `+$64 bit5` and `+$32 bit3`.
- Test193: Perfect Plex contains two exact `+$68=$16` (22) victim writes; alternate branch also writes `+$60=$5E`.
- Test194: Slaughter Cobra Clutch pulse is exact `+$68=5 -> $111C8`; alternate release writes victim `+$60=$62`, sets flags and invokes `$215B6`.
- Test195: DiBiase Million Dollar Dream pulse is exact `+$68=5 -> $111C8`; alternate release writes victim `+$60=$63`, sets flags and invokes `$215B6`.

Per-pulse hold operands remain distinct from total hold damage/cadence.

## Tests196-200 — exact clear-stage stamina restore

- Test196: `$90D6` iterates four actor records from `$1C05B0` at stride `$10C`, skipping records with `+$FF bit0` set.
- Test197: restore amount comes from global config `$1C0066 bits $6000` through exact table `{24,32,12,0}` at `$912A`.
- Test198: the same amount is added to live stamina `+$66` and queued stamina delta `+$6A`.
- Test199: live `+$66` is clamped to actor maximum `+$72`; the separately queued `+$6A` addition is preserved.
- Test200: native TAG `game_clear_stage_restore()` is regression-validated against those exact semantics: human-role exclusion, table values, max clamp and queued HUD/stamina delta behavior.

## Validation

- Complete host regression: **192/192 PASS**.
- Targeted ASan/UBSan for Tests172-200: **29/29 PASS**.
- No SH-2/Yaul runtime source was modified by Tests172-199; Test200 is a runtime reconciliation test, not a new gameplay semantic guess.
- No hardware BIN/CUE generated.
