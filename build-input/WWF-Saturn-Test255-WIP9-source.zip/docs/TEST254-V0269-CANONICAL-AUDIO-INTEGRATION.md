# Test254 / V0.269 — canonical audio subsystem integration

Base gameplay: **Test253 / V0.268**.  This checkpoint deliberately does **not**
replace the gameplay baseline with the older Test200-era gameplay snapshot that
was bundled with the audio research package.

The integration contract was read first from
`docs/audio/INTEGRATE-WITH-CURRENT-GAMEPLAY.md`.

## Package integrity

`WWF-Saturn-Audio-Complete-Integration` was verified against its supplied
`SHA256SUMS-AUDIO-COMPLETE.txt`: **596/596 entries match**.  The verification log
is retained at `docs/audio/package-sha256-verification.log`.

## Canonical audio modules integrated

The current gameplay tree now carries the package's audio event/command,
recovered OKI sequencing/index/decode, CDDA command layer and poneSound/SCSP
boundary:

- `wf_audio_event.c/.h`
- `wf_audio_sfx.c/.h`
- `wf_audio_adpcm_index.c/.h`
- `wf_oki_decode.c/.h`
- `wf_music_cdda.c/.h`
- `wf_audio_saturn.c/.h`
- `ponesound_min.c/.h`
- `assets/SDRV.BIN`
- `cd/AUDADP.PAK`
- all `music-vgm/FM01..FM12.vgm.gz` source masters plus `MUSIC-MANIFEST.json`
- CDDA renderer/fetch/build tools and focused audio host regressions.

`audio-tracks/` intentionally contains no generated CDDA `.BIN` tracks in this
source-only checkpoint.  They are to be rendered from the recovered VGM masters
when a disc build is explicitly requested.

## RECOVERED_ROM associations preserved

The command number remains the integration key; no command is renamed or
reinterpreted.

- stage music table: `04,0A,0C,0F,06,04,0A,0C,0F,06`
- stamina warning threshold: `< 0x18` -> FM command `0x0B`
- leaving the warning path -> restore the current stage music command
- displayed ring-out counts 17/18/19/20 -> commands `0x65/0x66/0x67/0x68`
- long heavy/finisher reaction layer -> command `0x32`

The audio package itself notes an important evidence boundary: mapping the
recovered low-stamina rule onto native Saturn active-human `fighters[0]` is a
Saturn role binding, not a newly recovered arcade actor-role rule.  In the
current gameplay architecture this remains valid across TAG because
`swap_fighters()` promotes the active teammate into slot 0.

## Saturn transport adaptation — PROVISIONAL infrastructure, exact payloads

The package reference `wf_audio_saturn.c` kept the complete 438,658-byte
`AUDADP.PAK` plus a 40 KiB decode staging area resident in HWRAM.  Test253 has a
much larger graphics/runtime footprint than the Test200 audio baseline, so
copying that policy verbatim would consume roughly 480 KiB of persistent HWRAM
and risk destabilizing the canonical gameplay.

Test254 therefore changes **storage policy only**:

- the full `AUDADP.PAK` remains the canonical source asset;
- at initialization, the backend reads only the payloads that have current
  RECOVERED_ROM gameplay producers;
- exact OKI bank-0 samples `18,69,70,71,72` are decoded with
  `wf_oki_decode_pcm8()` and copied into SCSP RAM;
- initialization uses at most ~52 KiB of temporary HWRAM scratch and frees it;
- persistent HWRAM audio-payload cost after initialization is **0 bytes**;
- the five decoded payloads occupy 49,540 bytes of SCSP sample data, ending at
  approximately `0x201B6`, below the reserved dynamic/music regions used by the
  package architecture.

The original package backend is preserved byte-for-byte for reference in
`docs/audio/reference-runtime/wf_audio_saturn-package.c/.h`.

This transport adaptation is **PROVISIONAL Saturn infrastructure**.  The command
IDs, OKI source bytes, decoder and SFX event sequences are not altered.

## Registered but not automatically emitted

`wf_audio_sfx.c` still contains the complete recovered command table for
`0x20..0x81`.  The current gameplay event layer has proven producers only for
`0x32` and `0x65..0x68`; Test254 does not invent gameplay triggers for the other
commands.  They remain canonical audio evidence / **REGISTRADO PERO NO
IMPLEMENTADO as gameplay bindings** until their 68000 producers are recovered.

Likewise the VGM set preserves FM commands `0x01..0x12`; Test254 only invokes
commands justified by the recovered stage/low-stamina mappings.  No title,
selection, wrestler-entry or victory music assignment is guessed from sound
alone.

## Gameplay preservation audit

The audio package's gameplay/AI source was compared against Test253 before
integration:

- `arcade_ai.c/.h`: byte-identical to Test253;
- `arcade_action_map`, `arcade_moves`, `arcade_ringside`, `arcade_rumble`,
  `arcade_stamina`, `campaign` and `campaign_runtime`: byte-identical;
- `arcade_animation_data.h`: byte-identical;
- `arcade_animation.c/.h`, `game.c/.h`, `main.c` and presentation/render files
  in the package are older than the current baseline.

Therefore none of the package's old gameplay files were used to replace current
Test253 runtime code.  The intended gameplay changes in Test254 are limited to
calling the audio observer/backend and resetting its latch state when a native
match is restarted.

## Cross-domain evidence found in the audio package

There is **no hidden newer graphics, animation or AI implementation** in this
ZIP.  Its non-audio gameplay source is either identical to or older than the
current checkpoint.  It does, however, add useful exact timing/semantic anchors
for future ROM work:

- command `0x32` is an independent recovered marker for the long
  heavy/finisher-reaction impact path; this can be cross-correlated with the
  exact animation callback/impact frame rather than choosing an effect by eye;
- commands `0x65..0x68` anchor the final displayed ring-out counts 17..20 and
  can be used when reconstructing referee/countout presentation timing;
- command `0x0B` and its stage-music restore path anchor the low-stamina state
  transition, useful when auditing stamina-dependent AI/behavior;
- the ten-entry stage music table gives a reliable audio-side anchor for
  campaign/stage presentation transitions.

These are cross-checks, not permission to infer new sprite poses, AI decisions
or presentation choreography without 68000/game-ROM evidence.

## Validation

- package SHA256 manifest: **596/596 PASS**;
- corrected Test254 event/binding regression: **PASS**;
- recovered SFX sequencer regression: **PASS**;
- ADPCM index/layout regression: **PASS**;
- exact sample-18 OKI decode against package PCM reference: **PASS**;
- Test254 hot-set sector/index/SCSP layout regression: **PASS**;
- focused audio tests under ASan/UBSan: **PASS**;
- `wf_audio_saturn.c` host syntax build against a minimal Yaul API stub with
  `-Wall -Wextra -Werror`: **PASS**;
- historical gameplay suite: ran through a long sequence of existing tests with
  no observed failure before the environment time limit; it requires external
  `program.bin` for several ROM assertions and is not claimed as a complete run;
- Yaul/SH-2 compile/link: **NOT RUN** in this environment (SDK unavailable);
- emulator/hardware audible validation: **NOT RUN**;
- BIN/CUE/ISO: **NOT GENERATED**.

## Classification summary

### RECOVERED_ROM

Command identities/tables and mappings listed above; Z80-derived FM masters;
OKI command/sequencer/index data; exact ADPCM payloads; exact OKI decoder
behavior represented by the package evidence.

### PROVISIONAL

Saturn-specific memory/storage strategy for the hot SFX set and native actor-slot
binding where explicitly identified as a Saturn integration choice.

### REGISTRADO PERO NO IMPLEMENTADO

Gameplay producers for the remaining recovered SFX command table; final rendered
CDDA tracks until an image build is requested; audible validation on Saturn;
semantic assignment of unbound music commands to presentation scenes.
