# Tests145-147 / V0.160-V0.162 — Signature / Super Throws fidelity

## Test145 — exact hold pulse operands

ROM program SHA256 remains the canonical user ROM payload. At `$17ECE` (Sgt. Slaughter route) and `$179C0` (Ted DiBiase route), the program contains the same sequence:

`MOVE.w #$0005,+$68(A2)` -> `JSR $000111C8`.

This proves a **5-point callback pulse operand**. It does not prove total damage or repetition cadence. Those remain **REGISTERED BUT NOT IMPLEMENTED/SEMANTICALLY CLOSED**.

## Test146 — Earthquake false candidate gated

The old Earthquake candidate used raw action `$23`, descriptor/address `$15CE0`. Test136 already proved independently that raw action `$23 -> $15CE0` is **STOMP**. Therefore treating the same exact raw action as Vertical Splash is contradictory. Test146 changes runtime gating so only `FINISHER_EVIDENCE_HIGH_CONFIDENCE` entries are gameplay-ready. Earthquake remains `CANDIDATE` and is unavailable instead of fabricating a finisher.

## Test147 — new Earthquake raw route

The recovered action table gives, for selection character 8 (Earthquake), prone category `$07`, fresh button 1:

- raw action `$47`;
- descriptor `$14440`;
- callback `$14458`;
- first recovered pose 132.

This is **ROM-EXACT control/data recovery**. The human-readable move name is still **CANDIDATE** until callback semantics and the required composition/overlay are closed.

## Validation

- Host regression in four bounded shards: **142/142 PASS**.
- Targeted ASan/UBSan: Tests145, 146, 147 and the nine-high-confidence finisher runtime: **PASS**.
- SH-2/Yaul compile and link: **PASS**.
- ISO generation: **PASS**, used only for build validation. No Test147 BIN/CUE package published.

## Test148 — Earthquake action-$47 callback prelude

Callback `$14458` is now modeled as a raw helper without assigning unsupported move semantics. Exact branch/write sequence recovered: actor `+$60 bit7` or `+$1C bit7` takes the early branch; otherwise actor `+$01` is cleared, `+$5C=$0600`, `+$5E=$0048`, and D0 is selected as 5 only when target `+$21==$05 && +$61==$61`, else 2, before `JSR $26AE`.

## Test149 — D0=2/5 is not damage

`$26AE` begins `LEA $275C,A1; LSL.w #2,D0; MOVE.w (A1,D0.w),D4; MOVE.w 2(A1,D0.w),D5`. Therefore the callback's D0 values are 4-byte table selectors. They are explicitly **not treated as damage operands**.

## Test150 — exact selected effect vectors

The ROM table selected by `$26AE` contains selector 2 = `{$0038,$FFF8}` and selector 5 = `{$0040,$FFFF}`. These are preserved as raw effect/vector evidence; no gameplay-semantic label is claimed yet.
