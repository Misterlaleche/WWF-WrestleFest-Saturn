# Tests223-225 — functional attract-style loading

## Evidence classification

### FUNCTIONAL / VALIDATED NATIVE
- Technos -> title is intercepted by a dedicated staged boot-load state.
- The loading surface reaches VDP1/VDP2 before any staged blocking CD read.
- Boot stages preload SELECT0/1 RLE+PAL, MODE RLE+PAL, ENTRY.RLE and TITLE.ANM.
- TITLE.ANM is hash-validated during loading and consumed without a second CD read by the title presentation.
- Per-match loading is entered when HALL/ANNOUNCE requires wrestler packs that are not resident; the actual native match is selected first and its roster packs are loaded under the visible surface.
- The subsequent RING.BIN/RING.PAL read occurs while the previously rendered loading frame remains on screen.
- 512-byte palette CD transfers use a 2048-byte capacity buffer, preserving the hardware CHECK301 rule.

### ARCADE-DERIVED VISUAL MATERIAL
- The loading portrait is generated from the already recovered arcade HUD 3x3 portrait tiles/palette for the selected wrestler and enlarged by nearest-neighbour 3x. No new wrestler artwork is invented.

### PROVISIONAL
- The loading dialogue box geometry.
- The use of the HUD portrait as a stand-in for the larger animated attract/demo portrait.
- Text such as `HOLD ON, BROTHER!`, `THE WWF IS LOADING...`, `GET READY FOR ACTION!`, and `PREPARING THE MATCH...`.
- Portrait animation is currently limited to loading-panel motion/blink/progress treatment; the exact arcade attract portrait frame sequence has not yet been recovered.

### REGISTERED BUT NOT IMPLEMENTED
- Exact attract/demo portrait animation and speech-window composition from the original ROM/capture.
- Stage-specific ring cache/preload once multiple exact ring backgrounds are integrated.
- Audio cues/voice during loading.

## Memory strategy

The boot loader deliberately caches only reusable front-end resources that are cheap enough to keep in Work RAM. Fighter packs remain match-specific and continue to use the low-RAM roster allocation strategy. This avoids attempting to hold every wrestler/ring/audio asset simultaneously.
