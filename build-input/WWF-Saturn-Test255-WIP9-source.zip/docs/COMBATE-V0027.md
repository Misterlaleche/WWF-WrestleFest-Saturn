# WWF WrestleFest Saturn — combate V0.027

4 de septiembre de 2026 · Base: V0.026 / Test15 V0.025.

## Resultado

Este bloque amplía el bucle real de agarre sin introducir sprites inventados.

1. **Reversal de agarre.** Cuando la CPU controla `PAIR_HOLD`, L/GRAB durante
   ticks 8–30 cambia el atacante al jugador. El plan de dibujo ya dependía de
   `pair_attacker`, por lo que la misma composición capturada cambia de roles.
   La alineación se recalcula como pareja completa y conserva el contacto.
2. **Escape separado de contra.** A/B sigue sumando `grapple_escape`; no activa
   la inversión. Así escape y reversal son dos decisiones distintas.
3. **Contra CPU provisional.** Un agarre prolongado por el jugador puede dar a
   la CPU una oportunidad determinista de invertirlo. Solo se permite un cambio
   de dueño por toma. La regla se etiqueta nativa/provisional.
4. **Irish Whip.** B desde `PAIR_HOLD` libera la pareja y fuerza al defensor a
   usar `ST_RUN`/`ST_REBOUND`, las velocidades de personaje y los descriptores
   de carrera/rebote ya integrados. Tras un rebote regresa al punto de origen y
   frena. Un impacto cancela la carrera forzada.
5. **Cancelación.** A+B simultáneos durante el agarre conservan una salida nativa
   sin convertirla accidentalmente en Irish Whip.

## Finishers

Se añadió `finisher_data.h` con la identidad de los diez trademark moves del
roster. `finisher_graphics_ready()` devuelve falso para todos en V0.027 de forma
intencionada. Un finisher no se habilita hasta tener:

- composición original del atacante;
- composición/reacción original de la víctima cuando corresponda;
- secuencia temporal/descriptor validado;
- callback/condición de activación mapeados;
- test de daño/finalización y render por ambos sentidos.

Esto evita reutilizar el body slam como sustituto visual de DDT, Perfect Plex,
Gorilla Press, etc.

## Pruebas nuevas

- `grapple_counters`: ventana, role swap, posiciones, daño exacto una vez,
  escape A/B, contra CPU, anti ping-pong y pausa.
- `irish_whip`: ambas direcciones, rebote, regreso, bloqueo de control,
  interrupción por golpe, cancelación y frontera de ring.
- `finisher_registry`: las diez identidades y la garantía de que ninguna se
  expone como lista antes de sus gráficos.

Las 20 suites host pasan. Las 20 se ejecutaron también con ASan/UBSan en dos
lotes porque la ejecución conjunta supera el tiempo del runner; no hubo fallos.

No se ha generado BIN/CUE/ISO/ELF en esta revisión.
