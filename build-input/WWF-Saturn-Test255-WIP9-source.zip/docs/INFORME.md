# WWF WrestleFest Saturn — Test15 V0.025

4 de septiembre de 2026 · Base: COMBAT DEV V0.024.

## Entrega

Esta revisión incluye **BIN/CUE para probar en Saturn NTSC-U con MODE**, fuentes,
recursos y pruebas. No requiere cartucho de RAM. No se ha escrito en GitHub.

Se ha compilado y verificado el disco, pero **no se ha arrancado esta build en
Saturn real, MiSTer ni Mednafen**. Sigue siendo una prueba de desarrollo:
no se presenta como el juego completo ni como una alpha equivalente al arcade.

## Cambios nuevos y revisión de capas

| Hallazgo | Corrección implementada |
|---|---|
| Las pruebas antiguas y el render real de Saturn usaban caminos de ordenación distintos | Un único plan de dibujo, consumido por Saturn y por los nuevos tests; incluye los seis slots |
| El renderer pintaba agarres/pins después de todos los compañeros, aunque uno estuviera más cerca | La composición doble participa en la ordenación por profundidad junto a los compañeros |
| Un luchador tumbado podía adelantarse visualmente por el desplazamiento de su pose | Se conserva la profundidad de suelo al ordenar derribado/recuperación; levantarse no introduce ese salto |
| Cualquier luchador fuera del ring se enviaba al primer plano | Se separa el exterior trasero/lateral del exterior frontal |
| Varios cuerpos sobre las cuerdas seguían el orden de slot | Se ordenan por profundidad, conservando completas las composiciones de esquina, salto y cruce |
| Era difícil distinguir una pieza tapada de una pieza ausente | Cuatro vistas de inspección de capas durante la pausa |

El árbitro caminando sigue la profundidad de la escena. Arrodillado, contando
o incorporándose conserva la prioridad sobre los cuerpos en el suelo.
Las cuerdas delanteras mantienen su capa propia.

No se han quitado piezas de los luchadores para resolver la oclusión.
Se ha comprobado que el reparto de piezas de las tres composiciones dobles
cubre todos sus registros para los diez bancos, sin omitir ni duplicar rangos.

### Diagnóstico en Saturn

Pulsa **START** en combate y después **C** para alternar:
todas las capas; sin cuerdas superpuestas; actores con bitmap de fondo;
entorno sin actores. El HUD desaparece en las vistas parciales.
START reanuda y restaura la imagen completa.

La simulación queda detenida durante la inspección. C sigue siendo relevo
cuando no estás en pausa. La pausa muestra `TEST15 V0.025` para identificarla.

**Límite detectado:** parte del ring y las cuerdas traseras siguen incorporadas
al bitmap de fondo. No son todavía capas independientes y no desaparecen con
el filtro de cuerdas VDP1. Resolver todas sus oclusiones desde el exterior
requiere separarlas; esta build no afirma haber cerrado ese trabajo.

## Avances anteriores incluidos en este disco

El usuario recibió V0.023/V0.024 como fuentes; ahora quedan compilados en la prueba:

- Recuperación con pulsaciones A/B, CPU de combate/relevo y resultados en RAM.
- Brazo en carrera con seis poses originales para siete luchadores.
- Patadón con dos poses originales para Hogan y Earthquake.
- 46 composiciones gráficas adicionales por personaje, **no 46 movimientos**.
- Bancos WFC2 comprimidos y lector C. Los seis bancos más grandes ocupan
  915.456 bytes alineados y caben en RAM baja.
- Se conservan selección, presentación, combate, HUD y flujo básico
  de resultado/continue/gameover de la base.

Estos son avances heredados, no acciones nuevas añadidas durante esta revisión
de capas. El detalle del bloque de combate está en `docs/COMBATE-V0024.md`.

## Verificación

| Comprobación | Resultado |
|---|---|
| Suites host | 16 pasan |
| Las mismas con ASan/UBSan | 16 pasan; LeakSanitizer desactivado |
| Orden de dibujo | 60.000 actualizaciones TAG/Rumble, plan sin mutaciones, sin actores duplicados |
| Regresiones de combate heredadas | 50.000 ticks adicionales; pruebas de ataques, recuperación, pin, CPU y relevo |
| Lector de gráficos | 13.574 tiles, diez bancos, hashes y casos malformados |
| Comparación visual | Nueve imágenes reconstruidas desde recursos reales y código C compartido |
| Diferencias antes/después | Pin/compañero: 1.089 píxeles; derribado: 699; exterior trasero: 1.190 |
| Esquina CPU de control | Imagen idéntica, composición completa conservada |
| Cota conservadora de combate | 788 de 1.024 comandos, contando seis personajes distintos y reservas para UI |
| Cota de tiles dinámicos | 228 de 512, sin suponer reutilización |
| Texturas VDP1 | 341.344 bytes; particiones y alineación comprobadas |
| Compilación/enlace | SH-2 con Yaul; cuatro advertencias RWX del enlace documentadas |
| Archivos del disco | Los 25 coinciden byte a byte con los de la compilación, incluido A.BIN |
| BIN/CUE | 1.893 sectores MODE1/2352, cabecera Saturn y área USA |
| Lectura independiente | libcdio lee el CUE y recupera todos los bytes del ISO |
| Integridad de sectores | EDC bit a bit y ECC contrastado con las tablas de MAME |
| Arranque físico/emulado y FPS | **No realizados en esta revisión** |

La comprobación ECC utiliza las tablas del
[código primario de MAME para CD-ROM](https://github.com/mamedev/mame/blob/master/src/lib/util/cdrom.cpp).
El informe técnico guarda el SHA256 del fichero de referencia utilizado.

Las imágenes de la auditoría son reconstrucciones software, no fotos ni
capturas de Saturn. La cota de comandos se refiere a los recursos actuales
de combate: no mide tiempo de dibujo, transferencia, descompresión ni FPS.
Los logs y JSON vigentes están incluidos en las fuentes.

## Prueba recomendada en hardware

Descomprime el paquete en una carpeta nueva y conserva juntos el BIN y su CUE.
No mezcles este CUE MODE1/2352 con el ISO/CUE intermedio de Yaul MODE1/2048.
Mantén el test anterior para comparar.

1. Inicia TAG y comprueba las ayudas durante un pin y el árbitro.
2. Prueba derribo/levantamiento cerca de otro cuerpo y varias esquinas.
3. Recorre el exterior, vuelve al ring y compara ambos lados.
4. Usa START + C sobre un solapamiento para ver qué pieza queda tapada.
5. Prueba Rumble con varios cuerpos visibles.

Si aparece DATA ERROR, envía la pantalla completa. Para defectos gráficos:
personajes, acción, Saturn/MiSTer y un vídeo que incluya el momento anterior.

## Trabajo que sigue pendiente

- Muchas acciones específicas, finishers, contras y transiciones originales.
- Reglas, automatizaciones, IA y dificultad equivalentes al arcade.
- TAG Tournament y Royal Rumble completos.
- Fidelidad final del HUD, presentación, entrada y pantallas finales.
- Records persistentes y continuidad completa entre combates.
- Separación adicional del escenario y oclusiones del exterior.
- Medición y ajuste de velocidad en hardware.
- Música, voces y efectos.

No se ha rediseñado el HUD ni añadido audio en este bloque.
No se promete que todos los fallos gráficos estén resueltos.

Los recursos derivados de tus ROMs son de uso privado. No publicar el paquete
ni las fuentes con esos recursos en GitHub u otros repositorios públicos.
