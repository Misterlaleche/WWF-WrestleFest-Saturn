# Tests 232-234 — exact RISE asset closure

## Test232 — exact resident compositions without sprite-ROM reconstruction
**ROM-EXACT for the listed character/pose pairs.** The current 207-frame Cxx packs already contained exact captured legacy compositions whose sprite-code lists match raw ROM poses. The packs are extended to 212 frames by duplicating those existing tile records with only the coordinate/mirror transform required by the ROM composition decoder. No pixels are fabricated and no external art is introduced.

Recovered aliases:
- Hulk Hogan: raw poses 104, 112, 113.
- Jake Roberts: raw poses 104, 110, 111.

## Test233 — pack population
All six aliases resolve to populated WFC2 frames in the affected C00/C02 packs. All ten pack hashes and decompression are revalidated by `test_roster_pack`.

## Test234 — fallback remains narrow
Other characters' missing RISE compositions and all currently missing GROUND PICK UP / GROUND ATTACK / object compositions remain unmapped and therefore continue through the bounded Test212 family fallback. This checkpoint does not claim those assets recovered.

The full sprite region is still required to reconstruct the remaining unique compositions. The MRA in Library proves the exact gfx2 ROM lane set, but does not itself contain the ROM bytes.
