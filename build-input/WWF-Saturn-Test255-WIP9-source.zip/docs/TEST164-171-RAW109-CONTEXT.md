# Tests164-171 — raw +$109 producer linked-actor and mode context

Checkpoint: **Test171 / V0.186**

This block continues from canonical Test163/V0.178. It is ROM-audit/test/documentation-only and deliberately avoids assigning a high-level gameplay semantic to raw `+$109`.

- **Test164 ROM-EXACT:** `$20058` resolves `A1=A0+$56`, then `A2=A1+$26`; producer ticks local countdown on A0 while the incremented `+$109` belongs to the second linked actor A2.
- **Test165 ROM-EXACT:** on expiry, local phase `+$25` and linked `+$109` advance together; phase parity selects a distinct branch, and local state 5 promotes to state 6 with countdown `$38`.
- **Test166 ROM-EXACT:** phase 6 adds `$10` to countdown and then splits on global mode bit `$1C0161`; the two branches are structurally distinct.
- **Test167 ROM-EXACT:** terminal handling is mode-dependent: clear `$1C0161` writes actor `+$20=$8009` and linked `+$4A=4`; set `$1C0161` takes the alternate helper and writes actor `+$20=$8005`.
- **Test168 ROM-EXACT:** even producer phases increment global `$1C169A` and derive helper input from actor `+$24>>1`. `$1C169A` is independently recovered as ring-out/count storage.
- **Test169 ROM-EXACT:** clear-`$1C0161` (TAG) phase-6 path calls `$21358` on the `+$56` link, increments its `+$C4`, follows `+$26`, and sets bit4 of that actor's `+$32`.
- **Test170 ROM-EXACT:** set-`$1C0161` (Royal Rumble) phase-6 path writes raw role `$4000` to the two `+$86`-linked actors and raw role `$4001` to the `+$26` side and its `+$86` link, proving explicit four-actor role reassignment.
- **Test171 ROM-EXACT:** Royal phase-6 cleanup clears global `$1C169E`, calls `$90D6`, then returns. `$90D6` is independently recovered as the clear-stage stamina restore routine.

## Validation

- Complete host regression: **163/163 PASS** using parallelized equivalent execution of the `tools/check_host.py` matrix.
- Targeted ASan/UBSan for Tests164-171: **PASS**.
- Runtime C/SH-2 source was not modified by Tests164-171; Test147/V0.162 remains the latest Yaul compile/link PASS.
- No new BIN/CUE generated.

## Fidelity boundary

The `+$109` route is now tied to a secondary actor substate, a second linked actor, explicit TAG/Royal mode branches, ring-out/count storage, Royal role reassignment, and a stamina-restore cleanup path. This materially narrows its gameplay context, but it still does **not** prove that `+$109` itself means fatigue, aggression, recovery phase, attack cadence, or another named mechanic. The equality comparison against stamina bucket `+$BD` remains ROM-EXACT; semantic promotion to live stamina-tier CPU behavior remains blocked until the label/behavior is demonstrated from ROM flow.
