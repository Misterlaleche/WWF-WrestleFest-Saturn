# Tests220-222 — post-match and Royal presentation cleanup

- **Test220:** introduces a resolved-side post-match role helper. Winner/defeated ownership is derived only from the resolved match state.
- **Test221 PROVISIONAL:** TAG winners, after reaching the centre staging point, reuse already recovered character presentation gesture frames instead of freezing idle. These frames are **not** promoted to the exact arcade clap descriptor. Demolition remains idle rather than inventing unsupported frames.
- **Test222 PROVISIONAL:** Royal announce actors are arranged in a bounded 3x2 grid and the two unrelated character-logo plates are removed from Royal. Exact arcade Royal coordinates/timing remain pending.

The exact TAG victory clap, defeated/sad animation, and their ROM control-flow identities remain **REGISTERED BUT NOT IMPLEMENTED**.
