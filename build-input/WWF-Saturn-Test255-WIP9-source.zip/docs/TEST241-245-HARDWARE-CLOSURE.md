# Tests241-245 / V0.256-V0.260 — hardware feedback closure

- Test241: adds a shared pre-hold grapple struggle. Both roles remain in one paired composition while action-button edges accumulate; the higher effort side becomes hold owner. Arcade existence/behavior comes from hardware/user reference. Exact PCB threshold, timeout and CPU cadence remain PROVISIONAL.
- Test242: presenter stops the front-facing announce loop before leaving, uses a turn cue and then an exit-walk alternation while moving toward the upper/rear rope. The recovered presenter bank contains only seven front/side compositions; exact rear-view art remains unavailable and is NOT mislabeled ROM-EXACT.
- Test243: lateral run rebound latches the rope actually contacted before facing reverses. Rope deflection uses that contact side instead of re-inferring side from the already-clamped actor position.
- Test244: finisher ownership has priority over ground-action use of the single Fxx overlay slot for the whole rendered frame. This closes the Test238 overlay overwrite path that could surface as CHECK338 in attract/demo.
- Test245: Test212 fallback is no longer state-family-wide. It is restricted to the explicit unresolved raw-pose registry (RISE 104/110-113, PICK UP 395/206-210, ground 470-471/263-267/248/292-294/516-520, objects 114-123). Unknown missing poses now fail closed.

## Exact partner-dependent asset audit
A program.bin composition-signature audit was run against every current Fxx source pose and every unresolved registered pose. Beyond the already integrated Warrior 263/264 and DiBiase 248 overlaps, there are no further byte/command-identical target compositions in the current Fxx banks. Therefore no extra pose is falsely promoted to ROM-EXACT. Further exact atlas closure requires the original assembled sprite region or a new validated capture containing those compositions.
