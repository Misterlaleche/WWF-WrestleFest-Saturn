# Tests120-124 / V0.135-V0.139 — Royal Rumble ROM reconciliation

These tests extend the canonical Test118 queue/lifecycle rather than replacing it.

- Test124: ROM `$10ACC` exact six raw opening anchors.
- Test120: ROM `$10AF0/$10B26` six-word reverse free-slot scan, index 5 -> 0.
- Test121: ROM `$BB30` replacement service waits exactly `$0126` (294) ticks and only services below six active actors.
- Test122: ROM `$BB80/$BC00` two-pool (IDs 0-5 / 6-11) balancing plus four random tries and reverse-scan fallback recovered as an isolated exact selector. The current Saturn session queue remains ten characters because Hawk/Animal asset packs are not yet present; therefore the exact 12-ID selector is not yet wired as the live identity source.
- Test123: canonical Test118 replacement lifecycle now uses the exact `$0126` delay and exact six-slot reverse free scan. Existing visible announcement duration, entry duration and native entry geometry remain PROVISIONAL.

The Test118 properties remain preserved: six live slots are separate from the overall entrant queue, human elimination ends the Rumble, and player victory requires queue exhaustion plus final-survivor state.
