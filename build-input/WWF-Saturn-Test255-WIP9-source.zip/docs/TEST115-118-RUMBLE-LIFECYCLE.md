# Tests115-118 — Royal Rumble entrant lifecycle

Checkpoint target: Test118 / V0.133.

## Test115 — complete entrant queue
Rumble session construction now produces a unique ten-wrestler order with the human selection first. The order after the human remains **PROVISIONAL** because the original arcade RNG core/source has not yet been recovered; this test validates uniqueness, completeness and ownership only.

## Test116 — elimination/replacement ownership
The six live fighter slots are now explicitly separated from the entrant queue. CPU elimination clears its active bit, increments elimination statistics once, consumes the next queued identity, exposes an announcement phase, then activates the replacement through an entry phase. Announcement/entry timings and native entry geometry are **PROVISIONAL** pending ROM/video measurement.

## Test117 — player elimination
Human over-rope elimination ends the Rumble immediately and does not consume a queued replacement.

## Test118 — final survivor
The human is declared winner only when all other active fighters are gone, no replacement is pending and the entrant queue is exhausted.

## Validation
- New targeted host tests Test115-Test118: PASS.
- Full host regression: 114/114 binaries PASS using parallelized equivalent compilation/execution of `tools/check_host.py` test matrix.
- Targeted ASan/UBSan Test115-Test118: PASS.
- No Saturn BIN/CUE generated.
