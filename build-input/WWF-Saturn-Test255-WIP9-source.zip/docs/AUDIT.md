# Test13 implementation and validation notes

Base: user-tested Test10-R1. This revision has not been booted on Saturn, MiSTer or Mednafen in this environment.

## Graphics and presentation

The Test10 environment exporter decoded every non-sprite tile with the background decoder, including the `fg4` foreground composites used for the GET UP hand. Test13 handles fg4 as four independently decoded 8×8 foreground tiles. Both resulting 80×96 poses, including padding and palette values, were compared exactly with the saved arcade foreground maps at `power_coin/p6060` and `p6062`.

The roster cursor's measured inclusive arcade rectangle is x=27..114, y=35..122, with 96-pixel column/row spacing. The displayed-page offset is subtracted before placement. A private UI palette entry changes its green intensity from 12 to 31 and back; the active mode has a distinct bright frame and explicit label. Geometry is shared with host tests.

Seven presenter poses come from sprite bank 8 of the original ring-introduction capture, assigned a separate Saturn palette. Eight individual logo designs and the shared Demolition design come from original foreground maps for all ten characters. Demolition is integer-reduced 2:1 to fit the individual logo slot. The introduction is a new native composition, not a claim of original arcade timing or dialogue.

## Memory map

| CRAM indices | Use |
|---|---|
| 256–415 | Ten wrestler palettes |
| 512–847 | Environment, referee, hand and UI |
| 848–863 | PRESS START |
| 864–879 | Presenter |
| 1024–1279 | Background or title page 0 |
| 1280–1535 | Title page 1 |
| 1536–1791 | Entrance crowd |
| 1792–2031 | Logos; 240 entries maximum |
| 2032–2047 | HUD font, left untouched |

ENV.TEX is 231424 bytes, fitting the existing 262144-byte high-RAM staging buffer including sector rounding. The Test10-R1 high-RAM-only graphics DMA guard and post-upload hash remain enabled. VDP1 has 768 commands and a 65536-byte visible-character buffer. No expansion RAM is addressed.

## Timing and rendering

The existing Yaul VBlank-out callback counts video intervals. `timing_steps` converts elapsed NTSC intervals into 57.445-Hz logic ticks; maximum eight-interval catch-up bounds stalls, and loading transitions reset the snapshot. Tests show identical logic tick totals for 600 one-interval renders and 300 two-interval renders. This does not establish hardware FPS; Y shows measured completed frames per second.

Text is flushed only when content changes. Dynamic tile lookup uses a bounded 1024-entry hash table instead of scanning up to 512 tiles per piece. The established one-shot VDP1 plotting, CHANGE_ONLY swap and full-screen clear polygon remain.

TAG bench actors precede side ropes; entering/exiting actors cross above them. A separate support state machine handles entrance, rescue/protection, return and exit without replacing the two legal wrestlers. The defender updates first, irrespective of team index. A cooldown prevents unlimited immediate rescues. These are provisional native rules. Five-minute time-up, pause, throws and RUMBLE removal have regression coverage.

## Validation limits

Run the C tests in `tools` and `tools/verify_iso.py`; the included workflow builds the pinned Yaul image. No source compiler diagnostics remain; embedded linker RWX LOAD-segment warnings are retained. ASan/UBSan were used for the new tests; leak detection is unavailable in this host environment. Hardware behavior and FPS still require the user's test. Earlier validation JSON files describe their named historical releases, not Test13.
