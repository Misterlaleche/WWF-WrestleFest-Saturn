# Tests246-248 / V0.261-V0.263

## Test246 — sparse exact pose recovery

A conservative pixel-source audit was extended beyond byte-identical frame aliases. `program.bin` supplies the exact composition command stream; existing Cxx/Fxx banks supply only pixel payloads that can be tied back to sprite codes through uniquely identified exact frames. A mapping is accepted only when the overlay frame geometry identifies one unique `(partner, phase)` source.

This closes raw pose **267** for:

- Jake Roberts (character 2): 24 pieces
- Big Boss Man (character 3): 23 pieces
- Earthquake (character 8): 23 pieces

All three records are composition kind 1 (non-pair) and are inserted as character-specific resident frame 214. No sprite pixels are fabricated. The worst six-bank LWRAM footprint remains 923648 / 1048576 bytes.

## Test247 — fallback reduction

Exact closures are explicitly excluded from Test212 fallback accounting. Registered fallback now remains only for genuinely unresolved character/pose combinations. This prevents an exact asset from being silently treated as provisional legacy art if a caller bypasses the normal draw-path ordering.

## Test248 — complete gfx2 recovery path

`tools/recover_gfx2.py` accepts the user's original `wwfwfest.zip` or a directory containing the eight sprite ROMs. It verifies all CRC32 values and concatenates the exact plane-major order already used by `tools/extract_assets.py`:

`31j3.ic9, 31j2.ic8, 31j5.ic11, 31j4.ic10, 31j6.ic12, 31j7.ic13, 31j9.ic15, 31j8.ic14`.

Expected result: 0x800000 bytes, SHA256 `a3b5e1fedd6c41cd398ba0cb437cddb2f50b3ae0a0dc178a10b70a7ed5d010ba`. Once that user-supplied input is available, the existing builders can generate the still-missing PICK UP 395/206-210, Elbow 265-266/other variants, Knee 292-294, Fist 516-520 and object 114-123 compositions exactly.

**ROM-EXACT:** Test246 composition commands and pixels for the three recovered pose267 character mappings.

**PROVISIONAL:** none added by Tests246-248.

**REGISTERED BUT NOT IMPLEMENTED:** the remaining unique compositions listed above because their source tile pixels do not exist in any currently shipped exact Cxx/Fxx bank.
