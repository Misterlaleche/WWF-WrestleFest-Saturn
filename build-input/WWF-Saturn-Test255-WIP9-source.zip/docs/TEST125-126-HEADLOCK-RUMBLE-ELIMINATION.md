# Tests125-126 / V0.140-V0.141 — movable headlock and Royal Rumble body-slam elimination

## Test126 — headlock walking
A WrestleFest move guide documents that a wrestler in a headlock can be walked to the ropes (and, in TAG, to the partner corner). The native PAIR_HOLD composition can now move as one unit under human directional input. The exact original walk speed is not yet recovered, so the current one-pixel-per-tick rate is **PROVISIONAL**.

## Test126 — playable Rumble rope elimination
The same guide documents a Royal Rumble exploit/operation: carry a headlocked opponent to the ropes, turn and press an action button; wrestlers with Body Slam can send the opponent over the ropes, while Mr Perfect and Ted DiBiase cannot because their grapple repertoires lack Body Slam. The Saturn path now makes this playable with Punch from a rope-adjacent headlock for wrestlers whose recovered move set actually contains `AMOVE_BODY_SLAM`, reusing the existing tossed-over-rope trajectory.

The move availability is backed by the recovered wrestler move catalogue and the guide. The exact raw rope threshold/input callback/trajectory timing are not yet claimed ROM-exact.
