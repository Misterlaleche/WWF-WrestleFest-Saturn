# Tests127-130 / V0.142-V0.145 — difficulty DIP and AI probability audit

## Test127 — exact difficulty DIP packing
Program ROM `$1E1E-$1E6A` packs four operator input words into `$1C0066` and inverts the result. Difficulty comes from `$140022` bits 8-9 and becomes `$1C0066` bits 8-9 after inversion. The native helper now reproduces the complete packing transform.

## Test128 — direct consumer audit
The exact difficulty mask `$0300` is extracted once at `$107F8` and indexes the stamina adjustment table at `$1085C`. There are no direct `BTST #8/#9,$1C0066` consumers in program ROM. Therefore no separate difficulty-dependent CPU aggression/cadence is claimed. Adjacent `$0C00` consumers use bits 10-11 and are a different DIP field.

This is an important correction to the hardware-feedback plan: arcade Difficulty directly changes CPU stamina; behavior then changes through the common AI, wrestler-specific policy and stamina/state context. A Saturn-only 'Hard = faster AI' multiplier would not be arcade-backed.

## Test129 — weighted-choice kernel
Program ROM `$24CC` obtains an accepted random value below 100, normalizes zero to one, accumulates a byte weight table, and returns the first bucket whose cumulative weight reaches the roll. `arcade_ai_weighted_choice()` reproduces that selection stage exactly; the native random source itself is deliberately kept separate.

## Test130 — wrestler-specific distance gates
The state-0 AI branch around `$1F318` indexes two 12-wrestler two-way tables by character ID (`+$57 * 2`). The recovered first-bucket weights are:

- raw distance branch `$C8..$DF`: `8,14,5,7,16,10,3,12,7,8,10,12` percent-like weights;
- raw distance branch `>= $E0`: `20,30,15,20,35,25,10,25,12,18,25,22`.

The tables and weighted-selection semantics are exact. Their raw-distance-to-Saturn-coordinate transform and the semantic name of the selected state transition are not yet claimed exact, so these probabilities are not yet forced into the live Saturn movement code.
