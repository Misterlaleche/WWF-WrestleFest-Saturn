# WWF WrestleFest Saturn — bloque de combate V0.026

4 de septiembre de 2026 · Base exacta: Test15 V0.025 / COMBAT DEV V0.024.

## Alcance

Este checkpoint amplía el prototipo sin crear BIN/CUE/ISO. El objetivo del bloque es
convertir el exterior del ring, que en Test15 era esencialmente una ruta de movimiento
y reentrada, en un bucle básico de combate jugable sin inventar nuevos gráficos.

No se afirma paridad arcade de las reglas exteriores. Se reutilizan únicamente las
animaciones básicas ya verificadas de puño/patada y sus relojes de contacto.

## Implementado

- Puño y patada básicos entre dos luchadores situados en ringside.
- Resolución simultánea de impactos sin sesgo de P1, igual que el combate interior.
- Hit-stop compartido con el combate existente.
- CPU exterior: orientación, persecución en X/Y, selección básica puño/patada y contacto.
- Separación física de los dos cuerpos también fuera del ring.
- Empuje de impactos limitado a la región caminable de ringside; no se usa `floor_x`
  para un actor exterior y por tanto un golpe no puede colocarlo dentro del tapiz.
- Frontera lógica de cuerdas: `hit_eligible` exige que ambos actores estén en el mismo
  lado interior/exterior; no existen golpes a través de las cuerdas.
- Recuperación exterior conserva `rise_y` sin aplicarle el clamp vertical del ring.
- A 0 de energía fuera del ring se usa una recuperación válida en vez de dejar al actor
  tumbado indefinidamente esperando un pin que allí no puede iniciarse.
- Royal Rumble conserva la regla anterior: salir sigue eliminando inmediatamente al actor.
- Grabs, pins, running attacks, clothesline, big boot y finishers siguen restringidos al ring.

## Verificación

Se añade `tools/test_ringside_combat.c` y se incorpora a `tools/check_host.py`.

Casos dirigidos:

1. contacto de puño y patada con daño exacto una vez;
2. golpes simultáneos y hit-stop;
3. empuje contra el límite exterior derecho sin salir de la geometría legal;
4. recuperación a 0 de energía y retorno a `ST_IDLE` manteniendo `outside=true`;
5. persecución/ataque de CPU;
6. imposibilidad de golpear a un rival situado al otro lado de las cuerdas.

Además se ejecutan 20.000 ticks deterministas repartidos entre las diez identidades del
roster, alternando movimiento y ataques, comprobando en cada tick la geometría exterior.

Resultado: 17 suites host pasan. El bloque nuevo pasa también con AddressSanitizer y
UndefinedBehaviorSanitizer; las rutas restantes de la suite se comprobaron con los mismos
sanitizadores en lotes separados para evitar el límite temporal del runner.

## Archivos modificados

- `game.c`
- `main.c` (identificador de revisión V0.026)
- `Makefile` (IP_VERSION V0.026; no se ha construido disco)
- `tools/check_host.py`
- `tools/test_ringside_combat.c` (nuevo)
- `README.md`
- `docs/COVERAGE.md`
- `docs/COMBATE-V0026.md` (nuevo)

## Sigue pendiente

El siguiente bloque de mayor valor es reconstruir las transiciones arcade específicas:
contras/agarres adicionales, finishers y callbacks por personaje. Para el exterior aún
faltan las animaciones/reglas originales de agarre y acciones especiales, además de separar
las cuerdas traseras que Test15 conserva dentro del bitmap de escenario.
