# Tests138-144 / V0.153-V0.159 — WIP closure + raw stamina/AI gate

Evidence labels in this checkpoint are strict: **ROM-EXACT**, **PROVISIONAL**, or **REGISTERED BUT NOT IMPLEMENTED**.

## Tests138-140 — ROM-EXACT raw stamina route

- **Test138:** `$1E48C-$1E4D8` classifies actor stamina `+$66` into raw bucket `+$BD`: `>=128 -> 0`, `101..127 -> 1`, `80..100 -> 2`, `64..79 -> 3`, `37..63 -> 4`, `1..36 -> 5`, `0 -> 8`.
- **Test139:** `$1E45C-$1E464` compares raw actor `+$109` for equality with `+$BD`. The equality predicate is exact; no fatigue/aggression/cadence label is assigned to `+$109`.
- **Test140:** bounded ROM audit pins the explicit `+$109` read at `$1E45C`, the byte increment at `$2006C`, and the direct compare against 4/5 at `$21282/$2128A`. This proves producer/consumer flow without inventing the field's semantic name.

## Test141 — ROM-EXACT rise presentation

`ST_RISE` uses the recovered role-specific `$181FC/$181EC` descriptors for the first 26 ticks (13+13), then `$11E36` for the final 17 ticks. This matches the previously recovered 43-tick rise chain.

## Tests142-143 — PROVISIONAL post-match staging, visible ring

- **Test142:** resolved TAG/Royal winners and losers move into an initial post-match staging. Ownership comes from exact resolved match state; Saturn coordinates and movement rates are **PROVISIONAL** pending recovery of the arcade coordinate/timing routine.
- **Test143:** the old opaque centre result plate is removed from `FLOW_RESULT`; only a shallow top banner remains, leaving the ring centre and staged wrestlers visible. Exact arcade result typography/layout is **REGISTERED BUT NOT IMPLEMENTED**.
- Victory clap, dedicated winner pose, and exact defeated/sad pose remain **REGISTERED BUT NOT IMPLEMENTED**. No visually plausible descriptor has been relabelled as one of these without ROM control-flow evidence.

## Test144 — ROM-EXACT consequence of the stamina/raw-109 gate

The branch `$1E45C-$1E48A` is now reproduced as a raw helper. When `+$109 != +$BD`, it leaves the tested outputs unchanged. On equality it:

1. clears the low byte of raw actor state `+$20`;
2. tests actor `+$61`;
3. writes raw `+$60 = $004B` for `+$61 == $4A` or `$64`;
4. otherwise writes raw `+$60 = $0056`.

This is the first native helper in this WIP line that links the recovered stamina classifier to an exact CPU-state consequence. It is **not** yet called a tired-walk, fatigue cooldown, aggression reduction, or similar gameplay concept: the semantic meaning of raw `+$60/$61/$109` is still under audit.

## Validation closure

- Full host regression: **139/139 PASS**.
- Targeted ASan/UBSan for Tests138-144: **PASS**.
- SH-2/Yaul compile+link using the pinned Yaul toolchain lineage from Test100: **PASS**.
- Yaul ISO structural verification: **PASS** (Saturn header, USA area, V0.159/title, ISO9660, 35 CD files and exact `A.BIN`).
- MODE1/2352 BIN/CUE conversion: **PASS**; every sector regenerated/compared, payload round-trip exact, EDC/ECC writer verification PASS.
- Independent libcdio CUE read + bitwise EDC verification: **PASS**.
- Real NTSC-U Saturn + Terraonion MODE: **PENDING**. Test100/V0.115 remains the latest hardware-confirmed image until Test144 is physically tested.

## Signature / Super Throws tracking

The current source already carries native overlay/state-machine routes for the ten trademark moves in `finisher_data.h`/`finisher_assets.h`. That is **implemented source functionality**, but it is not a claim that every finisher is fully ROM-exact: each record keeps its recovered/candidate/provisional boundaries for entry conditions, callback resolution and damage.

The project requirement **All Super Throws / Signature Finisher Moves** is therefore **REGISTERED BUT NOT FULLY IMPLEMENTED/PROVEN** as a completeness target. Future tests must establish wrestler → trigger/condition → raw action/state → descriptor/composition → impact/effect from ROM evidence before upgrading any remaining route.
