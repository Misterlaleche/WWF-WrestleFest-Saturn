# Test249-251 full gfx2 recovery

Evidence labels:

- ROM-EXACT: source ROM CRCs, assembled gfx2 SHA256, program.bin composition commands, all Cxx/Gxy tile pixels and piece geometry generated in this block.
- PROVISIONAL: none added to the composition data itself.
- REGISTERED BUT NOT IMPLEMENTED: complete object/weapon bank-15 rendering for raw poses 114-123. Fighter-side state/timing remains implemented, but prop palette/art still needs its own renderer.

Test249 recovered the exact sprite region from the supplied original ROM set. Test250 expanded resident non-pair poses without guessed pixels. Test251 moved pair-dependent ground/PICK UP compositions into per-matchup Gxy packs so the renderer can preserve attacker/victim ordering exactly without duplicating the victim and without inflating Fxx finisher overlays beyond Saturn low-RAM limits.

Host validation:
- exact gfx2 size: 0x800000 bytes
- exact gfx2 SHA256: a3b5e1fedd6c41cd398ba0cb437cddb2f50b3ae0a0dc178a10b70a7ed5d010ba
- 90 Gxy packs
- 873 exact pair-dependent frames
- largest Gxy aligned allocation: 65536 bytes
- worst six Cxx aligned allocation: 937984 bytes
- combined worst case: 1003520 / 1048576 bytes
