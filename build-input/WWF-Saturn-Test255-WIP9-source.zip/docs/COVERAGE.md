# Cobertura — source checkpoint V0.027

| Área | Estado actual | Pendiente principal |
|---|---|---|
| Contras de agarre | Contra jugador a agarre CPU, swap de roles sin salto; una contra CPU provisional; lock anti ping-pong | Mapear ventanas/probabilidades exactas de callbacks arcade |
| Transiciones de agarre | Body slam, cancelación, throw-out e Irish Whip con carrera/rebote ROM | Resto de cuatro-move rotation, suplexes, submissions y transiciones específicas |
| Acciones específicas | Clothesline en 7 personajes; big boot Hogan/Earthquake | Más acciones por personaje con composiciones verificadas |
| Finishers | Diez identidades oficiales registradas, 0 expuestos falsamente | Integrar gráficos atacante/víctima/suelo + callbacks y condiciones arcade |
| Ringside | Movimiento, puño/patada, CPU, hit-stop, empuje legal, recuperación, reentrada | Agarres/especiales exteriores y oclusiones del bitmap |
| Attract/demo | Timeout de título inicia demo del motor actual | Reproducir guion/IA attract exactos del arcade |
| Capas | Plan común, seis actores, profundidad de parejas/árbitro/cuerdas separadas | Separar elementos aún embebidos en bitmap |
| Memoria | WFC2; peor combinación conocida de 6 bancos 915456/1048576 bytes | Recalcular al añadir finishers |
| Audio | Sin cambios | Música, voces y efectos |

V0.027 es un checkpoint de desarrollo, no una alpha equivalente al arcade.
20 suites host pasan; las 20 se han repetido con ASan/UBSan en dos lotes.
