# Test144 / V0.159 — Saturn hardware validation checklist

Target: Sega Saturn NTSC-U + Terraonion MODE.

## Build provenance

- Canonical source lineage: Test137/V0.152 + reconciled Tests138-143 + Test144.
- SH-2 compile/link: PASS with the pinned Yaul toolchain used by the project build route.
- Final image: single data track, MODE1/2352 BIN/CUE.
- Structural/sector verification and independent libcdio payload read: PASS.
- Hardware status before this test: **PENDING**. Test100/V0.115 is still the latest image confirmed on real hardware.

## What Test144 should validate visibly

1. Boot and reach normal title/mode flow without regression.
2. Normal combat, TAG and Royal remain playable relative to Test100.
3. Knockdown rise uses the recovered 13+13+17 descriptor chain without a visible regression.
4. At a completed TAG/Royal match, the ring remains visible during the result and the provisional winner/loser staging occurs instead of the old large centre plate.
5. Record any crash, sprite corruption, missing asset, CD read stall, palette issue or input regression with the mode, wrestler(s) and moment it occurs.

## Do not infer from this hardware test

- Test144 does **not** yet claim an arcade-semantic name for raw actor `+$109`, `+$60` or `+$61`.
- The post-match coordinates/speeds are still **PROVISIONAL**.
- Exact victory clap, exact defeated/sad pose and exact arcade result typography remain **REGISTERED BUT NOT IMPLEMENTED**.
- The existence of the ten current finisher routes does not mean **All Super Throws / Signature Finisher Moves** are fully ROM-exact; their per-record evidence labels remain authoritative.
