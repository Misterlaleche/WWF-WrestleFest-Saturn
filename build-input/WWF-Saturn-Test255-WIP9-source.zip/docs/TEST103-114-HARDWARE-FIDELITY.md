# Tests103-114 — Test100 hardware-fidelity block

This block is rebased on the canonical Test102/V0.117 line. Test101's ROM-backed Rumble active-recovery gate and Test102's standard Kick corner TAG are preserved.

- Test103: TAG HUD exposes active/reserve stamina for both teams; no forced grayscale reserve portrait.
- Test104: waiting partner receives a render-only outward correction; gameplay coordinates remain unchanged (PROVISIONAL visual transform).
- Test105: rope enter/exit no longer uses a static idle slide; verified common locomotion animation is used pending dedicated descriptor recovery (PROVISIONAL presentation mapping).
- Test106: TAG pre-match staging uses separate rear/front anchors and draw order based on hardware/reference imagery.
- Test107: TAG presentation becomes four individual 180-tick wrestler windows plus a 180-tick presenter exit, providing an explicit future audio timeline (timings PROVISIONAL until measured from arcade video/ROM).
- Test108: referee follows the active action instead of returning to a fixed centre point; exact trajectory remains PROVISIONAL.
- Test109: live pin count exposes visible 1/2/3 indication.
- Test110: CPU roster filling uses the full ten-wrestler pool instead of the former fixed sequential walk; entropy source is PROVISIONAL pending arcade RNG recovery.
- Test111: both select pages are preloaded and page switching no longer performs a CD read.
- Test112: the existing recovery-effort mechanic now exposes the rapid-button prompt after knockdown without overriding a pin escape prompt.
- Test113: local visual rope deflection is rendered during rebound; exact arcade deformation curve remains PROVISIONAL.
- Test114: Royal opening uses six separated depth anchors and exposes the green 1P player marker during live Rumble.

Validation: 110/110 host tests PASS split 55/55 + 55/55; Tests103-114 targeted ASan/UBSan PASS. `main.c`, `game.c`, `session.c`, and `hud.c` compile for SH-2 using the exported pinned Yaul toolchain. No BIN/CUE was generated.
