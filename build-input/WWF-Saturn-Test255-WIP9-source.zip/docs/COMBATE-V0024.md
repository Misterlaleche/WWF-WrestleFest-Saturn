# WWF WrestleFest Saturn — informe del bloque de combate

4 de septiembre de 2026 · COMBAT DEV V0.024 · Base: post-Test14 V0.023

## Resultado de este bloque

Se han integrado **dos acciones adicionales con sus secuencias gráficas
originales**: golpe de brazo en carrera y patadón frontal. Están conectadas al
control del jugador, a decisiones de la CPU y al sistema de contacto/derribo.
También se ha cambiado el almacenamiento de gráficos para que los seis bancos
de luchadores necesarios quepan en la RAM baja de Saturn estándar.

La entrega contiene fuentes, recursos, pruebas, una vista de las poses y este
informe. **No se han generado nuevas imágenes BIN/ISO/CUE ni se ha escrito en
GitHub.** El bloque anterior se conserva por separado.

No significa que estén terminadas todas las acciones del juego. Sigue siendo
un checkpoint de desarrollo, no una versión equivalente al arcade ni una
previa a alpha completa.

## 1. Acciones nuevas y cobertura real

| Luchador | Brazo en carrera | Patadón frontal | Composiciones añadidas |
|---|---|---|---:|
| Hulk Hogan | Sí | Sí | 8 |
| Ultimate Warrior | Sí | No | 6 |
| Jake Roberts | No | No | 0 |
| Big Bossman | No | No | 0 |
| Demolition Smash | Sí | No | 6 |
| Demolition Crush | Sí | No | 6 |
| Sgt. Slaughter | Sí | No | 6 |
| Mr. Perfect | Sí | No | 6 |
| Earthquake | Sí | Sí | 8 |
| Ted DiBiase | No | No | 0 |

Son **46 composiciones gráficas adicionales distribuidas entre personajes,
no 46 movimientos distintos**. Los luchadores que no disponen de estas
secuencias conservan las acciones anteriores: no se les asignan piezas de
otro luchador ni una animación vacía.

### Golpe de brazo en carrera

- Reproduce las seis poses 150–155 del descriptor ROM `0x12f08`.
- Sus duraciones son 7, 7, 7, 7, 5 y 13 ticks de animación: 46 en total.
- Se inicia desde carrera/frenada; mantiene desplazamiento y termina frenando.
- Tiene una ventana activa, comprueba dirección, distancia y profundidad,
  hace daño una sola vez y derriba al rival si conecta.
- Puede fallar por alcance/profundidad. Si alcanza las cuerdas pasa al rebote
  existente, sin salir del límite del ring.
- No puede reiniciarse durante su propio tiempo de espera entre ataques.

### Patadón frontal

- Reproduce las poses 180/181 del descriptor `0x15b24`, disponibles en Hogan
  y Earthquake, con 15 y 25 ticks respectivamente.
- La preparación no hace daño. El contacto se habilita al pasar a la segunda
  pose, puede fallar y solo descuenta stamina una vez.
- Derriba al rival y permite continuar con un pin mediante las reglas ya
  existentes. Puede ser interrumpido por un golpe antes de contactar.

### Controles de desarrollo

- Se mantiene A+B + izquierda/derecha para correr.
- Al soltar la combinación de carrera y pulsar de nuevo **A** mientras el
  luchador corre o frena, los siete compatibles ejecutan el brazo en carrera.
  Los demás mantienen el ataque en carrera anterior.
- **B** durante esa carrera/frenada mantiene la patada en carrera anterior.
- **A+B sin dirección**, estando de pie, inicia el patadón con Hogan o
  Earthquake. Requiere una pulsación nueva; mantenerlo no encadena ataques.
- A/B durante recuperación o pin mantiene su función anterior de esfuerzo.

Este reparto de controles es una adaptación de Saturn, no una afirmación de
que sean las mismas combinaciones del arcade.

### Qué utiliza ya la CPU

La CPU puede escoger el brazo en carrera en los luchadores compatibles y
alternarlo con el ataque anterior. También puede escoger el patadón con
Hogan/Earthquake, atendiendo a distancia y contador de ataques. Conserva la
prioridad de retirarse para relevar cuando corresponde.

**Límite importante:** las poses y sus duraciones proceden de la ROM, pero
daño, alcance, decisiones de IA y reglas de derribo siguen siendo nativos y
provisionales. Tras impactar se utiliza la recuperación nativa existente.
Quedan pendientes las redirecciones originales a composiciones enlazadas de
ambos luchadores, ciertos contraataques y otros callbacks. No se presenta
este bloque como una reproducción exacta de esos movimientos arcade.

## 2. Recursos y memoria

Los bancos pasan de 199 a 207 posiciones de frame. Las posiciones nuevas no
compatibles quedan vacías y protegidas por las comprobaciones de capacidad;
no se cuentan como animaciones implementadas.

Se han conservado las **1.990 composiciones anteriores** —199 × 10—,
comprobando posiciones, flips e identidad de sus texturas. Los colores de
los luchadores no se han sustituido por una paleta diagnóstica.

El nuevo formato WFC2 guarda texturas 4bpp en bloques independientes de 16
tiles comprimidos con LZ4. El código descomprime únicamente los bloques que
necesita en una caché de cuatro bloques —8 KiB de píxeles— y copia los tiles al
buffer de RAM alta que ya utiliza VDP1. No se introduce DMA directo desde RAM
baja. Se mantiene soporte de lectura del formato anterior.

| Comprobación de espacio | Resultado |
|---|---:|
| Peor combinación de seis bancos, alineados a sectores | 915.456 bytes |
| Capacidad de RAM baja prevista | 1.048.576 bytes |
| Margen restante para esos bancos | 133.120 bytes |
| Banco de luchador que necesite desbordar a RAM alta | Ninguno con estos recursos |
| Posiciones de frame por archivo | 207 |
| Tiles decodificados y verificados por el lector C | 13.574 |

Esto deja espacio para ampliar recursos, pero **no demuestra que el juego
vaya más rápido**. La descompresión tiene un coste de CPU que deberá medirse
en Saturn. La caché de texturas VDP1 y el límite de comandos no se han ampliado.

El lector comprueba cabeceras, índices de frames/piezas, tamaños y directorios
de bloques. Rechaza índices fuera de rango y datos truncados; una
descompresión fallida no se conserva como una entrada válida de caché.

## 3. Pruebas realizadas

| Prueba | Resultado |
|---|---|
| 14 suites de lógica/recursos en ordenador | Pasan |
| Las mismas 14 con AddressSanitizer y UndefinedBehaviorSanitizer | Pasan; LeakSanitizer desactivado |
| Simulación determinista | 50.000 ticks, diez composiciones de roster; 212 contactos y 1.491 muestras de estado de las nuevas acciones |
| Ventanas de contacto y duración | Verificadas para ambos ataques |
| Orientaciones, fallos, pausa y límites del ring | Verificados en los casos automatizados |
| Interrupción del patadón y continuación a pin | Verificadas |
| Selección de ataques por CPU | Verificada para las diez identidades |
| Bancos comprimidos | Lectura C de todos los tiles, hashes, acceso aleatorio, reutilización de caché y casos malformados |
| Compatibilidad gráfica anterior | 1.990 composiciones conservadas por comparación de sus datos |
| Compilación y enlace SH-2 con Yaul | Completados, solo objetivo ELF |

Las doce suites anteriores siguen pasando; las dos nuevas cubren acciones y
bancos de texturas. La simulación no equivale a una partida observada en
hardware ni a una prueba exhaustiva de toda la lógica del juego.

La imagen de poses adjunta se reconstruye con **el lector C real de los bancos
y la paleta que utiliza el port**. Se ha revisado visualmente. No es una captura
de Saturn, MiSTer ni Mednafen, ni una animación de combate completo.

El final estático del ejecutable está en `0x060684e4`. El enlazador conserva
cuatro advertencias de segmentos RWX, incluidas en el log. No hay una medición
nueva de FPS, picos de heap/pila o comportamiento del lector en Saturn.

**No se ha arrancado esta revisión en Saturn, MiSTer ni Mednafen.** Al no
generar disco, tampoco se ha realizado una nueva comprobación ISO.

Evidencia del checkpoint: `docs/combat-validation.json`, `combat-assets.json`,
`combat-preview.json`, `sh2-validation.json` y los logs de pruebas. Los informes
de versiones anteriores incluidos en las fuentes son históricos.

## 4. Qué se conserva, pero no es nuevo de este bloque

Continúan la recuperación activa A/B, los tiempos de levantarse, agarres y
slams de CPU, rescates/relevos TAG, selección con fondos resaltados, correcciones
de entrada, flujo provisional de continue/game over y el historial interno de
ocho resultados. No se cuentan otra vez como avances nuevos.

## 5. Qué queda pendiente

- Completar el resto de acciones específicas de cada luchador, finishers,
  agarres/lanzamientos, caídas, contraataques y reacciones enlazadas.
- Portar y contrastar los callbacks originales que deciden movimientos,
  daño, dificultad, automatizaciones y comportamiento de la CPU.
- Completar TAG Tournament y Royal Rumble: progresión, rivales, entradas,
  finales y reglas que todavía son parciales.
- Completar presentación, presentadora, transiciones y efectos del título.
- Acercar los estados y aspecto del HUD de stamina/participantes al arcade.
  **Este bloque no modifica visualmente esos indicadores.**
- Completar acciones exteriores, reglas asociadas y prioridades de cuerdas
  para cada movimiento que se incorpore.
- Sustituir las pantallas finales provisionales por sus secuencias arcade;
  añadir puntuación, Records, iniciales y persistencia.
- Medir rendimiento y validar esta nueva ruta de recursos en Saturn real
  cuando volvamos a preparar una imagen de prueba.
- Implementar música, voces y efectos. El audio sigue pendiente.

El avance concreto de esta entrega son **dos acciones, sus recursos realmente
integrados y una ampliación de la capacidad de almacenamiento en RAM**. El
catálogo completo de poses no se confunde con acciones ya jugables.
