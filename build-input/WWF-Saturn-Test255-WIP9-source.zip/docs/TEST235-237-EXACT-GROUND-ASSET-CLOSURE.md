# Tests235-237 — exact ground-asset closure from validated overlays

## Test235 — Earthquake STOMP resident atlas
The validated Test200 disc contains the exact `F08.PAK` generated from the user's original sprite ROM region. Its two frames correspond to Earthquake action `$23` descriptor `$15CE0`, poses `470` and `471`. These poses are non-pair compositions, so their complete frame records and texture payloads can be copied into the normal `C08.PAK` without opponent-dependent role ambiguity.

`Cxx.PAK` now exposes 214 frame slots. Only Earthquake fills new frames 212/213; the other nine packs contain empty slots at those indices. The worst six-pack aligned LWRAM use remains 923,648 / 1,048,576 bytes.

## Test236 — pixel/geometry identity
The new resident frames are checked record-by-record against `F08.PAK`: x/y/flip fields are identical and every referenced 128-byte 16x16 4bpp texture is byte-identical. No sprite pixels are drawn, interpolated or recoloured.

## Test237 — fallback removal scope
Earthquake STOMP now resolves raw pose 470 to resident frame 212 (and pose 471 to 213), so the Test212 fallback is no longer used for this move. Callback-held completion timing for the `$FF00` phase remains **PROVISIONAL**; only the visual compositions are claimed **ROM-EXACT**.

The overlay audit also found exact target-pose overlap for Warrior poses 263/264 and DiBiase pose 248, but those are partner-dependent compositions. They are deliberately not copied into a single generic resident frame because doing so would lose opponent-specific interleave/role ownership. PICK UP 395/206-210, the remaining elbow/knee/fist-drop poses and object 114-123 remain registered but unresolved.
