# Tests201–203 / V0.216–V0.218 — hardware combat fixes

These checkpoints are based on canonical Test200/V0.215 and respond to NTSC-U Saturn + Terraonion MODE observations.

## Test201 — rope-side deflection routing

**PROVISIONAL native rendering correction.** `game_rope_deflection()` now classifies both the rebounding fighter and every rope piece against the same trapezoid boundary (north/east/south/west). A lateral rebound can therefore deform only that lateral side and can no longer animate the south/front rope merely because a draw piece is nearby.

Host proof: `tools/test201_rope_side_mapping.c`.

## Test202 — CPU prone-pressure / effective damage

**PROVISIONAL native AI correction; ROM stamina evidence unchanged.** Hardware testing showed TAG/Royal CPU pressure was too punitive and repeatedly attacked a prone P1 instead of lifting him. A per-attacker prone-pressure counter now forces the CPU to try exact action `$22` PICK UP after one successful prone follow-up. The counter clears when PICK UP hands the victim to RISE or when the victim is no longer prone.

Native CPU-vs-P1 hit damage in TAG/Royal is also scaled at the native damage application layer (Normal 70%, Easy 55%, Hard 85%, Hardest 100%). This does **not** alter ROM-exact stamina maxima, stage/difficulty tables, action descriptors or callback evidence.

Host proof: `tools/test202_cpu_prone_pressure.c`.

## Test203 — player control during TAG rescue

**PROVISIONAL native TAG control integration.** When the CPU pins/submits P1 and the human reserve has entered the ring (`SUPPORT_RUN`), P1 directional/P/K input is routed to that reserve partner. P/K no longer simultaneously feeds the prone legal wrestler's mash/escape meter. The reserve can move, punch/kick the pinner, break the pin/hold, or engage the opponent reserve if that reserve has also entered.

Autonomous support movement is reduced from 3/4 px per tick to 2 px per tick to remove the hardware-observed robotic sprint while exact apron/intervention trajectories remain under ROM audit.

Host proof: `tools/test203_tag_rescue_control.c`.

## Animation closure status

The exact ROM descriptors are already live for the missing families, but the canonical packs still contain only 207 resident frames. The exact raw poses still absent from `roster_arcade_frame()` are:

- STOMP `$15CE0`: `470`
- ELBOW DROP `$1603A`: `263–267`
- KNEE DROP `$16116`: `248, 292–294`
- FIST DROP `$1623C`: `516–519`
- PICK UP `$15B6C`: `395, 206–210`
- RISE: `110–113, 104`

These are **ROM-EXACT pose IDs / descriptors**, but their pixel compositions cannot be appended faithfully from `program.bin` alone: the current canonical source snapshot does not contain the assembled sprite-ROM pixel region required by `tools/build_combat_assets.py`. No new guessed/fabricated compositions were added in Tests201–203.

## Validation

- Parallel equivalent of complete `tools/check_host.py` matrix: **195/195 PASS**.
- Targeted ASan/UBSan Test201–203: **3/3 PASS**.
- No Saturn BIN/CUE generated in this checkpoint; SH-2/Yaul build still requires the pinned external Yaul toolchain.
