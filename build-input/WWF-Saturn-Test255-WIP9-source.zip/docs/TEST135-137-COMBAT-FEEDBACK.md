# Tests135-137 / V0.150-V0.152 — hardware combat feedback

## Test135 — submission mash prompt
Player-victim PAIR_SUBMISSION now exposes the live rapid-button prompt. Fresh Punch/Kick edges contribute to the already existing submission escape counter; no input allows the existing drain-to-zero submission loss. Hold-specific exact drain/timing remains provisional where callbacks are not yet recovered.

## Test136 — visible arcade ground attacks
The native ST_GROUND_ATTACK renderer previously had no arcade pose mapping, explaining hardware reports of stamina loss with no visible CPU move. The four catalogued ground-drop actions are now rendered from their exact action descriptors: STOMP action $23 -> $15CE0; ELBOW DROP $24 -> $1603A; KNEE DROP $25 -> $16116; FIST DROP $26 -> $1623C.

## Test137 — CPU PICK UP
Arcade action $22 is PICK UP and maps to descriptor $15B6C. CPU ground policy can now choose PICK UP against a live prone opponent, play that descriptor and return the victim to the rise path instead of only repeatedly damaging/pinning. The native completion tick/state translation is provisional pending exact callback audit.

## Still open from hardware feedback
- fatigue/tired walk after sustained damage;
- stationary stunned/exhausted pose;
- prompt finger/star palette, missing frames, cadence and incomplete lower star points;
- exact per-hold submission drain/escape timing;
- exact CPU choice probabilities between ground strike, submission, pickup and pin.
