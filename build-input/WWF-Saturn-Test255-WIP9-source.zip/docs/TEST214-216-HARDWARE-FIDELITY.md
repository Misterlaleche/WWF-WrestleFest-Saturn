# Tests214-216 — prone PICK UP, presenter exit, HUD identity

## Test214 — human PICK UP access
**ROM-EXACT action selection for recovered category `$05`.** The arcade `$E4FE` action matrix contains only the two recovered physical action buttons. For wrestlers whose category `$05` both-button entry is raw action `$22`, pressing both physical action buttons now starts PICK UP through exact descriptor `$15B6C`. Wrestlers whose same entry is another still-unresolved raw action (for example Jake/Perfect/DiBiase -> `$09`) are not falsely promoted to PICK UP. The Saturn `INPUT_GRAB` convenience alias remains available for the existing ground-submission path.

## Test215 — presenter exit direction
**Hardware/arcade-reference correction.** TAG presenter exit now moves from Y=168 toward Y=88 (upper side of ring) instead of toward Y=248 (bottom/foreground). Exact per-frame arcade trajectory remains unproven; direction and endpoint are native corrections.

## Test216 — HUD portrait actor-order mapping
**ROM-EXACT identity mapping.** Portrait tiles and palettes now use the exact `$64CC` selection-slot -> internal actor-id mapping already validated by the stamina subsystem. This fixes the prior direct `character` indexing that assigned wrong portrait/palette blocks to most wrestlers, including Slaughter and Mr. Perfect. Jake/Boss Man now resolve through their correct internal IDs rather than selection-order assumptions.
