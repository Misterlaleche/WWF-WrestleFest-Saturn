# Tests204–206 / V0.219–V0.221 — finisher overlay + staged TAG/intervention

## Test204 — CHECK 338 same-frame overlay race

**PROVISIONAL/native integration fix, preserving ROM-exact finisher descriptors.**

Hardware feedback showed CHECK 338 after repeated ground pressure. The Saturn renderer requires the finisher overlay to be resident before drawing `ST_FINISHER` / `PAIR_FINISHER`. A CPU or context-sensitive finisher can become live *inside* `game_tick()`, after the pre-tick overlay probe has already run. The same video frame could therefore reach render with no matching overlay.

`main.c` now performs a post-`game_tick()` live-state check and loads the actual attacker's overlay before rendering that frame. CHECK 338 remains active for genuinely invalid overlay/frame mismatches; it is not suppressed.

## Test205 — staged manual/CPU TAG

**PROVISIONAL presentation/geometry; existing TAG input and roster ownership preserved.**

The previous native TAG used an instantaneous `swap_fighters()`. Hardware feedback confirmed the missing palmada/change animation. TAG now passes through:

1. approach to the team's corner;
2. visible hand-contact phase (currently uses the verified strike schedule as a temporary gesture — not claimed arcade-exact);
3. identity swap only after contact;
4. incoming wrestler crosses the ropes through `ST_RING_ENTER`;
5. outgoing wrestler becomes the reserve and the normal TAG cooldown starts only when entry is complete.

The original K-edge route remains the primary manual trigger and Saturn C/`INPUT_TAG` remains an alias. KO reserves remain blocked.

## Test206 — partner intervention strikes

**PROVISIONAL native support AI/control.**

TAG support partners no longer use movement-only interception. The intervention state machine accepts both `ST_PUNCH` and `ST_KICK`, and CPU support can select either strike while confronting the opposing reserve or breaking/protecting a pin. Test203 temporary human control of P1's rescue partner remains active.

Exact arcade apron entry/exit descriptors, TAG slap artwork/timing, double-team forms and support AI cadence remain REGISTERED BUT NOT IMPLEMENTED.
