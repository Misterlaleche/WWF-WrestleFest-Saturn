#ifndef WWF_LAYER_VIEW_H
#define WWF_LAYER_VIEW_H
#include "game.h"
enum { VIEW_ALL, VIEW_NO_ROPES, VIEW_ACTORS, VIEW_ENVIRONMENT, VIEW_COUNT };
static inline bool layer_view_actor(unsigned view){return view!=VIEW_ENVIRONMENT;}
static inline bool layer_view_ropes(unsigned view){return view==VIEW_ALL||view==VIEW_ENVIRONMENT;}
static inline bool layer_view_crowd(unsigned view){return view!=VIEW_ACTORS;}
static inline bool layer_view_object(unsigned view,unsigned object){
    if(object==DRAW_SIDE_ROPES||object==DRAW_FRONT_ROPES)return layer_view_ropes(view);
    if(object==DRAW_PROMPT)return view==VIEW_ALL;
    return layer_view_actor(view);
}
static inline const char *layer_view_name(unsigned view){
    const char *names[VIEW_COUNT]={"ALL LAYERS","NO FOREGROUND ROPES","ACTORS + FLOOR","ENVIRONMENT"};
    return names[view<VIEW_COUNT?view:VIEW_ALL];
}
#endif
