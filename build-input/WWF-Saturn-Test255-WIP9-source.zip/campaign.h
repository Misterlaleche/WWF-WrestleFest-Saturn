#ifndef WWF_CAMPAIGN_H
#define WWF_CAMPAIGN_H
#include <stdbool.h>
#include <stdint.h>

enum { CAMPAIGN_TAG, CAMPAIGN_RUMBLE };
typedef struct {
    unsigned mode;
    unsigned stage;              /* zero-based native progression index */
    unsigned championship_match; /* operator DIP: 4 or 5 */
    unsigned clear_stage_setting;/* operator DIP: 0..3 -> 24/32/12/0 */
    unsigned difficulty;
    unsigned wins;
    unsigned losses;
    bool championship;       /* player currently owns the tag title */
    bool complete;
    unsigned player_character[2];
    unsigned player_health[2];
    unsigned player_max[2];
    bool player_stamina_valid;
} campaign_t;

void campaign_reset(campaign_t *c,unsigned mode,unsigned championship_match,
                    unsigned clear_stage_setting,unsigned difficulty);
bool campaign_is_title_match(const campaign_t *c);
bool campaign_is_final_lod(const campaign_t *c);
bool campaign_is_lod_match(const campaign_t *c);
bool campaign_is_cage_match(const campaign_t *c);
/* Returns true when another match should start. A loss does not advance. */
bool campaign_finish_match(campaign_t *c,bool player_won);
unsigned campaign_stage(const campaign_t *c);
unsigned campaign_clear_stage_setting(const campaign_t *c);
/* Player-team stamina survives stage transitions in TAG.  $90D6 restores
 * only actors whose +$FE role word has low bit clear (human slots), not CPU. */
void campaign_set_players(campaign_t *c,unsigned first,unsigned second);
void campaign_capture_player_stamina(campaign_t *c,unsigned character,unsigned health);
void campaign_clear_stage_power_up(campaign_t *c);
unsigned campaign_player_stamina(const campaign_t *c,unsigned character);
/* Program ROM $1034A-$10466 opponent selector. Rolls are original $24CC
 * percentile inputs in the inclusive 1..100 range, exposed for deterministic
 * host tests. Logical characters 10/11 represent Hawk/Animal. */
void campaign_select_opponents(const campaign_t *c,unsigned roll_first,unsigned roll_second,unsigned out[2]);
#endif
