#ifndef WWF_ARCADE_BEHIND_PAIR_H
#define WWF_ARCADE_BEHIND_PAIR_H
#include <stdbool.h>
#include <stdint.h>

typedef struct {
    uint8_t action;
    uint32_t descriptor_address;
    uint32_t callback_address;
    uint8_t target_link_byte;
    uint16_t target_state20;
    uint8_t target_pose61;
    bool clears_target44;
    bool copies_attacker_facing;
    bool sets_pair_status33;
} arcade_behind_pair_profile_t;

/* Test77: exact entry signatures recovered from the action descriptors and
 * callbacks.  This describes only demonstrated raw writes; it does not invent
 * hold duration, damage, escape policy or double-team continuation. */
const arcade_behind_pair_profile_t *arcade_behind_pair_profile(unsigned action);
#endif
