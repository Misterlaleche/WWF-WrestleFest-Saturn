#include "arcade_behind_pair.h"

static const arcade_behind_pair_profile_t profiles[]={
    /* descriptor $15668 -> callback $1567C.  Acquisition path writes target
       +$60=$C0, +$20=5, +$61=$52, +$44=0 and copies attacker +$2E. */
    {0x1c,0x15668,0x1567c,0xc0,5,0x52,true,true,false},
    /* descriptor $1585C -> callback $15870.  Acquisition path writes target
       +$60=$80, sets bit6 of +$33 on both actors, +$20=5, +$61=$53,
       clears target +$44. */
    {0x1d,0x1585c,0x15870,0x80,5,0x53,true,false,true},
};
const arcade_behind_pair_profile_t *arcade_behind_pair_profile(unsigned action){
    for(unsigned i=0;i<sizeof(profiles)/sizeof(profiles[0]);++i)
        if(profiles[i].action==action)return &profiles[i];
    return 0;
}
