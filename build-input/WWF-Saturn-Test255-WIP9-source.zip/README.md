
## Test238 / V0.253

Partner-dependent ground-attack compositions now use the exact validated Fxx overlays where proven: Ultimate Warrior raw poses 263/264 and Ted DiBiase raw pose 248. Attacker/victim role interleave is preserved and unresolved poses remain guarded. A fresh NTSC-U BIN/CUE was generated and structurally validated; hardware boot is still pending.

## Test235-237 / V0.250-V0.252

- Earthquake STOMP poses 470/471 are now resident in C08.PAK using exact frame records and texture bytes recovered from the validated Test200 F08 overlay.
- The new frames are byte/geometry verified against F08; no fabricated art.
- Warrior 263/264 and DiBiase 248 were found in exact overlays too, but remain unmapped because their compositions are opponent-dependent and cannot safely be collapsed into one resident frame.
- Exact callback release timing for STOMP remains PROVISIONAL.
- See `docs/TEST235-237-EXACT-GROUND-ASSET-CLOSURE.md`.


## Test229-231 / V0.249

- PICK UP action `$22` now preserves the complete 98-tick ROM `$15B6C` six-pose visual schedule.
- Finite ground-action lengths are derived directly from recovered descriptors (Elbow 61, Knee 68).
- Callback-held STOMP/FIST completion remains explicitly provisional; no fake timing or sprite art is introduced.
- See `docs/TEST229-231-GROUND-ANIMATION-CLOSURE.md`.

# WWF WrestleFest Saturn — Test213 / V0.228 checkpoint

6 de septiembre de 2026. Continuación fuente desde Test209/V0.224. Tests210–213
cierran el intercambio TAG sin teleport (salida+entrada simultáneas por cuerdas),
eliminan el salto visual del reserve durante la transición, restauran el guard
acotado contra CHECK 324 para las familias ROM válidas aún sin atlas y preservan
los schedules visuales finitos de ELBOW DROP/KNEE DROP (61/68 ticks).
No se genera BIN/CUE en este checkpoint; la validación Saturn real queda pendiente.

5 de septiembre de 2026. Continuación reconciliada de la línea canónica
Test137 / V0.152 y del WIP Tests138-143. Port nativo Yaul/libyaul para Saturn
NTSC-U estándar. Test144 incluye una imagen BIN/CUE separada para validación
en Saturn real; Test100 / V0.115 sigue siendo la última imagen confirmada en
NTSC-U + Terraonion MODE hasta que Test144 se pruebe físicamente.

## Objetivo de V0.029

V0.028 demostró cuatro finishers auténticos, pero al incrustar sus variantes en
los diez bancos residentes `Cxx.PAK` el peor conjunto de seis luchadores rozaba
el 1 MiB de LWRAM. V0.029 cambia la arquitectura: los bancos normales vuelven a
207 frames y los movimientos especiales se almacenan en overlays `Fxx.PAK` que
se cargan bajo demanda.

## Arquitectura de overlays

- `C00.PAK` ... `C09.PAK`: locomoción, golpes, recuperación, agarres y acciones
  normales; 207 frames por banco, igual que antes de la expansión de finishers.
- `F00.PAK` ... `F09.PAK`: un overlay de finisher por luchador. Los movimientos
  de pareja contienen variantes por rival y preservan el intercalado original
  atacante/víctima de la composición arcade.
- Solo un `Fxx.PAK` necesita estar activo en la reserva temporal de LWRAM.
- El lector WFC2 acepta ahora bloques de 16 o 32 tiles: los bancos normales
  conservan su formato compacto anterior y los overlays nuevos usan 32.
- Al reutilizar la misma dirección de LWRAM para otro overlay se invalida la
  caché de bloques descomprimidos para evitar lecturas obsoletas.

### Memoria

Peor conjunto de seis bancos normales: **915.456 bytes**.
Overlay más grande: **90.979 bytes** (DDT de Jake Roberts; 92.160 bytes alineado
a sector). Peor combinación normal + overlay: **1.007.616 bytes / 1.048.576**.
Quedan aproximadamente 40 KiB dentro de la reserva de LWRAM, por lo que no se
requiere cartucho de 4 MB.

## Diez finishers convertidos al sistema de overlay

| Luchador | Movimiento | Descriptor / action | Contexto Saturn actual |
|---|---|---:|---|
| Hulk Hogan | Legdrop | 64 / 53 | Rival tumbado, aproximación diagonal |
| Ultimate Warrior | Gorilla Press | 58 / 47 | Grapple |
| Jake Roberts | DDT | 63 / 52 | Grapple |
| Big Boss Man | Boss Man Slam | 60 / 49 | Rival regresando del Irish Whip |
| Demolition Smash | Suplex | 51 / 40 | Grapple |
| Demolition Crush | Back-breaker | 141 / 137 | Grapple |
| Sgt. Slaughter | Cobra Clutch | 70 / 59 | Por detrás |
| Mr. Perfect | Perfect Plex | 38 / 26 | Grapple |
| Earthquake | Vertical Splash | 46 / 35 | Rival tumbado, aproximación diagonal |
| Ted DiBiase | Million Dollar Dream | 65 / 54 | Por detrás |

Los diez usan composiciones extraídas de las ROM del usuario y relojes de pose
derivados de los descriptores originales. El daño, la resolución de callbacks
`0xff00` y parte de las condiciones de entrada siguen siendo reimplementación
nativa Saturn y no se presentan como equivalencia exacta del 68000.

Earthquake action 35 se conserva con evidencia **candidato** hasta terminar de
reconstruir el callback que confirma la semántica completa del Vertical Splash.

### Variantes bloqueadas deliberadamente

- Un finisher de pareja contra el mismo personaje no se ejecuta todavía: cuando
  atacante y víctima comparten banco, la composición recuperada no basta para
  etiquetar de forma inequívoca la propiedad de cada pieza.
- Crush Back-breaker contra Smash carece de una fase completa utilizable en la
  familia recuperada; esa única pareja devuelve "gráficos no disponibles" en
  vez de sustituir el movimiento por arte inventado.

## Runtime

`game.c` dispone de `ST_FINISHER`/`PAIR_FINISHER`, reloj por fases, impacto único,
recuperación y pausa. Desde Test73, A+B ya no dispara un finisher en el frontend Saturn normal. Los
inputs sintéticos de finisher/pin quedan como hooks internos de diagnóstico
mientras la entrada física P/K se reconstruye desde las categorías de la ROM.

En Saturn, antes de consumir el input de finisher, `main.c` carga el `Fxx.PAK`
correspondiente en la zona temporal de LWRAM, verifica tamaño/hash y abre el
pack. El renderer obtiene las piezas del overlay y aplica la paleta del atacante
o de la víctima según los runs de roles generados desde la composición ROM.

## Combate ya heredado

Se mantienen contras de grapple, Irish Whip, carrera y rebote, clothesline,
big boot, pins, TAG/Rumble, ringside jugable y demo/attract nativa del motor.
El exterior del ring todavía no tiene todo el repertorio de agarres/finishers.

## Verificación de Test144

- Regresión host completa: **139/139 PASS**.
- ASan/UBSan focal para Tests138-144: **PASS**.
- Compilación y enlace SH-2 con el toolchain Yaul fijado por el proyecto: **PASS**.
- ISO intermedio: cabecera Saturn, área USA, V0.159/título, ISO9660 y los 35
  ficheros del CD verificados; `A.BIN` coincide con el ejecutable compilado.
- Conversión final BIN/CUE MODE1/2352: todos los sectores regenerados y
  comparados; lectura independiente con libcdio recupera el payload ISO exacto
  y valida EDC bit a bit.
- **Hardware real: PENDIENTE.** Una build correcta no sustituye la prueba en
  Saturn NTSC-U + Terraonion MODE.

## Estado de Signature / Super Throws

La fuente actual ya contiene las rutas de overlay y state machine de los diez
trademark moves de la plantilla Saturn principal. Su existencia no implica que
todos sean todavía arcade-exactos: daños, callbacks/condiciones de entrada y
algunas variantes conservan sus etiquetas de evidencia individuales;
Earthquake sigue marcado como candidato.

La meta **All Super Throws / Signature Finisher Moves** queda registrada como
trabajo de fidelidad: cerrar semántica/entrada/efecto exactos para cada luchador
y ampliar los luchadores/rutas que aún no tengan una composición validada. No
se añadirá ningún finisher por semejanza visual o memoria del arcade.


## Tests145-147 — Signature / Super Throws fidelity

- **Test145 / V0.160 — ROM-EXACTO:** los callbacks de Sgt. Slaughter Cobra Clutch (`$17ECE`) y Ted DiBiase Million Dollar Dream (`$179C0`) escriben exactamente `#$0005` en el operando de daño `+$68` inmediatamente antes de `JSR $111C8`. Se expone como **pulso de 5 puntos**; número de pulsos, escape y daño total siguen sin reclamarse.
- **Test146 / V0.161 — CORRECCIÓN DE FIDELIDAD:** Earthquake ya no puede ejecutar el antiguo candidato `action $23 / $15CE0`, porque Test136 demostró posteriormente que esa acción/dirección es **STOMP** exacto. El overlay histórico F08 permanece como evidencia archivada, pero `game_finisher_probe()` lo devuelve `UNMAPPED` y no se usa en gameplay.
- **Test147 / V0.162 — ROM-EXACTO (semántica aún candidata):** para Earthquake (selection 8), la tabla exacta de acciones de rival tumbado devuelve `raw action $47` en categoría `$07` + botón 1. `arcade_action_animations[$47]` conduce a descriptor `$14440`, callback `$14458`, primer pose 132. Aún no se etiqueta como Vertical Splash hasta cerrar callback/composición/asset.

Validación Test147: **142/142 host PASS**, ASan/UBSan focal PASS y SH-2/Yaul compile/link/ISO PASS. No se publica nueva BIN/CUE en este checkpoint.

## Siguiente prioridad

1. Probar Test144 BIN/CUE en Saturn real y registrar el resultado sin extrapolar.
2. Recuperar descriptores/estados exactos de victoria, derrota y palmada para
   TAG y Royal.
3. Continuar la ruta `+$66 -> +$BD / +$109 -> +$20,+$60` hasta asignar
   semántica jugable solo cuando la ROM lo demuestre.
4. Completar **All Super Throws / Signature Finisher Moves** con evidencia
   wrestler→condición→estado/action→descriptor→efecto.
5. Resolver roles same-character, variantes incompletas y el resto de
   prioridades TAG/Royal/ringside.
## Tests214-216 / V0.229-V0.231 — hardware-fidelity closure

- **Test214 / V0.229:** human prone PICK UP is now reachable from the recovered ROM action matrix. For wrestlers whose prone category `$05` + both physical action buttons resolves to raw action `$22`, the native runtime starts exact PICK UP descriptor `$15B6C`. Other unresolved raw results are not relabelled. Saturn `INPUT_GRAB` still preserves the existing ground-submission convenience path.
- **Test215 / V0.230:** TAG presenter exit is corrected toward the upper side of the ring (decreasing Saturn Y). The old native path incorrectly moved toward the foreground/bottom. Exact arcade per-frame trajectory remains pending.
- **Test216 / V0.231:** HUD portrait tile and palette selection now uses the exact ROM `$64CC` selection-slot -> internal actor mapping instead of direct character-select indexing. This addresses the wrong portrait/palette family seen on hardware, including Slaughter and Mr. Perfect and the Jake/Boss Man identity mismatch.

Targeted validation: Tests214-216 ASan/UBSan **PASS**; affected regressions for ground submissions, ground animation, ground pin/PICK UP input, CPU PICK UP, HUD, TAG announce timing and TAG HUD **PASS**. No BIN/CUE generated in this checkpoint.

Still **REGISTERED BUT NOT IMPLEMENTED** here: exact Hogan/Demolition between-match campaign interstitial, arcade Records presentation/persistence, and exact presenter trajectory beyond the corrected exit direction.

## Tests217-219 / V0.232-V0.234 — tournament interstitial + Records
- **Test217 / V0.232:** adds an explicit TAG tournament-progress presentation state after a win, before the next match preload. The runtime count of completed/remaining matches is exact to the native ten-stage campaign; layout is PROVISIONAL.
- **Test218 / V0.233:** the progress scene now loads dedicated Hogan + Demolition Smash roster packs and animates them around a functional ten-match ladder. Character identity/count are functional; exact arcade pointing choreography/art/timing remain PROVISIONAL pending direct recovery.
- **Test219 / V0.234:** adds the first functional Records screen backed by the real in-RAM `match_history`. It is shown after campaign completion and is skippable with START/A. Ranking typography and persistence are PROVISIONAL; no claim of arcade-exact record semantics is made.


## Tests220-222 / V0.235-V0.237 — post-match + Royal cleanup
- **Test220:** explicit resolved TAG winner/defeated role classification.
- **Test221 / V0.236:** winners no longer freeze idle after centre staging; they reuse existing recovered presentation gestures as a clearly **PROVISIONAL** celebration. Exact clap identity remains unproven.
- **Test222 / V0.237:** removes the unrelated Royal logo plates and replaces the single-row six-wrestler presentation with a bounded 3x2 provisional layout.

## Tests223-225 / V0.238-V0.240 — functional attract-style loading
- **Test223 / V0.238:** the natural Technos -> title transition now enters a real staged boot-loading state. The loading surface is rendered for at least one complete frame before blocking CD work begins; `TITLE.ANM` is read and hash-validated while that screen remains visible, then reused directly by the title renderer.
- **Test224 / V0.239:** the long boot load now persistently preloads the two SELECT pages, MODE plate and ENTRY RLE instead of performing a decorative wait. The 512-byte SELECT/MODE palettes use 2048-byte sector-capacity buffers, preserving the hardware CHECK301 fix. MODE no longer discards the boot cache.
- **Test225 / V0.240:** match-specific loads now use a short staged loading surface before HALL/ANNOUNCE whenever the required wrestler packs are not resident. The panel uses authentic arcade HUD portrait pixels enlarged 3x plus an attract-style dialogue box; exact attract portrait animation, wording, timing and layout are explicitly **PROVISIONAL** until recovered from the arcade demo. Roster and subsequent ring reads are real CD work covered by the visible loading surface.

No BIN/CUE is generated for this source checkpoint. SH-2 compile/link validation is required; exact hardware appearance remains pending real Saturn test.

## Tests226-228 / V0.241-V0.243 — attract/help loading fidelity
- **Test226:** loading help wording is now byte-pinned to original program-ROM tutorial/attract strings. Their reuse in the Saturn loading panel is PROVISIONAL; the text itself is ROM-EXACT.
- **Test227:** real boot preload stages rotate authentic recovered arcade HUD portraits instead of a single static Hogan image. No facial animation is fabricated.
- **Test228:** invented loading slogans are removed. `NOW LOADING` remains a native Saturn status label, with mode-context original arcade help wording below/alongside it. Exact large attract/interview portrait frames remain registered pending source/capture recovery.


## Test240 / V0.255 — CHECK314 boot-loading heap fix

- Hardware Test238 exposed **CHECK314** immediately after the Technōs screen.
- CHECK314 is the failed `malloc()` for the resident `ENTRY.RLE` boot cache, not a corrupt CD read.
- Test223-224 had reserved worst-case 64/128 KiB buffers for four compressed front-end plates. On real Saturn this unnecessarily consumed 384 KiB although the files total only about 185 KiB.
- Test240 allocates sector-rounded capacities matching the actual CD files: SELECT0 47104, SELECT1 45056, MODE 45056, ENTRY 55296 bytes. Total persistent RLE heap drops to 192512 bytes.
- The Test164 sector-alignment rule remains intact: every `cd_read()` capacity is still a multiple of 2048 and the 512-byte palette staging buffers remain 2048 bytes.
- No gameplay, atlas or animation semantics changed.

**Hardware status:** fix requires retest on Saturn/MODE.

## Test245 / V0.260 — hardware feedback + stricter atlas guard
Tests241-245 add the pre-hold mash struggle, correct run-rope contact-side selection, serialize the shared Fxx overlay slot so finisher frames cannot be overwritten by a ground overlay, stage the presenter exit away from the front announce loop, and restrict Test212 fallback to the explicit unresolved pose registry. No BIN/CUE is produced for this checkpoint by request.
## Test246-248 / V0.261-V0.263 — sparse exact recovery + gfx2 importer

- **Test246:** raw pose **267** is recovered as resident **ROM-EXACT** art for Jake Roberts, Big Boss Man and Earthquake. The composition comes from `program.bin`; every referenced 16x16 pixel payload is resolved only from already-validated exact Cxx/Fxx banks, with no guessed pixels. All three use the same new character-specific frame slot 214; other characters keep that slot empty.
- **Test247:** Test212 fallback accounting is narrowed again. Exact resident/overlay closures are no longer reported as fallback coverage: Earthquake 470/471, Jake/Boss Man/Earthquake 267, Warrior 263/264 and DiBiase 248. Unresolved variants still fail through the explicit registered fallback only.
- **Test248:** `tools/recover_gfx2.py` is ready for the user-supplied `wwfwfest.zip`. It validates the eight gfx2 ROM CRCs, assembles the exact 8 MiB plane-major sprite region used by the asset builders, and pins SHA256 `a3b5e1fedd6c41cd398ba0cb437cddb2f50b3ae0a0dc178a10b70a7ed5d010ba` already recorded by the earlier validated build. This is the remaining input needed to close PICK UP, KNEE/FIST and object art that cannot be reconstructed from current banks.

No BIN/CUE is generated for this checkpoint, per hardware-test request.


## Test249-251 / V0.266 - full gfx2 recovery and exact ground overlays

- Test249: verified the user-provided original `wwfwfest.zip` graphics ROMs by CRC32 and assembled the exact 8 MiB `gfx2` sprite region (SHA256 `a3b5e1fedd6c41cd398ba0cb437cddb2f50b3ae0a0dc178a10b70a7ed5d010ba`). The ROM/gfx2 bytes are not included in this source checkpoint.
- Test250: rebuilt missing non-pair resident animation art from `program.bin` composition commands plus exact gfx2 pixels. This closes reachable RISE poses, PICK UP setup pose 395, and non-pair terminal elbow poses 266/267 where present.
- Test251: generated 90 bounded matchup overlay packs (`Gxy.PAK`) containing 873 exact partner-dependent PICK UP / ground-attack compositions. Runtime uses one small matchup pack at a time and keeps finisher overlays on the same temporary slot with explicit overlay-kind ownership, preventing the Test238/244 slot collision class.
- Worst six Cxx resident packs: 937984 bytes aligned. Largest Gxy overlay: 65536 bytes aligned. Combined worst case: 1003520 / 1048576 bytes low work RAM.
- Object poses 114-123 remain registered fallback: their complete arcade composition mixes wrestler pieces with bank-15 prop art/palette. They were deliberately not flattened into wrestler palette data.

## Test252 / V0.267 — ROM-exact bank-15 objects and Test212 fallback closure

- **ROM-EXACT:** recovered palette bank 15 from `program.bin` palette table (`0x2F22 + 15*0x20 = 0x3102`) and generated `OBJECT15.PAL` without using a wrestler palette.
- **ROM-EXACT:** generated one persistent `OBJ15.PAK` with all 100 complete object compositions for poses 114–123 (10 wrestlers), preserving original piece order and per-piece palette banks. The pack is 105279 bytes and does not consume the Fxx/Gxy low-RAM overlay slot.
- **ROM-EXACT:** the explicit Test212 fallback registry is now empty. Its GROUND/PICK UP entries were already covered by 873 exact Gxy compositions; its final object entries are now covered by OBJ15. Unknown unmapped poses fail closed through CHECK324.
- **PROVISIONAL Saturn infrastructure:** the object pack is held persistently in high work RAM. CDFS root capacity is raised from 64 to 160 because the source CD tree now contains 125 files.
- **REGISTRADO PERO NO IMPLEMENTADO:** no bank-15 graphics remain pending for 114–123; unrelated known items such as the presenter's back-facing sprite remain pending.
- Focused host and ASan/UBSan regressions pass. SH-2 compile was not run because a Yaul `sh2eb-elf-gcc` toolchain is not available in the current environment.
- No BIN/CUE/ISO was generated.


## Test253 / V0.268 — ROM-exact grapple struggle and ring-transition animation closure

- **ROM-EXACT:** linked grapple action `$29` uses descriptor `$1656A` / callback `$16582`, exact paired poses 245/246/247/466, exact finite clock 21/9/15/15 = 60 ticks, universal category-$08 P/K/P+K mapping, and the recovered first/second completion terminal state path. Ninety `Sxy.PAK` matchup packs preserve both wrestler banks without guessed pixels.
- **PROVISIONAL:** CPU synthetic action-edge cadence and simultaneous-edge arbitration during the struggle remain native until their producer/AI path is fully recovered. The old arbitrary six-point/90-tick mash rule is gone.
- **ROM-EXACT:** ring-out aggressor is raw action `$06`, descriptor `$13020`, poses 175(33) -> 176(25) -> 0(33), 91 ticks; all four recovered linked toss producers assign it.
- **ROM-EXACT:** victim thrown-flight state4 selector14 uses descriptor `$1B460`, poses 177/177/178/179. Ring exit raw `$69` uses poses 32..38 and clears the inside-ring flag; front entry raw `$6C` uses 39/40/41/42/43/42 and sets it. Outside fall/recovery follows raw `$68` then `$6A`.
- **ROM-EXACT:** bank-14 rope pieces and palette are reconstructed from `program.bin` + original `gfx2`; `RING14.PAK` contains the required per-character compositions. Ground tumble/roll recovery uses the recovered `$181FC/$181EC` 112/113 or 110/111 sequences (13+13 ticks) followed by pose 104.
- **PROVISIONAL:** Saturn world-coordinate interpolation through the ropes, tossed-flight parabola and callback-held release durations for poses 43/179/22 are not yet numerically reconstructed from the 68000 callbacks.
- Historical Test125/Test126 regressions were updated to traverse the new raw-$29 pre-hold struggle instead of assuming GRAB jumps directly to a hold. Runtime behavior was not weakened to satisfy them.
- Focused Test253 host and ASan/UBSan regressions pass. The full historical runner was also repaired for the HUD `arcade_stamina.c` link dependency; a complete end-to-end rerun remains expensive in this environment.
- No BIN/CUE/ISO is generated for this checkpoint.

## Test254 / V0.269 — canonical audio subsystem on the Test253 gameplay baseline

- **RECOVERED_ROM:** integrated the canonical recovered audio command/event layer,
  complete `0x20..0x81` SFX table/index/OKI decoder, `SDRV.BIN`, `AUDADP.PAK` and
  the 18 Z80-derived FM01..FM12 VGM masters without replacing any current
  gameplay/AI baseline file.
- **RECOVERED_ROM:** preserved stage music table
  `04,0A,0C,0F,06,04,0A,0C,0F,06`, low-stamina `<0x18 -> 0x0B` plus stage
  restore, final ring-out counts `17..20 -> 0x65..0x68`, and heavy/finisher
  reaction command `0x32`.
- **PROVISIONAL Saturn infrastructure:** the old audio snapshot's ~480 KiB
  persistent HWRAM copy of `AUDADP.PAK` is not used.  Exact currently-bound
  samples 18/69/70/71/72 are sector-read from the canonical pack at init,
  decoded exactly and retained in SCSP RAM; temporary HWRAM scratch is freed.
- **REGISTRADO PERO NO IMPLEMENTADO:** the remaining recovered SFX commands are
  retained as canonical command evidence but are not assigned invented gameplay
  producers.  CDDA track `.BIN` files remain unrendered until a disc image is
  explicitly requested.
- Package integrity is 596/596 SHA256 PASS; focused host and ASan/UBSan audio
  regressions pass.  SH-2/Yaul and audible Saturn/MODE validation remain pending.
- Audit of the audio ZIP found no newer hidden graphics/animation/AI runtime:
  `arcade_ai` and the animation data table match Test253 byte-for-byte, while
  differing gameplay/presentation sources are older.  Audio commands do provide
  useful exact timing anchors for finishers, ring-out count presentation,
  low-stamina behavior and stage transitions.
- See `docs/TEST254-V0269-CANONICAL-AUDIO-INTEGRATION.md`.
- No BIN/CUE/ISO generated.

### Test255 WIP — presentation audio producer closure
- ROM-EXACT `$AC56` script-command table is now represented and audited (`0x7B/0x7C/0x7D`).
- ROM-EXACT `$AC4A` character-command table is now represented and audited; Smash/Crush/Hawk/Animal share raw command `0x73`.
- Semantic assignment of these commands to the two Demolition speaker interstitials remains intentionally unclaimed pending state-0/state-1 producer closure.

### Test255 WIP5 — exact state-entry interstitial scripts
- `$AE20` mode 1/2 calls are now tied to attract-state entry 1/2.
- Exact scripts `$B1E2` (62 phases / 707 ticks / voice `$316A`) and `$B25E` (30 phases / 431 ticks / voice `$316B`) are recovered and ROM-audited.
- Speaker identity remains deliberately unassigned until object-type `$2C` graphics are decoded; no guessed Smash/Crush mapping is used.
