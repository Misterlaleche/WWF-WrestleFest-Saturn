#ifndef WWF_INTRO_H
#define WWF_INTRO_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
enum { INTRO_WARNING, INTRO_LEGAL, INTRO_TECHNOS, INTRO_TITLE, INTRO_GAME };
enum { INTRO_PLATE_TICKS=210,INTRO_TITLE_TICKS=1200 };
typedef struct { unsigned screen, blink, elapsed; bool start_down,demo; } intro_t;
void intro_reset(intro_t *intro);
/* Receives current button state, not auto-repeat. Returns true on page change. */
bool intro_tick(intro_t *intro, bool start_down);
bool intro_prompt_visible(const intro_t *intro);
/* Bounded byte RLE; succeeds only if both streams are consumed exactly. */
bool intro_unpack(const uint8_t *src, size_t size, uint8_t *dst, size_t capacity);
#endif
